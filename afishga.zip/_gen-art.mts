// Разовая генерация иллюстраций в стиле сайта (Gemini). Запуск: GEMINI_API_KEY=… npx tsx _gen-art.mts <id,id,…>
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { GoogleGenAI } from "@google/genai";

const OUT = process.env.ART_OUT!;
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

const STYLE = `Style: warm retro mid-century travel-poster illustration, exactly like the two reference images — sandy beige paper background (#E8D5AE, #F3E3C3), terracotta / rust / brick-red accents (#B84A32, #C8643C), muted ochre and soft brown, hand-drawn dark-brown outlines, flat shading with subtle paper grain, gentle nostalgic mood, simple clean composition with lots of air. Absolutely NO text, letters, numbers, logos or watermarks anywhere.`;

type Job = { id: string; aspect: string; prompt: string };
export const JOBS: Job[] = JSON.parse(readFileSync(process.env.ART_JOBS!, "utf8"));

const refs = ["public/brand/hero.webp", "public/brand/skyline.webp"].map((p) => ({ inlineData: { mimeType: "image/webp", data: readFileSync(p).toString("base64") } }));
const wanted = new Set((process.argv[2] ?? "").split(",").filter(Boolean));

for (const job of JOBS.filter((j) => wanted.size === 0 || wanted.has(j.id))) {
  const file = `${OUT}/${job.id}.png`;
  if (existsSync(file) && !process.env.FORCE) { console.log("skip", job.id); continue; }
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await ai.models.generateContent({
        model: "gemini-3.1-flash-image",
        contents: [{ role: "user", parts: [...refs, { text: `${job.prompt}\n\n${STYLE}\nAspect ratio ${job.aspect}.` }] }],
        config: { responseModalities: ["IMAGE"], imageConfig: { aspectRatio: job.aspect } },
      });
      if (!res.data) throw new Error("no image");
      writeFileSync(file, Buffer.from(res.data, "base64"));
      console.log("ok", job.id);
      break;
    } catch (e) {
      console.log("fail", job.id, attempt, (e as Error).message.slice(0, 160));
    }
  }
}
