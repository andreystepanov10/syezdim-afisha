// Ежедневный автоимпорт событий из всех источников по всем городам: npm run import
//
// Готовое к показу (есть картинка и ссылка на билеты) публикуется сразу, остальное — черновиками в админку.
// На сервере запускается по cron (см. deploy/crontab.txt). Запускать из корня проекта: картинки сохраняются
// в public/uploads, их раздаёт nginx.
import { runImport } from "../src/lib/import/run";
import { geocodeVenue } from "../src/lib/import/venues";
import { CITIES } from "../src/lib/cities";
import { listPublishedEventSlugs } from "../src/data/events";
import { isIndexNowConfigured, submitToIndexNow } from "../src/lib/indexnow";
import { DATE_LANDINGS } from "../src/lib/landings";

try {
  process.loadEnvFile(".env.local");
} catch {
  // .env.local необязателен
}

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL не задан — импорт пишет только в настоящую базу.");
  process.exit(1);
}

const startedAt = Date.now();
let failed = false;

for (const city of CITIES) {
  try {
    const reports = await runImport(city.slug, { publish: true, geocode: geocodeVenue });
    for (const r of reports) {
      const missing = r.skippedNoVenue.length ? `, нет площадки: ${r.skippedNoVenue.length} (${r.skippedNoVenue.slice(0, 5).join("; ")})` : "";
      console.log(`[${city.name}] ${r.source}: новых ${r.imported}, дополнено ${r.updated}, уже было ${r.skippedDuplicate}, ошибок ${r.errors}${missing}`);
      if (r.errors > 0) failed = true;
    }
  } catch (error) {
    failed = true;
    console.error(`[${city.name}] импорт упал:`, error instanceof Error ? error.message : error);
  }
}

// Сообщаем Яндексу о свежих страницах (IndexNow): события, добавленные или изменённые за последние сутки,
// и страницы городов, где они появились. --all — разово отправить все будущие события (первое подключение)
if (isIndexNowConfigured()) {
  try {
    const since = process.argv.includes("--all") ? new Date(0) : new Date(startedAt - 26 * 60 * 60 * 1000);
    const fresh = (await listPublishedEventSlugs()).filter((e) => e.updatedAt >= since).map((e) => `/events/${e.slug}`);
    // Страницы «сегодня / завтра / на выходных» меняются каждый день — отправляем всегда
    const cityPages = ["/", ...CITIES.flatMap((c) => [`/${c.slug}/events`, ...DATE_LANDINGS.map((d) => `/${c.slug}/${d.slug}`)])];
    console.log(`IndexNow: отправлено адресов ${await submitToIndexNow([...cityPages, ...fresh])}`);
  } catch (error) {
    console.error("IndexNow не принял адреса:", error instanceof Error ? error.message : error);
  }
}

console.log(`Готово за ${Math.round((Date.now() - startedAt) / 1000)} с`);
// Пул подключений к Postgres держит процесс живым — выходим явно
process.exit(failed ? 1 : 0);
