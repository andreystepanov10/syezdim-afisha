// Автопроверка интерфейса: переполнение по ширине на 5 размерах, поведение (город, избранное, модальное окно,
// тосты, вкладки, подсказки, формы, клавиатура), главная (hero, поиск, карта, карусель), данные (API, поиск, пагинация, 404),
// каталог (адреса с городом, панель фильтров, сортировка, чипы, мобильная шторка) и доступность (axe, WCAG 2.1 A/AA).
// Запуск: сервер на :3100 (npm run build && npm run start -- -p 3100), затем npm run check:ui
import { chromium } from "playwright-core";
import AxeBuilder from "@axe-core/playwright";

const browser = await chromium.launch({ executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe" });
// В продакшн-сборке Next заранее подгружает (prefetch) страницы по ссылкам и часть таких запросов отменяет на середине.
// Playwright не получает для них ни «завершён», ни «отменён», и waitUntil: "networkidle" может не наступить никогда —
// хотя сервер отвечает за миллисекунды и навигация мгновенная. Поэтому «networkidle» здесь означает: страница загружена
// (load) и в сети тихо, но не дольше 2,5 с. Кеш браузера тоже отключаем (route), чтобы прогоны не зависели от прошлых заходов.
const settle = (page) => page.waitForLoadState("networkidle", { timeout: 2500 }).catch(() => {});
function patchNavigation(page) {
  for (const method of ["goto", "reload", "goBack"]) {
    const original = page[method].bind(page);
    page[method] = async (...args) => {
      const options = typeof args.at(-1) === "object" ? args.at(-1) : undefined;
      if (options?.waitUntil !== "networkidle") return original(...args);
      const result = await original(...args.slice(0, -1), { ...options, waitUntil: "load" });
      await settle(page);
      return result;
    };
  }
  return page;
}
const b = {
  async newContext(options) {
    const ctx = await browser.newContext(options);
    await ctx.route("**/*", (route) => route.continue());
    const newPage = ctx.newPage.bind(ctx);
    ctx.newPage = async () => patchNavigation(await newPage());
    return ctx;
  },
  async newPage(options) {
    return (await this.newContext(options)).newPage();
  },
  close: () => browser.close(),
};
const results = [];
const check = (name, ok, extra = "") => { results.push(ok); console.log((ok ? "PASS " : "FAIL ") + name + (extra ? "  " + extra : "")); };
const BASE = "http://localhost:3100";

// ---------- 1. Переполнение по ширине ----------
for (const w of [320, 375, 768, 1024, 1440]) {
  const p = await b.newPage({ viewport: { width: w, height: 812 } });
  for (const r of ["/", "/ui-kit", "/events", "/voronezh/events", "/nonexistent"]) {
    await p.goto(BASE + r, { waitUntil: "networkidle" });
    const o = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    check(`нет горизонтальной прокрутки ${w}px ${r}`, o <= 0, o > 0 ? `+${o}px` : "");
  }
  await p.close();
}

// ---------- 2. Поведение (десктоп) ----------
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
const p = await ctx.newPage();
const errors = [];
p.on("pageerror", (e) => errors.push(String(e)));
p.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
await p.goto(BASE + "/ui-kit", { waitUntil: "networkidle" });

// Skip-link первым по Tab
await p.keyboard.press("Tab");
await p.waitForTimeout(400);
const skip = await p.evaluate(() => { const a = document.activeElement; return { text: a?.textContent, top: a?.getBoundingClientRect().top }; });
check("Tab: первым фокус получает «Перейти к содержимому» и он виден", skip.text?.includes("Перейти") && skip.top >= 0, JSON.stringify(skip));

// Город: выбор + cookie + сохранение после перезагрузки
await p.selectOption("header select", "kursk");
const cookie = (await ctx.cookies()).find((c) => c.name === "radius_city");
check("Город: выбор пишет cookie radius_city=kursk", cookie?.value === "kursk");
await p.reload({ waitUntil: "networkidle" });
check("Город: после перезагрузки остаётся «Курск»", (await p.inputValue("header select")) === "kursk");

// Избранное
const fav = p.locator("article button[aria-pressed]").first();
await fav.scrollIntoViewIfNeeded();
await fav.click();
check("Избранное: aria-pressed=true после клика", (await fav.getAttribute("aria-pressed")) === "true");

// Модальное окно
await p.getByRole("button", { name: "Открыть окно" }).scrollIntoViewIfNeeded();
await p.getByRole("button", { name: "Открыть окно" }).click();
await p.waitForTimeout(300);
const open1 = await p.evaluate(() => { const d = document.querySelector("dialog"); return { open: d?.open, focusInside: d?.contains(document.activeElement) }; });
check("Модальное окно: открылось, фокус внутри", open1.open && open1.focusInside, JSON.stringify(open1));
await p.keyboard.press("Escape");
await p.waitForTimeout(200);
check("Модальное окно: Esc закрывает", (await p.evaluate(() => document.querySelector("dialog")?.open)) === false);

// Тосты
await p.getByRole("button", { name: "Успех" }).click();
check("Toast: появился в live-области", await p.getByRole("status").filter({ hasText: "Добавлено в избранное" }).isVisible());
await p.getByRole("button", { name: "Закрыть уведомление" }).click();
await p.waitForTimeout(200);
check("Toast: закрывается крестиком", (await p.getByRole("status").filter({ hasText: "Добавлено в избранное" }).count()) === 0);

// Вкладки с клавиатуры
const tab1 = p.getByRole("tab", { name: "О событии" });
await tab1.scrollIntoViewIfNeeded();
await tab1.focus();
await p.keyboard.press("ArrowRight");
check("Tabs: → переключает на «Место» и переносит фокус", (await p.getByRole("tab", { name: "Место" }).getAttribute("aria-selected")) === "true" && (await p.evaluate(() => document.activeElement?.textContent?.includes("Место"))));

// Подсказка
const tipTrigger = p.getByRole("button", { name: "В избранное" }).last();
await tipTrigger.scrollIntoViewIfNeeded();
await tipTrigger.hover();
await p.waitForTimeout(300);
check("Tooltip: показывается по наведению", (await p.getByRole("tooltip").first().evaluate((el) => getComputedStyle(el).opacity)) === "1");

// Рассылка: валидация
await p.locator("footer input[type=email]").fill("bad");
await p.getByRole("button", { name: "Подписаться" }).click();
check("Рассылка: неверный email → aria-invalid + текст ошибки", (await p.locator("footer input[type=email]").getAttribute("aria-invalid")) === "true" && (await p.getByText("Введите корректный email").first().isVisible()));

// Двойной ползунок: клавиатура двигает бегунок
const lo = p.getByRole("slider", { name: "Цена: от" });
await lo.scrollIntoViewIfNeeded();
const before = await lo.inputValue();
await lo.focus(); await p.keyboard.press("ArrowRight");
check("Ползунок цены: стрелка меняет значение", (await lo.inputValue()) !== before, `${before} → ${await lo.inputValue()}`);

check("В консоли нет ошибок", errors.length === 0, errors.join(" | ").slice(0, 200));
await ctx.close();

// ---------- 2b. Главная страница ----------
for (const w of [375, 768, 1440]) {
  const q = await b.newPage({ viewport: { width: w, height: 900 } });
  await q.goto(BASE + "/", { waitUntil: "networkidle" });
  const r = await q.locator('section[aria-labelledby="hero-title"] img').first().evaluate((i) => { const box = i.getBoundingClientRect(); return { ratio: box.width / box.height }; });
  check(`Hero ${w}px: картинка в родных пропорциях 1815×592 (не растянута и не обрезана)`, Math.abs(r.ratio - 1815 / 592) < 0.03, `ratio=${r.ratio.toFixed(3)}`);
  const want = w >= 1280 ? 8 : 6;
  const visible = await q.locator("section:has(#popular-title) article").evaluateAll((els) => els.filter((e) => e.offsetParent !== null).length);
  check(`Популярные события ${w}px: показано ${want} карточек`, visible === want, `видно ${visible}`);
  await q.close();
}

{
  // поиск: форма собирает чистый адрес
  const c = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const h = await c.newPage();
  await h.goto(BASE + "/", { waitUntil: "networkidle" });
  await h.getByPlaceholder("Что ищем?").fill("джаз");
  await h.getByLabel("Когда?").selectOption("weekend");
  await h.getByLabel("Категория").selectOption("concerts");
  await h.getByRole("button", { name: "Найти" }).click();
  await h.waitForURL(/\/events\?/);
  const u = new URL(h.url());
  check("Поиск: переход на /<город>/events с параметрами q, when, category (город — в пути, не в параметрах)", u.pathname === "/voronezh/events" && u.searchParams.get("q") === "джаз" && u.searchParams.get("when") === "weekend" && u.searchParams.get("category") === "concerts" && !u.searchParams.has("city"), u.pathname + u.search);
  await h.goBack({ waitUntil: "networkidle" });
  await h.getByLabel("Когда?").selectOption("date");
  const dateVisible = await h.getByLabel("Дата события").isVisible();
  await h.getByLabel("Дата события").fill("2026-10-20");
  await h.getByRole("button", { name: "Найти" }).click();
  await h.waitForURL(/\/events\?/);
  const u2 = new URL(h.url());
  check("Поиск: «Выбрать дату…» показывает поле даты и передаёт date", dateVisible && u2.pathname === "/voronezh/events" && u2.searchParams.get("date") === "2026-10-20" && !u2.searchParams.has("when"), u2.pathname + u2.search);
  await c.close();
}

{
  // город: шапка, панель поиска и блоки синхронны
  const c = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const h = await c.newPage();
  await h.goto(BASE + "/", { waitUntil: "networkidle" });
  await h.selectOption("header select", "kursk");
  check("Город: заголовок блока — «Популярные события в Курске»", await h.getByRole("heading", { name: "Популярные события в Курске" }).isVisible());
  check("Город: панель поиска показывает тот же город", (await h.locator("form[role=search] select[name=city]").inputValue()) === "kursk");
  const href = await h.locator("section:has(#popular-title) article h3 a").first().getAttribute("href");
  check("Город: карточки — курские", href?.startsWith("/events/kursk-"), href ?? "");
  await c.close();
}

{
  // карта: ленивая загрузка, кластеры по городам, попап, карусель, подборки
  const c = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const h = await c.newPage();
  const herr = [];
  h.on("pageerror", (e) => herr.push(String(e)));
  h.on("console", (m) => { if (m.type() === "error") herr.push(m.text()); });
  await h.goto(BASE + "/", { waitUntil: "networkidle" });
  check("Карта: не грузится, пока блок далеко от экрана", (await h.locator(".leaflet-container").count()) === 0);
  await h.locator("#map-title").scrollIntoViewIfNeeded();
  await h.waitForSelector(".radius-cluster", { timeout: 20000 });
  const total = await h.locator(".radius-cluster").evaluateAll((els) => ({ n: els.length, sum: els.reduce((s, e) => s + Number((e.textContent ?? "").replace(/\D/g, "")), 0) }));
  check("Карта: 6 кластеров (по городам), в них все 84 события", total.n === 6 && total.sum === 84, JSON.stringify(total));
  await h.locator(".radius-cluster").first().click();
  await h.waitForTimeout(1500);
  const pins = await h.locator(".radius-pin").count();
  check("Карта: клик по кластеру приближает и показывает метки площадок", pins >= 2, `меток: ${pins}`);
  await h.locator(".radius-pin").first().click();
  await h.waitForSelector(".leaflet-popup a[href^='/events/']", { timeout: 5000 });
  check("Карта: попап площадки со ссылками на события", (await h.locator(".leaflet-popup a[href^='/events/']").count()) >= 1);

  const cards = h.locator("section:has(#collections-title) a[href^='/collections/']");
  check("Подборки: 3 плитки со ссылками на /collections/…", (await cards.count()) === 3);

  const list = h.locator('[aria-roledescription="карусель"] ul');
  await list.scrollIntoViewIfNeeded();
  const before = await list.evaluate((el) => el.scrollLeft);
  await h.getByRole("button", { name: "Вперёд" }).click();
  await h.waitForTimeout(900);
  check("Карусель выставок: «Вперёд» прокручивает ленту", (await list.evaluate((el) => el.scrollLeft)) > before);
  check("Главная: в консоли нет ошибок", herr.length === 0, herr.join(" | ").slice(0, 200));
  await c.close();
}

// ---------- 2c. Данные: API, поиск, пагинация, 404 ----------
{
  const api = async (qs) => { const r = await fetch(BASE + "/api/events" + qs); return { status: r.status, body: await r.json() }; };
  const base = (await api("?pageSize=1")).body.total;
  check("БД: в афише демо-события (84)", base === 84, `total=${base}`);

  const a1 = await api("?city=kursk&category=concerts&pageSize=48");
  check("API: город + категория — только курские концерты", a1.status === 200 && a1.body.total > 0 && a1.body.items.every((e) => e.city === "kursk" && e.category === "concerts"), `total=${a1.body.total}`);
  const a2 = await api("?q=" + encodeURIComponent("джаз") + "&pageSize=48");
  check("API: поиск «джаз» находит только джазовые события", a2.body.total > 0 && a2.body.items.every((e) => /джаз/i.test(e.title)), `total=${a2.body.total}`);
  const a3 = await api("?city=moscow&pageSize=100");
  check("API: некорректные параметры → 400 со списком проблем", a3.status === 400 && a3.body.issues.length === 2, JSON.stringify(a3.body.issues?.length));
  const p1 = await api("?page=1&pageSize=10"), p2r = await api("?page=2&pageSize=10");
  check("API: пагинация — страницы не пересекаются, pageCount верный", p2r.body.items.every((e) => !p1.body.items.some((x) => x.slug === e.slug)) && p1.body.pageCount === Math.ceil(base / 10) && p1.body.total === p2r.body.total);
  const byPrice = (await api("?sort=price&pageSize=48")).body.items.map((e) => e.priceFrom ?? Infinity);
  check("API: сортировка по цене", byPrice.every((v, i) => i === 0 || byPrice[i - 1] <= v));
  const evil = await api("?q=" + encodeURIComponent("'; DROP TABLE events; --"));
  check("API: SQL-инъекция в q безвредна, данные на месте", evil.status === 200 && (await api("?pageSize=1")).body.total === base);
  check("API: /events/<slug>: существующее — 200, несуществующее — 404", (await fetch(BASE + "/events/kursk-revizor")).status === 200 && (await fetch(BASE + "/events/net-takogo")).status === 404);

  const c = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const s = await c.newPage();
  await s.goto(BASE + "/", { waitUntil: "networkidle" });
  await s.getByPlaceholder("Что ищем?").fill("ревизор");
  await s.getByRole("button", { name: "Найти" }).click();
  await s.waitForURL(/\/events\?/);
  const titles = await s.locator("article h3").allInnerTexts();
  check("Поиск с главной: «ревизор» → только спектакль «Ревизор»", titles.length >= 1 && titles.every((t) => /ревизор/i.test(t)), `${titles.length} карт.`);
  check("Выдача: заголовок и счётчик", (await s.getByRole("heading", { level: 1 }).innerText()).includes("ревизор") && (await s.getByText(/Найдено \d+/).isVisible()));
  await s.getByRole("link", { name: /«ревизор»/ }).click();
  await s.waitForURL((u) => !u.search.includes("q="));
  check("Выдача: чип фильтра снимает поиск", !s.url().includes("q="), s.url().replace(BASE, ""));

  await s.goto(BASE + "/events", { waitUntil: "networkidle" });
  const first = await s.locator("article h3 a").first().getAttribute("href");
  check("Выдача: 12 карточек на странице, пагинация на 7 страниц", (await s.locator("article").count()) === 12 && (await s.getByRole("link", { name: /^Страница \d+$/ }).count()) === 7);
  await s.getByRole("link", { name: "Следующая страница" }).click();
  await s.waitForURL(/page=2/);
  check("Выдача: «Следующая страница» → page=2 и другие события", (await s.locator("article h3 a").first().getAttribute("href")) !== first);

  await s.goto(BASE + "/events?q=zzzzzz", { waitUntil: "networkidle" });
  check("Выдача: пустой результат — «Ничего не нашлось» и сброс", await s.getByRole("heading", { name: "Ничего не нашлось" }).isVisible() && await s.getByRole("link", { name: "Сбросить фильтры" }).isVisible());
  await c.close();
}

// ---------- 2d. Каталог: адреса с городом, панель фильтров, сортировка, чипы, мобильная шторка ----------
{
  const page = async (path) => (await fetch(BASE + path)).text();
  const robots = (html) => /<meta name="robots" content="([^"]*)"/.exec(html)?.[1] ?? "";
  const title = (html) => /<title>([^<]*)<\/title>/.exec(html)?.[1] ?? "";
  const api = async (qs) => (await fetch(BASE + "/api/events" + qs)).json();
  const priceOf = (t) => (/Бесплатно/.test(t) ? 0 : Number(t.replace(/\D/g, "")));

  // Адреса и SEO (без браузера)
  const legacy = await fetch(BASE + "/events?city=kursk&category=concerts&page=2", { redirect: "manual" });
  const loc = legacy.headers.get("location") ?? "";
  check("Каталог: /events?city=… → постоянный редирект на /<город>/events с остальными параметрами", legacy.status === 308 && loc.endsWith("/kursk/events?category=concerts&page=2"), `${legacy.status} ${loc}`);
  check("Каталог: неизвестный город — 404, известный — 200", (await fetch(BASE + "/moscow/events")).status === 404 && (await fetch(BASE + "/kursk/events")).status === 200);
  const kursk = await page("/kursk/events");
  const rPlain = robots(kursk), rFilter = robots(await page("/kursk/events?category=concerts")), rPage2 = robots(await page("/kursk/events?page=2")), rSort = robots(await page("/kursk/events?sort=price"));
  check("SEO: чистый список города индексируется, фильтры, сортировка и вторые страницы — нет", rPlain.includes("index") && !rPlain.includes("noindex") && [rFilter, rPage2, rSort].every((r) => r.includes("noindex")), [rPlain, rFilter, rPage2, rSort].join(" | "));
  check("SEO: у страницы города свой заголовок", title(kursk) === "Афиша Курска — Радиус «Съездим»", title(kursk));

  const c = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const s = await c.newPage();
  const cerr = [];
  s.on("pageerror", (e) => cerr.push(String(e)));
  s.on("console", (m) => { if (m.type() === "error") cerr.push(m.text()); });
  const panel = s.locator('form[aria-label="Фильтры каталога"]:visible');
  const apply = () => panel.getByRole("button", { name: "Применить фильтры" }).click();

  // Город в адресе и в шапке
  await s.goto(BASE + "/kursk/events", { waitUntil: "networkidle" });
  await s.waitForTimeout(300);
  const hrefs = await s.locator("article h3 a").evaluateAll((as) => as.map((a) => a.getAttribute("href")));
  check("Каталог города: заголовок, счётчик и только курские события", (await s.getByRole("heading", { level: 1 }).innerText()) === "Афиша Курска" && (await s.getByText("Найдено 14 событий").isVisible()) && hrefs.length === 12 && hrefs.every((h) => h.startsWith("/events/kursk-")), `${hrefs.length} карт.`);
  check("Каталог города: город страницы становится городом сайта (шапка и cookie)", (await s.inputValue("header select")) === "kursk" && (await c.cookies()).find((x) => x.name === "radius_city")?.value === "kursk");
  check("Меню: «События» ведёт в каталог выбранного города и подсвечено", (await s.locator('header nav a[href="/kursk/events"]').getAttribute("aria-current")) === "page");

  await s.goto(BASE + "/kursk/events?category=concerts", { waitUntil: "networkidle" });
  await s.selectOption("header select", "lipetsk");
  await s.waitForURL(/\/lipetsk\/events/);
  await s.waitForTimeout(300);
  check("Шапка: смена города переключает открытый каталог и сохраняет фильтры", new URL(s.url()).search === "?category=concerts" && (await s.getByRole("heading", { level: 1 }).innerText()) === "Афиша Липецка" && (await s.inputValue("header select")) === "lipetsk", s.url().replace(BASE, ""));

  // Панель фильтров: категории + цена
  await s.goto(BASE + "/voronezh/events", { waitUntil: "networkidle" });
  check("Панель: в каталоге города в поле «Город» выбран этот город", (await panel.getByLabel("Город").inputValue()) === "voronezh");
  await panel.getByText("Концерты", { exact: true }).click();
  await panel.getByText("Театр", { exact: true }).click();
  const hi = panel.getByRole("slider", { name: "Цена: до" });
  await hi.focus();
  for (let i = 0; i < 30; i++) await s.keyboard.press("ArrowLeft");
  await apply();
  await s.waitForURL(/category=/);
  const u = new URL(s.url());
  check("Панель: категории и цена попадают в чистый адрес (без лишних параметров)", u.pathname === "/voronezh/events" && u.searchParams.get("category") === "concerts,theatre" && u.searchParams.get("priceMax") === "2000" && [...u.searchParams.keys()].length === 2, u.pathname + u.search);
  const want = (await api("?city=voronezh&category=concerts,theatre&priceMax=2000&pageSize=1")).total;
  check("Панель: число найденных совпадает с API по тем же условиям", want > 0 && (await s.getByText(/Найдено \d+/).innerText()).includes(String(want)), `API ${want}`);
  check("Панель: после перехода поля заполнены из адреса", (await panel.getByRole("checkbox", { name: "Концерты" }).isChecked()) && (await panel.getByRole("checkbox", { name: "Театр" }).isChecked()) && !(await panel.getByRole("checkbox", { name: "Кино" }).isChecked()) && (await panel.getByRole("slider", { name: "Цена: до" }).inputValue()) === "2000");

  // Чипы выбранных фильтров
  const chipLinks = await s.getByRole("list", { name: "Выбранные фильтры" }).getByRole("link").allInnerTexts();
  check("Чипы: город, обе категории и цена — по чипу на фильтр, в конце «Сбросить все»", chipLinks.length === 5 && chipLinks.some((t) => t.includes("Театр")) && chipLinks.some((t) => /до 2\s000/.test(t)) && chipLinks.at(-1).includes("Сбросить все"), chipLinks.join(" | "));
  await s.getByRole("link", { name: "Убрать фильтр: Театр" }).click();
  await s.waitForURL((x) => x.searchParams.get("category") === "concerts");
  check("Чипы: снятие категории оставляет остальные фильтры", new URL(s.url()).searchParams.get("priceMax") === "2000" && (await s.getByRole("link", { name: "Убрать фильтр: Театр" }).count()) === 0, s.url().replace(BASE, ""));
  await s.getByRole("link", { name: "Сбросить все" }).click();
  await s.waitForURL((x) => x.pathname === "/voronezh/events" && !x.search);
  check("Чипы: «Сбросить все» очищает фильтры, но остаётся в городе", (await s.getByText("Найдено 14 событий").isVisible()) && (await s.getByRole("link", { name: "Сбросить все" }).count()) === 0);

  // Дата: быстрый выбор и период
  await s.goto(BASE + "/voronezh/events", { waitUntil: "networkidle" });
  const today = panel.getByRole("button", { name: "Сегодня" });
  await today.click();
  const pressed1 = await today.getAttribute("aria-pressed");
  await panel.getByLabel("Дата: с").fill("2026-10-15");
  const pressed2 = await today.getAttribute("aria-pressed");
  await panel.getByLabel("Дата: по").fill("2026-10-20");
  check("Панель: «Сегодня» нажимается, а ввод даты снимает быстрый выбор", pressed1 === "true" && pressed2 === "false", `${pressed1} → ${pressed2}`);
  await apply();
  await s.waitForURL(/from=/);
  check("Панель: период попадает в адрес и подписан словами", new URL(s.url()).search === "?from=2026-10-15&to=2026-10-20" && (await s.getByRole("link", { name: "Убрать фильтр: 15 октября — 20 октября" }).isVisible()), s.url().replace(BASE, ""));

  // Только бесплатные
  await s.goto(BASE + "/voronezh/events", { waitUntil: "networkidle" });
  await panel.getByRole("switch", { name: "Только бесплатные" }).check();
  const locked = (await panel.locator("[inert]").count()) === 1;
  await apply();
  await s.waitForURL(/free=1/);
  const freeTexts = await s.locator("article p.font-display").allInnerTexts();
  check("«Только бесплатные»: ползунок цены блокируется, в выдаче — только бесплатные", locked && freeTexts.length > 0 && freeTexts.every((t) => t.trim() === "Бесплатно"), `${freeTexts.length} карт.`);

  // Город из поля панели — в путь
  await s.goto(BASE + "/voronezh/events?category=kids", { waitUntil: "networkidle" });
  await panel.getByLabel("Город").selectOption("orel");
  await apply();
  await s.waitForURL(/\/orel\/events/);
  check("Панель: смена города в поле ведёт на /orel/events, остальные фильтры сохраняются", new URL(s.url()).search === "?category=kids" && (await s.getByRole("heading", { level: 1 }).innerText()) === "Афиша Орла", s.url().replace(BASE, ""));
  await panel.getByLabel("Город").selectOption("");
  await apply();
  await s.waitForURL((x) => x.pathname === "/events");
  check("Панель: «Все города» ведёт на общий каталог /events", new URL(s.url()).search === "?category=kids" && (await panel.getByLabel("Город").inputValue()) === "");

  // Сортировка ссылками
  await s.goto(BASE + "/voronezh/events", { waitUntil: "networkidle" });
  await s.getByRole("link", { name: "Дешевле" }).click();
  await s.waitForURL(/sort=price/);
  const prices = (await s.locator("article p.font-display").allInnerTexts()).map(priceOf);
  check("Сортировка «Дешевле»: цены по возрастанию, пункт отмечен", prices.length === 12 && prices.every((v, i) => i === 0 || prices[i - 1] <= v) && (await s.getByRole("link", { name: "Дешевле" }).getAttribute("aria-current")) === "true", prices.join(","));
  await s.getByRole("link", { name: "По дате" }).click();
  await s.waitForURL((x) => !x.search.includes("sort="));
  check("Сортировка «По дате» — порядок по умолчанию, в адрес не пишется", !s.url().includes("sort="));
  await s.goto(BASE + "/voronezh/events?q=" + encodeURIComponent("джаз"), { waitUntil: "networkidle" });
  check("Поиск: появляется сортировка «По совпадению» и она выбрана по умолчанию", (await s.getByRole("link", { name: "По совпадению" }).getAttribute("aria-current")) === "true");

  // Пустая выдача и страница за концом
  await s.goto(BASE + "/voronezh/events?q=zzzzzz", { waitUntil: "networkidle" });
  await s.getByRole("link", { name: "Искать во всех городах" }).click();
  await s.waitForURL((x) => x.pathname === "/events");
  check("Пусто в городе: «Искать во всех городах» снимает город и сохраняет запрос", new URL(s.url()).search === "?q=zzzzzz", s.url().replace(BASE, ""));
  await s.goto(BASE + "/voronezh/events?page=9", { waitUntil: "networkidle" });
  await s.waitForURL(/page=2/, { timeout: 10000 }).catch(() => {});
  check("Страница за концом выдачи ведёт на последнюю, а не на «ничего не нашлось»", new URL(s.url()).searchParams.get("page") === "2" && (await s.getByText("Найдено 14 событий").isVisible()), s.url().replace(BASE, ""));
  check("Каталог: в консоли нет ошибок", cerr.length === 0, cerr.join(" | ").slice(0, 200));
  await c.close();

  // Телефон: шторка фильтров
  const mc = await b.newContext({ viewport: { width: 375, height: 812 } });
  const m = await mc.newPage();
  await m.goto(BASE + "/voronezh/events", { waitUntil: "networkidle" });
  const openBtn = m.getByRole("button", { name: /^Фильтры/ });
  check("Телефон: карточки фильтров нет, есть кнопка «Фильтры»", (await m.locator('form[aria-label="Фильтры каталога"]:visible').count()) === 0 && (await openBtn.isVisible()));
  await openBtn.click();
  await m.waitForTimeout(450);
  const geo = await m.evaluate(() => {
    const d = document.querySelector("dialog");
    const r = d.getBoundingClientRect();
    return { open: d.open, focusInside: d.contains(document.activeElement), gapBottom: Math.round(innerHeight - r.bottom), width: Math.round(r.width), lock: getComputedStyle(document.documentElement).overflow };
  });
  check("Шторка: выезжает снизу на всю ширину, фокус внутри, страница под ней не прокручивается", geo.open && geo.focusInside && geo.gapBottom === 0 && geo.width === 375 && geo.lock === "hidden", JSON.stringify(geo));
  await m.locator("dialog").getByText("Театр", { exact: true }).click();
  await m.getByRole("button", { name: "Показать события" }).click();
  await m.waitForURL(/category=theatre/);
  await m.waitForTimeout(300);
  check("Шторка: «Показать события» применяет фильтр и закрывается; на кнопке счётчик 1", !(await m.evaluate(() => document.querySelector("dialog").open)) && (await m.getByLabel("выбрано: 1").isVisible()), m.url().replace(BASE, ""));
  await openBtn.click();
  await m.waitForTimeout(450);
  const filled = await m.locator("dialog").getByRole("checkbox", { name: "Театр" }).isChecked();
  const axeSheet = await new AxeBuilder({ page: m }).withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"]).analyze();
  check(`axe шторка фильтров 375px: нарушений ${axeSheet.violations.length}`, axeSheet.violations.length === 0);
  for (const v of axeSheet.violations) console.log("   -", v.id, `[${v.impact}]`, v.nodes.length + " узл.", "|", v.help);
  await m.keyboard.press("Escape");
  await m.waitForTimeout(300);
  const back = await m.evaluate(() => ({ open: document.querySelector("dialog").open, focus: document.activeElement?.textContent ?? "" }));
  check("Шторка: поля заполнены из адреса, Esc закрывает и возвращает фокус на «Фильтры»", filled && !back.open && back.focus.includes("Фильтры"), JSON.stringify(back));
  await openBtn.click();
  await m.waitForTimeout(450);
  await m.locator("dialog").getByRole("link", { name: "Сбросить" }).click();
  await m.waitForURL((x) => !x.search.includes("category"));
  await m.waitForTimeout(300);
  check("Шторка: «Сбросить» очищает фильтры и закрывает шторку", !(await m.evaluate(() => document.querySelector("dialog").open)) && new URL(m.url()).pathname === "/voronezh/events" && !new URL(m.url()).search, m.url().replace(BASE, ""));
  await mc.close();

  // Самый узкий телефон: содержимое шторки не выходит за её края
  const nc = await b.newContext({ viewport: { width: 320, height: 640 } });
  const n = await nc.newPage();
  await n.goto(BASE + "/voronezh/events", { waitUntil: "networkidle" });
  await n.getByRole("button", { name: /^Фильтры/ }).click();
  await n.waitForTimeout(450);
  const out = await n.evaluate(() => {
    const d = document.querySelector("dialog");
    const dr = d.getBoundingClientRect();
    return [...d.querySelectorAll("*")].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && (r.right > dr.right + 1 || r.left < dr.left - 1); }).map((e) => e.tagName + "." + String(e.className).slice(0, 30));
  });
  check("Шторка 320px: ничего не выходит за края", out.length === 0, out.join(", "));
  await nc.close();
}

// ---------- 3. Нижний таб-бар ----------
for (const [w, want] of [[375, true], [768, false]]) {
  const q = await b.newPage({ viewport: { width: w, height: 812 } });
  await q.goto(BASE + "/", { waitUntil: "networkidle" });
  const vis = await q.getByRole("navigation", { name: "Нижняя панель навигации" }).isVisible();
  check(`Таб-бар ${want ? "виден" : "скрыт"} на ${w}px`, vis === want);
  await q.close();
}

// ---------- 4. Аудит доступности axe (WCAG 2.1 A/AA) ----------
for (const [path, w] of [["/", 1440], ["/", 375], ["/events?q=%D1%80%D0%B5%D0%B2%D0%B8%D0%B7%D0%BE%D1%80", 1440], ["/events?q=zzzzzz", 375], ["/ui-kit", 1440], ["/ui-kit", 375], ["/events", 1440], ["/voronezh/events", 1440], ["/voronezh/events", 375], ["/kursk/events?category=concerts,theatre&when=weekend&priceMax=2000", 1440], ["/voronezh/events?q=zzzzzz", 1440], ["/nonexistent", 375]]) {
  const qc = await b.newContext({ viewport: { width: w, height: 900 } });
  const q = await qc.newPage();
  await q.goto(BASE + path, { waitUntil: "networkidle" });
  if (path === "/") { await q.locator("#map-title").scrollIntoViewIfNeeded(); await q.waitForSelector(".radius-cluster", { timeout: 20000 }); await q.waitForTimeout(500); }
  const r = await new AxeBuilder({ page: q }).withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"]).analyze();
  check(`axe ${path} ${w}px: нарушений ${r.violations.length}`, r.violations.length === 0);
  for (const v of r.violations) {
    console.log("   -", v.id, `[${v.impact}]`, v.nodes.length + " узл.", "|", v.help);
    for (const n of v.nodes.slice(0, 4)) console.log("       .", n.html.slice(0, 150).split(/\s+/).join(" "));
  }
  await qc.close();
}

console.log(`\nИтого: ${results.filter(Boolean).length}/${results.length} проверок пройдено`);
await b.close();
