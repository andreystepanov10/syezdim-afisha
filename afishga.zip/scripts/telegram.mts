// Служебные команды Telegram-бота: npm run telegram -- <setup|remind>
//
//   setup    подключить webhook (https://syezdim.ru/api/telegram/webhook), задать команды и описание бота —
//            один раз после выдачи токена и при смене адреса сайта
//   post event [--dry]   опубликовать одно событие с картинкой и кнопками (без повторов)
//   post today|weekend [--dry]   опубликовать в каналы городов (TELEGRAM_CHANNELS) «куда сходить сегодня»
//            или «на выходных»; --dry — только показать текст, ничего не отправлять
//   remind   разослать напоминания о сохранённых событиях, которые начинаются завтра (по МСК) — раз в день по cron
//
// Переменные (.env.local): TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET, DATABASE_URL (для remind).
import { deleteTelegramUser, listDueReminders, markEventPosted, markReminderSent } from "../src/data/telegram";
import { SITE_URL } from "../src/lib/site";
import { createTelegramApi, TelegramError } from "../src/lib/telegram/api";
import { reminderMessage } from "../src/lib/telegram/bot";
import { buildDigest, buildEventPost, parseChannels, type Digest, type DigestKind } from "../src/lib/telegram/digest";
import { addDays, startOfDayMsk } from "../src/lib/time";

try {
  process.loadEnvFile(".env.local");
} catch {
  // .env.local необязателен
}

const command = process.argv[2];
const dry = process.argv.includes("--dry");
const api = dry ? async () => ({}) : createTelegramApi();

if (command === "setup") {
  const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
  if (!secret || !/^[A-Za-z0-9_-]{16,256}$/.test(secret)) {
    console.error("TELEGRAM_WEBHOOK_SECRET не задан или некорректен: 16–256 символов A-Z, a-z, 0-9, _ и -");
    process.exit(1);
  }
  const me = (await api("getMe", {})) as { username: string };
  await api("setWebhook", {
    url: `${SITE_URL}/api/telegram/webhook`,
    secret_token: secret,
    allowed_updates: ["message", "callback_query", "my_chat_member"],
    drop_pending_updates: true,
  });
  await api("setMyCommands", {
    commands: [
      { command: "start", description: "Начать" },
      { command: "saved", description: "Моя подборка" },
      { command: "city", description: "Сменить город" },
      { command: "reminders", description: "Включить/выключить напоминания" },
      { command: "help", description: "Как пользоваться" },
    ],
  });
  await api("setMyShortDescription", { short_description: "Афиша Черноземья: куда сходить сегодня, завтра и на выходных" });
  await api("setMyDescription", {
    description:
      "Концерты, спектакли, выставки и фестивали в Воронеже, Белгороде, Курске, Липецке, Тамбове и Орле. Ищите события, сохраняйте в подборку, делитесь с друзьями и получайте напоминания. Сайт: syezdim.ru",
  });
  console.log(`Бот @${me.username} подключён: webhook ${SITE_URL}/api/telegram/webhook`);
  console.log(`Добавьте в .env.local TELEGRAM_BOT_USERNAME=${me.username} — для кнопки «Открыть в Telegram» на сайте.`);
  process.exit(0);
}

if (command === "remind") {
  const tomorrow = addDays(startOfDayMsk(new Date()), 1);
  const due = await listDueReminders({ from: tomorrow, to: addDays(tomorrow, 1) });
  let sent = 0;
  for (const r of due) {
    const message = await reminderMessage(r.slug, {});
    if (!message) continue;
    try {
      await api("sendMessage", { chat_id: r.chatId, parse_mode: "HTML", link_preview_options: { is_disabled: true }, ...message });
      await markReminderSent(r.chatId, r.eventId);
      sent++;
    } catch (error) {
      // 403 — пользователь заблокировал бота: забываем его, чтобы не писать снова
      if (error instanceof TelegramError && error.code === 403) await deleteTelegramUser(r.chatId);
      else console.error(`Напоминание ${r.chatId}/${r.eventId} не отправлено:`, error instanceof Error ? error.message : error);
    }
    // Лимит Telegram — ~30 сообщений в секунду; с запасом
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  console.log(`${new Date().toISOString()} напоминаний отправлено: ${sent} из ${due.length}`);
  process.exit(0);
}

/**
 * Пост с картинками: 2+ постера — альбом с подписью (кнопки к альбому Telegram не прикрепляет, ссылки — в подписи);
 * один постер — фото с кнопками; без картинок или если Telegram не смог их скачать — текст с превью страницы.
 */
async function publishDigest(chat: string, digest: Digest): Promise<void> {
  const { text, caption, photos, reply_markup, link_preview_options } = digest;
  try {
    if (photos.length >= 2) {
      await api("sendMediaGroup", {
        chat_id: chat,
        media: photos.map((url, i) => ({ type: "photo", media: url, ...(i === 0 ? { caption, parse_mode: "HTML" } : {}) })),
      });
      return;
    }
    if (photos.length === 1) {
      await api("sendPhoto", { chat_id: chat, photo: photos[0], caption, parse_mode: "HTML", reply_markup });
      return;
    }
  } catch (error) {
    console.error(`Картинки не приняты (${error instanceof Error ? error.message : error}) — публикую текстом`);
  }
  await api("sendMessage", { chat_id: chat, text, parse_mode: "HTML", reply_markup, link_preview_options });
}

// Одно событие с картинкой и кнопками — несколько раз в день (cron), без повторов
if (command === "post" && process.argv[3] === "event") {
  let failed = false;
  for (const [city, chat] of parseChannels()) {
    const post = await buildEventPost(city);
    if (!post) {
      console.log(`[${city}] нечего публиковать — нет новых событий с картинкой`);
      continue;
    }
    if (dry) {
      console.log(`--- [${city}] → ${chat} · ${post.photo}\n${post.caption}\n`);
      continue;
    }
    try {
      try {
        await api("sendPhoto", { chat_id: chat, photo: post.photo, caption: post.caption, parse_mode: "HTML", reply_markup: post.reply_markup });
      } catch (error) {
        // Telegram не смог скачать картинку — событие всё равно публикуем, текстом
        if (error instanceof TelegramError && error.code === 400) {
          await api("sendMessage", { chat_id: chat, text: post.caption, parse_mode: "HTML", reply_markup: post.reply_markup });
        } else throw error;
      }
      await markEventPosted(city, post.eventId);
      console.log(`${new Date().toISOString()} [${city}] событие ${post.slug} опубликовано в ${chat}`);
    } catch (error) {
      failed = true;
      console.error(`[${city}] не опубликовано:`, error instanceof Error ? error.message : error);
    }
  }
  process.exit(failed ? 1 : 0);
}

if (command === "post") {
  const kind = process.argv[3] as DigestKind;
  if (kind !== "today" && kind !== "weekend") {
    console.error("Использование: npm run telegram -- post <today|weekend> [--dry]");
    process.exit(1);
  }
  const channels = parseChannels();
  if (channels.size === 0) console.log("TELEGRAM_CHANNELS не задан — публиковать некуда");
  let failed = false;
  for (const [city, chat] of channels) {
    const digest = await buildDigest(city, kind);
    if (!digest) {
      console.log(`[${city}] событий мало — пост пропущен`);
      continue;
    }
    if (dry) {
      console.log(`--- [${city}] → ${chat} · картинок: ${digest.photos.length}\n${digest.caption}\n`);
      continue;
    }
    try {
      await publishDigest(chat, digest);
      console.log(`${new Date().toISOString()} [${city}] пост «${kind}» опубликован в ${chat}`);
    } catch (error) {
      failed = true;
      console.error(`[${city}] не опубликовано в ${chat}:`, error instanceof Error ? error.message : error);
    }
  }
  process.exit(failed ? 1 : 0);
}

console.error("Использование: npm run telegram -- <setup|post|remind>");
process.exit(1);
