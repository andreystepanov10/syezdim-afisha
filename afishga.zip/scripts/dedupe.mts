// Склейка дублей среди предстоящих опубликованных событий: npm run dedupe [-- --dry]
//
// Дубль — тот же город, то же название после нормализации и начало в пределах 45 минут (src/lib/import/dedupe.ts).
// Из группы остаётся лучшее событие (картинка, ссылка на билеты, описание), остальные — в архив (не удаляются);
// избранное, подборки и отметки автопостинга переносятся на оставшееся. --dry — только показать.
import { and, eq, gte, inArray, sql } from "drizzle-orm";
import { getDb } from "../src/db/client";
import { channelPosts, collectionEvents, events, favorites } from "../src/db/schema";
import { titleKey } from "../src/lib/import/dedupe";

try {
  process.loadEnvFile(".env.local");
} catch {
  // .env.local необязателен
}

const dry = process.argv.includes("--dry");
const db = await getDb();
const rows = await db
  .select({
    id: events.id,
    title: events.title,
    cityId: events.cityId,
    startsAt: events.startsAt,
    image: events.image,
    ticketUrl: events.ticketUrl,
    descLen: sql<number>`length(${events.description})`,
  })
  .from(events)
  .where(and(eq(events.status, "published"), gte(sql`coalesce(${events.endsAt}, ${events.startsAt})`, sql`now()`)));

const score = (r: (typeof rows)[number]) => (r.image ? 4 : 0) + (r.ticketUrl ? 2 : 0) + (r.descLen > 100 ? 1 : 0);
const TOLERANCE = 45 * 60 * 1000;

// Группы: город + ключ названия, внутри — события, начинающиеся не дальше 45 минут друг от друга
const byKey = new Map<string, (typeof rows)[number][]>();
for (const r of rows) {
  const key = `${r.cityId}|${titleKey(r.title)}`;
  byKey.set(key, [...(byKey.get(key) ?? []), r]);
}

let archived = 0;
for (const list of byKey.values()) {
  list.sort((a, b) => +a.startsAt - +b.startsAt);
  const clusters: (typeof rows)[number][][] = [];
  for (const r of list) {
    const last = clusters.at(-1);
    if (last && +r.startsAt - +last[0].startsAt <= TOLERANCE) last.push(r);
    else clusters.push([r]);
  }
  for (const cluster of clusters) {
    if (cluster.length < 2) continue;
    const [keep, ...drop] = [...cluster].sort((a, b) => score(b) - score(a) || a.id - b.id);
    const dropIds = drop.map((d) => d.id);
    console.log(`${dry ? "[dry] " : ""}оставляю #${keep.id} «${keep.title}», в архив: ${drop.map((d) => `#${d.id} «${d.title}»`).join(", ")}`);
    archived += drop.length;
    if (dry) continue;

    await db.transaction(async (tx) => {
      // Избранное, подборки, отметки канала — на оставшееся событие, без дублей
      const favs = await tx.select({ deviceId: favorites.deviceId }).from(favorites).where(inArray(favorites.eventId, dropIds));
      if (favs.length) await tx.insert(favorites).values(favs.map((f) => ({ deviceId: f.deviceId, eventId: keep.id }))).onConflictDoNothing();
      const cols = await tx.select({ collectionId: collectionEvents.collectionId }).from(collectionEvents).where(inArray(collectionEvents.eventId, dropIds));
      if (cols.length) await tx.insert(collectionEvents).values(cols.map((c) => ({ collectionId: c.collectionId, eventId: keep.id }))).onConflictDoNothing();
      const posts = await tx.select({ city: channelPosts.city }).from(channelPosts).where(inArray(channelPosts.eventId, dropIds));
      if (posts.length) await tx.insert(channelPosts).values(posts.map((p) => ({ city: p.city, eventId: keep.id }))).onConflictDoNothing();
      await tx.update(events).set({ status: "archived", updatedAt: new Date() }).where(inArray(events.id, dropIds));
    });
  }
}

console.log(`${dry ? "Найдено" : "Убрано в архив"} дублей: ${archived} из ${rows.length} предстоящих событий`);
process.exit(0);
