// Генерирует плейсхолдер-обложки в стиле дизайна (плоские иллюстрации в палитре бренда).
// Нужны, пока нет реальных фото событий. Запуск: node scripts/gen-placeholders.mjs
import { mkdirSync, writeFileSync } from "node:fs";

const C = { mustard: "#E0A82E", brick: "#B54A2B", olive: "#7A7A3D", choco: "#3B2417", cream: "#F5E6C8", beige: "#E8D5AE", ink: "#1A0F08", paper: "#FBF5E9" };

function rng(seed) {
  let s = seed >>> 0;
  return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296;
}
const f = (n) => n.toFixed(1);
const svg = (body, defs = "") =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500" width="800" height="500" preserveAspectRatio="xMidYMid slice"><defs>${defs}</defs>${body}</svg>\n`;
const vgrad = (id, a, b) => `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;

// Город днём/на закате: небо, солнце, силуэты домов с окнами, дорога
function skyline({ seed, sky, sun, city, cityAlt, ground }) {
  const r = rng(seed);
  let x = -10;
  let out = "";
  while (x < 810) {
    const w = 36 + r() * 54;
    const h = 90 + r() * 190;
    const top = 390 - h;
    const fill = r() > 0.5 ? city : cityAlt;
    out += `<rect x="${f(x)}" y="${f(top)}" width="${f(w)}" height="${f(h + 120)}" fill="${fill}"/>`;
    if (r() > 0.7) out += `<rect x="${f(x + w / 2 - 2)}" y="${f(top - 26)}" width="4" height="26" fill="${fill}"/>`;
    for (let wy = top + 14; wy < 375; wy += 22)
      for (let wx = x + 9; wx < x + w - 12; wx += 15)
        if (r() > 0.62) out += `<rect x="${f(wx)}" y="${f(wy)}" width="7" height="10" rx="1" fill="${sun}" opacity=".75"/>`;
    x += w + 3 + r() * 8;
  }
  return svg(
    `<rect width="800" height="500" fill="url(#sky)"/><circle cx="${f(520 + r() * 160)}" cy="120" r="58" fill="${sun}"/>${out}` +
      `<path d="M0 410C180 385 330 455 800 395V500H0Z" fill="${ground}"/>` +
      `<path d="M0 452C200 430 360 490 800 438" stroke="${sky[1]}" stroke-width="5" stroke-dasharray="26 20" fill="none"/>`,
    vgrad("sky", sky[0], sky[1]),
  );
}

// Сцена: тёмный зал, лучи прожекторов, силуэт артиста, зрители
function stage({ seed, bg, beam, floor }) {
  const r = rng(seed);
  const beams = [130, 400, 670]
    .map((cx) => {
      const spread = 90 + r() * 50;
      return `<polygon points="${cx - 12},0 ${cx + 12},0 ${f(cx + spread)},430 ${f(cx - spread)},430" fill="url(#beam)" opacity="${f(0.5 + r() * 0.4)}"/>`;
    })
    .join("");
  let crowd = "";
  for (let x = -10; x < 830; x += 32) crowd += `<circle cx="${f(x + r() * 12)}" cy="${f(486 + r() * 18)}" r="${f(20 + r() * 10)}" fill="${C.ink}"/>`;
  const defs = `<linearGradient id="beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${beam}" stop-opacity=".55"/><stop offset="1" stop-color="${beam}" stop-opacity=".05"/></linearGradient>`;
  return svg(
    `<rect width="800" height="500" fill="${bg}"/>${beams}<ellipse cx="400" cy="425" rx="340" ry="44" fill="${floor}"/>` +
      `<circle cx="400" cy="262" r="24" fill="${C.ink}"/><path d="M362 430c2-70 14-112 38-112s36 42 38 112z" fill="${C.ink}"/>` +
      `<path d="M446 300v130" stroke="${C.ink}" stroke-width="4"/><circle cx="446" cy="296" r="7" fill="${C.ink}"/>${crowd}`,
    defs,
  );
}

// Театр: занавес, сцена, свет
function curtain({ curtain: c, dark, gold, floor }) {
  const folds = (side) =>
    Array.from({ length: 6 }, (_, i) => {
      const x = side === "l" ? 16 + i * 40 : 800 - 16 - i * 40;
      return `<path d="M${x} 0Q${x + (side === "l" ? 14 : -14)} 250 ${x + (side === "l" ? 4 : -4)} 500" stroke="${dark}" stroke-width="12" opacity=".35" fill="none"/>`;
    }).join("");
  const defs = `<radialGradient id="glow" cx=".5" cy=".62" r=".6"><stop offset="0" stop-color="${gold}" stop-opacity=".95"/><stop offset="1" stop-color="${gold}" stop-opacity="0"/></radialGradient>`;
  return svg(
    `<rect width="800" height="500" fill="${dark}"/><rect width="800" height="500" fill="url(#glow)"/>` +
      `<rect y="400" width="800" height="100" fill="${floor}"/>` +
      `<path d="M0 0H300C250 120 215 300 190 500H0Z" fill="${c}"/><path d="M800 0H500C550 120 585 300 610 500H800Z" fill="${c}"/>${folds("l")}${folds("r")}` +
      `<path d="M0 0H800V64C640 30 160 30 0 64Z" fill="${c}"/><path d="M0 64C160 30 640 30 800 64" stroke="${gold}" stroke-width="5" fill="none"/>`,
    defs,
  );
}

// Выставка: стена с картинами и скамьёй
function exhibition({ wall, frame, art, floor }) {
  const paint = (x, y, w, h, kind) => {
    const inner = { x: x + 12, y: y + 12, w: w - 24, h: h - 24 };
    const shapes =
      kind === 0
        ? `<circle cx="${inner.x + inner.w * 0.62}" cy="${inner.y + inner.h * 0.36}" r="${inner.w * 0.2}" fill="${art[0]}"/><path d="M${inner.x} ${inner.y + inner.h}L${inner.x + inner.w * 0.4} ${inner.y + inner.h * 0.5}L${inner.x + inner.w} ${inner.y + inner.h}Z" fill="${art[1]}"/>`
        : kind === 1
          ? Array.from({ length: 5 }, (_, i) => `<rect x="${inner.x + (i * inner.w) / 5}" y="${inner.y}" width="${inner.w / 5 - 4}" height="${inner.h}" fill="${art[i % 3]}"/>`).join("")
          : `<rect x="${inner.x}" y="${inner.y + inner.h * 0.55}" width="${inner.w}" height="${inner.h * 0.45}" fill="${art[1]}"/><circle cx="${inner.x + inner.w / 2}" cy="${inner.y + inner.h * 0.4}" r="${inner.w * 0.24}" fill="${art[0]}"/>`;
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${frame}"/><rect x="${x + 12}" y="${y + 12}" width="${w - 24}" height="${h - 24}" fill="${art[2]}"/>${shapes}`;
  };
  return svg(
    `<rect width="800" height="500" fill="${wall}"/><rect y="405" width="800" height="95" fill="${floor}"/>` +
      `${paint(70, 70, 200, 270, 0)}${paint(330, 105, 240, 160, 1)}${paint(610, 60, 130, 210, 2)}` +
      `<rect x="330" y="360" width="240" height="18" rx="4" fill="${frame}"/><rect x="350" y="378" width="10" height="34" fill="${frame}"/><rect x="540" y="378" width="10" height="34" fill="${frame}"/>`,
  );
}

// Дорога через холмы с меткой — «съездим»
function road({ sky, hill1, hill2, roadColor, sun }) {
  return svg(
    `<rect width="800" height="500" fill="url(#sky)"/><circle cx="600" cy="110" r="52" fill="${sun}"/>` +
      `<path d="M0 300C140 240 260 250 380 290S640 330 800 250V500H0Z" fill="${hill1}"/>` +
      `<path d="M0 370C160 330 300 350 420 380S680 400 800 340V500H0Z" fill="${hill2}"/>` +
      `<path d="M300 500C340 430 420 400 470 370 520 340 470 300 400 310" stroke="${roadColor}" stroke-width="64" stroke-linecap="round" fill="none"/>` +
      `<path d="M300 500C340 430 420 400 470 370 520 340 470 300 400 310" stroke="${C.cream}" stroke-width="4" stroke-dasharray="16 14" fill="none"/>` +
      `<path d="M400 120c-30 0-52 22-52 50 0 38 52 84 52 84s52-46 52-84c0-28-22-50-52-50z" fill="${C.brick}" stroke="${C.ink}" stroke-width="4"/><circle cx="400" cy="170" r="17" fill="${C.paper}"/>`,
    vgrad("sky", sky[0], sky[1]),
  );
}

// ---------------------------------------------------------------------------
// Вертикальные иллюстрации 4:5 для плиток «Редакционных подборок».
// Низ (≈30%) оставлен «пустым» (дорога/земля): туда ложится заголовок плитки.
// ---------------------------------------------------------------------------
const psvg = (body, defs = "") =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 800" width="640" height="800" preserveAspectRatio="xMidYMid slice"><defs>${defs}</defs>${body}</svg>\n`;

// Ретро-авто на дороге с меткой — «Топ уикендов»
function carScene() {
  const wheel = (cx) => `<circle cx="${cx}" cy="450" r="46" fill="${C.ink}"/><circle cx="${cx}" cy="450" r="21" fill="${C.cream}"/><circle cx="${cx}" cy="450" r="7" fill="${C.choco}"/>`;
  return psvg(
    `<rect width="640" height="800" fill="url(#sky)"/><circle cx="470" cy="150" r="64" fill="${C.mustard}"/>` +
      `<path d="M0 330C120 280 250 290 380 330S560 360 640 300V800H0Z" fill="${C.olive}"/>` +
      `<path d="M0 420C160 380 300 400 420 430S600 450 640 420V800H0Z" fill="#5f5f2f"/>` +
      `<path d="M0 500C200 470 420 510 640 480V800H0Z" fill="${C.choco}"/>` +
      `<path d="M0 565C200 540 420 580 640 550" stroke="${C.cream}" stroke-width="6" stroke-dasharray="34 26" fill="none"/>` +
      `<ellipse cx="320" cy="500" rx="230" ry="16" fill="${C.ink}" opacity=".4"/>` +
      `<rect x="100" y="370" width="440" height="84" rx="30" fill="${C.brick}"/>` +
      `<path d="M186 372L246 296H408L470 372Z" fill="${C.brick}"/>` +
      `<path d="M208 368L252 308H312V368ZM332 368V308H398L442 368Z" fill="${C.cream}"/>` +
      `<path d="M100 416H540" stroke="${C.ink}" stroke-width="4" opacity=".35"/>` +
      `<circle cx="524" cy="398" r="11" fill="${C.mustard}"/><rect x="100" y="390" width="14" height="22" rx="4" fill="${C.mustard}"/>` +
      wheel(214) + wheel(430) +
      `<path d="M150 90c-28 0-48 20-48 46 0 36 48 80 48 80s48-44 48-80c0-26-20-46-48-46z" fill="${C.brick}" stroke="${C.ink}" stroke-width="4"/><circle cx="150" cy="136" r="16" fill="${C.paper}"/>`,
    vgrad("sky", C.mustard, C.cream),
  );
}

// Двое детей с воздушным шаром на дороге между деревьев — «Куда поехать с детьми»
function kidsScene() {
  const tree = (x, y, s) =>
    `<rect x="${f(x - 7 * s)}" y="${f(y)}" width="${f(14 * s)}" height="${f(70 * s)}" fill="${C.choco}"/><circle cx="${f(x)}" cy="${f(y - 8 * s)}" r="${f(52 * s)}" fill="${C.olive}"/><circle cx="${f(x - 30 * s)}" cy="${f(y + 12 * s)}" r="${f(32 * s)}" fill="#8a8a45"/>`;
  const kid = (x, y, body) =>
    `<rect x="${x - 15}" y="${y + 98}" width="10" height="38" fill="${C.ink}"/><rect x="${x + 5}" y="${y + 98}" width="10" height="38" fill="${C.ink}"/>` +
    `<path d="M${x - 26} ${y + 100}L${x - 16} ${y + 28}H${x + 16}L${x + 26} ${y + 100}Z" fill="${body}"/><circle cx="${x}" cy="${y}" r="22" fill="${C.cream}" stroke="${C.ink}" stroke-width="3"/>`;
  return psvg(
    `<rect width="640" height="800" fill="url(#sky)"/><circle cx="130" cy="140" r="58" fill="${C.mustard}"/>` +
      `<path d="M0 380C140 330 260 340 380 380S560 400 640 350V800H0Z" fill="${C.olive}"/>` +
      `<path d="M200 800C260 640 300 560 330 470L370 470C380 560 420 660 560 800Z" fill="${C.cream}"/>` +
      `<path d="M0 500C120 470 200 520 300 560L260 800H0Z" fill="#5f5f2f"/><path d="M640 520C540 500 470 540 420 600L470 800H640Z" fill="#5f5f2f"/>` +
      tree(90, 290, 1.1) + tree(560, 300, 1.25) + tree(40, 430, 0.8) +
      kid(292, 330, C.brick) + kid(372, 350, C.mustard) +
      `<path d="M314 380Q332 392 352 396" stroke="${C.ink}" stroke-width="5" fill="none" stroke-linecap="round"/>` +
      `<path d="M394 356L470 250" stroke="${C.ink}" stroke-width="2.5"/><ellipse cx="478" cy="220" rx="34" ry="42" fill="${C.brick}" stroke="${C.ink}" stroke-width="3"/>` +
      `<rect y="700" width="640" height="100" fill="${C.choco}"/>`,
    vgrad("sky", C.cream, C.beige),
  );
}

// Вечерний парк с фонарями — «Бесплатно и интересно»
function eveningPark() {
  const r = rng(77);
  const stars = Array.from({ length: 26 }, () => `<circle cx="${f(r() * 640)}" cy="${f(r() * 300)}" r="${f(1 + r() * 2.2)}" fill="${C.cream}" opacity="${f(0.5 + r() * 0.5)}"/>`).join("");
  const lamp = (x) =>
    `<circle cx="${x}" cy="360" r="90" fill="url(#glow)"/><rect x="${x - 5}" y="360" width="10" height="230" fill="${C.ink}"/><rect x="${x - 22}" y="336" width="44" height="30" rx="8" fill="${C.mustard}"/>`;
  const tree = (x, y, s) => `<rect x="${f(x - 8 * s)}" y="${f(y)}" width="${f(16 * s)}" height="${f(120 * s)}" fill="${C.ink}"/><circle cx="${f(x)}" cy="${f(y - 20 * s)}" r="${f(74 * s)}" fill="#2f3a1a"/><circle cx="${f(x + 44 * s)}" cy="${f(y + 10 * s)}" r="${f(48 * s)}" fill="#3a4620"/>`;
  const defs = vgrad("sky", C.choco, "#a5522a") + `<radialGradient id="glow"><stop offset="0" stop-color="${C.mustard}" stop-opacity=".7"/><stop offset="1" stop-color="${C.mustard}" stop-opacity="0"/></radialGradient>`;
  return psvg(
    `<rect width="640" height="800" fill="url(#sky)"/>${stars}<circle cx="480" cy="130" r="46" fill="${C.cream}"/><circle cx="500" cy="118" r="42" fill="#8f4a2c" opacity=".0"/>` +
      `<path d="M0 470C160 440 320 470 640 430V800H0Z" fill="#26170f"/>` +
      tree(90, 300, 1.1) + tree(560, 320, 1) + lamp(230) + lamp(420) +
      `<rect x="250" y="530" width="140" height="14" rx="4" fill="${C.brick}"/><rect x="256" y="508" width="128" height="10" rx="4" fill="${C.brick}"/><rect x="262" y="544" width="8" height="34" fill="${C.ink}"/><rect x="370" y="544" width="8" height="34" fill="${C.ink}"/>` +
      `<rect y="600" width="640" height="200" fill="${C.ink}"/>`,
    defs,
  );
}

const items = {
  "ph-1": skyline({ seed: 11, sky: [C.mustard, C.cream], sun: C.brick, city: C.choco, cityAlt: "#5a3a26", ground: C.ink }),
  "ph-2": stage({ seed: 21, bg: C.choco, beam: C.mustard, floor: "#5a3a26" }),
  "ph-3": curtain({ curtain: C.brick, dark: C.choco, gold: C.mustard, floor: C.ink }),
  "ph-4": exhibition({ wall: C.olive, frame: C.cream, art: [C.mustard, C.brick, C.beige], floor: C.choco }),
  "ph-5": road({ sky: [C.cream, C.paper], hill1: C.olive, hill2: "#5f5f2f", roadColor: C.choco, sun: C.mustard }),
  "ph-6": skyline({ seed: 37, sky: [C.cream, C.beige], sun: C.mustard, city: C.brick, cityAlt: "#8a341c", ground: C.choco }),
  "ph-7": stage({ seed: 5, bg: C.ink, beam: C.brick, floor: C.choco }),
  "ph-8": exhibition({ wall: C.beige, frame: C.choco, art: [C.brick, C.olive, C.cream], floor: "#c9b07f" }),
  "ph-9": skyline({ seed: 53, sky: [C.mustard, C.beige], sun: C.brick, city: C.choco, cityAlt: "#7a4a30", ground: C.ink }),
  "ph-10": stage({ seed: 9, bg: "#2a1a10", beam: C.cream, floor: C.choco }),
  "ph-11": curtain({ curtain: C.olive, dark: C.choco, gold: C.mustard, floor: C.ink }),
  "ph-12": exhibition({ wall: C.cream, frame: C.brick, art: [C.olive, C.mustard, C.beige], floor: "#d9c08c" }),
  "ph-13": road({ sky: [C.mustard, C.cream], hill1: C.brick, hill2: "#8a341c", roadColor: C.ink, sun: C.cream }),
  "ph-14": exhibition({ wall: C.choco, frame: C.mustard, art: [C.cream, C.brick, C.olive], floor: C.ink }),
  "col-weekend": carScene(),
  "col-kids": kidsScene(),
  "col-free": eveningPark(),
};

mkdirSync("public/placeholders", { recursive: true });
for (const [name, content] of Object.entries(items)) writeFileSync(`public/placeholders/${name}.svg`, content);
console.log("written:", Object.keys(items).length, "placeholders");
