"""Вырезает круглую эмблему из logo1.jpg и делает фон прозрачным.
Запуск: python scripts/make-emblem.py <путь к logo1.jpg>
Создаёт public/brand/emblem.png и favicon-иконки в src/app/.
"""
import sys
from PIL import Image, ImageDraw

im = Image.open(sys.argv[1]).convert("RGB")
px = im.load()
w, h = im.size
dark = lambda p: p[0] < 90 and p[1] < 70 and p[2] < 60

# Центр и радиус: крайние тёмные пиксели кольца по горизонтали (через середину) и по вертикали (через центр)
row = 270
xs = [x for x in range(w) if dark(px[x, row])]
x0, x1 = min(xs), max(xs)
cx = (x0 + x1) / 2
top = min(next(y for y in range(0, 300) if dark(px[x, y])) for x in range(int(cx) - 6, int(cx) + 7))
bottom = max(max(y for y in range(300, 500) if dark(px[x, y])) for x in range(int(cx) - 6, int(cx) + 7))
cy = (top + bottom) / 2
r = min((x1 - x0) / 2, (bottom - top) / 2) - 0.5   # чуть внутрь кольца, чтобы не захватить бумажный фон
print(f"center=({cx:.1f},{cy:.1f}) r={r:.1f}  x:{x0}-{x1} y:{top}-{bottom}")

box = (round(cx - r), round(cy - r), round(cx + r) + 1, round(cy + r) + 1)
crop = im.crop(box).convert("RGBA")
size = crop.size[0]
SS = 4
mask = Image.new("L", (size * SS, size * SS), 0)
ImageDraw.Draw(mask).ellipse((0, 0, size * SS - 1, size * SS - 1), fill=255)
crop.putalpha(mask.resize((size, size), Image.LANCZOS))

out = sys.argv[2] if len(sys.argv) > 2 else "public/brand/emblem.png"
crop.resize((512, 512), Image.LANCZOS).save(out, optimize=True)
crop.resize((192, 192), Image.LANCZOS).save("src/app/icon.png", optimize=True)
crop.resize((180, 180), Image.LANCZOS).save("src/app/apple-icon.png", optimize=True)
print("ok", size)
