// Команды для работы с базой: npm run db:migrate | db:seed | db:purge-demo
//
//   migrate      применить миграции и заполнить справочники (города, категории) — безопасно повторять
//   seed         migrate + загрузить демо-события (один раз)
//   purge-demo   удалить все демо-записи (перед запуском с настоящими данными)
//
// Подключение: DATABASE_URL (PostgreSQL) или PGLITE_DIR (демо-база PGlite на диске, один процесс).
import { mkdirSync } from "node:fs";
import { count, eq } from "drizzle-orm";
import { PGlite } from "@electric-sql/pglite";
import { drizzle as drizzlePg } from "drizzle-orm/node-postgres";
import { migrate as migratePg } from "drizzle-orm/node-postgres/migrator";
import { drizzle as drizzlePglite } from "drizzle-orm/pglite";
import { migrate as migratePglite } from "drizzle-orm/pglite/migrator";
import { Pool } from "pg";
import type { Db } from "../src/db/client";
import * as schema from "../src/db/schema";
import { purgeDemo, seedDemo, seedReference } from "../src/db/seed";

try {
  process.loadEnvFile(".env.local");
} catch {
  // .env.local необязателен
}

const command = process.argv[2];
if (!["migrate", "seed", "purge-demo"].includes(command)) {
  console.error("Использование: tsx scripts/db.mts <migrate|seed|purge-demo>");
  process.exit(1);
}

const folder = "./drizzle";
let db: Db;
let close = async () => {};

if (process.env.DATABASE_URL) {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const pg = drizzlePg(pool, { schema });
  await migratePg(pg, { migrationsFolder: folder });
  db = pg as unknown as Db;
  close = () => pool.end();
} else if (process.env.PGLITE_DIR) {
  mkdirSync(process.env.PGLITE_DIR, { recursive: true }); // PGlite сам родительские папки не создаёт
  const client = new PGlite(process.env.PGLITE_DIR);
  const lite = drizzlePglite(client, { schema });
  await migratePglite(lite, { migrationsFolder: folder });
  db = lite as unknown as Db;
  close = () => client.close();
} else {
  console.error("Не задана база. Укажите DATABASE_URL (PostgreSQL) или PGLITE_DIR (PGlite на диске), см. .env.example");
  process.exit(1);
}

try {
  await seedReference(db);
  if (command === "migrate") console.log("Миграции применены, справочники (города, категории) обновлены.");

  if (command === "seed") {
    const [{ n }] = await db.select({ n: count() }).from(schema.events).where(eq(schema.events.isDemo, true));
    if (n > 0) console.log(`Демо-данные уже загружены (${n} событий), пропускаю.`);
    else console.log("Демо-данные загружены:", await seedDemo(db));
  }

  if (command === "purge-demo") {
    await purgeDemo(db);
    console.log("Демо-записи удалены.");
  }
} finally {
  await close();
}
