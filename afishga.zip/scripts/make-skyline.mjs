// Иллюстрация для шапки каталога: правый край hero (силуэт города и метка над ним).
// Запуск: node scripts/make-skyline.mjs   (результат — public/brand/skyline.webp)
import sharp from "sharp";

const SRC = "public/brand/hero.webp"; // 1815×592
const OUT = "public/brand/skyline.webp";

// Обрезаем по линии горизонта (y≈298): ниже начинается дорога, которой в шапке каталога не нужно
const region = { left: 1100, top: 0, width: 715, height: 298 };

await sharp(SRC).extract(region).webp({ quality: 88 }).toFile(OUT);
const meta = await sharp(OUT).metadata();
console.log(`saved ${OUT}: ${meta.width}×${meta.height}`);
