// Подготовка сгенерированных иллюстраций для сайта: обрезка белой рамки и приведение к нужному формату.
// node scripts/art-process.mjs <папка с исходниками col-*.jpg, cat-*.jpg, city-*.jpg, tg-*.jpg>
// Результат — public/art/{collections,categories,cities,telegram}/<slug>.jpg
import { mkdirSync, readdirSync } from "node:fs";
import path from "node:path";
import sharp from "sharp";

const src = process.argv[2];
const SETS = [
  { prefix: "col-", dir: "collections", width: 800, height: 1000 },
  { prefix: "cat-", dir: "categories", width: 1200, height: 900 },
  // Широкая полоса под шапку страницы города (там картинка не выше 298px)
  { prefix: "city-", dir: "cities", width: 1600, height: 686 },
  { prefix: "tg-", dir: "telegram", width: 640, height: 640 },
];

for (const file of readdirSync(src).filter((f) => /\.(jpe?g|png)$/i.test(f))) {
  const set = SETS.find((s) => file.startsWith(s.prefix));
  if (!set) continue;
  const slug = file.slice(set.prefix.length).replace(/\.\w+$/, "");
  const outDir = path.join("public/art", set.dir);
  mkdirSync(outDir, { recursive: true });
  // GigaChat рисует квадрат с белыми полями по краю — срезаем их, потом кадрируем по центру под формат
  // Поля бывают белыми и серыми — trim берёт цвет поля из угла картинки
  const trimmed = await sharp(path.join(src, file)).trim({ threshold: 25 }).toBuffer();
  await sharp(trimmed)
    .resize(set.width, set.height, { fit: "cover", position: set.dir === "cities" ? "centre" : "attention" })
    .jpeg({ quality: 84, mozjpeg: true })
    .toFile(path.join(outDir, `${slug}.jpg`));
  console.log("ok", `${set.dir}/${slug}.jpg`);
}
