CREATE TABLE "channel_posts" (
	"city" text NOT NULL,
	"event_id" integer NOT NULL,
	"posted_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "channel_posts_city_event_id_pk" PRIMARY KEY("city","event_id")
);
--> statement-breakpoint
ALTER TABLE "channel_posts" ADD CONSTRAINT "channel_posts_event_id_events_id_fk" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE cascade ON UPDATE no action;