CREATE TABLE "page_views" (
	"id" serial PRIMARY KEY NOT NULL,
	"day" text NOT NULL,
	"path" text NOT NULL,
	"device_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "page_views_day_idx" ON "page_views" USING btree ("day");