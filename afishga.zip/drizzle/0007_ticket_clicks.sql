CREATE TABLE "ticket_clicks" (
	"day" text NOT NULL,
	"event_id" integer NOT NULL,
	"source" text NOT NULL,
	"count" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "ticket_clicks_day_event_id_source_pk" PRIMARY KEY("day","event_id","source")
);
--> statement-breakpoint
ALTER TABLE "ticket_clicks" ADD CONSTRAINT "ticket_clicks_event_id_events_id_fk" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE cascade ON UPDATE no action;