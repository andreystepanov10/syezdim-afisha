CREATE TABLE "link_tokens" (
	"token" text PRIMARY KEY NOT NULL,
	"device_id" text NOT NULL,
	"purpose" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "reminder_log" (
	"chat_id" bigint NOT NULL,
	"event_id" integer NOT NULL,
	"sent_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reminder_log_chat_id_event_id_pk" PRIMARY KEY("chat_id","event_id")
);
--> statement-breakpoint
CREATE TABLE "share_links" (
	"id" text PRIMARY KEY NOT NULL,
	"device_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "share_links_device_id_unique" UNIQUE("device_id")
);
--> statement-breakpoint
CREATE TABLE "telegram_users" (
	"chat_id" bigint PRIMARY KEY NOT NULL,
	"device_id" text NOT NULL,
	"city" text,
	"reminders" boolean DEFAULT true NOT NULL,
	"last_query" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "reminder_log" ADD CONSTRAINT "reminder_log_event_id_events_id_fk" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE cascade ON UPDATE no action;