import { defineConfig } from "drizzle-kit";

// Миграции генерируются из src/db/schema.ts командой `npm run db:generate` и лежат в ./drizzle
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
});
