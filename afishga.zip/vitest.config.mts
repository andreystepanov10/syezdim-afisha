import path from "node:path";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "src") } },
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
    // База поднимается заново в каждом файле (PGlite в памяти + миграции + seed)
    testTimeout: 60_000,
    hookTimeout: 120_000,
  },
});
