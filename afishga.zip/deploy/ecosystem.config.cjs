// pm2-конфиг: держит Next.js поднятым и перезапускает при падении/перезагрузке сервера.
// Установка на VPS: npm i -g pm2
// Запуск:           pm2 start deploy/ecosystem.config.cjs
// Автозапуск после reboot: pm2 startup   (выполнить команду, которую он выведет)  &&  pm2 save
module.exports = {
  apps: [
    {
      name: "syezdim",
      cwd: "/var/www/syezdim",
      script: "node_modules/next/dist/bin/next",
      args: "start -p 3000",
      instances: 1,
      autorestart: true,
      max_memory_restart: "500M",
      env: {
        NODE_ENV: "production",
      },
    },
  ],
};
