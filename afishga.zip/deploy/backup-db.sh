#!/bin/bash
# Ежедневный бэкап базы PostgreSQL — устанавливается через cron (см. deploy/README ниже в этом файле).
# Восстановление: gunzip -c /var/backups/syezdim/syezdim-ДАТА.sql.gz | sudo -u postgres psql -d syezdim
set -euo pipefail

BACKUP_DIR=/var/backups/syezdim
KEEP_DAYS=14

mkdir -p "$BACKUP_DIR"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
FILE="$BACKUP_DIR/syezdim-$TIMESTAMP.sql.gz"

sudo -u postgres pg_dump syezdim | gzip > "$FILE"

# Не храним старые бэкапы вечно — диск на VPS ограничен (15 ГБ)
find "$BACKUP_DIR" -name "syezdim-*.sql.gz" -mtime "+$KEEP_DAYS" -delete

echo "$(date -Iseconds) OK: $FILE ($(du -h "$FILE" | cut -f1))"
