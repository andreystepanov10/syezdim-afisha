import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      // /go/ — переходы к партнёрам за билетами: роботам там делать нечего, а счётчик они бы портили
      disallow: ["/admin/", "/api/", "/tickets", "/go/"],
    },
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}
