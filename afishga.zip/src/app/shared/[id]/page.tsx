import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { getFavoriteEvents } from "@/data/events";
import { getDeviceIdByShareId } from "@/data/telegram";
import { timeShort } from "@/lib/format";
import { groupFavoritesByDay } from "@/lib/plan";
import { OPEN_GRAPH_DEFAULTS } from "@/lib/site";

type Props = { params: Promise<{ id: string }>; searchParams: Promise<{ own?: string }> };

export const metadata: Metadata = {
  title: "Подборка событий",
  description: "Кто-то поделился с вами подборкой событий на афише «Съездим» — посмотрите, куда сходить вместе.",
  // Личная подборка — не для поисковиков
  robots: { index: false, follow: false },
  openGraph: { ...OPEN_GRAPH_DEFAULTS, title: "Куда сходим? Подборка событий", description: "Подборка событий на афише «Съездим»" },
};

/** Публичная подборка по ссылке «Поделиться» (из бота или «Моих билетов»): только просмотр, без изменения */
export default async function SharedPlanPage({ params, searchParams }: Props) {
  const deviceId = await getDeviceIdByShareId((await params).id);
  if (!deviceId) notFound();
  const own = (await searchParams).own === "1";
  const { upcoming } = groupFavoritesByDay(await getFavoriteEvents(deviceId), new Date());

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Подборка событий" }]} className="mb-6" />
      <div className="mb-8 max-w-2xl">
        <h1 className="type-h2 mb-2">Подборка событий</h1>
        <p className="text-muted">
          {own
            ? "Это ваша подборка — скопируйте адрес страницы и отправьте друзьям. По ссылке её можно только посмотреть, изменить можете только вы."
            : "С вами поделились подборкой — вот куда можно сходить вместе. Отмечайте сердечком то, что понравилось, — события сохранятся в ваших «Моих билетах»."}
        </p>
      </div>

      {upcoming.length > 0 ? (
        <div className="space-y-10">
          {upcoming.map((day) => (
            <section key={day.key} aria-labelledby={`shared-day-${day.key}`}>
              <h2 id={`shared-day-${day.key}`} className="type-h5 mb-4">
                {day.label}
              </h2>
              <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {day.events.map((event) => (
                  <li key={event.slug}>
                    <EventCard event={event} actions="buy-more" className="h-full" timeLabel={timeShort(event.startsAt)} />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : (
        <EmptyState
          title="В подборке пока нет предстоящих событий"
          description="Возможно, все события уже прошли. Загляните в афишу — там много нового."
          action={
            <Button href="/events" variant="secondary">
              Смотреть события
            </Button>
          }
        />
      )}
    </div>
  );
}
