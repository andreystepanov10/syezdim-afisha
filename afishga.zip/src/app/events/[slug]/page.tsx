import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { EventDetail, eventMetadata } from "@/components/event/EventDetail";
import { getEventBySlug, getOtherSessions, getSimilarEvents } from "@/data/events";
import { eventJsonLd, jsonLdString } from "@/lib/seo";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getEventBySlug((await params).slug);
  return eventMetadata(event);
}

export default async function EventPage({ params }: Props) {
  const event = await getEventBySlug((await params).slug);
  if (!event) notFound();
  const [similar, otherDates] = await Promise.all([getSimilarEvents(event), getOtherSessions(event)]);
  return (
    <>
      {/* Schema.org Event — дата, место и цена в выдаче Яндекса и Google */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLdString(eventJsonLd(event)) }} />
      <EventDetail event={event} similar={similar} otherDates={otherDates} />
    </>
  );
}
