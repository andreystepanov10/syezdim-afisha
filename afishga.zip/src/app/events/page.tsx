import type { Metadata } from "next";
import { permanentRedirect } from "next/navigation";
import { Catalog, catalogFilters, catalogMetadata } from "@/components/catalog/Catalog";
import { catalogHref } from "@/data/catalog-url";
import type { RawParams } from "@/data/filters";
import { isCitySlug } from "@/lib/cities";

type Props = { searchParams: Promise<RawParams> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  return catalogMetadata(await searchParams);
}

/**
 * Каталог по всем городам. Адрес города — /<город>/events, поэтому старые ссылки /events?city=… ведут туда
 * постоянным редиректом: у страницы один адрес, и поисковики не видят дублей.
 */
export default async function EventsPage({ searchParams }: Props) {
  const raw = await searchParams;
  const city = Array.isArray(raw.city) ? raw.city[0] : raw.city;
  if (city && isCitySlug(city)) permanentRedirect(catalogHref({ ...catalogFilters(raw), city }));
  return <Catalog searchParams={raw} />;
}
