import type { Metadata } from "next";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";

export const metadata: Metadata = { title: "Страница не найдена" };

export default function NotFound() {
  return (
    <div className="container-page py-12 md:py-20">
      <EmptyState
        title="Дорога закончилась"
        description="Такой страницы нет или она переехала. Вернитесь на главную и найдите, куда съездить."
        action={<Button href="/">На главную</Button>}
      />
    </div>
  );
}
