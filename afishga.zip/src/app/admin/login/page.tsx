import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AdminLoginForm } from "@/components/admin/AdminLoginForm";
import { isAdmin } from "@/lib/admin-session";

export const metadata: Metadata = { title: "Вход в админку", robots: { index: false, follow: false } };

export default async function AdminLoginPage() {
  if (await isAdmin()) redirect("/admin");
  return (
    <div className="container-page py-12">
      <div className="mx-auto max-w-sm rounded-xl bg-white p-6 shadow-soft md:p-8">
        <h1 className="type-h3 mb-6 text-center">Админка «Радиус»</h1>
        <AdminLoginForm />
      </div>
    </div>
  );
}
