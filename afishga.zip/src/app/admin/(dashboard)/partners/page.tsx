import type { Metadata } from "next";
import Link from "next/link";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { listPartners } from "@/data/admin";
import { deletePartnerAction } from "@/lib/admin/partner-actions";

export const metadata: Metadata = { title: "Партнёры" };

export default async function AdminPartnersPage() {
  const partners = await listPartners();

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="type-h2">Партнёры</h1>
        <Button href="/admin/partners/new" iconLeft={<Plus className="size-4" aria-hidden />}>
          Добавить
        </Button>
      </div>

      <div className="overflow-x-auto rounded-xl bg-white shadow-soft">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>
              <th className="px-4 py-3 font-semibold">Название</th>
              <th className="px-4 py-3 font-semibold">Slug</th>
              <th className="px-4 py-3 font-semibold">Сайт</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {partners.map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-3">
                  <Link href={`/admin/partners/${p.id}`} className="font-semibold text-ink hover:text-brick hover:underline">
                    {p.name}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">{p.slug}</td>
                <td className="px-4 py-3 text-muted">{p.siteUrl ?? "—"}</td>
                <td className="px-4 py-3 text-right">
                  <form action={deletePartnerAction.bind(null, p.id)}>
                    <button type="submit" aria-label={`Удалить «${p.name}»`} className="focus-ring rounded-xs p-2 text-muted hover:text-brick">
                      <Trash2 className="size-4" aria-hidden />
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {partners.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-muted">
                  Пока нет ни одного партнёра.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
