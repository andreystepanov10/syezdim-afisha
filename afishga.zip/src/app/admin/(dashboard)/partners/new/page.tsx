import type { Metadata } from "next";
import { PartnerForm } from "@/components/admin/PartnerForm";

export const metadata: Metadata = { title: "Новый партнёр" };

export default function AdminNewPartnerPage() {
  return (
    <div>
      <h1 className="type-h2 mb-8">Новый партнёр</h1>
      <PartnerForm />
    </div>
  );
}
