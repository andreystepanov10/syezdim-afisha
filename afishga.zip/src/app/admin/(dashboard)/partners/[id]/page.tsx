import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PartnerForm } from "@/components/admin/PartnerForm";
import { getPartner } from "@/data/admin";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const partner = await getPartner(Number((await params).id));
  return { title: partner?.name ?? "Партнёр не найден" };
}

export default async function AdminEditPartnerPage({ params }: Props) {
  const partner = await getPartner(Number((await params).id));
  if (!partner) notFound();
  return (
    <div>
      <h1 className="type-h2 mb-8">{partner.name}</h1>
      <PartnerForm partner={partner} />
    </div>
  );
}
