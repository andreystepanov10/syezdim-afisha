import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { adminLogoutAction } from "@/lib/admin/auth-actions";
import { isAdmin } from "@/lib/admin-session";

export const metadata: Metadata = {
  title: { template: "%s — Админка", default: "Админка" },
  robots: { index: false, follow: false },
};

const NAV = [
  { href: "/admin", label: "Обзор" },
  { href: "/admin/events", label: "События" },
  { href: "/admin/venues", label: "Площадки" },
  { href: "/admin/partners", label: "Партнёры" },
  { href: "/admin/collections", label: "Подборки" },
  { href: "/admin/import", label: "Импорт" },
  { href: "/admin/stats", label: "Статистика" },
];

export default async function AdminDashboardLayout({ children }: { children: React.ReactNode }) {
  if (!(await isAdmin())) redirect("/admin/login");

  return (
    <div className="bg-cream">
      <div className="border-b border-line bg-white">
        <div className="container-page flex h-16 flex-wrap items-center gap-x-6 gap-y-2 py-2">
          <Link href="/admin" className="font-display text-lg font-bold text-ink">
            Админка «Радиус»
          </Link>
          <nav aria-label="Разделы админки" className="flex flex-wrap gap-x-5 gap-y-1">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="focus-ring rounded-xs text-sm font-semibold text-choco hover:text-brick">
                {item.label}
              </Link>
            ))}
          </nav>
          <form action={adminLogoutAction} className="ml-auto">
            <Button type="submit" variant="ghost" size="sm">
              Выйти
            </Button>
          </form>
        </div>
      </div>
      <div className="container-page py-8">{children}</div>
    </div>
  );
}
