import type { Metadata } from "next";
import { EventForm } from "@/components/admin/EventForm";
import { listPartners, listVenues } from "@/data/admin";

export const metadata: Metadata = { title: "Новое событие" };

export default async function AdminNewEventPage() {
  const [venues, partners] = await Promise.all([listVenues(), listPartners()]);
  return (
    <div>
      <h1 className="type-h2 mb-8">Новое событие</h1>
      <EventForm venues={venues} partners={partners} />
    </div>
  );
}
