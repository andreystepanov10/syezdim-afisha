import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AiGenerateButton } from "@/components/admin/AiGenerateButton";
import { EventForm } from "@/components/admin/EventForm";
import { getEventForAdmin, listPartners, listVenues } from "@/data/admin";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const event = await getEventForAdmin(Number((await params).id));
  return { title: event?.title ?? "Событие не найдено" };
}

export default async function AdminEditEventPage({ params }: Props) {
  const id = Number((await params).id);
  const [event, venues, partners] = await Promise.all([getEventForAdmin(id), listVenues(), listPartners()]);
  if (!event) notFound();
  return (
    <div>
      <h1 className="type-h2 mb-4">{event.title}</h1>
      <AiGenerateButton eventId={event.id} />
      <EventForm event={event} venues={venues} partners={partners} />
    </div>
  );
}
