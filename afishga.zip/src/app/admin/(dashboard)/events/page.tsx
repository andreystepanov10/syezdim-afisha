import type { Metadata } from "next";
import { Plus } from "lucide-react";
import { EventsTable } from "@/components/admin/EventsTable";
import { Button } from "@/components/ui/Button";
import { listEventsForAdmin } from "@/data/admin";

export const metadata: Metadata = { title: "События" };

export default async function AdminEventsPage() {
  const events = await listEventsForAdmin();

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="type-h2">События</h1>
        <Button href="/admin/events/new" iconLeft={<Plus className="size-4" aria-hidden />}>
          Добавить
        </Button>
      </div>

      <EventsTable events={events} />
    </div>
  );
}
