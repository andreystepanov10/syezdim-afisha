import type { Metadata } from "next";
import { Download } from "lucide-react";
import { buttonClasses } from "@/components/ui/Button";
import { getDailyStats, getTopPaths } from "@/data/analytics";
import { getClickStats } from "@/data/clicks";

export const metadata: Metadata = { title: "Статистика" };

const RANGE_OPTIONS = [7, 30, 90];

type Props = { searchParams: Promise<{ days?: string }> };

export default async function AdminStatsPage({ searchParams }: Props) {
  const raw = Number((await searchParams).days);
  const days = RANGE_OPTIONS.includes(raw) ? raw : 30;

  const [daily, topPaths, clicks] = await Promise.all([getDailyStats(days), getTopPaths(days, 10), getClickStats(days)]);
  const byDay = [...daily].reverse(); // свежие сверху
  const totalViews = daily.reduce((sum, d) => sum + d.views, 0);
  const avgUniquePerDay = daily.length ? Math.round(daily.reduce((sum, d) => sum + d.uniqueVisitors, 0) / daily.length) : 0;

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <h1 className="type-h2">Статистика</h1>
        <div className="flex items-center gap-3">
          <div className="flex overflow-hidden rounded-sm border border-line">
            {RANGE_OPTIONS.map((opt) => (
              <a
                key={opt}
                href={`/admin/stats?days=${opt}`}
                className={`px-3.5 py-2 text-sm font-semibold ${opt === days ? "bg-choco text-cream" : "bg-white text-choco hover:bg-cream"}`}
              >
                {opt} дн.
              </a>
            ))}
          </div>
          <a
            href={`/api/admin/stats/export?days=${days}`}
            className={buttonClasses({ variant: "secondary", size: "sm" })}
          >
            <Download className="size-4" aria-hidden />
            Экспорт CSV
          </a>
        </div>
      </div>

      <div className="mb-8 grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl bg-white p-6 shadow-soft">
          <p className="font-display text-3xl font-extrabold text-ink">{totalViews}</p>
          <p className="mt-1 text-muted">Просмотров за {days} дн.</p>
        </div>
        <div className="rounded-xl bg-white p-6 shadow-soft">
          <p className="font-display text-3xl font-extrabold text-ink">{avgUniquePerDay}</p>
          <p className="mt-1 text-muted">Уникальных посетителей в среднем за день</p>
        </div>
        <div className="rounded-xl bg-white p-6 shadow-soft">
          <p className="font-display text-3xl font-extrabold text-ink">{clicks.total}</p>
          <p className="mt-1 text-muted">
            Переходов «Купить билет» к партнёрам — сайт {clicks.bySource.site ?? 0}, канал {clicks.bySource.channel ?? 0}, бот {clicks.bySource.bot ?? 0}
          </p>
        </div>
      </div>

      {clicks.top.length > 0 && (
        <div className="mb-8 overflow-x-auto rounded-xl bg-white shadow-soft">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line text-muted">
                <th className="px-4 py-3 font-semibold">Событие — куда чаще всего идут за билетами</th>
                <th className="px-4 py-3 font-semibold">Переходов</th>
              </tr>
            </thead>
            <tbody>
              {clicks.top.map((t) => (
                <tr key={t.slug} className="border-b border-line last:border-0">
                  <td className="px-4 py-3">
                    <a href={`/events/${t.slug}`} className="font-semibold text-ink hover:underline">
                      {t.title}
                    </a>
                  </td>
                  <td className="px-4 py-3">{t.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <div className="overflow-x-auto rounded-xl bg-white shadow-soft">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-muted">
              <tr>
                <th className="px-4 py-3 font-semibold">Дата</th>
                <th className="px-4 py-3 font-semibold">Просмотры</th>
                <th className="px-4 py-3 font-semibold">Уникальные посетители</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {byDay.map((d) => (
                <tr key={d.day}>
                  <td className="px-4 py-3 font-semibold text-ink">{d.day}</td>
                  <td className="px-4 py-3 text-muted">{d.views}</td>
                  <td className="px-4 py-3 text-muted">{d.uniqueVisitors}</td>
                </tr>
              ))}
              {byDay.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-4 py-8 text-center text-muted">
                    За этот период просмотров ещё не было.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="overflow-x-auto rounded-xl bg-white shadow-soft">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-muted">
              <tr>
                <th className="px-4 py-3 font-semibold">Страница</th>
                <th className="px-4 py-3 font-semibold">Просмотры</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {topPaths.map((p) => (
                <tr key={p.path}>
                  <td className="max-w-[220px] truncate px-4 py-3 text-ink" title={p.path}>
                    {p.path}
                  </td>
                  <td className="px-4 py-3 text-muted">{p.views}</td>
                </tr>
              ))}
              {topPaths.length === 0 && (
                <tr>
                  <td colSpan={2} className="px-4 py-8 text-center text-muted">
                    Нет данных.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
