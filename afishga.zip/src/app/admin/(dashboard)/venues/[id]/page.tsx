import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { VenueForm } from "@/components/admin/VenueForm";
import { getVenue } from "@/data/admin";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const venue = await getVenue(Number((await params).id));
  return { title: venue?.name ?? "Площадка не найдена" };
}

export default async function AdminEditVenuePage({ params }: Props) {
  const venue = await getVenue(Number((await params).id));
  if (!venue) notFound();
  return (
    <div>
      <h1 className="type-h2 mb-8">{venue.name}</h1>
      <VenueForm venue={venue} />
    </div>
  );
}
