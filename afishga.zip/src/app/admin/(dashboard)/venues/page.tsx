import type { Metadata } from "next";
import Link from "next/link";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { listVenues } from "@/data/admin";
import { deleteVenueAction } from "@/lib/admin/venue-actions";
import { cityName } from "@/lib/cities";

export const metadata: Metadata = { title: "Площадки" };

export default async function AdminVenuesPage() {
  const venues = await listVenues();

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="type-h2">Площадки</h1>
        <Button href="/admin/venues/new" iconLeft={<Plus className="size-4" aria-hidden />}>
          Добавить
        </Button>
      </div>

      <div className="overflow-x-auto rounded-xl bg-white shadow-soft">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>
              <th className="px-4 py-3 font-semibold">Название</th>
              <th className="px-4 py-3 font-semibold">Город</th>
              <th className="px-4 py-3 font-semibold">Адрес</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {venues.map((v) => (
              <tr key={v.id}>
                <td className="px-4 py-3">
                  <Link href={`/admin/venues/${v.id}`} className="font-semibold text-ink hover:text-brick hover:underline">
                    {v.name}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">{cityName(v.city)}</td>
                <td className="px-4 py-3 text-muted">{v.address || "—"}</td>
                <td className="px-4 py-3 text-right">
                  <form action={deleteVenueAction.bind(null, v.id)}>
                    <button type="submit" aria-label={`Удалить «${v.name}»`} className="focus-ring rounded-xs p-2 text-muted hover:text-brick">
                      <Trash2 className="size-4" aria-hidden />
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {venues.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-muted">
                  Пока нет ни одной площадки.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
