import type { Metadata } from "next";
import { VenueForm } from "@/components/admin/VenueForm";

export const metadata: Metadata = { title: "Новая площадка" };

export default function AdminNewVenuePage() {
  return (
    <div>
      <h1 className="type-h2 mb-8">Новая площадка</h1>
      <VenueForm />
    </div>
  );
}
