import type { Metadata } from "next";
import { ImportForm } from "@/components/admin/ImportForm";
import { isGigaChatConfigured } from "@/lib/ai/gigachat";

export const metadata: Metadata = { title: "Импорт событий" };

export default function AdminImportPage() {
  const aiOn = isGigaChatConfigured();
  return (
    <div>
      <h1 className="type-h2 mb-2">Импорт событий</h1>
      <p className="mb-6 max-w-2xl text-muted">
        Подтягивает свежие события по выбранному городу с внешних афиш (KASSIR.RU, «Афиша Города», Афиша.ру) — название, дату,
        площадку, цену, ссылку на покупку, постер и описание события. Постер копируется с сайта-источника как есть — по
        вашему решению.{" "}
        {aiOn
          ? "Описание переписывается своими словами через GigaChat (не дословная копия)."
          : "Описание пока копируется с сайта-источника как есть — GigaChat не настроен (GIGACHAT_AUTH_KEY)."}{" "}
        Всё попадает черновиками — ничего не публикуется автоматически, проверьте перед публикацией в разделе «События».
      </p>
      <ImportForm />
    </div>
  );
}
