import Link from "next/link";
import { listCollectionsForAdmin, listEventsForAdmin, listPartners, listVenues } from "@/data/admin";

const TILES = [
  { href: "/admin/events", label: "События" },
  { href: "/admin/venues", label: "Площадки" },
  { href: "/admin/partners", label: "Партнёры" },
  { href: "/admin/collections", label: "Подборки" },
];

export default async function AdminOverviewPage() {
  const [events, venues, partners, collections] = await Promise.all([
    listEventsForAdmin(),
    listVenues(),
    listPartners(),
    listCollectionsForAdmin(),
  ]);
  const counts: Record<string, number> = {
    "/admin/events": events.length,
    "/admin/venues": venues.length,
    "/admin/partners": partners.length,
    "/admin/collections": collections.length,
  };

  return (
    <div>
      <h1 className="type-h2 mb-8">Обзор</h1>
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {TILES.map((tile) => (
          <li key={tile.href}>
            <Link
              href={tile.href}
              className="focus-ring block rounded-xl bg-white p-6 shadow-soft transition duration-200 hover:-translate-y-0.5 hover:shadow-hover"
            >
              <p className="font-display text-3xl font-extrabold text-ink">{counts[tile.href]}</p>
              <p className="mt-1 text-muted">{tile.label}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
