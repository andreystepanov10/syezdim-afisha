import type { Metadata } from "next";
import { CollectionForm } from "@/components/admin/CollectionForm";
import { listEventOptions } from "@/data/admin";

export const metadata: Metadata = { title: "Новая подборка" };

export default async function AdminNewCollectionPage() {
  const events = await listEventOptions();
  return (
    <div>
      <h1 className="type-h2 mb-8">Новая подборка</h1>
      <CollectionForm events={events} />
    </div>
  );
}
