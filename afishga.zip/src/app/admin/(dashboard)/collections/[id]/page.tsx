import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CollectionForm } from "@/components/admin/CollectionForm";
import { getCollectionForAdmin, listEventOptions } from "@/data/admin";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const collection = await getCollectionForAdmin(Number((await params).id));
  return { title: collection?.title ?? "Подборка не найдена" };
}

export default async function AdminEditCollectionPage({ params }: Props) {
  const id = Number((await params).id);
  const [collection, events] = await Promise.all([getCollectionForAdmin(id), listEventOptions()]);
  if (!collection) notFound();
  return (
    <div>
      <h1 className="type-h2 mb-8">{collection.title}</h1>
      <CollectionForm collection={collection} events={events} />
    </div>
  );
}
