import type { Metadata } from "next";
import Link from "next/link";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { listCollectionsForAdmin } from "@/data/admin";
import { deleteCollectionAction } from "@/lib/admin/collection-actions";

export const metadata: Metadata = { title: "Подборки" };

export default async function AdminCollectionsPage() {
  const collections = await listCollectionsForAdmin();

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="type-h2">Подборки</h1>
        <Button href="/admin/collections/new" iconLeft={<Plus className="size-4" aria-hidden />}>
          Добавить
        </Button>
      </div>

      <div className="overflow-x-auto rounded-xl bg-white shadow-soft">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>
              <th className="px-4 py-3 font-semibold">Название</th>
              <th className="px-4 py-3 font-semibold">Slug</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {collections.map((c) => (
              <tr key={c.id}>
                <td className="px-4 py-3">
                  <Link href={`/admin/collections/${c.id}`} className="font-semibold text-ink hover:text-brick hover:underline">
                    {c.title}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">{c.slug}</td>
                <td className="px-4 py-3 text-right">
                  <form action={deleteCollectionAction.bind(null, c.id)}>
                    <button type="submit" aria-label={`Удалить «${c.title}»`} className="focus-ring rounded-xs p-2 text-muted hover:text-brick">
                      <Trash2 className="size-4" aria-hidden />
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {collections.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-8 text-center text-muted">
                  Пока нет ни одной подборки.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
