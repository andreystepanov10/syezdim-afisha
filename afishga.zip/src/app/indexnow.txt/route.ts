/** Ключ IndexNow (src/lib/indexnow.ts): Яндекс проверяет по нему, что уведомления о новых страницах шлёт владелец сайта */
export function GET() {
  const key = process.env.INDEXNOW_KEY;
  if (!key) return new Response("Not found", { status: 404 });
  return new Response(key, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
}
