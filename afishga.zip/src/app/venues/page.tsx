import type { Metadata } from "next";
import { Venues, venuesMetadata } from "@/components/venues/Venues";
import type { RawParams } from "@/data/filters";

type Props = { searchParams: Promise<RawParams> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  return venuesMetadata(await searchParams);
}

export default async function VenuesPage({ searchParams }: Props) {
  return <Venues searchParams={await searchParams} />;
}
