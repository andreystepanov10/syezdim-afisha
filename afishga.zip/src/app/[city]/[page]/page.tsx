import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Landing } from "@/components/catalog/Landing";
import { catalogHref } from "@/data/catalog-url";
import { getLocalities, listEvents, type Locality } from "@/data/events";
import { cityLocative, cityRegion, isCitySlug, type CitySlug } from "@/lib/cities";
import { dateLandingDescription, dateLandingTitle, findDateLanding, landingDates, localityDescription, localityTitle } from "@/lib/landings";
import { OPEN_GRAPH_DEFAULTS } from "@/lib/site";

type Props = { params: Promise<{ city: string; page: string }>; searchParams: Promise<{ page?: string }> };

const PAGE_SIZE = 24;

/** /voronezh/segodnya … /voronezh/na-nedele — даты; /belgorod/staryy-oskol — населённый пункт области; иначе 404 */
async function resolve(citySlug: string, slug: string) {
  if (!isCitySlug(citySlug)) return null;
  const city: CitySlug = citySlug;
  const date = findDateLanding(slug);
  if (date) return { city, kind: "date" as const, date, localities: await getLocalities(city) };
  const localities = await getLocalities(city);
  const locality = localities.find((l) => l.slug === slug);
  return locality ? { city, kind: "locality" as const, locality, localities } : null;
}

function pageNumber(raw: string | undefined): number {
  const n = Number(raw);
  return Number.isInteger(n) && n > 1 && n <= 500 ? n : 1;
}

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { city, page } = await params;
  const r = await resolve(city, page);
  if (!r) return {};
  const now = new Date();
  const title = r.kind === "date" ? dateLandingTitle(r.date, r.city) : localityTitle(r.locality.name);
  const description = r.kind === "date" ? dateLandingDescription(r.date, r.city, now) : localityDescription(r.locality.name, r.city);
  const path = `/${r.city}/${page}`;
  const isFirst = pageNumber((await searchParams).page) === 1;
  return {
    title,
    description,
    // В индекс — только первая страница; вторая и дальше склеиваются с ней canonical-ом
    robots: { index: isFirst, follow: true },
    alternates: { canonical: path },
    openGraph: { ...OPEN_GRAPH_DEFAULTS, title, description, url: path },
  };
}

export default async function LandingPage({ params, searchParams }: Props) {
  const { city, page } = await params;
  const r = await resolve(city, page);
  if (!r) notFound();
  const now = new Date();
  const pageNo = pageNumber((await searchParams).page);
  const path = `/${r.city}/${page}`;

  if (r.kind === "date") {
    const list = await listEvents({ city: r.city, when: r.date.when, page: pageNo, pageSize: PAGE_SIZE, groupSessions: true });
    const dates = landingDates(r.date.when, now);
    return (
      <Landing
        city={r.city}
        path={path}
        title={dateLandingTitle(r.date, r.city)}
        intro={`Что идёт ${cityLocative(r.city)} и области (${dates}): концерты, спектакли, фильмы в прокате, выставки и детские события. Сначала — разовые события по времени, потом то, что идёт несколько дней.`}
        list={list}
        localities={r.localities}
        activeSlug={page}
        moreHref={catalogHref({ city: r.city, when: r.date.when })}
      />
    );
  }

  const locality: Locality = r.locality;
  const list = await listEvents({ city: r.city, locality: locality.name, page: pageNo, pageSize: PAGE_SIZE, groupSessions: true });
  return (
    <Landing
      city={r.city}
      path={path}
      title={localityTitle(locality.name)}
      intro={`Ближайшие события: ${locality.name}, ${cityRegion(r.city)}. Концерты, спектакли, выставки и детские события с датами, ценами и ссылками на билеты. Афиша обновляется каждый день.`}
      list={list}
      localities={r.localities}
      activeSlug={page}
      moreHref={`/${r.city}/events`}
    />
  );
}
