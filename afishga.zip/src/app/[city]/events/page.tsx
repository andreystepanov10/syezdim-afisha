import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Catalog, catalogMetadata } from "@/components/catalog/Catalog";
import type { RawParams } from "@/data/filters";
import { isCitySlug } from "@/lib/cities";

type Props = { params: Promise<{ city: string }>; searchParams: Promise<RawParams> };

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { city } = await params;
  return isCitySlug(city) ? catalogMetadata(await searchParams, city) : {};
}

/** Каталог одного города: /voronezh/events, /kursk/events?category=concerts … Неизвестный город — 404 */
export default async function CityEventsPage({ params, searchParams }: Props) {
  const { city } = await params;
  if (!isCitySlug(city)) notFound();
  return <Catalog city={city} searchParams={await searchParams} />;
}
