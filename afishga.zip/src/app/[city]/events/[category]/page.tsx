import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Catalog, catalogFilters } from "@/components/catalog/Catalog";
import { filterCount } from "@/data/catalog-url";
import type { RawParams } from "@/data/filters";
import { categoryGenitive, categoryName, isCategorySlug } from "@/lib/categories";
import { cityLocative, isCitySlug } from "@/lib/cities";

type Props = { params: Promise<{ city: string; category: string }>; searchParams: Promise<RawParams> };

/**
 * Красивый индексируемый адрес для категории в городе: /voronezh/events/concerts — «Концерты в Воронеже».
 * Тот же список, что и /voronezh/events?category=concerts, но с собственным заголовком под конкретный запрос
 * в поиске и открытый для индексации (сама выдача — общий компонент Catalog, ничего не дублируем).
 */
export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { city, category } = await params;
  if (!isCitySlug(city) || !isCategorySlug(category)) return {};

  const raw = await searchParams;
  const f = catalogFilters({ ...raw, category }, city);
  // Индексируем только чистую страницу категории — с доп. фильтрами (даты, цена, сортировка) это уже не та страница
  const isPureLanding = filterCount({ ...f, category: undefined }) === 0 && !f.sort && (f.page ?? 1) === 1;

  return {
    title: `${categoryName(category)} ${cityLocative(city)}`,
    description: `Афиша ${categoryGenitive(category)} ${cityLocative(city)}: даты, цены, ссылки на билеты у партнёров.`,
    robots: { index: isPureLanding, follow: true },
    // Канонический адрес — чистая страница категории (и для неё самой, и для вариантов с доп. фильтрами)
    alternates: { canonical: `/${city}/events/${category}` },
  };
}

export default async function CityCategoryEventsPage({ params, searchParams }: Props) {
  const { city, category } = await params;
  if (!isCitySlug(city) || !isCategorySlug(category)) notFound();
  return <Catalog city={city} searchParams={{ ...(await searchParams), category }} />;
}
