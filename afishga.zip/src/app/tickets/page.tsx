import type { Metadata } from "next";
import { Tickets } from "@/components/tickets/Tickets";
import { getFavoriteEvents } from "@/data/events";
import { getDeviceId } from "@/lib/device";
import { botUsername } from "@/lib/telegram/api";

export const metadata: Metadata = { title: "Мои билеты" };

type Props = { searchParams: Promise<{ link?: string }> };

export default async function TicketsPage({ searchParams }: Props) {
  const deviceId = await getDeviceId();
  const events = deviceId ? await getFavoriteEvents(deviceId) : [];
  const { link } = await searchParams;
  return <Tickets events={events} hasBot={botUsername() !== null} linkStatus={link === "ok" || link === "expired" ? link : undefined} />;
}
