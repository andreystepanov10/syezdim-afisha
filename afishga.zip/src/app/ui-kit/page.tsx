import type { Metadata } from "next";
import { ExternalLink, Heart, Search, X } from "lucide-react";
import { CoverImage } from "@/components/cards/CoverImage";
import { EventCard } from "@/components/cards/EventCard";
import { CollectionTile, SmallCard } from "@/components/cards/MoreCards";
import { TicketCard } from "@/components/cards/TicketCard";
import { Wordmark } from "@/components/layout/Logo";
import { MapCluster, MapPin } from "@/components/map/MapMarkers";
import { Badge, DateBadge } from "@/components/ui/Badge";
import { Button, IconButton } from "@/components/ui/Button";
import { Checkbox, Radio, Switch } from "@/components/ui/Choice";
import { Chip } from "@/components/ui/Chip";
import { EmptyState } from "@/components/ui/EmptyState";
import { Input, Select, SearchInput } from "@/components/ui/Input";
import { Breadcrumbs, Pagination } from "@/components/ui/Navigation";
import { ProgressBar, RatingInline, Stars } from "@/components/ui/Rating";
import { EventCardSkeleton, Skeleton } from "@/components/ui/Skeleton";
import { mockEvents } from "@/lib/mock-events";
import { ModalDemo, SliderDemo, TabsDemo, ToastDemo, TooltipDemo } from "./demos";

export const metadata: Metadata = {
  title: "UI-kit",
  description: "Дизайн-система Радиус «Съездим»: токены и компоненты",
  robots: { index: false, follow: false },
};

// ---------------------------------------------------------------------------
// Контраст по WCAG — считаем на месте, чтобы таблица не устаревала
// ---------------------------------------------------------------------------
function luminance(hex: string) {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function contrast(a: string, b: string) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

const colors = [
  { name: "mustard", hex: "#E0A82E", swatch: "bg-mustard text-ink", use: "Солнце: акценты, активный чип, фокус" },
  { name: "brick", hex: "#B54A2B", swatch: "bg-brick text-white", use: "CTA, ссылки, метки на карте" },
  { name: "olive", hex: "#7A7A3D", swatch: "bg-olive text-white", use: "Вторичные действия, «бесплатно»" },
  { name: "choco", hex: "#3B2417", swatch: "bg-choco text-cream", use: "Основной текст, тёмный подвал" },
  { name: "cream", hex: "#F5E6C8", swatch: "bg-cream text-ink", use: "Карточки, панели, чипы" },
  { name: "beige", hex: "#E8D5AE", swatch: "bg-beige text-ink", use: "Фон секций, разделители" },
  { name: "paper", hex: "#FBF5E9", swatch: "bg-paper text-ink border border-line", use: "Фон страницы (снят с макета)" },
  { name: "ink", hex: "#1A0F08", swatch: "bg-ink text-cream", use: "Заголовки, цвет теней" },
];

const contrastPairs = [
  { label: "Основной текст", fg: "#3B2417", bg: "#FBF5E9" },
  { label: "Вторичный текст (muted)", fg: "#6B5645", bg: "#FBF5E9" },
  { label: "Кнопка primary", fg: "#FFFFFF", bg: "#B54A2B" },
  { label: "Кнопка olive (#727239)", fg: "#FFFFFF", bg: "#727239" },
  { label: "Активный чип", fg: "#1A0F08", bg: "#E0A82E" },
  { label: "Текст в подвале", fg: "#F5E6C8", bg: "#3B2417" },
  { label: "Граница поля", fg: "#8C7B70", bg: "#FFFFFF", min: 3 },
];

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} aria-labelledby={`${id}-title`} className="scroll-mt-24 border-t border-line py-10">
      <h2 id={`${id}-title`} className="type-h3 mb-8">
        {title}
      </h2>
      <div className="space-y-10">{children}</div>
    </section>
  );
}

function Sub({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0 space-y-4">
      <h3 className="type-caption text-muted">{title}</h3>
      {children}
    </div>
  );
}

const sections = [
  ["colors", "Цвета"],
  ["type", "Типографика"],
  ["shape", "Радиусы и тени"],
  ["buttons", "Кнопки"],
  ["inputs", "Поля"],
  ["chips", "Чипы и бейджи"],
  ["cards", "Карточки"],
  ["nav", "Навигация"],
  ["feedback", "Обратная связь"],
  ["map", "Карта и рейтинг"],
] as const;

export default function UiKitPage() {
  const [main, second, third] = mockEvents;
  return (
    <div className="container-page py-10 md:py-14">
      <header className="mb-8 space-y-4">
        <p className="type-accent text-brick">этап 1 · фундамент</p>
        <h1 className="type-h1">UI-kit</h1>
        <p className="max-w-2xl text-lg text-muted">
          Токены и компоненты дизайн-системы «Радиус». Это страница приёмки: наведите курсор, нажмите и пройдите Tab по элементам, чтобы увидеть hover, active и focus.
        </p>
        <nav aria-label="Разделы UI-kit" className="flex flex-wrap gap-2 pt-2">
          {sections.map(([id, label]) => (
            <Chip key={id} href={`#${id}`}>
              {label}
            </Chip>
          ))}
        </nav>
      </header>

      {/* ------------------------------------------------------------------ Цвета */}
      <Section id="colors" title="Цвета">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {colors.map((c) => (
            <div key={c.name} className="overflow-hidden rounded-lg bg-white shadow-soft">
              <div className={`flex h-24 items-end p-3 font-display text-2xl font-bold ${c.swatch}`}>Aa</div>
              <div className="space-y-0.5 p-3">
                <p className="font-display text-sm font-bold text-ink">
                  {c.name} <span className="font-normal text-muted">{c.hex}</span>
                </p>
                <p className="text-xs text-muted">{c.use}</p>
              </div>
            </div>
          ))}
        </div>
        <Sub title="Проверка контраста (WCAG AA: текст ≥ 4.5:1, границы полей ≥ 3:1)">
          <div
            role="region"
            aria-label="Таблица контрастов"
            tabIndex={0}
            className="focus-ring overflow-x-auto rounded-lg bg-white shadow-soft"
          >
            <table className="w-full min-w-[32rem] text-left text-sm">
              <thead className="border-b border-line text-muted">
                <tr>
                  <th className="p-3 font-semibold">Пара</th>
                  <th className="p-3 font-semibold">Пример</th>
                  <th className="p-3 font-semibold">Контраст</th>
                  <th className="p-3 font-semibold">Норма</th>
                </tr>
              </thead>
              <tbody>
                {contrastPairs.map((p) => {
                  const ratio = contrast(p.fg, p.bg);
                  const min = p.min ?? 4.5;
                  return (
                    <tr key={p.label} className="border-b border-line/60 last:border-0">
                      <td className="p-3">{p.label}</td>
                      <td className="p-3">
                        {p.min ? (
                          // для границ показываем рамку, а не текст: норма для них 3:1, а не 4.5:1
                          <span aria-hidden className="inline-block h-7 w-16 rounded-sm" style={{ background: p.bg, border: `2px solid ${p.fg}` }} />
                        ) : (
                          <span className="rounded-xs px-2 py-1 font-semibold" style={{ color: p.fg, background: p.bg, border: "1px solid #dccaa4" }}>
                            Текст
                          </span>
                        )}
                      </td>
                      <td className="p-3 font-display font-bold">{ratio.toFixed(2)}:1</td>
                      <td className={`p-3 font-semibold ${ratio >= min ? "text-olive-strong" : "text-brick"}`}>{ratio >= min ? `✓ ≥ ${min}` : `✗ < ${min}`}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="text-sm text-muted">
            Отступление от макета: чистый olive #7A7A3D под белым текстом даёт {contrast("#FFFFFF", "#7A7A3D").toFixed(2)}:1 — на 0.01 ниже нормы 4.5:1. Поэтому в кнопках и бейджах используется чуть более тёмный
            #727239, а сам #7A7A3D — только для декора и крупных элементов.
          </p>
        </Sub>
      </Section>

      {/* ------------------------------------------------------------------ Типографика */}
      <Section id="type" title="Типографика">
        <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
          <div className="space-y-4">
            <p className="type-h1">H1 Montserrat Bold 64/72</p>
            <p className="type-h2">H2 Montserrat Bold 48/56</p>
            <p className="type-h3">H3 Montserrat SemiBold 32/40</p>
            <p className="type-h4">H4 Montserrat Bold 24/32</p>
            <p className="type-h5">H5 Montserrat Bold 18/24</p>
            <p className="type-h6">H6 Montserrat Bold 16/22</p>
          </div>
          <div className="space-y-4 rounded-lg bg-white p-5 shadow-soft">
            <p className="text-lg">Body L — Open Sans 18/28. Афиша для тех, кто любит выбираться из дома.</p>
            <p>Body M — Open Sans 16/24. Концерты, театр, выставки и фестивали в шести городах Черноземья.</p>
            <p className="text-sm">Body S — Open Sans 14/20. Вторичный текст и подписи.</p>
            <p className="type-caption text-muted">Caption — 12/16, капс</p>
            <p className="type-accent text-brick">Accent — Caveat, рукописный</p>
            <div className="border-t border-line pt-4">
              <p className="mb-2 text-xs text-muted">Логотип-словесный знак</p>
              <Wordmark />
            </div>
          </div>
        </div>
      </Section>

      {/* ------------------------------------------------------------------ Радиусы и тени */}
      <Section id="shape" title="Радиусы и тени">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-6">
          {(
            [
              ["xs · 4", "rounded-xs"],
              ["sm · 8", "rounded-sm"],
              ["md · 12", "rounded-md"],
              ["lg · 16", "rounded-lg"],
              ["xl · 24", "rounded-xl"],
              ["pill · 999", "rounded-pill"],
            ] as const
          ).map(([label, cls]) => (
            <div key={label} className="space-y-2 text-center">
              <div className={`mx-auto h-16 w-full bg-choco ${cls}`} />
              <p className="text-sm font-semibold">{label}</p>
            </div>
          ))}
        </div>
        <div className="grid gap-6 rounded-xl bg-cream p-6 md:grid-cols-3">
          {(
            [
              ["soft", "shadow-soft"],
              ["medium", "shadow-medium"],
              ["hover", "shadow-hover"],
            ] as const
          ).map(([label, cls]) => (
            <div key={label} className={`grid h-24 place-items-center rounded-lg bg-white font-display font-bold ${cls}`}>
              shadow-{label}
            </div>
          ))}
        </div>
      </Section>

      {/* ------------------------------------------------------------------ Кнопки */}
      <Section id="buttons" title="Кнопки">
        <Sub title="Варианты и состояния (hover / active / focus — на живых кнопках)">
          <div className="space-y-4">
            {(["primary", "secondary", "olive", "choco", "ghost", "link"] as const).map((v) => (
              <div key={v} className="flex flex-wrap items-center gap-3">
                <span className="w-24 text-sm font-semibold text-muted">{v}</span>
                <Button variant={v}>Купить билет</Button>
                <Button variant={v} disabled>
                  Недоступно
                </Button>
                <Button variant={v} loading>
                  Загрузка
                </Button>
              </div>
            ))}
          </div>
        </Sub>
        <Sub title="Размеры, иконки, ссылка на партнёра">
          <div className="flex flex-wrap items-center gap-3">
            <Button size="sm">Small 36</Button>
            <Button size="md">Medium 44</Button>
            <Button size="lg">Large 52</Button>
            <Button href="https://example.com" external iconRight={<ExternalLink className="size-4" aria-hidden />}>
              Купить у партнёра
            </Button>
            <Button variant="secondary" iconLeft={<Heart className="size-4" aria-hidden />}>
              В избранное
            </Button>
          </div>
        </Sub>
        <Sub title="Иконочные кнопки (44px)">
          <div className="flex flex-wrap items-center gap-3">
            <IconButton label="Поиск" variant="choco">
              <Search className="size-5" aria-hidden />
            </IconButton>
            <IconButton label="В избранное" variant="ghost">
              <Heart className="size-5" aria-hidden />
            </IconButton>
            <IconButton label="Закрыть" variant="secondary">
              <X className="size-5" aria-hidden />
            </IconButton>
            <IconButton label="Поиск" variant="primary">
              <Search className="size-5" aria-hidden />
            </IconButton>
            <IconButton label="Недоступно" variant="choco" disabled>
              <Search className="size-5" aria-hidden />
            </IconButton>
          </div>
        </Sub>
      </Section>

      {/* ------------------------------------------------------------------ Поля */}
      <Section id="inputs" title="Поля ввода">
        <div className="grid gap-x-8 gap-y-6 md:grid-cols-2">
          <Input label="Текстовое поле" placeholder="Например, джаз" />
          <Input label="С подсказкой" placeholder="name@mail.ru" hint="Пришлём код для входа на этот адрес" />
          <Input label="С ошибкой" defaultValue="name@" error="Введите корректный email, например name@mail.ru" />
          <Input label="Отключено" placeholder="Недоступно" disabled />
          <SearchInput label="Поиск" placeholder="Найти событие…" />
          <SearchInput label="Поиск с ошибкой" placeholder="Найти событие…" error="Введите хотя бы 2 символа" />
          <Select label="Категория" defaultValue="">
            <option value="" disabled>
              Выберите категорию
            </option>
            <option>Концерты</option>
            <option>Театр</option>
            <option>Выставки</option>
            <option>Детям</option>
          </Select>
          <Select label="Select с ошибкой" defaultValue="" error="Выберите значение">
            <option value="" disabled>
              Выберите
            </option>
            <option>Вариант</option>
          </Select>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          <Sub title="Чекбоксы">
            <div className="space-y-1">
              <Checkbox label="Только бесплатные" />
              <Checkbox label="С детьми" defaultChecked />
              <Checkbox label="С ошибкой" error="Нужно принять условия" />
              <Checkbox label="Отключён" disabled defaultChecked />
            </div>
          </Sub>
          <Sub title="Радио">
            <div className="space-y-1" role="radiogroup" aria-label="Сортировка">
              <Radio name="sort" label="По дате" defaultChecked />
              <Radio name="sort" label="По цене" />
              <Radio name="sort" label="По рейтингу" />
              <Radio name="sort" label="Отключено" disabled />
            </div>
          </Sub>
          <Sub title="Переключатели">
            <div className="space-y-1">
              <Switch label="Напоминать о событиях" defaultChecked />
              <Switch label="Рассылка" />
              <Switch label="С ошибкой" error="Не удалось сохранить" />
              <Switch label="Отключён" disabled />
            </div>
          </Sub>
        </div>

        <Sub title="Ползунки">
          <SliderDemo />
        </Sub>
      </Section>

      {/* ------------------------------------------------------------------ Чипы и бейджи */}
      <Section id="chips" title="Чипы и бейджи">
        <Sub title="Фильтр-чипы (cream → mustard в активном состоянии)">
          <div className="flex flex-wrap gap-2">
            <Chip active>Все</Chip>
            <Chip>Концерты</Chip>
            <Chip count={12}>Театр</Chip>
            <Chip>Выставки</Chip>
            <Chip>Детям</Chip>
            <Chip>Бесплатно</Chip>
          </div>
        </Sub>
        <Sub title="Бейджи и плашка даты">
          <div className="flex flex-wrap items-center gap-3">
            <Badge variant="hot">Hot</Badge>
            <Badge variant="free">Free</Badge>
            <Badge variant="age">18+</Badge>
            <Badge variant="neutral">Новинка</Badge>
            <Badge variant="mustard">VIP</Badge>
            <DateBadge date="2026-10-15T19:00:00+03:00" />
            <DateBadge date="2026-11-01T12:00:00+03:00" />
          </div>
        </Sub>
      </Section>

      {/* ------------------------------------------------------------------ Карточки */}
      <Section id="cards" title="Карточки">
        <Sub title="Карточка события: главная (одна кнопка). Наведите курсор — карточка приподнимается">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {mockEvents.slice(0, 4).map((e) => (
              <EventCard key={e.slug} event={e} />
            ))}
          </div>
        </Sub>
        <Sub title="Карточка события: каталог («Купить билет» + «Ещё»)">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {mockEvents.slice(4, 7).map((e) => (
              <EventCard key={e.slug} event={e} actions="buy-more" />
            ))}
          </div>
        </Sub>
        <div className="grid gap-10 lg:grid-cols-2">
          <Sub title="Малая карточка: вертикальная">
            <div className="grid grid-cols-2 gap-4">
              <SmallCard event={main} />
              <SmallCard event={second} />
            </div>
          </Sub>
          <Sub title="Малая карточка: горизонтальная (список в календаре)">
            <div className="space-y-3">
              <SmallCard event={main} orientation="horizontal" />
              <SmallCard event={second} orientation="horizontal" />
              <SmallCard event={third} orientation="horizontal" />
            </div>
          </Sub>
        </div>
        <Sub title="Плитки подборок">
          <div className="grid gap-5 sm:grid-cols-3">
            <CollectionTile title="Топ уикендов" href="/collections" image="/placeholders/ph-5.svg" count={12} />
            <CollectionTile title="Куда поехать с детьми" href="/collections" image="/placeholders/ph-6.svg" count={8} />
            <CollectionTile title="Выставки осени" href="/collections" image="/placeholders/ph-4.svg" count={5} />
          </div>
        </Sub>
        <Sub title="Билет для кошелька (QR)">
          <div className="grid gap-6 rounded-xl bg-cream p-6 md:grid-cols-2">
            <TicketCard
              title="Спектакль «Ревизор»"
              startsAt="2026-10-16T18:30:00+03:00"
              venue="Драматический театр, Курск"
              ticketType="Партер"
              qrValue="RADIUS-DEMO-4821-7730"
              code="4821 7730"
              notchClassName="bg-cream"
            />
            <TicketCard
              title="Джазовый вечер в филармонии"
              startsAt="2026-10-18T19:00:00+03:00"
              venue="Воронежская филармония"
              ticketType="VIP"
              qrValue="RADIUS-DEMO-1093-5512"
              code="1093 5512"
              notchClassName="bg-cream"
            />
          </div>
        </Sub>
        <Sub title="Загрузка и обложка-заглушка">
          <div className="grid gap-5 sm:grid-cols-3">
            <EventCardSkeleton />
            <EventCardSkeleton />
            <div className="group relative aspect-[8/5] overflow-hidden rounded-lg shadow-soft">
              <CoverImage sizes="300px" />
            </div>
          </div>
        </Sub>
      </Section>

      {/* ------------------------------------------------------------------ Навигация */}
      <Section id="nav" title="Навигация">
        <p className="-mt-4 text-muted">Шапка (80px) и подвал — вживую вверху и внизу страницы. На телефоне снизу — таб-бар из 5 разделов.</p>
        <Sub title="Вкладки (← → Home End)">
          <TabsDemo />
        </Sub>
        <div className="grid gap-10 md:grid-cols-2">
          <Sub title="Хлебные крошки">
            <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "События", href: "/events" }, { label: "Спектакль «Ревизор»" }]} />
          </Sub>
          <Sub title="Пагинация">
            <div className="space-y-4">
              <Pagination page={5} pageCount={20} hrefFor={(p) => `#page-${p}`} />
              <Pagination page={1} pageCount={3} hrefFor={(p) => `#page-${p}`} />
            </div>
          </Sub>
        </div>
      </Section>

      {/* ------------------------------------------------------------------ Обратная связь */}
      <Section id="feedback" title="Обратная связь">
        <div className="grid gap-10 md:grid-cols-2">
          <Sub title="Уведомления (toast)">
            <ToastDemo />
          </Sub>
          <Sub title="Модальное окно">
            <ModalDemo />
          </Sub>
          <Sub title="Подсказка (наведение и фокус)">
            <TooltipDemo />
          </Sub>
          <Sub title="Скелетон">
            <div className="space-y-3 rounded-lg bg-white p-4 shadow-soft">
              <Skeleton className="h-4 w-1/3" />
              <Skeleton className="h-6 w-4/5" />
              <Skeleton className="h-4 w-3/5" />
            </div>
          </Sub>
        </div>
        <Sub title="Пустое состояние">
          <EmptyState
            title="Ничего не нашлось"
            description="Попробуйте изменить даты или выбрать другой город — рядом наверняка что-то происходит."
            action={<Button variant="secondary">Сбросить фильтры</Button>}
          />
        </Sub>
      </Section>

      {/* ------------------------------------------------------------------ Карта и рейтинг */}
      <Section id="map" title="Карта, рейтинг, прогресс">
        <Sub title="Метки и кластеры (будут использоваться на карте на этапе 4)">
          <div className="flex flex-wrap items-end gap-8 rounded-xl bg-[linear-gradient(135deg,var(--color-beige),var(--color-cream))] p-6">
            <figure className="flex flex-col items-center gap-2">
              <MapPin active label="Активная метка" />
              <figcaption className="text-xs font-semibold text-muted">active</figcaption>
            </figure>
            <figure className="flex flex-col items-center gap-2">
              <MapPin label="Неактивная метка" />
              <figcaption className="text-xs font-semibold text-muted">inactive</figcaption>
            </figure>
            <figure className="flex flex-col items-center gap-2">
              <MapCluster count={2} />
              <figcaption className="text-xs font-semibold text-muted">cluster</figcaption>
            </figure>
            <figure className="flex flex-col items-center gap-2">
              <MapCluster count={128} />
              <figcaption className="text-xs font-semibold text-muted">cluster</figcaption>
            </figure>
          </div>
        </Sub>
        <div className="grid gap-10 md:grid-cols-2">
          <Sub title="Рейтинг">
            <div className="flex flex-col items-start gap-3">
              <Stars value={5} />
              <Stars value={4.5} />
              <Stars value={3.2} />
              <RatingInline value={4.8} count={30} />
            </div>
          </Sub>
          <Sub title="Прогресс">
            <div className="space-y-4">
              <ProgressBar value={35} label="Продано билетов, 35%" />
              <ProgressBar value={70} label="Продано билетов, 70%" />
              <ProgressBar value={100} label="Продано билетов, 100%" />
            </div>
          </Sub>
        </div>
      </Section>
    </div>
  );
}
