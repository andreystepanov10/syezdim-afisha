"use client";

import { useState } from "react";
import { Bell, Heart } from "lucide-react";
import { Button, IconButton } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { RangeSlider, Slider } from "@/components/ui/Slider";
import { Tabs } from "@/components/ui/Tabs";
import { useToast } from "@/components/ui/Toast";
import { Tooltip } from "@/components/ui/Tooltip";
import { formatPrice } from "@/lib/format";

export function ToastDemo() {
  const { toast } = useToast();
  return (
    <div className="flex flex-wrap gap-3">
      <Button variant="olive" onClick={() => toast({ title: "Добавлено в избранное", description: "Событие сохранено в вашем списке.", variant: "success" })}>
        Успех
      </Button>
      <Button variant="secondary" onClick={() => toast({ title: "Не удалось сохранить", description: "Проверьте соединение и попробуйте снова.", variant: "error" })}>
        Ошибка
      </Button>
      <Button variant="secondary" onClick={() => toast({ title: "Билеты у партнёра", description: "Откроется сайт продавца.", variant: "info" })}>
        Информация
      </Button>
    </div>
  );
}

export function ModalDemo() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)}>Открыть окно</Button>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Перейти к покупке билета?"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Остаться здесь
            </Button>
            <Button href="https://example.com" external onClick={() => setOpen(false)}>
              Перейти к партнёру
            </Button>
          </>
        }
      >
        <p>Билеты на это событие продаёт наш партнёр. Вы перейдёте на его сайт в новой вкладке — оплата и получение билета происходят там.</p>
      </Modal>
    </>
  );
}

export function TooltipDemo() {
  return (
    <div className="flex gap-4 pt-8">
      <Tooltip label="Добавить в избранное">
        <IconButton label="В избранное" variant="ghost">
          <Heart className="size-5" aria-hidden />
        </IconButton>
      </Tooltip>
      <Tooltip label="Уведомления">
        <IconButton label="Уведомления" variant="choco">
          <Bell className="size-5" aria-hidden />
        </IconButton>
      </Tooltip>
    </div>
  );
}

export function SliderDemo() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Slider label="Радиус поиска" min={0} max={200} step={10} defaultValue={80} format={(v) => `${v} км`} />
      <Slider label="Оценка" tone="brick" min={0} max={5} step={0.5} defaultValue={3.5} />
      <RangeSlider
        label="Цена"
        min={0}
        max={7000}
        step={100}
        defaultValue={[1500, 5000]}
        format={formatPrice}
        className="md:col-span-2"
      />
    </div>
  );
}

export function TabsDemo() {
  return (
    <Tabs
      label="Разделы события"
      tabs={[
        { id: "about", label: "О событии", panel: <p className="text-muted">Описание, участники и программа события.</p> },
        { id: "place", label: "Место", panel: <p className="text-muted">Адрес площадки и карта проезда.</p> },
        { id: "tickets", label: "Билеты", panel: <p className="text-muted">Категории билетов и переход к покупке у партнёра.</p> },
      ]}
    />
  );
}
