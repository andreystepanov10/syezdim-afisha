import type { Metadata } from "next";
import { Calendar, calendarMetadata } from "@/components/calendar/Calendar";
import type { RawParams } from "@/data/filters";

type Props = { searchParams: Promise<RawParams> };

export function generateMetadata(): Metadata {
  return calendarMetadata();
}

export default async function CalendarPage({ searchParams }: Props) {
  return <Calendar searchParams={await searchParams} />;
}
