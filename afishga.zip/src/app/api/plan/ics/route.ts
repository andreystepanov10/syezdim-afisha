import { NextResponse } from "next/server";
import { getFavoriteEvents } from "@/data/events";
import { getDeviceId } from "@/lib/device";
import { buildIcsCalendar } from "@/lib/ics";
import { SITE_URL } from "@/lib/site";

/** GET /api/plan/ics — весь план: избранные события этого устройства, которые ещё не прошли */
export async function GET() {
  const deviceId = await getDeviceId();
  const events = deviceId ? await getFavoriteEvents(deviceId) : [];
  const upcoming = events.filter((e) => new Date(e.startsAt) >= new Date());

  const ics = buildIcsCalendar(
    upcoming.map((e) => ({
      uid: e.slug,
      title: e.title,
      startsAt: new Date(e.startsAt),
      location: e.subtitle,
      url: `${SITE_URL}/events/${e.slug}`,
    })),
  );

  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": 'attachment; filename="syezdim-plan.ics"',
      "Cache-Control": "private, no-store",
    },
  });
}
