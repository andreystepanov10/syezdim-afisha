import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin-session";
import { saveUpload } from "@/lib/uploads";

const MAX_SIZE = 5 * 1024 * 1024; // 5 МБ
const EXT_BY_TYPE: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/svg+xml": "svg",
};

/**
 * POST /api/admin/upload — загрузка картинки для события/подборки из админки. Сохраняет файл на диск сервера
 * (подходит для обычного сервера/VPS; для serverless-хостинга без постоянной файловой системы не годится —
 * тогда нужно внешнее хранилище вроде S3).
 */
export async function POST(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Не авторизовано" }, { status: 401 });

  const formData = await request.formData();
  const file = formData.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "Файл не передан" }, { status: 400 });

  const ext = EXT_BY_TYPE[file.type];
  if (!ext) return NextResponse.json({ error: "Поддерживаются только JPEG, PNG, WebP, GIF, SVG" }, { status: 400 });
  if (file.size > MAX_SIZE) return NextResponse.json({ error: "Файл больше 5 МБ" }, { status: 400 });

  const bytes = Buffer.from(await file.arrayBuffer());
  const url = await saveUpload(bytes, ext);

  return NextResponse.json({ url });
}
