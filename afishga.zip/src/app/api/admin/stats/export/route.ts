import { NextResponse } from "next/server";
import { getDailyStats } from "@/data/analytics";
import { isAdmin } from "@/lib/admin-session";

const RANGE_OPTIONS = [7, 30, 90];

/** CSV с BOM — открывается в Excel сразу с правильной кириллицей */
export async function GET(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const raw = Number(new URL(request.url).searchParams.get("days"));
  const days = RANGE_OPTIONS.includes(raw) ? raw : 30;
  const daily = await getDailyStats(days);

  const rows = ["Дата;Просмотры;Уникальные посетители", ...daily.map((d) => `${d.day};${d.views};${d.uniqueVisitors}`)];
  const csv = "﻿" + rows.join("\r\n");

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="syezdim-stats-${days}d.csv"`,
    },
  });
}
