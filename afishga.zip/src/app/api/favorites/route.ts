import { NextResponse } from "next/server";
import { getFavoriteSlugs } from "@/data/favorites";
import { getDeviceId } from "@/lib/device";

/**
 * GET /api/favorites — избранное этого устройства (анонимно, по cookie). Читает cookie, поэтому не кешируется.
 * Используется клиентским FavoritesProvider: страницы остаются статическими/ISR, а личное состояние
 * (сердечки на карточках) подтягивается на клиенте отдельным запросом. Не создаёт cookie сама — только читает:
 * если устройство ещё ничего не отмечало, cookie не существует и это нормально (см. lib/device.ts).
 */
export async function GET() {
  const deviceId = await getDeviceId();
  const slugs = deviceId ? [...(await getFavoriteSlugs(deviceId))] : [];
  return NextResponse.json({ slugs }, { headers: { "Cache-Control": "private, no-store" } });
}
