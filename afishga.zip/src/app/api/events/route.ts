import { NextResponse, type NextRequest } from "next/server";
import { listEvents } from "@/data/events";
import { parseFilters, type RawParams } from "@/data/filters";

/**
 * GET /api/events — поиск и фильтрация событий.
 * Параметры: city, category (через запятую или повтором), q, when (today|tomorrow|weekend|week|date), date, from, to,
 * priceMin, priceMax, free=1, venue, sort (date|popular|price|relevance), page, pageSize (до 48).
 * Неизвестные параметры игнорируются, некорректные значения — ошибка 400 со списком проблем.
 */
export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const raw: RawParams = {};
  for (const key of new Set(params.keys())) {
    const values = params.getAll(key);
    raw[key] = values.length > 1 ? values : values[0];
  }

  const parsed = parseFilters(raw, { strict: true });
  if (!parsed.ok) {
    return NextResponse.json({ error: "Некорректные параметры запроса", issues: parsed.issues }, { status: 400 });
  }

  const result = await listEvents(parsed.value);
  return NextResponse.json(result, { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } });
}
