import { NextResponse } from "next/server";
import { getEventBySlug } from "@/data/events";
import { buildIcsCalendar } from "@/lib/ics";
import { SITE_URL } from "@/lib/site";

/** GET /api/events/[slug]/ics — «Добавить в календарь» для одного события. Публично, cookie не нужен. */
export async function GET(_req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const event = await getEventBySlug(slug);
  if (!event) return NextResponse.json({ error: "Событие не найдено" }, { status: 404 });

  const ics = buildIcsCalendar([
    {
      uid: event.slug,
      title: event.title,
      startsAt: new Date(event.startsAt),
      endsAt: event.endsAt ? new Date(event.endsAt) : undefined,
      location: `${event.venue.name}, ${event.venue.address}`,
      url: `${SITE_URL}/events/${event.slug}`,
    },
  ]);

  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="${event.slug}.ics"`,
    },
  });
}
