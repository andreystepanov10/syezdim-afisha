import { NextResponse } from "next/server";
import { recordPageView } from "@/data/analytics";
import { getOrCreateDeviceId } from "@/lib/device";

/** Публичный маячок просмотра страницы — вызывается клиентским компонентом PageViewTracker */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { path?: unknown } | null;
  const path = typeof body?.path === "string" ? body.path.slice(0, 512) : null;
  if (!path || path.startsWith("/admin")) return NextResponse.json({ ok: false }, { status: 400 });

  const deviceId = await getOrCreateDeviceId();
  await recordPageView({ path, deviceId });
  return NextResponse.json({ ok: true });
}
