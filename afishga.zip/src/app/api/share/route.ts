import { NextResponse } from "next/server";
import { getOrCreateShareId } from "@/data/telegram";
import { getDeviceId } from "@/lib/device";
import { SITE_URL } from "@/lib/site";

/** GET /api/share — «Поделиться подборкой» на сайте: создаёт (или находит) публичную ссылку и открывает её */
export async function GET() {
  const deviceId = await getDeviceId();
  if (!deviceId) return NextResponse.redirect(`${SITE_URL}/tickets`);
  return NextResponse.redirect(`${SITE_URL}/shared/${await getOrCreateShareId(deviceId)}?own=1`);
}
