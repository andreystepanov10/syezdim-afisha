import { timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { createTelegramApi, isTelegramConfigured } from "@/lib/telegram/api";
import { handleUpdate, type Update } from "@/lib/telegram/bot";

/** Секрет из setWebhook (scripts/telegram.mts setup): Telegram присылает его в заголовке — чужие запросы отсекаем */
function isFromTelegram(request: Request): boolean {
  const expected = process.env.TELEGRAM_WEBHOOK_SECRET;
  const got = request.headers.get("x-telegram-bot-api-secret-token");
  if (!expected || !got || got.length !== expected.length) return false;
  return timingSafeEqual(Buffer.from(got), Buffer.from(expected));
}

/**
 * POST /api/telegram/webhook — обновления от Telegram-бота. Отвечаем 200 даже при ошибке обработки:
 * иначе Telegram будет повторять то же обновление и бот застрянет на нём.
 */
export async function POST(request: Request) {
  if (!isTelegramConfigured() || !isFromTelegram(request)) return NextResponse.json({ ok: false }, { status: 401 });

  const update = (await request.json().catch(() => null)) as Update | null;
  if (update) {
    try {
      await handleUpdate(update, { api: createTelegramApi() });
    } catch (error) {
      console.error("[telegram] ошибка обработки обновления:", error instanceof Error ? error.message : error);
    }
  }
  return NextResponse.json({ ok: true });
}
