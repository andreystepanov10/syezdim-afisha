import { NextResponse } from "next/server";
import { createLinkToken } from "@/data/telegram";
import { getOrCreateDeviceId } from "@/lib/device";
import { SITE_URL } from "@/lib/site";
import { botUsername } from "@/lib/telegram/api";

/** GET /api/telegram/connect — кнопка «Открыть в Telegram» на сайте: ведёт в бота с одноразовым токеном подборки */
export async function GET() {
  const bot = botUsername();
  if (!bot) return NextResponse.redirect(`${SITE_URL}/tickets`);
  const token = await createLinkToken(await getOrCreateDeviceId(), "to_bot");
  return NextResponse.redirect(`https://t.me/${bot}?start=l_${token}`);
}
