import { NextResponse } from "next/server";
import { consumeLinkToken, mergeFavorites } from "@/data/telegram";
import { getDeviceId, switchDeviceId } from "@/lib/device";
import { SITE_URL } from "@/lib/site";

/**
 * GET /api/telegram/open?t=<токен> — кнопка «Открыть подборку на сайте» в боте. Браузер переключается на подборку
 * бота (её device_id), а то, что было отмечено в этом браузере раньше, переносится в неё — ничего не теряется.
 */
export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("t") ?? "";
  const botDeviceId = await consumeLinkToken(token, "to_site");
  if (!botDeviceId) return NextResponse.redirect(`${SITE_URL}/tickets?link=expired`);

  const current = await getDeviceId();
  if (current) await mergeFavorites(current, botDeviceId);
  await switchDeviceId(botDeviceId);
  return NextResponse.redirect(`${SITE_URL}/tickets?link=ok`);
}
