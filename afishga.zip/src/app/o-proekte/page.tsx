import type { Metadata } from "next";
import Link from "next/link";
import { CalendarCheck, Mail, MapPinned, RefreshCw, Send, Ticket } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { getCatalogStats } from "@/data/events";
import { CITIES } from "@/lib/cities";
import { plural } from "@/lib/format";
import { CONTACT_EMAIL, CONTACT_TELEGRAM, SITE_NAME, SITE_URL } from "@/lib/site";
import { socialLinks } from "@/lib/social";
import { jsonLdString } from "@/lib/seo";

export const metadata: Metadata = {
  title: "О проекте и контакты",
  description: "«Съездим» — афиша Черноземья: как мы собираем события, откуда берутся билеты и как с нами связаться.",
  alternates: { canonical: "/o-proekte" },
};

export const revalidate = 3600;

const HOW = [
  {
    icon: RefreshCw,
    title: "Афиша обновляется каждый день",
    text: "Каждую ночь собираем свежие события с сайтов касс и городских афиш, убираем повторы и прошедшее. Утром на сайте — то, что идёт сегодня и в ближайшие недели.",
  },
  {
    icon: MapPinned,
    title: "Всё Черноземье, а не один город",
    text: "Воронеж, Белгород, Курск, Липецк, Тамбов, Орёл и их области — от Старого Оскола до Ельца. Удобно, если хочется выбраться в соседний город.",
  },
  {
    icon: Ticket,
    title: "Билеты — у официальных касс",
    text: "Сами мы билеты не продаём: кнопка «Купить билет» ведёт к кассе-партнёру (KASSIR.RU, Афиша и другие). Цена та же, что на сайте кассы. За часть покупок касса платит нам комиссию — так сайт остаётся бесплатным.",
  },
  {
    icon: CalendarCheck,
    title: "Ничего не нужно регистрировать",
    text: "Сохраняйте события сердечком — они появятся в «Моих билетах». Напоминания за день до события присылает наш Telegram-бот.",
  },
];

export default async function AboutPage() {
  const stats = await getCatalogStats();
  const links = socialLinks();
  // Карточка организации для поисковиков: название, сайт, контакты
  const org = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: SITE_NAME,
    url: SITE_URL,
    logo: `${SITE_URL}/brand/emblem.png`,
    email: CONTACT_EMAIL,
    areaServed: CITIES.map((c) => c.region),
    ...(links.telegram ? { sameAs: [links.telegram.href] } : {}),
  };

  return (
    <div className="container-page py-8 md:py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLdString(org) }} />
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "О проекте" }]} className="mb-6" />
      <h1 className="type-h2">О проекте</h1>
      <p className="mt-3 max-w-2xl text-lg text-muted">
        «Съездим» — афиша Черноземья в одном месте: концерты, спектакли, кино, выставки и детские события. Сейчас в афише{" "}
        {stats.events} {plural(stats.events, ["событие", "события", "событий"])} в {stats.localities}{" "}
        {plural(stats.localities, ["городе", "городах", "городах"])}.
      </p>

      <h2 className="type-h4 mt-12">Как это работает</h2>
      <ul className="mt-5 grid gap-4 md:grid-cols-2">
        {HOW.map(({ icon: Icon, title, text }) => (
          <li key={title} className="flex gap-4 rounded-xl bg-white p-6 shadow-soft">
            <Icon className="mt-1 size-6 shrink-0 text-brick" aria-hidden />
            <div>
              <h3 className="type-h6">{title}</h3>
              <p className="mt-1 text-muted">{text}</p>
            </div>
          </li>
        ))}
      </ul>

      <section aria-labelledby="contacts-title" className="mt-12 rounded-xl bg-beige p-6 md:p-8">
        <h2 id="contacts-title" className="type-h4">
          Контакты
        </h2>
        <p className="mt-2 max-w-2xl text-muted">
          Нашли ошибку в событии, хотите добавить своё или предложить сотрудничество — напишите, ответим в течение дня.
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          <Button href={`mailto:${CONTACT_EMAIL}`} iconLeft={<Mail className="size-4" aria-hidden />}>
            {CONTACT_EMAIL}
          </Button>
          <Button href={CONTACT_TELEGRAM} external variant="secondary" iconLeft={<Send className="size-4" aria-hidden />}>
            Написать в Telegram
          </Button>
          {links.telegram && (
            <Button href={links.telegram.href} external variant="secondary" iconLeft={<Send className="size-4" aria-hidden />}>
              {links.telegram.label}
            </Button>
          )}
        </div>
        <p className="mt-5 text-sm text-muted">
          Организаторам и площадкам — <Link href="/organizatoram" className="font-semibold text-brick underline-offset-4 hover:underline">как разместить событие</Link>.
        </p>
      </section>
    </div>
  );
}
