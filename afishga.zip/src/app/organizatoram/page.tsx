import type { Metadata } from "next";
import { CalendarPlus, Flame, LayoutGrid, Send } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { getCatalogStats } from "@/data/events";
import { CITIES } from "@/lib/cities";
import { plural } from "@/lib/format";
import { CONTACT_EMAIL, CONTACT_TELEGRAM } from "@/lib/site";
import { socialLinks } from "@/lib/social";

export const metadata: Metadata = {
  title: "Организаторам и площадкам",
  description: "Разместите событие в афише Черноземья «Съездим»: бесплатное размещение, выделение в афише, пост в Telegram-канале, место в подборке.",
  alternates: { canonical: "/organizatoram" },
};

// Цифры афиши меняются раз в сутки (ночной импорт) — пересчитываем раз в час
export const revalidate = 3600;

const OFFERS = [
  {
    icon: CalendarPlus,
    title: "Добавить событие",
    price: "Бесплатно",
    text: "Пришлите ссылку на событие или афишу — добавим в каталог вашего города с датой, ценой и ссылкой на билеты. Событие попадёт в поиск, календарь, подборки и Telegram-бота.",
  },
  {
    icon: Flame,
    title: "Выделить событие",
    price: "По запросу",
    text: "Отметка «Hot» и место в верхней части «Популярного» на главной и в каталоге города. Подходит для премьер и больших концертов.",
  },
  {
    icon: Send,
    title: "Пост в Telegram-канале",
    price: "По запросу",
    text: "Отдельный пост с вашей афишей, описанием и кнопкой «Билеты» в канале «Съездим | Афиша Воронежа». Публикация в удобное время.",
  },
  {
    icon: LayoutGrid,
    title: "Место в подборке",
    price: "По запросу",
    text: "Закрепление в подборках «На выходных», «С детьми», «Сегодня» и других — люди открывают их, когда ищут, куда сходить.",
  },
];

/** Как связаться: ADS_CONTACT_URL (например, https://t.me/ваш_ник) и ADS_EMAIL из настроек сервера */
function contacts() {
  return { url: process.env.ADS_CONTACT_URL || CONTACT_TELEGRAM, email: process.env.ADS_EMAIL || CONTACT_EMAIL };
}

export default async function OrganizersPage() {
  const stats = await getCatalogStats();
  const { url, email } = contacts();
  const channel = socialLinks().telegram;

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Организаторам" }]} className="mb-6" />
      <h1 className="type-h2">Организаторам и площадкам</h1>
      <p className="mt-3 max-w-2xl text-muted">
        «Съездим» — афиша Черноземья: концерты, спектакли, кино, выставки и детские события {CITIES.length} областных центров и их
        областей. Расскажите о своём событии тем, кто ищет, куда сходить.
      </p>

      <ul className="mt-8 grid gap-4 sm:grid-cols-3">
        {[
          [stats.events, plural(stats.events, ["событие", "события", "событий"]), "в афише прямо сейчас"],
          [stats.venues, plural(stats.venues, ["площадка", "площадки", "площадок"]), "театры, залы, клубы, музеи"],
          [stats.localities, plural(stats.localities, ["город", "города", "городов"]), "Черноземья с событиями"],
        ].map(([n, word, hint]) => (
          <li key={String(word)} className="rounded-xl bg-white p-6 shadow-soft">
            <p className="font-display text-3xl font-extrabold text-ink">
              {n} <span className="text-xl">{word}</span>
            </p>
            <p className="mt-1 text-muted">{hint}</p>
          </li>
        ))}
      </ul>

      <h2 className="type-h4 mt-12">Что мы предлагаем</h2>
      <ul className="mt-5 grid gap-4 md:grid-cols-2">
        {OFFERS.map(({ icon: Icon, title, price, text }) => (
          <li key={title} className="flex gap-4 rounded-xl bg-white p-6 shadow-soft">
            <Icon className="mt-1 size-6 shrink-0 text-brick" aria-hidden />
            <div>
              <div className="flex flex-wrap items-baseline gap-x-3">
                <h3 className="type-h6">{title}</h3>
                <span className="text-sm font-semibold text-brick">{price}</span>
              </div>
              <p className="mt-1 text-muted">{text}</p>
            </div>
          </li>
        ))}
      </ul>

      <section aria-labelledby="contact-title" className="mt-12 rounded-xl bg-beige p-6 md:p-8">
        <h2 id="contact-title" className="type-h4">
          Как разместиться
        </h2>
        <p className="mt-2 max-w-2xl text-muted">
          Напишите нам: какое событие, город и дата, ссылка на билеты. Ответим в течение дня и подскажем, какой формат подойдёт.
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          {url && (
            <Button href={url} external iconLeft={<Send className="size-4" aria-hidden />}>
              Написать нам
            </Button>
          )}
          {email && (
            <Button href={`mailto:${email}`} variant="secondary">
              {email}
            </Button>
          )}
          {!url && !email && channel && (
            <Button href={channel.href} external variant="secondary" iconLeft={<Send className="size-4" aria-hidden />}>
              Наш Telegram
            </Button>
          )}
        </div>
      </section>
    </div>
  );
}
