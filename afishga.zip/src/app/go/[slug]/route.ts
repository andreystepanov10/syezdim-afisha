import { NextResponse } from "next/server";
import { getTicketTarget, recordTicketClick } from "@/data/clicks";
import { affiliateUrl, type ClickSource } from "@/lib/affiliate";
import { SITE_URL } from "@/lib/site";

type Props = { params: Promise<{ slug: string }> };

/** Роботы и превью ссылок тоже открывают /go — их переходы покупками не считаем */
const BOT_UA = /bot|crawl|spider|preview|facebookexternalhit|telegram|whatsapp|vkshare|slurp|curl|wget/i;

/**
 * GET /go/<slug>[?from=channel|bot] — кнопка «Купить билет»: считаем переход и отправляем к партнёру
 * (с партнёрским кодом, если он настроен, см. src/lib/affiliate.ts). Нет ссылки на билеты — на страницу события.
 */
export async function GET(request: Request, { params }: Props) {
  const { slug } = await params;
  const target = await getTicketTarget(slug);
  if (!target) return NextResponse.redirect(`${SITE_URL}/events/${encodeURIComponent(slug)}`);

  const from = new URL(request.url).searchParams.get("from");
  const source: ClickSource = from === "channel" || from === "bot" ? from : "site";
  if (!BOT_UA.test(request.headers.get("user-agent") ?? "")) {
    await recordTicketClick(target.id, source).catch(() => {}); // счётчик не должен мешать покупке
  }
  // В Telegram (канал, бот) партнёрские ссылки у KASSIR и Афиши — «по согласованию», а у Яндекса рассылки в мессенджерах
  // запрещены: пока программы явно не разрешили (AFFILIATE_TELEGRAM=1), из Telegram ведём на обычную ссылку
  const partner = source === "site" || process.env.AFFILIATE_TELEGRAM === "1";
  return NextResponse.redirect(partner ? affiliateUrl(target.ticketUrl) : target.ticketUrl, { headers: { "X-Robots-Tag": "noindex, nofollow" } });
}
