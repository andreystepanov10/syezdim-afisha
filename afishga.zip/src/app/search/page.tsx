import type { Metadata } from "next";
import { Search, searchMetadata } from "@/components/search/Search";
import type { RawParams } from "@/data/filters";

type Props = { searchParams: Promise<RawParams> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  return searchMetadata(await searchParams);
}

export default async function SearchPage({ searchParams }: Props) {
  return <Search searchParams={await searchParams} />;
}
