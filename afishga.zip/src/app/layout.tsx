import type { Metadata, Viewport } from "next";
import { Caveat, Marck_Script, Montserrat, Open_Sans, Oswald } from "next/font/google";
import { PageViewTracker } from "@/components/analytics/PageViewTracker";
import { YandexMetrika } from "@/components/analytics/YandexMetrika";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { MobileTabBar } from "@/components/layout/MobileTabBar";
import { ToastProvider } from "@/components/ui/Toast";
import { FavoritesProvider } from "@/lib/favorites-context";
import { OPEN_GRAPH_DEFAULTS, SITE_NAME, SITE_URL } from "@/lib/site";
import "./globals.css";

// Шрифты самохостятся при сборке (next/font): запросов к Google из браузера нет.
// Gilroy из макета платный, поэтому заголовки — Montserrat, близкий по рисунку и с кириллицей.
const montserrat = Montserrat({ subsets: ["cyrillic", "latin"], variable: "--font-montserrat", display: "swap" });
const openSans = Open_Sans({ subsets: ["cyrillic", "latin"], variable: "--font-open-sans", display: "swap" });
const oswald = Oswald({ subsets: ["cyrillic"], weight: "700", variable: "--font-oswald", display: "swap" });
const marck = Marck_Script({ subsets: ["cyrillic", "latin"], weight: "400", variable: "--font-marck", display: "swap" });
const caveat = Caveat({ subsets: ["cyrillic"], variable: "--font-caveat", display: "swap", preload: false });

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Радиус «Съездим» — афиша Черноземья",
    template: "%s — Радиус «Съездим»",
  },
  description:
    "Все события Черноземья в одном месте: концерты, театр, выставки и фестивали в Воронеже, Белгороде, Курске, Липецке, Тамбове и Орле.",
  applicationName: SITE_NAME,
  openGraph: OPEN_GRAPH_DEFAULTS,
  // Подтверждение сайта в партнёрской сети Admitad (Mitgo) — для партнёрских ссылок на билеты
  other: { "mitgo-verification": "e00ace5e-78c4-4184-b656-3b2fd114dce0" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#FBF5E9",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="ru"
      className={`${montserrat.variable} ${openSans.variable} ${oswald.variable} ${marck.variable} ${caveat.variable}`}
    >
      <body className="flex min-h-dvh flex-col">
        <a href="#main" className="skip-link">
          Перейти к содержимому
        </a>
        <PageViewTracker />
        <YandexMetrika />
        <ToastProvider>
          <FavoritesProvider>
            <Header />
            <main id="main" className="flex-1">
              {children}
            </main>
            <Footer />
            <MobileTabBar />
          </FavoritesProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
