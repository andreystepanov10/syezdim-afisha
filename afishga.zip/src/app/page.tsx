import type { Metadata } from "next";
import { CollectionsSection } from "@/components/home/CollectionsSection";
import { Hero } from "@/components/home/Hero";
import { PopularEvents } from "@/components/home/PopularEvents";
import { PopularMap } from "@/components/home/PopularMap";
import { UpcomingExhibitions } from "@/components/home/UpcomingExhibitions";
import { getHomeData } from "@/data/home";

// Данные обновляем раз в 5 минут (ISR), а не при каждом запросе
export const revalidate = 300;

// Канонический адрес только здесь, не в layout: там он унаследовался бы всеми страницами без своего
export const metadata: Metadata = { alternates: { canonical: "/" } };

// Главная по макету: hero с поиском → популярные события → карта → подборки → выставки
export default async function HomePage() {
  const data = await getHomeData();
  return (
    <>
      <Hero />
      <PopularEvents byCity={data.popularByCity} />
      <PopularMap venues={data.mapVenues} />
      <CollectionsSection byCity={data.autoCollectionsByCity} />
      <UpcomingExhibitions byCity={data.exhibitionsByCity} />
    </>
  );
}
