import type { MetadataRoute } from "next";
import { getCollections, getLocalities, listPublishedEventSlugs } from "@/data/events";
import { DATE_LANDINGS } from "@/lib/landings";
import { CATEGORIES } from "@/lib/categories";
import { CITIES } from "@/lib/cities";
import { SITE_URL } from "@/lib/site";

// Список меняется несколько раз в день (публикации из админки) — не нужен на каждый запрос,
// но и не должен быть статикой на весь build
export const revalidate = 3600;

const STATIC_PATHS: MetadataRoute.Sitemap = [
  { url: `${SITE_URL}/`, changeFrequency: "daily", priority: 1 },
  { url: `${SITE_URL}/events`, changeFrequency: "hourly", priority: 0.9 },
  { url: `${SITE_URL}/venues`, changeFrequency: "weekly", priority: 0.6 },
  { url: `${SITE_URL}/collections`, changeFrequency: "weekly", priority: 0.6 },
  { url: `${SITE_URL}/calendar`, changeFrequency: "daily", priority: 0.5 },
  { url: `${SITE_URL}/o-proekte`, changeFrequency: "monthly", priority: 0.4 },
  { url: `${SITE_URL}/organizatoram`, changeFrequency: "monthly", priority: 0.4 },
  { url: `${SITE_URL}/privacy`, changeFrequency: "yearly", priority: 0.1 },
  { url: `${SITE_URL}/terms`, changeFrequency: "yearly", priority: 0.1 },
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [eventSlugs, collections, localities] = await Promise.all([listPublishedEventSlugs(), getCollections(), getLocalities()]);

  // Посадочные под частые запросы: «куда сходить в Воронеже сегодня», «Старый Оскол: афиша»
  const landingPages: MetadataRoute.Sitemap = [
    ...CITIES.flatMap((c) => DATE_LANDINGS.map((d) => ({ url: `${SITE_URL}/${c.slug}/${d.slug}`, changeFrequency: "daily" as const, priority: 0.8 }))),
    ...localities.map((l) => ({ url: `${SITE_URL}/${l.city}/${l.slug}`, changeFrequency: "daily" as const, priority: 0.7 })),
  ];

  const cityPages: MetadataRoute.Sitemap = CITIES.map((c) => ({
    url: `${SITE_URL}/${c.slug}/events`,
    changeFrequency: "hourly",
    priority: 0.8,
  }));

  const categoryPages: MetadataRoute.Sitemap = CITIES.flatMap((c) =>
    CATEGORIES.map((cat) => ({
      url: `${SITE_URL}/${c.slug}/events/${cat.slug}`,
      changeFrequency: "hourly" as const,
      priority: 0.6,
    })),
  );

  const eventPages: MetadataRoute.Sitemap = eventSlugs.map((e) => ({
    url: `${SITE_URL}/events/${e.slug}`,
    lastModified: e.updatedAt,
    changeFrequency: "weekly",
    priority: 0.7,
  }));

  const collectionPages: MetadataRoute.Sitemap = collections.map((c) => ({
    url: `${SITE_URL}/collections/${c.slug}`,
    changeFrequency: "weekly",
    priority: 0.5,
  }));

  return [...STATIC_PATHS, ...cityPages, ...landingPages, ...categoryPages, ...eventPages, ...collectionPages];
}
