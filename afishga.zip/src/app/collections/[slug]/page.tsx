import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CollectionDetail, collectionMetadata } from "@/components/collections/CollectionDetail";
import { getCollectionBySlug } from "@/data/events";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const collection = await getCollectionBySlug((await params).slug);
  return collectionMetadata(collection);
}

export default async function CollectionPage({ params }: Props) {
  const collection = await getCollectionBySlug((await params).slug);
  if (!collection) notFound();
  return <CollectionDetail collection={collection} />;
}
