import { CollectionsIndex, collectionsMetadata } from "@/components/collections/CollectionsIndex";

export const metadata = collectionsMetadata;

type Props = { searchParams: Promise<{ city?: string }> };

export default async function CollectionsPage({ searchParams }: Props) {
  return <CollectionsIndex cityParam={(await searchParams).city} />;
}
