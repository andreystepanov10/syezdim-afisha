// Избранное: анонимное, по device_id из cookie (src/lib/device.ts) — без учётных записей и персональных данных.
import { and, eq } from "drizzle-orm";
import { getDb, type Db } from "@/db/client";
import { events, favorites } from "@/db/schema";

export type Ctx = { db?: Db };

export async function getFavoriteSlugs(deviceId: string, ctx: Ctx = {}): Promise<Set<string>> {
  const db = ctx.db ?? (await getDb());
  const rows = await db
    .select({ slug: events.slug })
    .from(favorites)
    .innerJoin(events, eq(events.id, favorites.eventId))
    .where(eq(favorites.deviceId, deviceId));
  return new Set(rows.map((r) => r.slug));
}

/** Переключает избранное по slug события; возвращает новое состояние. Неизвестный slug — false, ничего не делает */
export async function toggleFavorite(deviceId: string, slug: string, ctx: Ctx = {}): Promise<boolean> {
  const db = ctx.db ?? (await getDb());
  const [event] = await db.select({ id: events.id }).from(events).where(eq(events.slug, slug)).limit(1);
  if (!event) return false;

  const existing = await db
    .select({ eventId: favorites.eventId })
    .from(favorites)
    .where(and(eq(favorites.deviceId, deviceId), eq(favorites.eventId, event.id)))
    .limit(1);

  if (existing.length > 0) {
    await db.delete(favorites).where(and(eq(favorites.deviceId, deviceId), eq(favorites.eventId, event.id)));
    return false;
  }
  await db.insert(favorites).values({ deviceId, eventId: event.id });
  return true;
}
