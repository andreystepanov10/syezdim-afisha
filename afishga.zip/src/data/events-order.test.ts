import { beforeAll, describe, expect, it } from "vitest";
import { createEvent, createVenue } from "@/data/admin";
import { createDemoDb, type Db } from "@/db/client";
import { listEvents } from "./events";

// Импортированные события без рейтинга: «популярное» и «по дате» сводятся к порядку по дате начала
const NOW = new Date("2026-10-11T09:00:00Z");
let db: Db;

beforeAll(async () => {
  db = await createDemoDb({ now: NOW });
  const venueId = await createVenue({ slug: "kinoteatry-test", name: "Кинотеатры Теста", address: "", lat: 52.6, lon: 39.6, city: "lipetsk" }, { db });
  const base = { description: "", city: "lipetsk" as const, venueId, partnerId: null, priceFrom: 300, priceTo: null, ageLimit: null, image: null, isHot: false, pushkinCard: false, ticketUrl: null, status: "published" as const, ticketTypes: [] };
  // Фильм уже в прокате: начался вчера, идёт неделю — раньше вставал в начало любого списка
  await createEvent({ ...base, slug: "film-v-prokate", title: "Фильм в прокате", category: "cinema", startsAt: new Date("2026-10-10T07:00:00Z"), endsAt: new Date("2026-10-17T20:00:00Z") }, { db });
});

describe("порядок длящихся событий", () => {
  it("идущий фильм не вытесняет разовые события из начала «популярного» и «по дате»", async () => {
    for (const sort of ["popular", "date"] as const) {
      const { items } = await listEvents({ city: "lipetsk", sort, pageSize: 48 }, { db, now: NOW });
      expect(items.at(-1)?.slug === "film-v-prokate" || items.findIndex((e) => e.slug === "film-v-prokate") > 0).toBe(true);
      expect(items[0].slug).not.toBe("film-v-prokate");
    }
  });

  it("в разделе «Кино» фильм на месте", async () => {
    const { items } = await listEvents({ city: "lipetsk", category: ["cinema"] }, { db, now: NOW });
    expect(items.map((e) => e.slug)).toContain("film-v-prokate");
  });
});

describe("склейка сеансов", () => {
  it("три сеанса спектакля в одной площадке — одна карточка «и ещё 2 даты», в «Других датах» — остальные", async () => {
    const { createEvent } = await import("@/data/admin");
    const { getOtherSessions, getEventBySlug } = await import("./events");
    const venueId = await createVenue({ slug: "teatr-test", name: "Театр Теста", address: "", lat: 52.6, lon: 39.6, city: "lipetsk" }, { db });
    const base = { description: "", city: "lipetsk" as const, venueId, partnerId: null, priceFrom: 500, priceTo: null, ageLimit: null, image: null, isHot: false, pushkinCard: false, ticketUrl: null, status: "published" as const, ticketTypes: [], category: "theatre" as const, endsAt: null };
    for (const [i, day] of ["12", "15", "18"].entries()) {
      await createEvent({ ...base, slug: `kashtanka-${i}`, title: i === 1 ? "КАШТАНКА" : "Каштанка", startsAt: new Date(`2026-10-${day}T16:00:00Z`) }, { db });
    }
    const grouped = await listEvents({ city: "lipetsk", category: ["theatre"], groupSessions: true, pageSize: 48 }, { db, now: NOW });
    const cards = grouped.items.filter((e) => e.title.toLowerCase() === "каштанка");
    expect(cards).toHaveLength(1);
    expect(cards[0]).toMatchObject({ slug: "kashtanka-0", moreDates: 2 });
    expect(grouped.total).toBe(grouped.items.length);

    const plain = await listEvents({ city: "lipetsk", category: ["theatre"], pageSize: 48 }, { db, now: NOW });
    expect(plain.items.filter((e) => e.title.toLowerCase() === "каштанка")).toHaveLength(3);

    const ev = (await getEventBySlug("kashtanka-0", { db }))!;
    expect((await getOtherSessions(ev, { db, now: NOW })).map((d) => d.slug)).toEqual(["kashtanka-1", "kashtanka-2"]);
  });
});
