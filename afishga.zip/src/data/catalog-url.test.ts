import { describe, expect, it } from "vitest";
import {
  PRICE_SLIDER,
  activeFilters,
  catalogHref,
  catalogPath,
  defaultSort,
  filterCount,
  filtersFromState,
  priceStepLabel,
  searchHref,
  sortOptions,
  stateFromFilters,
  type FilterFormState,
} from "./catalog-url";
import { parseFilters, type EventFilters } from "./filters";

/** Форматтер ru-RU ставит неразрывные пробелы — в сравнениях приводим их к обычным */
const norm = (s: string) => s.replace(/\s/g, " ");

const blank: FilterFormState = {
  q: "",
  category: [],
  city: "",
  when: "",
  from: "",
  to: "",
  price: [PRICE_SLIDER.min, PRICE_SLIDER.max],
  free: false,
  pushkinCard: false,
};

describe("адрес каталога", () => {
  it("город — в пути, остальное — в параметрах", () => {
    expect(catalogPath()).toBe("/events");
    expect(catalogPath("voronezh")).toBe("/voronezh/events");
    expect(catalogHref({})).toBe("/events");
    expect(catalogHref({ city: "voronezh" })).toBe("/voronezh/events");
    expect(catalogHref({ city: "kursk", category: ["concerts", "theatre"], when: "weekend" })).toBe("/kursk/events?category=concerts,theatre&when=weekend");
  });

  it("пустые значения, первая страница и размер страницы в адрес не попадают", () => {
    expect(catalogHref({ city: "orel", q: "", page: 1, pageSize: 12, free: false, category: [] })).toBe("/orel/events");
    expect(catalogHref({ city: "orel", page: 3 })).toBe("/orel/events?page=3");
    expect(catalogHref({ free: true, sort: "price" })).toBe("/events?free=1&sort=price");
  });

  it("кириллица в поиске кодируется и читается обратно", () => {
    const href = catalogHref({ q: "джаз и блюз" });
    expect(new URL(href, "http://x").searchParams.get("q")).toBe("джаз и блюз");
  });

  it("адрес читается тем же разбором, что и API: ничего не теряется", () => {
    const sets: EventFilters[] = [
      { category: ["concerts", "theatre"], when: "weekend", sort: "popular" },
      { q: "ревизор", sort: "date" },
      { date: "2026-10-20", priceMin: 500, priceMax: 2000 },
      { from: "2026-10-15", to: "2026-10-20", free: true },
      { venue: "kursk-filarmoniya", page: 4 },
    ];
    for (const f of sets) {
      const url = new URL(catalogHref(f), "http://x");
      const parsed = parseFilters(Object.fromEntries(url.searchParams), { strict: true });
      expect(parsed.ok).toBe(true);
      if (parsed.ok) expect(parsed.value).toMatchObject(f);
    }
  });
});

describe("адрес поиска", () => {
  it("без запроса и без страницы — просто /search", () => {
    expect(searchHref({})).toBe("/search");
    expect(searchHref({ page: 1 })).toBe("/search");
  });

  it("запрос и вторая страница попадают в адрес", () => {
    expect(searchHref({ q: "джаз" })).toBe("/search?q=%D0%B4%D0%B6%D0%B0%D0%B7");
    expect(searchHref({ q: "джаз", page: 3 })).toBe("/search?q=%D0%B4%D0%B6%D0%B0%D0%B7&page=3");
  });
});

describe("сортировка", () => {
  it("по умолчанию — по дате, а при поиске — по совпадению", () => {
    expect(defaultSort({})).toBe("date");
    expect(defaultSort({ q: "джаз" })).toBe("relevance");
    expect(sortOptions({})).toEqual(["date", "popular", "price"]);
    expect(sortOptions({ q: "джаз" })).toEqual(["relevance", "date", "popular", "price"]);
  });
});

describe("выбранные фильтры (чипы)", () => {
  it("каждый чип ведёт на адрес без этого фильтра, остальные сохраняются", () => {
    const f: EventFilters = { city: "kursk", category: ["concerts", "theatre"], q: "джаз", when: "weekend", sort: "popular" };
    const chips = activeFilters(f);
    expect(chips.map((c) => c.label)).toEqual(["Курск", "Концерты", "Театр", "«джаз»", "На выходных"]);

    const href = (label: string) => chips.find((c) => c.label === label)!.href;
    expect(href("Курск")).toBe("/events?category=concerts,theatre&q=%D0%B4%D0%B6%D0%B0%D0%B7&when=weekend&sort=popular");
    expect(href("Концерты")).toBe("/kursk/events?category=theatre&q=%D0%B4%D0%B6%D0%B0%D0%B7&when=weekend&sort=popular");
    expect(href("Театр")).toBe("/kursk/events?category=concerts&q=%D0%B4%D0%B6%D0%B0%D0%B7&when=weekend&sort=popular");
    expect(href("На выходных")).toBe("/kursk/events?category=concerts,theatre&q=%D0%B4%D0%B6%D0%B0%D0%B7&sort=popular");
  });

  it("снятие фильтра сбрасывает страницу выдачи", () => {
    const [chip] = activeFilters({ category: ["kids"], page: 3 });
    expect(chip.href).toBe("/events");
  });

  it("последняя категория снимается целиком", () => {
    const [chip] = activeFilters({ city: "orel", category: ["kids"] }).filter((c) => c.key.startsWith("category"));
    expect(chip.href).toBe("/orel/events");
  });

  it("даты подписаны словами, а не ISO", () => {
    expect(activeFilters({ date: "2026-10-20" })[0].label).toBe("20 октября");
    expect(activeFilters({ from: "2026-10-15" })[0].label).toBe("с 15 октября");
    expect(activeFilters({ to: "2026-10-20" })[0].label).toBe("по 20 октября");
    expect(activeFilters({ from: "2026-10-15", to: "2026-10-20" })[0].label).toBe("15 октября — 20 октября");
    // «Выбрать дату» с главной приходит как when=date&date=…
    expect(activeFilters({ when: "date", date: "2026-10-20" })[0].label).toBe("20 октября");
  });

  it("цена — один чип: диапазон, «от», «до»; «бесплатно» вытесняет цену", () => {
    expect(norm(activeFilters({ priceMin: 500, priceMax: 2000 })[0].label)).toBe("500 ₽ — 2 000 ₽");
    expect(norm(activeFilters({ priceMin: 500 })[0].label)).toBe("от 500 ₽");
    expect(norm(activeFilters({ priceMax: 2000 })[0].label)).toBe("до 2 000 ₽");
    const free = activeFilters({ free: true, priceMax: 2000 });
    expect(free.map((c) => c.label)).toEqual(["Бесплатно"]);
  });

  it("площадка: название, а если его нет — slug", () => {
    expect(activeFilters({ venue: "kursk-filarmoniya" }, { venueName: "Курская филармония" })[0].label).toBe("Площадка: Курская филармония");
    expect(activeFilters({ venue: "kursk-filarmoniya" })[0].label).toBe("Площадка: kursk-filarmoniya");
  });

  it("сортировка и страница фильтрами не считаются, город в счётчик не входит", () => {
    expect(activeFilters({ sort: "price", page: 2 })).toEqual([]);
    expect(filterCount({ city: "kursk", sort: "price" })).toBe(0);
    expect(filterCount({ city: "kursk", category: ["concerts", "theatre"], free: true, when: "today" })).toBe(3);
  });
});

describe("панель фильтров ↔ адрес", () => {
  it("значения по умолчанию в адрес не попадают", () => {
    expect(filtersFromState(blank)).toEqual({});
    expect(filtersFromState({ ...blank, q: "   " })).toEqual({});
    expect(filtersFromState({ ...blank, price: [PRICE_SLIDER.min, PRICE_SLIDER.max] })).toEqual({});
  });

  it("ползунок цены: сдвинутая граница попадает в фильтр, крайнее положение — нет", () => {
    expect(filtersFromState({ ...blank, price: [500, PRICE_SLIDER.max] })).toEqual({ priceMin: 500 });
    expect(filtersFromState({ ...blank, price: [PRICE_SLIDER.min, 2000] })).toEqual({ priceMax: 2000 });
    expect(filtersFromState({ ...blank, price: [500, 2000] })).toEqual({ priceMin: 500, priceMax: 2000 });
  });

  it("«только бесплатные» отменяет цену", () => {
    expect(filtersFromState({ ...blank, free: true, price: [500, 2000] })).toEqual({ free: true });
  });

  it("быстрый выбор даты вытесняет поля «с» и «по»", () => {
    expect(filtersFromState({ ...blank, when: "today", from: "2026-10-15", to: "2026-10-20" })).toEqual({ when: "today" });
  });

  it("даты: перепутанный порядок исправляется, один день — это date", () => {
    expect(filtersFromState({ ...blank, from: "2026-10-20", to: "2026-10-15" })).toEqual({ from: "2026-10-15", to: "2026-10-20" });
    expect(filtersFromState({ ...blank, from: "2026-10-15", to: "2026-10-15" })).toEqual({ date: "2026-10-15" });
    expect(filtersFromState({ ...blank, from: "2026-10-15" })).toEqual({ from: "2026-10-15" });
  });

  it("категории идут в порядке справочника, поиск обрезается", () => {
    const f = filtersFromState({ ...blank, category: ["kids", "concerts", "theatre"], q: "  джаз " });
    expect(f).toEqual({ category: ["concerts", "theatre", "kids"], q: "джаз" });
  });

  it("сортировка и площадка переносятся из текущих фильтров", () => {
    expect(filtersFromState({ ...blank, city: "kursk" }, { sort: "price", venue: "kursk-filarmoniya" })).toEqual({
      city: "kursk",
      sort: "price",
      venue: "kursk-filarmoniya",
    });
  });

  it("фильтры → поля → фильтры даёт то же самое", () => {
    const sets: EventFilters[] = [
      {},
      { city: "belgorod", category: ["concerts", "kids"], q: "джаз", when: "week", sort: "popular" },
      { date: "2026-10-20", priceMin: 500, priceMax: 2000 },
      { from: "2026-10-15", to: "2026-10-20", free: true },
      { city: "orel", venue: "orel-teatr", priceMax: 1500 },
    ];
    for (const f of sets) expect(filtersFromState(stateFromFilters(f), f)).toEqual(f);
  });

  it("when=date с главной превращается в поля «с» и «по»", () => {
    const s = stateFromFilters({ when: "date", date: "2026-10-20" });
    expect(s).toMatchObject({ when: "", from: "2026-10-20", to: "2026-10-20" });
  });

  it("если заданы и быстрый выбор, и даты — побеждает быстрый (как в слое данных)", () => {
    expect(stateFromFilters({ when: "today", from: "2026-10-15" })).toMatchObject({ when: "today", from: "", to: "" });
  });

  it("цена из адреса подрезается под ползунок", () => {
    const { min, max, step } = PRICE_SLIDER;
    expect(stateFromFilters({ priceMin: 99_999 }).price).toEqual([max - step, max]);
    expect(stateFromFilters({ priceMax: 0 }).price).toEqual([min, min + step]);
    expect(stateFromFilters({ priceMin: 800, priceMax: 700 }).price).toEqual([800, 900]);
  });

  it("подпись ползунка: верхнее положение — «без границы»", () => {
    expect(norm(priceStepLabel(500))).toBe("500 ₽");
    expect(norm(priceStepLabel(PRICE_SLIDER.max))).toBe("5 000+ ₽");
  });
});
