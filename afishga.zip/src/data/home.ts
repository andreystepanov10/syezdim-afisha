import { CITIES, type CitySlug } from "@/lib/cities";
import type { HomeData } from "@/lib/types";
import { getAutoCollections } from "./auto-collections";
import { getCollections, getMapVenues, getPopularEvents, getUpcomingExhibitions, type Ctx } from "./events";

/**
 * Данные главной: популярное и выставки по каждому городу (переключение города — на клиенте, без перезагрузки),
 * площадки для карты и подборки.
 */
export async function getHomeData(ctx: Ctx = {}): Promise<HomeData> {
  const [perCity, mapVenues, collections] = await Promise.all([
    Promise.all(
      CITIES.map(async (city) => ({
        slug: city.slug,
        popular: await getPopularEvents(city.slug, 8, ctx),
        exhibitions: await getUpcomingExhibitions(city.slug, 8, ctx),
        autoCollections: (await getAutoCollections(city.slug, ctx)).slice(0, 6),
      })),
    ),
    getMapVenues(undefined, ctx),
    getCollections(ctx),
  ]);
  return {
    popularByCity: Object.fromEntries(perCity.map((c) => [c.slug, c.popular])) as Record<CitySlug, HomeData["popularByCity"][CitySlug]>,
    exhibitionsByCity: Object.fromEntries(perCity.map((c) => [c.slug, c.exhibitions])) as Record<CitySlug, HomeData["exhibitionsByCity"][CitySlug]>,
    mapVenues,
    collections,
    autoCollectionsByCity: Object.fromEntries(perCity.map((c) => [c.slug, c.autoCollections])) as HomeData["autoCollectionsByCity"],
  };
}
