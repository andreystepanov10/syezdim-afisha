import { asc, gte, sql } from "drizzle-orm";
import { getDb, type Db } from "@/db/client";
import { pageViews } from "@/db/schema";
import { addDays, isoDayMsk, startOfDayMsk } from "@/lib/time";

export type Ctx = { db?: Db };

export type DailyStat = { day: string; views: number; uniqueVisitors: number };
export type PathStat = { path: string; views: number };

/** Пишет анонимный просмотр — без IP и User-Agent, только device_id (см. schema.ts) */
export async function recordPageView(input: { path: string; deviceId: string }, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.insert(pageViews).values({ day: isoDayMsk(new Date()), path: input.path, deviceId: input.deviceId });
}

function fromDayFor(days: number): string {
  return isoDayMsk(addDays(startOfDayMsk(new Date()), -(days - 1)));
}

/** Просмотры и уникальные посетители по дням за последние `days` дней (включая сегодня), по возрастанию даты */
export async function getDailyStats(days: number, ctx: Ctx = {}): Promise<DailyStat[]> {
  const db = ctx.db ?? (await getDb());
  const fromDay = fromDayFor(days);
  const rows = await db
    .select({
      day: pageViews.day,
      views: sql<number>`count(*)`.mapWith(Number),
      uniqueVisitors: sql<number>`count(distinct ${pageViews.deviceId})`.mapWith(Number),
    })
    .from(pageViews)
    .where(gte(pageViews.day, fromDay))
    .groupBy(pageViews.day)
    .orderBy(asc(pageViews.day));
  return rows;
}

/** Самые посещаемые страницы за последние `days` дней, по убыванию просмотров */
export async function getTopPaths(days: number, limit: number, ctx: Ctx = {}): Promise<PathStat[]> {
  const db = ctx.db ?? (await getDb());
  const fromDay = fromDayFor(days);
  const rows = await db
    .select({ path: pageViews.path, views: sql<number>`count(*)`.mapWith(Number) })
    .from(pageViews)
    .where(gte(pageViews.day, fromDay))
    .groupBy(pageViews.path)
    .orderBy(sql`count(*) desc`)
    .limit(limit);
  return rows;
}
