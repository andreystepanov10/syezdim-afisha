// Фильтры событий: разбор параметров из URL/API (с проверкой) и вычисление диапазона дат.
// Здесь нет обращений к БД — модуль безопасно импортировать откуда угодно.
import { z } from "zod";
import { CATEGORIES, type CategorySlug } from "@/lib/categories";
import { CITIES, type CitySlug } from "@/lib/cities";
import { addDays, parseDayMsk, startOfDayMsk, weekdayMsk } from "@/lib/time";

export const WHEN_VALUES = ["today", "tomorrow", "weekend", "week", "date"] as const;
export const SORT_VALUES = ["date", "popular", "price", "relevance"] as const;
export type When = (typeof WHEN_VALUES)[number];
export type Sort = (typeof SORT_VALUES)[number];

export type EventFilters = {
  city?: CitySlug;
  category?: CategorySlug[];
  /** Поисковая строка */
  q?: string;
  when?: When;
  /** Конкретный день (вместе с when=date или сам по себе), YYYY-MM-DD */
  date?: string;
  /** Произвольный период, YYYY-MM-DD (to включительно) */
  from?: string;
  to?: string;
  priceMin?: number;
  priceMax?: number;
  free?: boolean;
  /** Принимают Пушкинскую карту — берём как факт от источника, см. src/lib/import */
  pushkinCard?: boolean;
  venue?: string;
  /** Населённый пункт области («Старый Оскол») — для страниц городов области; в адрес каталога не попадает */
  locality?: string;
  /**
   * Склеить сеансы: один спектакль в одной площадке много раз за период — одна карточка (ближайший сеанс) с
   * числом остальных дат. Для каталога, посадочных и подборок; в адрес не попадает
   */
  groupSessions?: boolean;
  sort?: Sort;
  page?: number;
  pageSize?: number;
};

const citySlugs = CITIES.map((c) => c.slug) as [CitySlug, ...CitySlug[]];
const categorySlugs = CATEGORIES.map((c) => c.slug) as [CategorySlug, ...CategorySlug[]];
const isoDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((s) => parseDayMsk(s) !== null, "Некорректная дата");

const schema = z.object({
  city: z.enum(citySlugs).optional(),
  category: z.array(z.enum(categorySlugs)).max(CATEGORIES.length).optional(),
  q: z.string().trim().min(1).max(100).optional(),
  when: z.enum(WHEN_VALUES).optional(),
  date: isoDate.optional(),
  from: isoDate.optional(),
  to: isoDate.optional(),
  priceMin: z.coerce.number().int().min(0).max(1_000_000).optional(),
  priceMax: z.coerce.number().int().min(0).max(1_000_000).optional(),
  free: z.enum(["1", "true"]).optional(),
  pushkinCard: z.enum(["1", "true"]).optional(),
  venue: z.string().regex(/^[a-z0-9-]{1,80}$/).optional(),
  sort: z.enum(SORT_VALUES).optional(),
  page: z.coerce.number().int().min(1).max(500).default(1),
  pageSize: z.coerce.number().int().min(1).max(48).default(12),
});

export type RawParams = Record<string, string | string[] | undefined>;

type ParseResult = { ok: true; value: EventFilters } | { ok: false; issues: string[] };

const KEYS = ["city", "q", "when", "date", "from", "to", "priceMin", "priceMax", "free", "pushkinCard", "venue", "sort", "page", "pageSize"] as const;

/**
 * Разбирает параметры запроса. strict=true (API) — при ошибке возвращает список проблем;
 * strict=false (страницы) — молча выбрасывает некорректные параметры, чтобы страница открывалась всегда.
 */
export function parseFilters(raw: RawParams, options: { strict: boolean }): ParseResult {
  const first = (key: string) => {
    const v = raw[key];
    const s = Array.isArray(v) ? v[0] : v;
    return s === undefined || s === "" ? undefined : s;
  };
  const input: Record<string, unknown> = {};
  for (const key of KEYS) input[key] = first(key);
  const cats = ([] as string[])
    .concat(raw.category ?? [])
    .flatMap((v) => v.split(","))
    .map((v) => v.trim())
    .filter(Boolean);
  input.category = cats.length ? cats : undefined;

  let result = schema.safeParse(input);
  if (!result.success && !options.strict) {
    for (const issue of result.error.issues) delete input[String(issue.path[0])];
    result = schema.safeParse(input);
  }
  if (!result.success) {
    return { ok: false, issues: result.error.issues.map((i) => `${i.path.join(".") || "params"}: ${i.message}`) };
  }
  const { free, pushkinCard, ...rest } = result.data;
  return { ok: true, value: { ...rest, ...(free ? { free: true } : {}), ...(pushkinCard ? { pushkinCard: true } : {}) } };
}

/**
 * Диапазон дат по фильтрам (сутки — по МСК). Нижняя граница никогда не раньше `now`:
 * события, которые уже начались, в выдачу не попадают.
 */
export function resolveRange(filters: Pick<EventFilters, "when" | "date" | "from" | "to">, now: Date): { from: Date; to?: Date } {
  const today = startOfDayMsk(now);
  let from: Date | undefined;
  let to: Date | undefined;

  switch (filters.when) {
    case "today":
      from = today;
      to = addDays(today, 1);
      break;
    case "tomorrow":
      from = addDays(today, 1);
      to = addDays(today, 2);
      break;
    case "week":
      from = today;
      to = addDays(today, 7);
      break;
    case "weekend": {
      const dow = weekdayMsk(now); // 0 — воскресенье … 6 — суббота
      if (dow === 6) {
        from = today;
        to = addDays(today, 2);
      } else if (dow === 0) {
        from = today;
        to = addDays(today, 1);
      } else {
        from = addDays(today, 6 - dow);
        to = addDays(from, 2);
      }
      break;
    }
  }

  if (!from && filters.date) {
    const day = parseDayMsk(filters.date);
    if (day) {
      from = day;
      to = addDays(day, 1);
    }
  }
  if (!from && filters.from) from = parseDayMsk(filters.from) ?? undefined;
  if (!to && filters.to) {
    const end = parseDayMsk(filters.to);
    if (end) to = addDays(end, 1);
  }

  return { from: from && from > now ? from : now, to };
}

/** Строка для to_tsquery: слова через AND, каждое с префиксным совпадением («джаз» найдёт «джазовый»). null — искать нечего */
export function toTsQuery(q: string): string | null {
  const words = q.toLowerCase().match(/[\p{L}\p{N}]+/gu);
  if (!words) return null;
  return words
    .slice(0, 8)
    .map((w) => `${w}:*`)
    .join(" & ");
}
