// Демо-данные для БД: по 14 событий в каждом из 6 городов (8 обычных + 6 выставок), площадки, типы билетов
// и три редакционные подборки. Все названия и площадки вымышленные, ссылки на билеты ведут на example.com.
// Даты считаются от «сегодня» в момент заполнения БД — демо никогда не «протухает».
// Детерминировано (без Math.random): одна и та же дата запуска даёт одни и те же данные.
// Настоящие события вносятся через админку (этап 6), демо-записи удаляются командой db:purge-demo.
import type { CategorySlug } from "@/lib/categories";
import { CITIES, type CitySlug } from "@/lib/cities";
import { addDays, startOfDayMsk, weekdayMsk } from "@/lib/time";

export type VenueKind = "theatre" | "hall" | "gallery" | "park" | "club" | "cinema" | "center";

// Вымышленные точки: смещения от центра города (градусы)
const VENUE_KINDS: Record<VenueKind, { name: string; address: string; dLat: number; dLon: number }> = {
  theatre: { name: "Драматический театр", address: "пр-т Революции, 10", dLat: 0.006, dLon: -0.012 },
  hall: { name: "Городская филармония", address: "ул. Кольцовская, 4", dLat: -0.008, dLon: 0.01 },
  gallery: { name: "Художественный музей", address: "ул. Ленина, 22", dLat: 0.011, dLon: 0.008 },
  park: { name: "Центральный парк", address: "Центральный парк, вход с ул. Мира", dLat: -0.014, dLon: -0.009 },
  club: { name: "Клуб «Ноты и точки»", address: "ул. Советская, 15", dLat: 0.002, dLon: 0.018 },
  cinema: { name: "Кинотеатр «Звезда»", address: "ул. Победы, 31", dLat: -0.003, dLon: -0.02 },
  center: { name: "Центр «Радуга»", address: "ул. Садовая, 7", dLat: 0.015, dLon: -0.004 },
};

type Template = {
  key: string;
  title: string;
  description: string;
  category: CategorySlug;
  kind: VenueKind;
  /** Базовая («стандартная») цена, руб. 0 — бесплатно */
  price: number;
  rating: number;
  ratingCount: number;
  hot?: boolean;
  age?: number;
  image: string;
  hour: number;
};

const GENERAL: Template[] = [
  { key: "kvartirnik", title: "Квартирник у камина: вечер живой музыки", description: "Камерный вечер живой музыки в уютной обстановке: любимые песни, акустика и разговоры с музыкантами между композициями. Количество мест ограничено.", category: "concerts", kind: "club", price: 800, rating: 4.9, ratingCount: 30, hot: true, image: "ph-2", hour: 20 },
  { key: "revizor", title: "Спектакль «Ревизор»", description: "Классическая комедия Гоголя в новой постановке драматического театра. Два акта, антракт, живой оркестр.", category: "theatre", kind: "theatre", price: 1500, rating: 4.8, ratingCount: 112, image: "ph-3", hour: 18 },
  { key: "dzhaz", title: "Джазовый вечер в филармонии", description: "Вечер джаза в филармонии: стандарты, авторские композиции и импровизации. Выступает городской джазовый ансамбль.", category: "concerts", kind: "hall", price: 1200, rating: 5, ratingCount: 47, age: 18, image: "ph-10", hour: 19 },
  { key: "rospis-chashek", title: "Мастер-класс по росписи кофейных чашек", description: "Мастер-класс для начинающих: распишете кофейные чашки акриловыми красками под руководством художника. Все материалы включены, готовую чашку заберёте домой.", category: "workshops", kind: "center", price: 1500, rating: 4.7, ratingCount: 9, image: "ph-8", hour: 17 },
  { key: "ulichnaya-eda", title: "Фестиваль уличной еды «Вкус дороги»", description: "Фестиваль уличной еды: фудтраки, дегустации, мастер-классы от шефов и живая музыка на главной площадке парка.", category: "festivals", kind: "park", price: 300, rating: 4.5, ratingCount: 64, hot: true, image: "ph-1", hour: 12 },
  { key: "kinopokaz-smena", title: "Кинопоказ «Смена» с обсуждением", description: "Показ фильма «Смена» с обсуждением после сеанса. Гость вечера расскажет о съёмках и ответит на вопросы зрителей.", category: "cinema", kind: "cinema", price: 450, rating: 4.4, ratingCount: 21, image: "ph-7", hour: 20 },
  { key: "semejnyj-kvest", title: "Семейный квест по городу", description: "Семейный квест по городу: команды из детей и взрослых разгадывают загадки на маршруте. Подходит для детей от 6 лет, участие бесплатное по регистрации.", category: "kids", kind: "center", price: 0, rating: 4.6, ratingCount: 18, image: "ph-5", hour: 11 },
  { key: "simfoniya", title: "Симфонический оркестр: осенняя программа", description: "Осенняя программа симфонического оркестра: произведения русских композиторов. Дирижирует приглашённый маэстро.", category: "concerts", kind: "hall", price: 1800, rating: 4.9, ratingCount: 88, image: "ph-9", hour: 19 },
  { key: "kukolnyj", title: "Кукольный спектакль «Сказка о дороге»", description: "Кукольный спектакль для малышей и их родителей: добрая сказка о путешествии и поиске друзей. Продолжительность — 50 минут.", category: "kids", kind: "theatre", price: 600, rating: 4.6, ratingCount: 40, image: "ph-11", hour: 12 },
  { key: "yarmarka", title: "Ярмарка «Осенний урожай»", description: "Осенняя ярмарка фермеров и мастеров: овощи, мёд, выпечка, рукоделие. Вход свободный, детская площадка и музыка.", category: "festivals", kind: "park", price: 0, rating: 4.3, ratingCount: 52, image: "ph-6", hour: 10 },
  { key: "rok-live", title: "Рок-фестиваль «Чернозём Live»", description: "Open-air фестиваль рок-музыки: выступления местных и приглашённых групп, фуд-корт, зона отдыха.", category: "concerts", kind: "park", price: 1400, rating: 4.8, ratingCount: 76, hot: true, age: 18, image: "ph-7", hour: 16 },
  { key: "goncharnaya", title: "Гончарная мастерская: первый круг", description: "Знакомство с гончарным кругом: за два часа сформируете свою первую чашку или миску. Материалы и обжиг включены.", category: "workshops", kind: "center", price: 2200, rating: 4.9, ratingCount: 15, image: "ph-12", hour: 18 },
];

const EXHIBITIONS: Template[] = [
  { key: "vystavka-chernozem", title: "Выставка «Чернозём: земля и свет»", description: "Фотографии и живопись о плодородных землях Черноземья: поля, реки и люди, которые на них работают. Вход свободный.", category: "exhibitions", kind: "gallery", price: 0, rating: 4.6, ratingCount: 18, image: "ph-4", hour: 11 },
  { key: "vystavka-dorogi", title: "Фотовыставка «Дороги России»", description: "Фотовыставка о дорогах и путешествиях по России: снимки шести авторов, истории поездок и карта маршрутов.", category: "exhibitions", kind: "gallery", price: 300, rating: 4.7, ratingCount: 26, image: "ph-14", hour: 11 },
  { key: "vystavka-retro-avto", title: "Ретро-авто и мотоциклы", description: "Ретро-автомобили и мотоциклы советской эпохи из частных коллекций региона. Можно сесть за руль и сфотографироваться.", category: "exhibitions", kind: "gallery", price: 500, rating: 4.8, ratingCount: 34, hot: true, image: "ph-13", hour: 10 },
  { key: "vystavka-keramika", title: "Керамика Черноземья", description: "Современная и традиционная керамика мастеров Черноземья: посуда, игрушки, скульптура.", category: "exhibitions", kind: "gallery", price: 400, rating: 4.5, ratingCount: 12, image: "ph-8", hour: 11 },
  { key: "vystavka-plener", title: "Осенний пленэр: живопись", description: "Осенний пленэр: живопись местных художников, написанная на природе. Работы можно приобрести.", category: "exhibitions", kind: "gallery", price: 250, rating: 4.4, ratingCount: 9, image: "ph-12", hour: 12 },
  { key: "vystavka-skazki", title: "Иллюстрации к русским сказкам", description: "Иллюстрации к русским сказкам от книжных художников: оригиналы работ, эскизы и интерактивная зона для детей.", category: "exhibitions", kind: "gallery", price: 350, rating: 4.7, ratingCount: 21, image: "ph-4", hour: 10 },
  { key: "vystavka-makety", title: "Город в миниатюре: макеты", description: "Город в миниатюре: детальные макеты исторических зданий и целых кварталов, собранные местными моделистами.", category: "exhibitions", kind: "gallery", price: 450, rating: 4.6, ratingCount: 17, image: "ph-14", hour: 11 },
  { key: "vystavka-tekstil", title: "Текстиль и узор: народные промыслы", description: "Народные промыслы: вышивка, кружево, роспись по ткани. Мастер-классы по выходным.", category: "exhibitions", kind: "gallery", price: 300, rating: 4.5, ratingCount: 14, image: "ph-13", hour: 12 },
];

const roundTo = (value: number, step: number) => Math.max(step, Math.round(value / step) * step);

/** Категории билетов зависят от типа события; бесплатные события билетов не имеют */
function ticketTypesFor(tpl: Template): { name: string; priceRub: number }[] {
  if (tpl.price === 0) return [];
  const p = tpl.price;
  if (tpl.category === "exhibitions") {
    return [
      { name: "Взрослый", priceRub: p },
      { name: "Студенческий", priceRub: roundTo(p * 0.6, 50) },
      { name: "Детский", priceRub: roundTo(p * 0.4, 50) },
    ];
  }
  if (tpl.category === "concerts" || tpl.category === "theatre") {
    return [
      { name: "Балкон", priceRub: roundTo(p * 0.7, 50) },
      { name: "Партер", priceRub: p },
      { name: "VIP", priceRub: roundTo(p * 2.2, 100) },
    ];
  }
  return [
    { name: "Студенческий", priceRub: roundTo(p * 0.75, 50) },
    { name: "Стандарт", priceRub: p },
  ];
}

export type FixtureVenue = { slug: string; citySlug: CitySlug; name: string; address: string; lat: number; lon: number };

export type FixtureEvent = {
  slug: string;
  title: string;
  description: string;
  citySlug: CitySlug;
  venueSlug: string;
  categorySlug: CategorySlug;
  startsAt: Date;
  endsAt?: Date;
  priceFrom: number;
  priceTo: number;
  ageLimit?: number;
  image: string;
  rating: number;
  ratingCount: number;
  isHot: boolean;
  ticketUrl: string;
  ticketTypes: { name: string; priceRub: number }[];
};

export type FixtureCollection = { slug: string; title: string; description: string; image: string; eventSlugs: string[] };

const score = (e: Pick<FixtureEvent, "rating" | "ratingCount">) => e.rating * Math.log(e.ratingCount + 1);

export function buildFixtures(now: Date = new Date()) {
  const today = startOfDayMsk(now);
  const venues = new Map<string, FixtureVenue>();
  const events: FixtureEvent[] = [];

  CITIES.forEach((city, cityIndex) => {
    const make = (tpl: Template, k: number, dayOffset: number, minute: number, durationDays?: number) => {
      const venue = VENUE_KINDS[tpl.kind];
      const venueSlug = `${city.slug}-${tpl.kind}`;
      if (!venues.has(venueSlug)) {
        venues.set(venueSlug, {
          slug: venueSlug,
          citySlug: city.slug,
          name: venue.name,
          address: venue.address,
          lat: +(city.lat + venue.dLat).toFixed(5),
          lon: +(city.lon + venue.dLon).toFixed(5),
        });
      }
      const types = ticketTypesFor(tpl);
      const prices = types.map((t) => t.priceRub);
      const startsAt = new Date(addDays(today, dayOffset).getTime() + (tpl.hour * 60 + minute) * 60_000);
      events.push({
        slug: `${city.slug}-${tpl.key}`,
        title: tpl.title,
        description: tpl.description,
        citySlug: city.slug,
        venueSlug,
        categorySlug: tpl.category,
        startsAt,
        endsAt: durationDays ? addDays(startsAt, durationDays) : undefined,
        priceFrom: prices.length ? Math.min(...prices) : 0,
        priceTo: prices.length ? Math.max(...prices) : 0,
        ageLimit: tpl.age,
        image: `/placeholders/${tpl.image}.svg`,
        rating: tpl.rating,
        ratingCount: tpl.ratingCount + cityIndex * 3 + k,
        isHot: Boolean(tpl.hot),
        ticketUrl: `https://example.com/tickets/${city.slug}-${tpl.key}`,
        ticketTypes: types,
      });
    };
    for (let k = 0; k < 8; k++) make(GENERAL[(cityIndex * 3 + k) % GENERAL.length], k, 2 + ((k * 4 + cityIndex * 3) % 26), k % 2 ? 30 : 0);
    for (let k = 0; k < 6; k++) make(EXHIBITIONS[(cityIndex * 2 + k) % EXHIBITIONS.length], k, 1 + ((k * 5 + cityIndex * 2) % 20), 0, 40);
  });

  const top = (pick: (e: FixtureEvent) => boolean) =>
    events
      .filter(pick)
      .sort((a, b) => score(b) - score(a))
      .slice(0, 12)
      .map((e) => e.slug);

  const collections: FixtureCollection[] = [
    { slug: "top-weekend", title: "Топ уикендов", description: "Лучшие события на субботу и воскресенье по всему Черноземью.", image: "/placeholders/col-weekend.svg", eventSlugs: top((e) => [0, 6].includes(weekdayMsk(e.startsAt))) },
    { slug: "with-kids", title: "Куда поехать с детьми", description: "Спектакли, квесты и мастер-классы для всей семьи.", image: "/placeholders/col-kids.svg", eventSlugs: top((e) => e.categorySlug === "kids") },
    { slug: "free", title: "Бесплатно и интересно", description: "События, на которые можно попасть бесплатно.", image: "/placeholders/col-free.svg", eventSlugs: top((e) => e.priceFrom === 0) },
  ];

  return { venues: [...venues.values()], events, collections };
}
