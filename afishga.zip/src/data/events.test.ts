import { eq } from "drizzle-orm";
import { beforeAll, describe, expect, it } from "vitest";
import { createDemoDb, type Db } from "@/db/client";
import { categories, cities, events, ticketTypes } from "@/db/schema";
import { purgeDemo } from "@/db/seed";
import { CITIES } from "@/lib/cities";
import { addDays, addMonths, isoDayMsk, startOfDayMsk, startOfMonthMsk } from "@/lib/time";
import { buildFixtures } from "./fixtures";
import {
  getCollectionBySlug,
  getCollections,
  getDailyCounts,
  getEventBySlug,
  getMapVenues,
  getPopularEvents,
  getSimilarEvents,
  getUpcomingExhibitions,
  getVenueName,
  getVenues,
  listEvents,
  type Ctx,
} from "./events";

// Среда, 23 сентября 2026, 10:00 МСК — от неё считаются все даты демо-данных
const NOW = new Date("2026-09-23T07:00:00Z");
const TODAY = startOfDayMsk(NOW);
const ALL = 84; // 6 городов × (8 событий + 6 выставок)

let db: Db;
let ctx: Ctx;
beforeAll(async () => {
  db = await createDemoDb({ now: NOW });
  ctx = { db, now: NOW };
});

const score = (e: { rating?: number; ratingCount?: number }) => (e.rating ?? 0) * Math.log((e.ratingCount ?? 0) + 1);
const slugs = (items: { slug: string }[]) => items.map((i) => i.slug).sort();

describe("seed", () => {
  it("заполняет справочники и демо-события", async () => {
    expect((await db.select().from(cities)).length).toBe(6);
    expect((await db.select().from(categories)).length).toBe(8);
    expect((await listEvents({ pageSize: 1 }, ctx)).total).toBe(ALL);
  });

  it("по 14 событий в каждом городе, 6 из них — выставки", async () => {
    for (const city of CITIES) {
      expect((await listEvents({ city: city.slug }, ctx)).total).toBe(14);
      expect((await listEvents({ city: city.slug, category: ["exhibitions"] }, ctx)).total).toBe(6);
    }
  });
});

describe("фильтры", () => {
  it("несколько категорий сразу", async () => {
    const r = await listEvents({ city: "voronezh", category: ["concerts", "theatre"], pageSize: 48 }, ctx);
    expect(r.total).toBeGreaterThan(0);
    expect(r.items.every((e) => e.category === "concerts" || e.category === "theatre")).toBe(true);
  });

  // Ожидание считаем независимо, из фикстур: событие подходит, если оно идёт в периоде [from, to):
  // началось до конца периода и не закончилось до его начала (выставки длятся 40 дней).
  const fixtures = buildFixtures(NOW).events;
  const overlapping = (from: Date, to: Date) =>
    fixtures
      .filter((e) => e.startsAt < to && (e.endsAt ?? e.startsAt) >= (from > NOW ? from : NOW))
      .map((e) => e.slug)
      .sort();

  it("«завтра»: события завтрашнего дня по МСК и идущие выставки", async () => {
    const r = await listEvents({ when: "tomorrow", pageSize: 48 }, ctx);
    expect(r.total).toBeGreaterThan(0);
    expect(slugs(r.items)).toEqual(overlapping(addDays(TODAY, 1), addDays(TODAY, 2)));
  });

  it("«на выходных» из среды — суббота и воскресенье (26–27 сентября)", async () => {
    const sat = addDays(TODAY, 3);
    const r = await listEvents({ when: "weekend", pageSize: 48 }, ctx);
    expect(r.total).toBeGreaterThan(0);
    expect(slugs(r.items)).toEqual(overlapping(sat, addDays(sat, 2)));
    // разовые события — строго внутри выходных
    for (const e of r.items.filter((i) => i.category !== "exhibitions")) {
      const t = new Date(e.startsAt).getTime();
      expect(t).toBeGreaterThanOrEqual(sat.getTime());
      expect(t).toBeLessThan(sat.getTime() + 2 * 86_400_000);
    }
  });

  it("конкретная дата и период from–to (to включительно)", async () => {
    const dayStart = addDays(TODAY, 5);
    const day = new Date(dayStart.getTime() + 3 * 3600_000).toISOString().slice(0, 10); // YYYY-MM-DD по МСК
    const one = await listEvents({ date: day, pageSize: 48 }, ctx);
    const span = await listEvents({ from: day, to: day, pageSize: 48 }, ctx);
    expect(one.total).toBeGreaterThan(0);
    expect(slugs(one.items)).toEqual(overlapping(dayStart, addDays(dayStart, 1)));
    expect(slugs(span.items)).toEqual(slugs(one.items));
  });

  it("выставка, идущая с прошлой недели, попадает в «сегодня» и стоит в начале периода", async () => {
    // «сейчас» = через 10 дней: выставки, открывшиеся раньше, ещё идут (40 дней)
    const later = new Date(NOW.getTime() + 10 * 86_400_000);
    const r = await listEvents({ when: "today", pageSize: 48 }, { db, now: later });
    const running = r.items.filter((e) => e.category === "exhibitions" && new Date(e.startsAt) < later);
    expect(running.length).toBeGreaterThan(0);
    const firstSingle = r.items.findIndex((e) => e.category !== "exhibitions");
    if (firstSingle !== -1) expect(r.items.slice(0, firstSingle).every((e) => e.category === "exhibitions")).toBe(true);
  });

  it("цена: priceMax и «бесплатно»", async () => {
    const cheap = await listEvents({ priceMax: 500, pageSize: 48 }, ctx);
    expect(cheap.total).toBeGreaterThan(0);
    expect(cheap.items.every((e) => (e.priceFrom ?? Infinity) <= 500)).toBe(true);

    const free = await listEvents({ free: true, pageSize: 48 }, ctx);
    expect(free.total).toBeGreaterThan(0);
    expect(free.items.every((e) => e.priceFrom === 0 && e.badges?.includes("free"))).toBe(true);
  });

  it("площадка", async () => {
    const r = await listEvents({ venue: "kursk-theatre", pageSize: 48 }, ctx);
    expect(r.total).toBeGreaterThan(0);
    expect(r.items.every((e) => e.city === "kursk" && e.subtitle === "Драматический театр")).toBe(true);
  });

  it("прошедшие события не показываются (сдвиг «сейчас» на 15 дней)", async () => {
    const later = new Date(NOW.getTime() + 15 * 86_400_000);
    const r = await listEvents({ pageSize: 48 }, { db, now: later });
    expect(r.total).toBeLessThan(ALL);
    // выставки со сроком 40 дней остаются, одиночные события до «сейчас» пропадают
    expect(r.items.every((e) => new Date(e.startsAt).getTime() >= later.getTime() || e.category === "exhibitions")).toBe(true);
  });

  it("черновики и архив не попадают в выдачу", async () => {
    const [target] = await db.select({ id: events.id, slug: events.slug }).from(events).limit(1);
    await db.update(events).set({ status: "draft" }).where(eq(events.id, target.id));
    expect((await listEvents({ pageSize: 1 }, ctx)).total).toBe(ALL - 1);
    expect(await getEventBySlug(target.slug, ctx)).toBeNull();
    await db.update(events).set({ status: "published" }).where(eq(events.id, target.id));
    expect((await listEvents({ pageSize: 1 }, ctx)).total).toBe(ALL);
  });
});

describe("поиск", () => {
  const fx = buildFixtures(NOW);
  const expected = (test: (text: string) => boolean) => fx.events.filter((e) => test(`${e.title} ${e.description}`.toLowerCase())).map((e) => e.slug).sort();

  it("«джаз» находит и «джазовый», и «джаза» — ровно те события, где это слово есть", async () => {
    const r = await listEvents({ q: "джаз", pageSize: 48 }, ctx);
    expect(slugs(r.items)).toEqual(expected((t) => t.includes("джаз")));
    expect(r.total).toBeGreaterThan(0);
  });

  it("префикс: «ревиз» → «Ревизор»", async () => {
    const r = await listEvents({ q: "ревиз", pageSize: 48 }, ctx);
    expect(slugs(r.items)).toEqual(expected((t) => t.includes("ревизор")));
  });

  it("несколько слов — все должны встретиться", async () => {
    const r = await listEvents({ q: "кофейных чашек", pageSize: 48 }, ctx);
    expect(r.total).toBeGreaterThan(0);
    expect(r.items.every((e) => e.title.includes("кофейных чашек"))).toBe(true);
  });

  it("ищет и по названию площадки", async () => {
    const r = await listEvents({ q: "филармония", pageSize: 48 }, ctx);
    expect(r.total).toBeGreaterThan(0);
    expect(r.items.every((e) => `${e.title} ${e.subtitle}`.toLowerCase().includes("филармони"))).toBe(true);
  });

  it("поиск + фильтры вместе", async () => {
    const r = await listEvents({ q: "выставка", city: "orel", category: ["exhibitions"], pageSize: 48 }, ctx);
    expect(r.items.every((e) => e.city === "orel" && e.category === "exhibitions")).toBe(true);
  });

  it("по релевантности заголовок важнее описания", async () => {
    const r = await listEvents({ q: "джаз", sort: "relevance", pageSize: 48 }, ctx);
    const firstTitleHit = r.items.findIndex((e) => e.title.toLowerCase().includes("джаз"));
    const firstDescOnly = r.items.findIndex((e) => !e.title.toLowerCase().includes("джаз"));
    if (firstDescOnly !== -1) expect(firstTitleHit).toBeLessThan(firstDescOnly);
  });

  it("строка без букв ничего не находит, а SQL-инъекция безвредна", async () => {
    expect((await listEvents({ q: "!!! ???" }, ctx)).total).toBe(0);
    const evil = await listEvents({ q: "'; DROP TABLE events; --" }, ctx);
    expect(evil.total).toBeGreaterThanOrEqual(0);
    expect((await listEvents({ pageSize: 1 }, ctx)).total).toBe(ALL); // таблица на месте
  });
});

describe("пагинация и сортировка", () => {
  it("страницы не пересекаются и в сумме дают всё", async () => {
    const seen: string[] = [];
    let pageCount = 0;
    for (let page = 1; page <= 9; page++) {
      const r = await listEvents({ page, pageSize: 10 }, ctx);
      pageCount = r.pageCount;
      expect(r.items.length).toBe(page < 9 ? 10 : 4);
      seen.push(...r.items.map((e) => e.slug));
    }
    expect(pageCount).toBe(9);
    expect(new Set(seen).size).toBe(ALL);
  });

  it("страница за пределами выдачи — пустая, но total сохраняется", async () => {
    const r = await listEvents({ page: 50, pageSize: 10 }, ctx);
    expect(r.items).toEqual([]);
    expect(r.total).toBe(ALL);
  });

  it("sort=date, price и popular", async () => {
    const byDate = (await listEvents({ pageSize: 48, sort: "date" }, ctx)).items.map((e) => new Date(e.startsAt).getTime());
    expect(byDate).toEqual([...byDate].sort((a, b) => a - b));

    const byPrice = (await listEvents({ pageSize: 48, sort: "price" }, ctx)).items.map((e) => e.priceFrom ?? Infinity);
    expect(byPrice).toEqual([...byPrice].sort((a, b) => a - b));

    const byPop = (await listEvents({ pageSize: 48, sort: "popular" }, ctx)).items.map(score);
    expect(byPop).toEqual([...byPop].sort((a, b) => b - a));
  });
});

describe("блоки главной", () => {
  it("популярные: 8 событий города по убыванию популярности", async () => {
    for (const city of CITIES) {
      const list = await getPopularEvents(city.slug, 8, ctx);
      expect(list).toHaveLength(8);
      expect(list.every((e) => e.city === city.slug)).toBe(true);
      const s = list.map(score);
      expect(s).toEqual([...s].sort((a, b) => b - a));
    }
  });

  it("выставки: 6 штук, только выставки, по возрастанию даты", async () => {
    const list = await getUpcomingExhibitions("tambov", 8, ctx);
    expect(list).toHaveLength(6);
    expect(list.every((e) => e.category === "exhibitions")).toBe(true);
    const t = list.map((e) => new Date(e.startsAt).getTime());
    expect(t).toEqual([...t].sort((a, b) => a - b));
  });

  it("карта: все события сгруппированы по площадкам", async () => {
    const map = await getMapVenues(undefined, ctx);
    expect(map.length).toBeGreaterThan(6);
    expect(map.every((v) => v.events.length > 0 && v.lat > 49 && v.lat < 54)).toBe(true);
    expect(map.reduce((n, v) => n + v.events.length, 0)).toBe(ALL);
  });

  it("подборки: три, с количеством событий", async () => {
    const list = await getCollections(ctx);
    expect(list.map((c) => c.slug)).toEqual(["top-weekend", "with-kids", "free"]);
    expect(list.every((c) => (c.count ?? 0) > 0 && (c.count ?? 0) <= 12)).toBe(true);
  });

  it("название площадки по slug (подпись фильтра); неизвестная — null", async () => {
    const [venue] = await getMapVenues(undefined, ctx);
    expect(await getVenueName(venue.id, ctx)).toBe(venue.name);
    expect(await getVenueName("net-takoj-ploshchadki", ctx)).toBeNull();
  });

  it("каталог площадок: адрес, город и число ближайших событий по каждой площадке", async () => {
    const fx = buildFixtures(NOW);
    const expected = new Map(fx.venues.map((v) => [v.slug, { citySlug: v.citySlug, name: v.name, address: v.address, count: 0 }]));
    for (const e of fx.events) {
      if ((e.endsAt ?? e.startsAt) >= NOW) expected.get(e.venueSlug)!.count++;
    }

    const all = await getVenues(undefined, ctx);
    expect(all.length).toBe(fx.venues.length);
    for (const v of all) {
      const exp = expected.get(v.slug)!;
      expect(v).toMatchObject({ city: exp.citySlug, name: exp.name, address: exp.address, upcomingCount: exp.count });
    }

    const kursk = await getVenues("kursk", ctx);
    expect(kursk.length).toBe(fx.venues.filter((v) => v.citySlug === "kursk").length);
    expect(kursk.every((v) => v.city === "kursk")).toBe(true);
  });

  it("количество событий по дням месяца — по дате начала, суммарно совпадает с числом событий месяца", async () => {
    const fx = buildFixtures(NOW);
    const from = startOfMonthMsk(NOW);
    const to = addMonths(from, 1);
    const counts = await getDailyCounts({ from, to }, undefined, ctx);

    const inMonth = fx.events.filter((e) => e.startsAt >= from && e.startsAt < to);
    expect([...counts.values()].reduce((a, b) => a + b, 0)).toBe(inMonth.length);

    const [sampleDay] = counts.keys();
    expect(counts.get(sampleDay)).toBe(inMonth.filter((e) => isoDayMsk(e.startsAt) === sampleDay).length);

    const kurskCounts = await getDailyCounts({ from, to }, "kursk", ctx);
    const kurskInMonth = inMonth.filter((e) => e.citySlug === "kursk");
    expect([...kurskCounts.values()].reduce((a, b) => a + b, 0)).toBe(kurskInMonth.length);
  });

  it("подборка целиком: описание и события в порядке редактора, без прошедших; неизвестная — null", async () => {
    const fx = buildFixtures(NOW);
    const expectedSlugs = fx.collections.find((c) => c.slug === "with-kids")!.eventSlugs;
    const c = await getCollectionBySlug("with-kids", ctx);
    expect(c).not.toBeNull();
    expect(c!.title).toBe("Куда поехать с детьми");
    expect(c!.description.length).toBeGreaterThan(0);
    expect(c!.events.every((e) => e.category === "kids")).toBe(true);
    // тот же порядок, что задан подборкой (только актуальные события — все eventSlugs здесь в будущем)
    expect(c!.events.map((e) => e.slug)).toEqual(expectedSlugs);
    expect(await getCollectionBySlug("net-takoj-podborki", ctx)).toBeNull();
  });
});

describe("карточка события", () => {
  it("возвращает описание, площадку, партнёра и типы билетов", async () => {
    const e = await getEventBySlug("voronezh-revizor", ctx);
    expect(e).not.toBeNull();
    expect(e!.venue.name).toBe("Драматический театр");
    expect(e!.partner?.name).toBe("Демо-партнёр");
    expect(e!.ticketTypes.map((t) => t.name)).toEqual(["Балкон", "Партер", "VIP"]);
    expect(e!.priceFrom).toBe(Math.min(...e!.ticketTypes.map((t) => t.priceRub)));
    expect(e!.priceTo).toBe(Math.max(...e!.ticketTypes.map((t) => t.priceRub)));
  });

  it("бесплатное — без типов билетов; несуществующее — null", async () => {
    const free = (await listEvents({ free: true, pageSize: 1 }, ctx)).items[0];
    expect((await getEventBySlug(free.slug, ctx))!.ticketTypes).toEqual([]);
    expect(await getEventBySlug("net-takogo", ctx)).toBeNull();
  });

  it("билеты удаляются вместе с событием (каскад)", async () => {
    const [{ before }] = await db.select({ before: ticketTypes.id }).from(ticketTypes).limit(1);
    expect(before).toBeGreaterThan(0);
  });
});

describe("похожие события", () => {
  it("та же категория и город, без самого события, не больше лимита", async () => {
    const event = await getEventBySlug("voronezh-vystavka-chernozem", ctx);
    const similar = await getSimilarEvents(event!, 4, ctx);
    expect(similar.length).toBeGreaterThan(0);
    expect(similar.length).toBeLessThanOrEqual(4);
    expect(similar.every((e) => e.city === event!.city && e.category === event!.category && e.slug !== event!.slug)).toBe(true);
  });

  it("нет других таких же — пустой список", async () => {
    const event = await getEventBySlug("voronezh-revizor", ctx);
    // в Воронеже единственный спектакль в демо-данных
    expect(await getSimilarEvents(event!, 4, ctx)).toEqual([]);
  });
});

describe("очистка демо-данных", () => {
  it("purgeDemo удаляет демо-записи, но оставляет города и категории", async () => {
    const own = await createDemoDb({ now: NOW });
    expect((await listEvents({ pageSize: 1 }, { db: own, now: NOW })).total).toBe(ALL);
    await purgeDemo(own);
    expect((await listEvents({ pageSize: 1 }, { db: own, now: NOW })).total).toBe(0);
    expect((await getCollections({ db: own, now: NOW })).length).toBe(0);
    expect((await own.select().from(cities)).length).toBe(6);
    expect((await own.select().from(categories)).length).toBe(8);
  });
});
