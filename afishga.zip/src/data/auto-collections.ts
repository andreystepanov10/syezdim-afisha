// Автоматические подборки: готовые тематические списки событий города («Бесплатно», «С детьми», «По Пушкинской
// карте»…). Наполняются сами из афиши — редакционных подборок вручную мало, и раздел выглядел пустым и непонятным.
import { catalogHref } from "@/data/catalog-url";
import { listEvents, type Ctx } from "@/data/events";
import type { EventFilters } from "@/data/filters";
import { collectionArt } from "@/lib/art";
import type { CitySlug } from "@/lib/cities";

type Def = {
  slug: string;
  title: string;
  /** Одна строка под заголовком — что внутри */
  hint: string;
  filters: Omit<EventFilters, "city">;
  href: (city: CitySlug) => string;
};

const DEFS: Def[] = [
  { slug: "vyhodnye", title: "На выходных", hint: "Всё, что идёт в субботу и воскресенье", filters: { when: "weekend" }, href: (c) => `/${c}/vyhodnye` },
  { slug: "segodnya", title: "Сегодня", hint: "Куда сходить прямо сегодня", filters: { when: "today" }, href: (c) => `/${c}/segodnya` },
  { slug: "besplatno", title: "Бесплатно", hint: "Вход свободный", filters: { free: true }, href: (c) => catalogHref({ city: c, free: true }) },
  { slug: "s-detmi", title: "С детьми", hint: "Спектакли, мастер-классы и шоу для детей", filters: { category: ["kids"] }, href: (c) => `/${c}/events/kids` },
  {
    slug: "pushkinskaya-karta",
    title: "По Пушкинской карте",
    hint: "Можно оплатить Пушкинской картой",
    filters: { pushkinCard: true },
    href: (c) => catalogHref({ city: c, pushkinCard: true }),
  },
  { slug: "do-1000", title: "До 1000 ₽", hint: "Недорого: билеты дешевле тысячи", filters: { priceMax: 1000 }, href: (c) => catalogHref({ city: c, priceMax: 1000 }) },
  { slug: "standup", title: "Стендап", hint: "Комики и юмористические шоу", filters: { q: "стендап" }, href: (c) => catalogHref({ city: c, q: "стендап" }) },
  { slug: "kino", title: "Кино в прокате", hint: "Фильмы во всех кинотеатрах города", filters: { category: ["cinema"] }, href: (c) => `/${c}/events/cinema` },
  { slug: "teatr", title: "Театр", hint: "Спектакли, мюзиклы, опера и балет", filters: { category: ["theatre"] }, href: (c) => `/${c}/events/theatre` },
  { slug: "kontserty", title: "Концерты", hint: "Живая музыка — от рока до классики", filters: { category: ["concerts"] }, href: (c) => `/${c}/events/concerts` },
  { slug: "vystavki", title: "Выставки и музеи", hint: "Экспозиции, которые идут сейчас", filters: { category: ["exhibitions"] }, href: (c) => `/${c}/events/exhibitions` },
  { slug: "master-klassy", title: "Мастер-классы", hint: "Научиться чему-то своими руками", filters: { category: ["workshops"] }, href: (c) => `/${c}/events/workshops` },
];

export type AutoCollection = { slug: string; title: string; hint: string; href: string; image?: string; count: number };

/**
 * Подборки города с числом событий и картинкой. Пустые не показываем. Картинки не повторяются между плитками
 * (одно и то же популярное событие часто попадает в несколько подборок).
 */
export async function getAutoCollections(city: CitySlug, ctx: Ctx = {}): Promise<AutoCollection[]> {
  const lists = await Promise.all(DEFS.map((d) => listEvents({ ...d.filters, city, sort: "popular", pageSize: 12, groupSessions: true }, ctx)));
  const used = new Set<string>();
  const out: AutoCollection[] = [];
  DEFS.forEach((d, i) => {
    const { items, total } = lists[i];
    if (total === 0) return;
    const withImage = items.filter((e) => e.image && !e.image.endsWith(".svg"));
    const pick = withImage.find((e) => !used.has(e.image!)) ?? withImage[0];
    if (pick?.image) used.add(pick.image);
    // Своя иллюстрация подборки (public/art/collections), если есть; иначе — постер популярного события
    out.push({ slug: d.slug, title: d.title, hint: d.hint, href: d.href(city), image: collectionArt(d.slug) ?? pick?.image, count: total });
  });
  return out;
}
