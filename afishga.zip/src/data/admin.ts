// Запись данных из админки (/admin) — в отличие от events.ts (публичное чтение), здесь CRUD для events,
// venues, partners, collections. Разделено по смыслу: там — что видит посетитель, здесь — что редактирует админ.
import { and, asc, desc, eq, gte, inArray, ne } from "drizzle-orm";
import { getDb, type Db } from "@/db/client";
import { categories, cities, collectionEvents, collections, events, partners, ticketTypes, venues } from "@/db/schema";
import type { CategorySlug } from "@/lib/categories";
import type { CitySlug } from "@/lib/cities";

export type Ctx = { db?: Db };

// ---------------------------------------------------------------------------
// Справочники для выпадающих списков в формах
// ---------------------------------------------------------------------------

export async function listCityRows(ctx: Ctx = {}) {
  const db = ctx.db ?? (await getDb());
  return db.select({ id: cities.id, slug: cities.slug, name: cities.name }).from(cities).orderBy(asc(cities.name));
}

export async function listCategoryRows(ctx: Ctx = {}) {
  const db = ctx.db ?? (await getDb());
  return db.select({ id: categories.id, slug: categories.slug, name: categories.name }).from(categories).orderBy(asc(categories.sort));
}

async function cityIdBySlug(db: Db, slug: CitySlug): Promise<number> {
  const [row] = await db.select({ id: cities.id }).from(cities).where(eq(cities.slug, slug)).limit(1);
  if (!row) throw new Error(`Город «${slug}» не найден в справочнике — выполните npm run db:migrate`);
  return row.id;
}

async function categoryIdBySlug(db: Db, slug: CategorySlug): Promise<number> {
  const [row] = await db.select({ id: categories.id }).from(categories).where(eq(categories.slug, slug)).limit(1);
  if (!row) throw new Error(`Категория «${slug}» не найдена в справочнике — выполните npm run db:migrate`);
  return row.id;
}

// ---------------------------------------------------------------------------
// Партнёры
// ---------------------------------------------------------------------------

export type PartnerRow = { id: number; slug: string; name: string; siteUrl: string | null };
export type PartnerInput = { slug: string; name: string; siteUrl: string };

export async function listPartners(ctx: Ctx = {}): Promise<PartnerRow[]> {
  const db = ctx.db ?? (await getDb());
  return db.select({ id: partners.id, slug: partners.slug, name: partners.name, siteUrl: partners.siteUrl }).from(partners).orderBy(asc(partners.name));
}

export async function getPartner(id: number, ctx: Ctx = {}): Promise<PartnerRow | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .select({ id: partners.id, slug: partners.slug, name: partners.name, siteUrl: partners.siteUrl })
    .from(partners)
    .where(eq(partners.id, id))
    .limit(1);
  return row ?? null;
}

export async function createPartner(input: PartnerInput, ctx: Ctx = {}): Promise<number> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .insert(partners)
    .values({ slug: input.slug, name: input.name, siteUrl: input.siteUrl || null })
    .returning({ id: partners.id });
  return row.id;
}

export async function updatePartner(id: number, input: PartnerInput, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.update(partners).set({ slug: input.slug, name: input.name, siteUrl: input.siteUrl || null }).where(eq(partners.id, id));
}

export async function deletePartner(id: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.delete(partners).where(eq(partners.id, id));
}

// ---------------------------------------------------------------------------
// Площадки
// ---------------------------------------------------------------------------

export type VenueRow = { id: number; slug: string; name: string; address: string; lat: number; lon: number; city: CitySlug; locality: string | null };
export type VenueInput = { slug: string; name: string; address: string; lat: number; lon: number; city: CitySlug; locality?: string | null; approx?: boolean };

export async function listVenues(ctx: Ctx = {}): Promise<VenueRow[]> {
  const db = ctx.db ?? (await getDb());
  const rows = await db
    .select({ id: venues.id, slug: venues.slug, name: venues.name, address: venues.address, lat: venues.lat, lon: venues.lon, city: cities.slug, locality: venues.locality })
    .from(venues)
    .innerJoin(cities, eq(venues.cityId, cities.id))
    .orderBy(asc(venues.name));
  return rows.map((r) => ({ ...r, city: r.city as CitySlug }));
}

export async function getVenue(id: number, ctx: Ctx = {}): Promise<VenueRow | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .select({ id: venues.id, slug: venues.slug, name: venues.name, address: venues.address, lat: venues.lat, lon: venues.lon, city: cities.slug, locality: venues.locality })
    .from(venues)
    .innerJoin(cities, eq(venues.cityId, cities.id))
    .where(eq(venues.id, id))
    .limit(1);
  return row ? { ...row, city: row.city as CitySlug } : null;
}

export async function createVenue(input: VenueInput, ctx: Ctx = {}): Promise<number> {
  const db = ctx.db ?? (await getDb());
  const cityId = await cityIdBySlug(db, input.city);
  const [row] = await db
    .insert(venues)
    .values({ slug: input.slug, name: input.name, address: input.address, lat: input.lat, lon: input.lon, cityId, locality: input.locality ?? null, approx: input.approx ?? false })
    .returning({ id: venues.id });
  return row.id;
}

export async function updateVenue(id: number, input: VenueInput, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  const cityId = await cityIdBySlug(db, input.city);
  await db.update(venues).set({ slug: input.slug, name: input.name, address: input.address, lat: input.lat, lon: input.lon, cityId }).where(eq(venues.id, id));
}

export async function deleteVenue(id: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.delete(venues).where(eq(venues.id, id));
}

// ---------------------------------------------------------------------------
// События
// ---------------------------------------------------------------------------

export type EventRow = {
  id: number;
  slug: string;
  title: string;
  description: string;
  city: CitySlug;
  venueId: number;
  category: CategorySlug;
  partnerId: number | null;
  startsAt: Date;
  endsAt: Date | null;
  priceFrom: number | null;
  priceTo: number | null;
  ageLimit: number | null;
  image: string | null;
  isHot: boolean;
  pushkinCard: boolean;
  ticketUrl: string | null;
  status: "draft" | "published" | "archived";
  ticketTypes: { name: string; priceRub: number }[];
};

export type EventInput = {
  slug: string;
  title: string;
  description: string;
  city: CitySlug;
  venueId: number;
  category: CategorySlug;
  partnerId: number | null;
  startsAt: Date;
  endsAt: Date | null;
  priceFrom: number | null;
  priceTo: number | null;
  ageLimit: number | null;
  image: string | null;
  isHot: boolean;
  pushkinCard: boolean;
  ticketUrl: string | null;
  status: "draft" | "published" | "archived";
  ticketTypes: { name: string; priceRub: number }[];
};

export type EventListItem = Pick<EventRow, "id" | "slug" | "title" | "startsAt" | "status"> & { city: CitySlug; venueName: string };

export async function listEventsForAdmin(ctx: Ctx = {}): Promise<EventListItem[]> {
  const db = ctx.db ?? (await getDb());
  const rows = await db
    .select({ id: events.id, slug: events.slug, title: events.title, startsAt: events.startsAt, status: events.status, city: cities.slug, venueName: venues.name })
    .from(events)
    .innerJoin(cities, eq(events.cityId, cities.id))
    .innerJoin(venues, eq(events.venueId, venues.id))
    .orderBy(desc(events.startsAt));
  return rows.map((r) => ({ ...r, city: r.city as CitySlug }));
}

export async function getEventForAdmin(id: number, ctx: Ctx = {}): Promise<EventRow | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .select({
      id: events.id,
      slug: events.slug,
      title: events.title,
      description: events.description,
      city: cities.slug,
      venueId: events.venueId,
      category: categories.slug,
      partnerId: events.partnerId,
      startsAt: events.startsAt,
      endsAt: events.endsAt,
      priceFrom: events.priceFrom,
      priceTo: events.priceTo,
      ageLimit: events.ageLimit,
      image: events.image,
      isHot: events.isHot,
      pushkinCard: events.pushkinCard,
      ticketUrl: events.ticketUrl,
      status: events.status,
    })
    .from(events)
    .innerJoin(cities, eq(events.cityId, cities.id))
    .innerJoin(categories, eq(events.categoryId, categories.id))
    .where(eq(events.id, id))
    .limit(1);
  if (!row) return null;

  const types = await db
    .select({ name: ticketTypes.name, priceRub: ticketTypes.priceRub })
    .from(ticketTypes)
    .where(eq(ticketTypes.eventId, id))
    .orderBy(asc(ticketTypes.sort));

  return { ...row, city: row.city as CitySlug, category: row.category as CategorySlug, ticketTypes: types };
}

async function replaceTicketTypes(db: Db, eventId: number, types: { name: string; priceRub: number }[]): Promise<void> {
  await db.delete(ticketTypes).where(eq(ticketTypes.eventId, eventId));
  if (types.length > 0) {
    await db.insert(ticketTypes).values(types.map((t, i) => ({ eventId, name: t.name, priceRub: t.priceRub, sort: i })));
  }
}

export async function createEvent(input: EventInput, ctx: Ctx = {}): Promise<number> {
  const db = ctx.db ?? (await getDb());
  const [cityId, categoryId] = await Promise.all([cityIdBySlug(db, input.city), categoryIdBySlug(db, input.category)]);
  const [row] = await db
    .insert(events)
    .values({
      slug: input.slug,
      title: input.title,
      description: input.description,
      cityId,
      venueId: input.venueId,
      categoryId,
      partnerId: input.partnerId,
      startsAt: input.startsAt,
      endsAt: input.endsAt,
      priceFrom: input.priceFrom,
      priceTo: input.priceTo,
      ageLimit: input.ageLimit,
      image: input.image,
      isHot: input.isHot,
      pushkinCard: input.pushkinCard,
      ticketUrl: input.ticketUrl,
      status: input.status,
    })
    .returning({ id: events.id });
  await replaceTicketTypes(db, row.id, input.ticketTypes);
  return row.id;
}

export type EventMediaState = { id: number; status: EventRow["status"]; image: string | null; description: string; endsAt: Date | null };

/** Для импорта: узнать, есть ли уже событие с таким slug и заполнены ли у него картинка/описание */
export async function getEventMediaBySlug(slug: string, ctx: Ctx = {}): Promise<EventMediaState | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .select({ id: events.id, status: events.status, image: events.image, description: events.description, endsAt: events.endsAt })
    .from(events)
    .where(eq(events.slug, slug))
    .limit(1);
  return row ?? null;
}

/** Продлевает период показа (фильм остаётся в прокате) — только вперёд, остальное не трогает */
export async function extendEventEnd(id: number, endsAt: Date, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.update(events).set({ endsAt, updatedAt: new Date() }).where(eq(events.id, id));
}

/** Точечно дозаполняет картинку/описание у уже существующего черновика — не трогает остальные поля и билеты */
export async function updateEventMedia(id: number, fields: { image: string | null; description: string }, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.update(events).set({ image: fields.image, description: fields.description, updatedAt: new Date() }).where(eq(events.id, id));
}

export async function updateEvent(id: number, input: EventInput, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  const [cityId, categoryId] = await Promise.all([cityIdBySlug(db, input.city), categoryIdBySlug(db, input.category)]);
  await db
    .update(events)
    .set({
      slug: input.slug,
      title: input.title,
      description: input.description,
      cityId,
      venueId: input.venueId,
      categoryId,
      partnerId: input.partnerId,
      startsAt: input.startsAt,
      endsAt: input.endsAt,
      priceFrom: input.priceFrom,
      priceTo: input.priceTo,
      ageLimit: input.ageLimit,
      image: input.image,
      isHot: input.isHot,
      pushkinCard: input.pushkinCard,
      ticketUrl: input.ticketUrl,
      status: input.status,
      updatedAt: new Date(),
    })
    .where(eq(events.id, id));
  await replaceTicketTypes(db, id, input.ticketTypes);
}

export async function deleteEvent(id: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.delete(events).where(eq(events.id, id));
}

/** Массовая смена статуса — для кнопки «Опубликовать выбранные» в списке событий */
export async function updateEventsStatus(ids: number[], status: EventRow["status"], ctx: Ctx = {}): Promise<void> {
  if (ids.length === 0) return;
  const db = ctx.db ?? (await getDb());
  await db.update(events).set({ status, updatedAt: new Date() }).where(inArray(events.id, ids));
}

// ---------------------------------------------------------------------------
// Подборки
// ---------------------------------------------------------------------------

export type CollectionRow = {
  id: number;
  slug: string;
  title: string;
  description: string;
  image: string | null;
  eventIds: number[];
};
export type CollectionInput = { slug: string; title: string; description: string; image: string | null; eventIds: number[] };

export async function listCollectionsForAdmin(ctx: Ctx = {}) {
  const db = ctx.db ?? (await getDb());
  return db
    .select({ id: collections.id, slug: collections.slug, title: collections.title })
    .from(collections)
    .orderBy(asc(collections.sort));
}

export async function getCollectionForAdmin(id: number, ctx: Ctx = {}): Promise<CollectionRow | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .select({ id: collections.id, slug: collections.slug, title: collections.title, description: collections.description, image: collections.image })
    .from(collections)
    .where(eq(collections.id, id))
    .limit(1);
  if (!row) return null;
  const links = await db
    .select({ eventId: collectionEvents.eventId })
    .from(collectionEvents)
    .where(eq(collectionEvents.collectionId, id))
    .orderBy(asc(collectionEvents.sort));
  return { ...row, eventIds: links.map((l) => l.eventId) };
}

async function replaceCollectionEvents(db: Db, collectionId: number, eventIds: number[]): Promise<void> {
  await db.delete(collectionEvents).where(eq(collectionEvents.collectionId, collectionId));
  if (eventIds.length > 0) {
    await db.insert(collectionEvents).values(eventIds.map((eventId, i) => ({ collectionId, eventId, sort: i })));
  }
}

export async function createCollection(input: CollectionInput, ctx: Ctx = {}): Promise<number> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .insert(collections)
    .values({ slug: input.slug, title: input.title, description: input.description, image: input.image })
    .returning({ id: collections.id });
  await replaceCollectionEvents(db, row.id, input.eventIds);
  return row.id;
}

export async function updateCollection(id: number, input: CollectionInput, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.update(collections).set({ slug: input.slug, title: input.title, description: input.description, image: input.image }).where(eq(collections.id, id));
  await replaceCollectionEvents(db, id, input.eventIds);
}

export async function deleteCollection(id: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.delete(collections).where(eq(collections.id, id));
}

/** Список событий для чекбоксов в форме подборки — просто и по названию, без пагинации (это внутренний инструмент) */
export async function listEventOptions(ctx: Ctx = {}): Promise<{ id: number; title: string; city: CitySlug; startsAt: Date }[]> {
  const db = ctx.db ?? (await getDb());
  const rows = await db
    .select({ id: events.id, title: events.title, city: cities.slug, startsAt: events.startsAt })
    .from(events)
    .innerJoin(cities, eq(events.cityId, cities.id))
    .orderBy(asc(events.startsAt));
  return rows.map((r) => ({ ...r, city: r.city as CitySlug }));
}

/** Названия и время предстоящих событий города (кроме архивных) — импорт по ним отсекает дубли из других источников */
export async function listCityEventTimes(city: CitySlug, from: Date, ctx: Ctx = {}): Promise<{ title: string; startsAt: Date }[]> {
  const db = ctx.db ?? (await getDb());
  return db
    .select({ title: events.title, startsAt: events.startsAt })
    .from(events)
    .innerJoin(cities, eq(events.cityId, cities.id))
    .where(and(eq(cities.slug, city), ne(events.status, "archived"), gte(events.startsAt, from)));
}
