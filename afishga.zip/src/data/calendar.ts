// Сетка месяца и адрес страницы календаря. Чистые функции без обращений к БД — ими пользуются
// страница (сервер) и тесты, как catalog-url.ts для каталога.
import type { CitySlug } from "@/lib/cities";
import { addDays, addMonths, isoDayMsk, weekdayMsk } from "@/lib/time";

export const WEEKDAY_LABELS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"] as const;

export type CalendarDay = { date: Date; iso: string; inMonth: boolean };

/**
 * Сетка месяца по МСК, неделями с понедельника: полные недели, дни соседних месяцев — только для
 * заполнения первой и последней недели (5 или 6 строк в зависимости от месяца).
 */
export function monthGrid(monthStart: Date): CalendarDay[] {
  const dow = weekdayMsk(monthStart); // 0 — воскресенье … 6 — суббота
  const mondayOffset = (dow + 6) % 7; // сколько дней от понедельника той недели до 1-го числа
  const gridStart = addDays(monthStart, -mondayOffset);
  const monthEnd = addMonths(monthStart, 1); // исключая
  const daysBeforeEnd = Math.round((monthEnd.getTime() - gridStart.getTime()) / (24 * 60 * 60 * 1000));
  const weeks = Math.ceil(daysBeforeEnd / 7);

  const days: CalendarDay[] = [];
  for (let i = 0; i < weeks * 7; i++) {
    const date = addDays(gridStart, i);
    days.push({ date, iso: isoDayMsk(date), inMonth: date >= monthStart && date < monthEnd });
  }
  return days;
}

/** Адрес календаря: /calendar?date=…&city=… */
export function calendarHref(f: { date?: string; city?: CitySlug }): string {
  const p = new URLSearchParams();
  if (f.date) p.set("date", f.date);
  if (f.city) p.set("city", f.city);
  const qs = p.toString();
  return qs ? `/calendar?${qs}` : "/calendar";
}
