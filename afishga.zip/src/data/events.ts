import { and, asc, count, desc, eq, gte, inArray, lt, lte, sql, type SQL } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { getDb, type Db } from "@/db/client";
import { categories, cities, collectionEvents, collections, events, favorites, partners, ticketTypes, venues } from "@/db/schema";
import type { CategorySlug } from "@/lib/categories";
import type { CitySlug } from "@/lib/cities";
import { affiliateMark } from "@/lib/affiliate";
import { categoryArt } from "@/lib/art";
import { slugify } from "@/lib/slug";
import { addDays } from "@/lib/time";
import type { CollectionSummary, EventBadge, EventSummary, MapVenue, VenueSummary } from "@/lib/types";
import { resolveRange, toTsQuery, type EventFilters } from "./filters";

/** db и now можно подменить (тесты); по умолчанию — общая база и текущее время */
export type Ctx = { db?: Db; now?: Date };

export type EventList = { items: EventSummary[]; total: number; page: number; pageSize: number; pageCount: number };

export type EventDetails = EventSummary & {
  description: string;
  endsAt?: string;
  priceTo: number | null;
  ageLimit?: number;
  venue: { slug: string; name: string; address: string; lat: number; lon: number; locality?: string; approx?: boolean };
  ticketTypes: { name: string; priceRub: number }[];
  partner?: { name: string; siteUrl?: string };
};

const iso = (d: Date) => sql`${d.toISOString()}::timestamptz`;

/** Другие сеансы того же события: та же площадка, то же название, разовое (не выставка/кино) и опубликовано */
const session = alias(events, "session");
/** «from events as session» — псевдоним в sql-шаблоне drizzle сам таблицу не подставляет */
const sessionFrom = sql`${events} as ${sql.raw('"session"')}`;
function sameShow(range: { from: Date; to?: Date }): SQL {
  return sql`${session.venueId} = ${events.venueId} and lower(${session.title}) = lower(${events.title}) and ${session.status} = 'published' and ${session.endsAt} is null and ${events.endsAt} is null and ${session.startsAt} >= ${iso(range.from)}${range.to ? sql` and ${session.startsAt} < ${iso(range.to)}` : sql``}`;
}
/** Когда событие заканчивается: у выставок — endsAt, у остальных — начало */
const lastMoment = sql`coalesce(${events.endsAt}, ${events.startsAt})`;
/** Условная площадка «Кинотеатры Воронежа» (кино из import/sources/afisha-ru-cinema) — точкой на карте и в каталоге площадок её не показываем */
const realVenue = sql`${venues.slug} not like 'kinoteatry-%' and not ${venues.approx}`;
const popularity = sql`coalesce(${events.rating}, 0) * ln(${events.ratingCount} + 1)`;

const summaryColumns = {
  slug: events.slug,
  title: events.title,
  image: events.image,
  startsAt: events.startsAt,
  priceFrom: events.priceFrom,
  rating: events.rating,
  ratingCount: events.ratingCount,
  isHot: events.isHot,
  pushkinCard: events.pushkinCard,
  ageLimit: events.ageLimit,
  ticketUrl: events.ticketUrl,
  city: cities.slug,
  category: categories.slug,
  venue: venues.name,
  venueLocality: venues.locality,
  venueApprox: venues.approx,
  venueLat: venues.lat,
  venueLon: venues.lon,
};

type Row = {
  slug: string;
  title: string;
  image: string | null;
  startsAt: Date;
  priceFrom: number | null;
  rating: number | null;
  ratingCount: number;
  isHot: boolean;
  pushkinCard: boolean;
  ageLimit: number | null;
  ticketUrl: string | null;
  city: string;
  category: string;
  venue: string;
  venueLocality: string | null;
  venueApprox: boolean;
  venueLat: number;
  venueLon: number;
};

function toSummary(r: Row): EventSummary {
  const badges: EventBadge[] = [];
  if (r.isHot) badges.push("hot");
  if (r.priceFrom === 0) badges.push("free");
  if ((r.ageLimit ?? 0) >= 18) badges.push("18+");
  if (r.pushkinCard) badges.push("pushkin");
  return {
    slug: r.slug,
    title: r.title,
    // Площадка в области — с населённым пунктом: «ДК «Горняк» · Старый Оскол»
    subtitle: r.venueLocality ? `${r.venue} · ${r.venueLocality}` : r.venue,
    locality: r.venueLocality ?? undefined,
    // Без постера — иллюстрация категории (public/art/categories), а не пустая заглушка
    image: r.image ?? categoryArt(r.category),
    startsAt: r.startsAt.toISOString(),
    city: r.city as CitySlug,
    category: r.category as CategorySlug,
    // Примерная точка (центр города) не годится для «Рядом со мной» — координаты не отдаём
    lat: r.venueApprox ? undefined : r.venueLat,
    lon: r.venueApprox ? undefined : r.venueLon,
    priceFrom: r.priceFrom,
    rating: r.rating ?? undefined,
    ratingCount: r.ratingCount,
    badges: badges.length ? badges : undefined,
    ticketUrl: r.ticketUrl ?? undefined,
    ...(affiliateMark(r.ticketUrl) ? { adMark: affiliateMark(r.ticketUrl)! } : {}),
  };
}

function conditions(f: EventFilters, range: { from: Date; to?: Date }): (SQL | undefined)[] {
  const conds: (SQL | undefined)[] = [eq(events.status, "published"), gte(lastMoment, iso(range.from))];
  if (range.to) conds.push(lt(events.startsAt, range.to));
  if (f.city) conds.push(eq(cities.slug, f.city));
  if (f.category?.length) conds.push(inArray(categories.slug, f.category));
  if (f.venue) conds.push(eq(venues.slug, f.venue));
  if (f.locality) conds.push(eq(venues.locality, f.locality));
  // Склейка сеансов: оставляем только самый ранний сеанс в периоде (при равном времени — с меньшим id)
  if (f.groupSessions)
    conds.push(
      sql`not exists (select 1 from ${sessionFrom} where ${sameShow(range)} and (${session.startsAt} < ${events.startsAt} or (${session.startsAt} = ${events.startsAt} and ${session.id} < ${events.id})))`,
    );
  if (f.free) conds.push(eq(events.priceFrom, 0));
  if (f.pushkinCard) conds.push(eq(events.pushkinCard, true));
  if (f.priceMax !== undefined) conds.push(lte(events.priceFrom, f.priceMax));
  if (f.priceMin !== undefined) conds.push(gte(sql`coalesce(${events.priceTo}, ${events.priceFrom})`, f.priceMin));
  if (f.q) {
    const tsq = toTsQuery(f.q);
    // поиск по заголовку, описанию и названию площадки; строка без букв и цифр ничего не находит
    conds.push(
      tsq
        ? sql`(${events.search} @@ to_tsquery('russian', ${tsq}) OR to_tsvector('russian', ${venues.name}) @@ to_tsquery('russian', ${tsq}))`
        : sql`false`,
    );
  }
  return conds;
}

function order(f: EventFilters, from: Date): SQL[] {
  const sort = f.sort ?? (f.q ? "relevance" : "date");
  // Длящаяся выставка (началась раньше) в выбранном периоде встаёт в начало периода, а не в день своего открытия
  const start = sql`greatest(${events.startsAt}, ${iso(from)})`;
  // Длящиеся события (кино в прокате, выставки) — после разовых: иначе уже идущие 20+ фильмов с началом «сейчас»
  // занимают весь верх списка «Сегодня» и «Популярного». В разделе «Кино» все длящиеся — там порядок прежний
  const isPeriod = sql`(${events.endsAt} is not null)`;
  const tail = [asc(isPeriod), asc(start), asc(events.startsAt), asc(events.id)];
  switch (sort) {
    case "popular":
      return [desc(popularity), ...tail];
    case "price":
      return [sql`${events.priceFrom} asc nulls last`, ...tail];
    case "relevance": {
      const tsq = f.q ? toTsQuery(f.q) : null;
      return tsq ? [desc(sql`ts_rank(${events.search}, to_tsquery('russian', ${tsq}))`), ...tail] : tail;
    }
    default:
      return tail;
  }
}

/** Поиск и фильтрация событий с пагинацией — основа каталога, поиска и API */
export async function listEvents(filters: EventFilters, ctx: Ctx = {}): Promise<EventList> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const page = filters.page ?? 1;
  const pageSize = filters.pageSize ?? 12;
  const range = resolveRange(filters, now);
  const where = and(...conditions(filters, range));

  // Число остальных сеансов — для подписи «ещё N дат» на карточке
  const columns = filters.groupSessions
    ? { ...summaryColumns, moreDates: sql<number>`(select count(*)::int from ${sessionFrom} where ${sameShow(range)} and ${session.id} <> ${events.id})` }
    : summaryColumns;
  const [rows, [{ total }]] = await Promise.all([
    db
      .select(columns)
      .from(events)
      .innerJoin(cities, eq(events.cityId, cities.id))
      .innerJoin(venues, eq(events.venueId, venues.id))
      .innerJoin(categories, eq(events.categoryId, categories.id))
      .where(where)
      .orderBy(...order(filters, range.from))
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db
      .select({ total: count() })
      .from(events)
      .innerJoin(cities, eq(events.cityId, cities.id))
      .innerJoin(venues, eq(events.venueId, venues.id))
      .innerJoin(categories, eq(events.categoryId, categories.id))
      .where(where),
  ]);

  const items = rows.map((r) => {
    const s = toSummary(r);
    const more = (r as { moreDates?: number }).moreDates;
    return more ? { ...s, moreDates: more } : s;
  });
  return { items, total, page, pageSize, pageCount: Math.max(1, Math.ceil(total / pageSize)) };
}

/** Популярные события города: по рейтингу с учётом числа оценок */
export async function getPopularEvents(city: CitySlug, limit = 8, ctx: Ctx = {}): Promise<EventSummary[]> {
  return (await listEvents({ city, sort: "popular", pageSize: limit, groupSessions: true }, ctx)).items;
}

/** Ближайшие выставки города (идущие сейчас и будущие) */
export async function getUpcomingExhibitions(city: CitySlug, limit = 8, ctx: Ctx = {}): Promise<EventSummary[]> {
  return (await listEvents({ city, category: ["exhibitions"], sort: "date", pageSize: limit }, ctx)).items;
}

/** Площадки с ближайшими событиями (следующие 60 дней) — для карты. city — сузить до одного города */
export async function getMapVenues(city?: CitySlug, ctx: Ctx = {}): Promise<MapVenue[]> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const rows = await db
    .select({
      venueSlug: venues.slug,
      venueName: venues.name,
      lat: venues.lat,
      lon: venues.lon,
      city: cities.slug,
      slug: events.slug,
      title: events.title,
      image: events.image,
      startsAt: events.startsAt,
      priceFrom: events.priceFrom,
    })
    .from(events)
    .innerJoin(venues, eq(events.venueId, venues.id))
    .innerJoin(cities, eq(venues.cityId, cities.id))
    .where(
      and(
        eq(events.status, "published"),
        gte(lastMoment, iso(now)),
        lt(events.startsAt, addDays(now, 60)),
        realVenue,
        city ? eq(cities.slug, city) : undefined,
      ),
    )
    .orderBy(asc(events.startsAt), asc(events.id));

  const byVenue = new Map<string, MapVenue>();
  for (const r of rows) {
    const venue = byVenue.get(r.venueSlug) ?? { id: r.venueSlug, name: r.venueName, city: r.city as CitySlug, lat: r.lat, lon: r.lon, events: [] };
    venue.events.push({ slug: r.slug, title: r.title, image: r.image ?? undefined, startsAt: r.startsAt.toISOString(), priceFrom: r.priceFrom });
    byVenue.set(r.venueSlug, venue);
  }
  return [...byVenue.values()];
}

/** Каталог площадок: адрес и число ближайших опубликованных событий (без ограничения в 60 дней, в отличие от карты). city — сузить до одного города */
export async function getVenues(city?: CitySlug, ctx: Ctx = {}): Promise<VenueSummary[]> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  // filter, а не count(events.id): у площадки без предстоящих событий leftJoin даёт одну пустую строку — считаем только опубликованные будущие
  const upcoming = sql<number>`count(${events.id}) filter (where ${events.status} = 'published' and ${lastMoment} >= ${iso(now)})::int`;
  const rows = await db
    .select({ slug: venues.slug, name: venues.name, address: venues.address, lat: venues.lat, lon: venues.lon, city: cities.slug, upcomingCount: upcoming })
    .from(venues)
    .innerJoin(cities, eq(venues.cityId, cities.id))
    .leftJoin(events, eq(events.venueId, venues.id))
    .where(and(realVenue, city ? eq(cities.slug, city) : undefined))
    .groupBy(venues.id, cities.slug)
    .orderBy(desc(upcoming), asc(venues.name));
  return rows.map((r) => ({ ...r, city: r.city as CitySlug }));
}

/** Число опубликованных событий по дням месяца (диапазон [from, to)) — для сетки календаря.
 *  Считает по дате начала: у идущих несколько дней выставок это день открытия, а не каждый день показа
 *  (точный список дня строит listEvents с фильтром date — он уже идущие выставки учитывает). */
export async function getDailyCounts(range: { from: Date; to: Date }, city?: CitySlug, ctx: Ctx = {}): Promise<Map<string, number>> {
  const db = ctx.db ?? (await getDb());
  const day = sql<string>`to_char(${events.startsAt} at time zone 'Europe/Moscow', 'YYYY-MM-DD')`;
  const rows = await db
    .select({ day, n: count() })
    .from(events)
    .innerJoin(cities, eq(events.cityId, cities.id))
    .where(
      and(eq(events.status, "published"), gte(events.startsAt, iso(range.from)), lt(events.startsAt, iso(range.to)), city ? eq(cities.slug, city) : undefined),
    )
    .groupBy(day);
  return new Map(rows.map((r) => [r.day, Number(r.n)]));
}

/** Подборки с количеством актуальных событий в каждой */
export type SitemapEvent = { slug: string; updatedAt: Date };

export type Locality = { city: CitySlug; name: string; slug: string; count: number };

/** Населённые пункты области с предстоящими событиями — для страниц «Афиша Старого Оскола» и ссылок на них */
export async function getLocalities(city?: CitySlug, ctx: Ctx = {}): Promise<Locality[]> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const n = sql<number>`count(${events.id})::int`;
  const rows = await db
    .select({ city: cities.slug, name: venues.locality, count: n })
    .from(events)
    .innerJoin(venues, eq(events.venueId, venues.id))
    .innerJoin(cities, eq(venues.cityId, cities.id))
    .where(and(eq(events.status, "published"), gte(lastMoment, iso(now)), sql`${venues.locality} is not null`, city ? eq(cities.slug, city) : undefined))
    .groupBy(cities.slug, venues.locality)
    .orderBy(desc(n));
  return rows.map((r) => ({ city: r.city as CitySlug, name: r.name!, slug: slugify(r.name!), count: r.count }));
}

/** Для sitemap.xml — слаги и время последнего изменения опубликованных событий, которые ещё не прошли */
export async function listPublishedEventSlugs(ctx: Ctx = {}): Promise<SitemapEvent[]> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  return db
    .select({ slug: events.slug, updatedAt: events.updatedAt })
    .from(events)
    .where(and(eq(events.status, "published"), gte(lastMoment, iso(now))));
}

export async function getCollections(ctx: Ctx = {}): Promise<CollectionSummary[]> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const rows = await db
    .select({ slug: collections.slug, title: collections.title, image: collections.image, count: sql<number>`count(${events.id})::int` })
    .from(collections)
    .leftJoin(collectionEvents, eq(collectionEvents.collectionId, collections.id))
    .leftJoin(events, and(eq(events.id, collectionEvents.eventId), eq(events.status, "published"), gte(lastMoment, iso(now))))
    .groupBy(collections.id)
    .orderBy(asc(collections.sort), asc(collections.id));
  return rows.map((r) => ({ slug: r.slug, title: r.title, image: r.image ?? undefined, count: r.count }));
}

export type CollectionDetails = CollectionSummary & { description: string; events: EventSummary[] };

/** Подборка целиком: описание и актуальные события в порядке редактора. null — такой подборки нет */
export async function getCollectionBySlug(slug: string, ctx: Ctx = {}): Promise<CollectionDetails | null> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const [row] = await db
    .select({ slug: collections.slug, title: collections.title, description: collections.description, image: collections.image })
    .from(collections)
    .where(eq(collections.slug, slug))
    .limit(1);
  if (!row) return null;

  const rows = await db
    .select(summaryColumns)
    .from(collectionEvents)
    .innerJoin(collections, eq(collections.id, collectionEvents.collectionId))
    .innerJoin(events, eq(events.id, collectionEvents.eventId))
    .innerJoin(cities, eq(events.cityId, cities.id))
    .innerJoin(venues, eq(events.venueId, venues.id))
    .innerJoin(categories, eq(events.categoryId, categories.id))
    .where(and(eq(collections.slug, slug), eq(events.status, "published"), gte(lastMoment, iso(now))))
    .orderBy(asc(collectionEvents.sort), asc(events.startsAt), asc(events.id));

  return { slug: row.slug, title: row.title, description: row.description, image: row.image ?? undefined, events: rows.map(toSummary) };
}

/** Похожие события: та же категория и город, без самого события — для страницы события */
export async function getSimilarEvents(event: Pick<EventSummary, "slug" | "city" | "category" | "title">, limit = 4, ctx: Ctx = {}): Promise<EventSummary[]> {
  if (!event.category) return [];
  const { items } = await listEvents({ city: event.city, category: [event.category], sort: "popular", pageSize: limit + 2, groupSessions: true }, ctx);
  // Другие сеансы этого же события — в блоке «Другие даты», не в «Похожих»
  const title = event.title.toLowerCase();
  return items.filter((e) => e.slug !== event.slug && e.title.toLowerCase() !== title).slice(0, limit);
}

/** Избранные события устройства («Мои билеты», анонимно по deviceId) — сначала добавленные последними */
export async function getFavoriteEvents(deviceId: string, ctx: Ctx = {}): Promise<EventSummary[]> {
  const db = ctx.db ?? (await getDb());
  const rows = await db
    .select(summaryColumns)
    .from(favorites)
    .innerJoin(events, eq(events.id, favorites.eventId))
    .innerJoin(cities, eq(events.cityId, cities.id))
    .innerJoin(venues, eq(events.venueId, venues.id))
    .innerJoin(categories, eq(events.categoryId, categories.id))
    .where(eq(favorites.deviceId, deviceId))
    .orderBy(desc(favorites.createdAt));
  return rows.map(toSummary);
}

/** Название площадки по slug (для подписи фильтра «Площадка: …»); null — такой площадки нет */
export async function getVenueName(slug: string, ctx: Ctx = {}): Promise<string | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db.select({ name: venues.name }).from(venues).where(eq(venues.slug, slug)).limit(1);
  return row?.name ?? null;
}

/** Событие целиком: описание, площадка, типы билетов, партнёр. null — не найдено или не опубликовано */
export async function getEventBySlug(slug: string, ctx: Ctx = {}): Promise<EventDetails | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db
    .select({
      ...summaryColumns,
      id: events.id,
      description: events.description,
      endsAt: events.endsAt,
      priceTo: events.priceTo,
      venueSlug: venues.slug,
      venueAddress: venues.address,
      venueLat: venues.lat,
      venueLon: venues.lon,
      partnerName: partners.name,
      partnerSite: partners.siteUrl,
    })
    .from(events)
    .innerJoin(cities, eq(events.cityId, cities.id))
    .innerJoin(venues, eq(events.venueId, venues.id))
    .innerJoin(categories, eq(events.categoryId, categories.id))
    .leftJoin(partners, eq(events.partnerId, partners.id))
    .where(and(eq(events.slug, slug), eq(events.status, "published")))
    .limit(1);
  if (!row) return null;

  const types = await db
    .select({ name: ticketTypes.name, priceRub: ticketTypes.priceRub })
    .from(ticketTypes)
    .where(eq(ticketTypes.eventId, row.id))
    .orderBy(asc(ticketTypes.sort), asc(ticketTypes.id));

  return {
    ...toSummary(row),
    description: row.description,
    endsAt: row.endsAt?.toISOString(),
    priceTo: row.priceTo,
    ageLimit: row.ageLimit ?? undefined,
    venue: { slug: row.venueSlug, name: row.venue, address: row.venueAddress, lat: row.venueLat, lon: row.venueLon, locality: row.venueLocality ?? undefined, approx: row.venueApprox },
    ticketTypes: types,
    partner: row.partnerName ? { name: row.partnerName, siteUrl: row.partnerSite ?? undefined } : undefined,
  };
}

/** Все предстоящие сеансы того же события (та же площадка и название) — блок «Другие даты» на странице события */
export async function getOtherSessions(event: Pick<EventDetails, "slug" | "title" | "venue" | "endsAt">, ctx: Ctx = {}): Promise<{ slug: string; startsAt: string }[]> {
  if (event.endsAt) return [];
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const rows = await db
    .select({ slug: events.slug, startsAt: events.startsAt })
    .from(events)
    .innerJoin(venues, eq(events.venueId, venues.id))
    .where(
      and(
        eq(venues.slug, event.venue.slug),
        sql`lower(${events.title}) = lower(${event.title})`,
        eq(events.status, "published"),
        sql`${events.endsAt} is null`,
        gte(events.startsAt, iso(now)),
        sql`${events.slug} <> ${event.slug}`,
      ),
    )
    .orderBy(asc(events.startsAt))
    .limit(30);
  return rows.map((r) => ({ slug: r.slug, startsAt: r.startsAt.toISOString() }));
}

/** Цифры для страницы «Организаторам»: сколько предстоящих событий, площадок и населённых пунктов в афише */
export async function getCatalogStats(ctx: Ctx = {}): Promise<{ events: number; venues: number; localities: number }> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const [row] = await db
    .select({
      events: sql<number>`count(distinct ${events.id})::int`,
      venues: sql<number>`count(distinct ${venues.id})::int`,
      localities: sql<number>`count(distinct coalesce(${venues.locality}, ${cities.slug}))::int`,
    })
    .from(events)
    .innerJoin(venues, eq(events.venueId, venues.id))
    .innerJoin(cities, eq(venues.cityId, cities.id))
    .where(and(eq(events.status, "published"), gte(lastMoment, iso(now))));
  return row;
}
