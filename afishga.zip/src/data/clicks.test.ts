import { beforeAll, describe, expect, it } from "vitest";
import { createDemoDb, type Db } from "@/db/client";
import { listEvents } from "./events";
import { getClickStats, getTicketTarget, recordTicketClick } from "./clicks";
import { getEventIds } from "./telegram";

const NOW = new Date("2026-10-14T09:00:00Z");
let db: Db;
beforeAll(async () => {
  db = await createDemoDb({ now: NOW });
});

describe("счётчик переходов за билетами", () => {
  it("копит переходы по источникам и показывает топ событий", async () => {
    const { items } = await listEvents({ city: "voronezh" }, { db, now: NOW });
    const withTicket = items.find((e) => e.ticketUrl)!;
    const target = await getTicketTarget(withTicket.slug, { db });
    expect(target?.ticketUrl).toBe(withTicket.ticketUrl);
    const id = (await getEventIds([withTicket.slug], { db })).get(withTicket.slug)!;

    await recordTicketClick(id, "site", { db, now: NOW });
    await recordTicketClick(id, "site", { db, now: NOW });
    await recordTicketClick(id, "channel", { db, now: NOW });
    const stats = await getClickStats(7, { db, now: NOW });
    expect(stats.total).toBe(3);
    expect(stats.bySource).toMatchObject({ site: 2, channel: 1 });
    expect(stats.top[0]).toMatchObject({ slug: withTicket.slug, count: 3 });
  });

  it("нет события — null", async () => {
    expect(await getTicketTarget("net-takogo", { db })).toBeNull();
  });
});
