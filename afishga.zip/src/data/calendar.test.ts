import { describe, expect, it } from "vitest";
import { parseDayMsk, startOfMonthMsk } from "@/lib/time";
import { calendarHref, monthGrid } from "./calendar";

describe("сетка месяца", () => {
  it("октябрь 2026 (начинается в четверг): 5 недель, с понедельника 28 сентября", () => {
    const grid = monthGrid(startOfMonthMsk(parseDayMsk("2026-10-15")!));
    expect(grid.length).toBe(35);
    expect(grid[0].iso).toBe("2026-09-28");
    expect(grid.at(-1)!.iso).toBe("2026-11-01");
    expect(grid.filter((d) => d.inMonth).map((d) => d.iso)[0]).toBe("2026-10-01");
    expect(grid.filter((d) => d.inMonth)).toHaveLength(31);
  });

  it("февраль 2027 (28 дней, начинается в понедельник): ровно 4 недели", () => {
    const grid = monthGrid(startOfMonthMsk(parseDayMsk("2027-02-10")!));
    expect(grid.length).toBe(28);
    expect(grid[0].iso).toBe("2027-02-01");
    expect(grid.every((d) => d.inMonth)).toBe(true);
  });

  it("каждая неделя — 7 дней подряд, без пропусков", () => {
    const grid = monthGrid(startOfMonthMsk(parseDayMsk("2026-12-01")!));
    for (let i = 1; i < grid.length; i++) {
      expect(grid[i].date.getTime() - grid[i - 1].date.getTime()).toBe(24 * 60 * 60 * 1000);
    }
  });
});

describe("адрес календаря", () => {
  it("без параметров — просто /calendar", () => {
    expect(calendarHref({})).toBe("/calendar");
  });

  it("дата и город попадают в адрес", () => {
    expect(calendarHref({ date: "2026-10-15" })).toBe("/calendar?date=2026-10-15");
    expect(calendarHref({ date: "2026-10-15", city: "kursk" })).toBe("/calendar?date=2026-10-15&city=kursk");
  });
});
