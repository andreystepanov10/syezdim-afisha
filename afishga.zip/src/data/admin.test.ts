import { beforeAll, describe, expect, it } from "vitest";
import { createDemoDb, type Db } from "@/db/client";
import {
  createCollection,
  createEvent,
  createPartner,
  createVenue,
  deleteCollection,
  deleteEvent,
  deletePartner,
  deleteVenue,
  getCollectionForAdmin,
  getEventForAdmin,
  getPartner,
  getVenue,
  listCollectionsForAdmin,
  listEventOptions,
  listEventsForAdmin,
  listPartners,
  listVenues,
  updateCollection,
  updateEvent,
  updateEventsStatus,
  updatePartner,
  updateVenue,
  type Ctx,
} from "./admin";

let db: Db;
let ctx: Ctx;
beforeAll(async () => {
  db = await createDemoDb();
  ctx = { db };
});

describe("партнёры", () => {
  it("создание, чтение, обновление, удаление", async () => {
    const id = await createPartner({ slug: "test-partner", name: "Тестовый партнёр", siteUrl: "https://example.com" }, ctx);
    expect(await getPartner(id, ctx)).toMatchObject({ name: "Тестовый партнёр", slug: "test-partner", siteUrl: "https://example.com" });
    expect((await listPartners(ctx)).some((p) => p.id === id)).toBe(true);

    await updatePartner(id, { slug: "test-partner", name: "Переименован", siteUrl: "" }, ctx);
    expect(await getPartner(id, ctx)).toMatchObject({ name: "Переименован", siteUrl: null });

    await deletePartner(id, ctx);
    expect(await getPartner(id, ctx)).toBeNull();
  });

  it("неизвестный id — null", async () => {
    expect(await getPartner(999_999, ctx)).toBeNull();
  });
});

describe("площадки", () => {
  it("создание, чтение, обновление, удаление", async () => {
    const id = await createVenue({ slug: "test-venue", name: "Тестовый зал", address: "ул. Тестовая, 1", lat: 51.6, lon: 39.2, city: "voronezh" }, ctx);
    expect(await getVenue(id, ctx)).toMatchObject({ name: "Тестовый зал", city: "voronezh" });
    expect((await listVenues(ctx)).some((v) => v.id === id)).toBe(true);

    await updateVenue(id, { slug: "test-venue", name: "Тестовый зал", address: "ул. Тестовая, 1", lat: 51.6, lon: 39.2, city: "kursk" }, ctx);
    expect(await getVenue(id, ctx)).toMatchObject({ city: "kursk" });

    await deleteVenue(id, ctx);
    expect(await getVenue(id, ctx)).toBeNull();
  });
});

describe("события", () => {
  it("создание с категориями билетов, чтение, обновление, удаление", async () => {
    const venueId = await createVenue({ slug: "test-venue-2", name: "Зал 2", address: "", lat: 51.6, lon: 39.2, city: "voronezh" }, ctx);
    const id = await createEvent(
      {
        slug: "test-event",
        title: "Тестовое событие",
        description: "Описание",
        city: "voronezh",
        venueId,
        category: "concerts",
        partnerId: null,
        startsAt: new Date("2027-01-01T18:00:00+03:00"),
        endsAt: null,
        priceFrom: null,
        priceTo: null,
        ageLimit: null,
        image: null,
        isHot: false,
        pushkinCard: false,
        ticketUrl: null,
        status: "draft",
        ticketTypes: [
          { name: "Партер", priceRub: 1000 },
          { name: "Балкон", priceRub: 500 },
        ],
      },
      ctx,
    );

    const created = await getEventForAdmin(id, ctx);
    expect(created).toMatchObject({ title: "Тестовое событие", status: "draft", city: "voronezh", category: "concerts" });
    expect(created!.ticketTypes.map((t) => t.name)).toEqual(["Партер", "Балкон"]);
    expect((await listEventsForAdmin(ctx)).some((e) => e.id === id)).toBe(true);
    expect((await listEventOptions(ctx)).some((e) => e.id === id)).toBe(true);

    await updateEvent(
      id,
      {
        ...created!,
        title: "Изменённое название",
        status: "published",
        ticketTypes: [{ name: "Единый билет", priceRub: 800 }],
      },
      ctx,
    );
    const updated = await getEventForAdmin(id, ctx);
    expect(updated).toMatchObject({ title: "Изменённое название", status: "published" });
    expect(updated!.ticketTypes.map((t) => t.name)).toEqual(["Единый билет"]);

    await deleteEvent(id, ctx);
    expect(await getEventForAdmin(id, ctx)).toBeNull();
    await deleteVenue(venueId, ctx);
  });

  it("массово меняет статус нескольким событиям", async () => {
    const venueId = await createVenue({ slug: "test-venue-bulk", name: "Зал для массовой публикации", address: "", lat: 51.6, lon: 39.2, city: "voronezh" }, ctx);
    const base = {
      description: "",
      city: "voronezh" as const,
      venueId,
      category: "concerts" as const,
      partnerId: null,
      startsAt: new Date("2027-02-01T18:00:00+03:00"),
      endsAt: null,
      priceFrom: null,
      priceTo: null,
      ageLimit: null,
      image: null,
      isHot: false,
      pushkinCard: false,
      ticketUrl: null,
      status: "draft" as const,
      ticketTypes: [],
    };
    const id1 = await createEvent({ ...base, slug: "bulk-1", title: "Черновик 1" }, ctx);
    const id2 = await createEvent({ ...base, slug: "bulk-2", title: "Черновик 2" }, ctx);
    const id3 = await createEvent({ ...base, slug: "bulk-3", title: "Не трогаем" }, ctx);

    await updateEventsStatus([id1, id2], "published", ctx);

    expect((await getEventForAdmin(id1, ctx))?.status).toBe("published");
    expect((await getEventForAdmin(id2, ctx))?.status).toBe("published");
    expect((await getEventForAdmin(id3, ctx))?.status).toBe("draft");

    await deleteEvent(id1, ctx);
    await deleteEvent(id2, ctx);
    await deleteEvent(id3, ctx);
    await deleteVenue(venueId, ctx);
  });
});

describe("подборки", () => {
  it("создание с событиями, чтение, обновление состава, удаление", async () => {
    const [{ id: firstEventId }] = await listEventOptions(ctx);
    const collectionId = await createCollection({ slug: "test-collection", title: "Тестовая подборка", description: "", image: null, eventIds: [firstEventId] }, ctx);

    const created = await getCollectionForAdmin(collectionId, ctx);
    expect(created).toMatchObject({ title: "Тестовая подборка", eventIds: [firstEventId] });
    expect((await listCollectionsForAdmin(ctx)).some((c) => c.id === collectionId)).toBe(true);

    await updateCollection(collectionId, { slug: "test-collection", title: "Тестовая подборка", description: "Новое описание", image: null, eventIds: [] }, ctx);
    expect(await getCollectionForAdmin(collectionId, ctx)).toMatchObject({ description: "Новое описание", eventIds: [] });

    await deleteCollection(collectionId, ctx);
    expect(await getCollectionForAdmin(collectionId, ctx)).toBeNull();
  });
});
