// Адреса каталога, «активные фильтры» и связь панели фильтров с адресом.
// Чистые функции без обращений к БД: ими пользуются страница (сервер), панель фильтров (браузер) и тесты.
import { CATEGORIES, categoryName, type CategorySlug } from "@/lib/categories";
import { cityName, type CitySlug } from "@/lib/cities";
import { dayMonthLong, formatPrice } from "@/lib/format";
import type { EventFilters, Sort, When } from "./filters";

/** Ползунок цены: верхнее положение означает «без верхней границы» */
export const PRICE_SLIDER = { min: 0, max: 5000, step: 100 } as const;

export const WHEN_LABELS: Record<When, string> = {
  today: "Сегодня",
  tomorrow: "Завтра",
  weekend: "На выходных",
  week: "Ближайшая неделя",
  date: "Выбранная дата",
};

/** Быстрые варианты даты в панели фильтров («Выбранная дата» — это поля «с» и «по») */
export const QUICK_WHEN = ["today", "tomorrow", "weekend", "week"] as const;
export type QuickWhen = (typeof QUICK_WHEN)[number];

export const SORT_LABELS: Record<Sort, string> = {
  date: "По дате",
  popular: "Популярные",
  price: "Дешевле",
  relevance: "По совпадению",
};

/** Сортировка по умолчанию: при поиске — по совпадению, иначе по дате (как в listEvents) */
export const defaultSort = (f: Pick<EventFilters, "q">): Sort => (f.q ? "relevance" : "date");

/** Варианты сортировки: «по совпадению» имеет смысл только при поиске */
export const sortOptions = (f: Pick<EventFilters, "q">): Sort[] => (f.q ? ["relevance", "date", "popular", "price"] : ["date", "popular", "price"]);

/** Город стоит в пути (/voronezh/events), а не в параметрах: у каждого города свой адрес для поисковиков */
export function catalogPath(city?: CitySlug): string {
  return city ? `/${city}/events` : "/events";
}

/** Параметры адреса для фильтров: без пустых значений, без города (он в пути), страница — только со второй */
export function catalogParams(f: EventFilters): URLSearchParams {
  const p = new URLSearchParams();
  const set = (key: string, value: string | number | boolean | undefined) => {
    if (value !== undefined && value !== false && value !== "") p.set(key, value === true ? "1" : String(value));
  };
  if (f.category?.length) set("category", f.category.join(","));
  set("q", f.q);
  set("when", f.when);
  set("date", f.date);
  set("from", f.from);
  set("to", f.to);
  set("priceMin", f.priceMin);
  set("priceMax", f.priceMax);
  set("free", f.free);
  set("pushkinCard", f.pushkinCard);
  set("venue", f.venue);
  set("sort", f.sort);
  if (f.page && f.page > 1) set("page", f.page);
  return p;
}

/** Адрес каталога для набора фильтров: /voronezh/events?category=concerts,theatre&when=weekend */
export function catalogHref(f: EventFilters): string {
  const query = catalogParams(f).toString().replaceAll("%2C", ",");
  return query ? `${catalogPath(f.city)}?${query}` : catalogPath(f.city);
}

/** Адрес страницы поиска: /search?q=…&page=2. Без q — стартовый экран с подсказками по категориям */
export function searchHref(f: { q?: string; page?: number }): string {
  const p = new URLSearchParams();
  if (f.q) p.set("q", f.q);
  if (f.page && f.page > 1) p.set("page", String(f.page));
  const qs = p.toString();
  return qs ? `/search?${qs}` : "/search";
}

export type ActiveFilter = { key: string; label: string; href: string };

/**
 * Выбранные фильтры для строки «чипов»: у каждого своя ссылка «снять» (она же сбрасывает страницу выдачи).
 * Сортировка и страница фильтрами не считаются.
 */
export function activeFilters(f: EventFilters, opts: { venueName?: string | null } = {}): ActiveFilter[] {
  const chips: ActiveFilter[] = [];
  const without = (patch: Partial<EventFilters>) => catalogHref({ ...f, ...patch, page: undefined });

  if (f.city) chips.push({ key: "city", label: cityName(f.city), href: without({ city: undefined }) });
  for (const c of f.category ?? []) {
    const rest = (f.category ?? []).filter((x) => x !== c);
    chips.push({ key: `category:${c}`, label: categoryName(c), href: without({ category: rest.length ? rest : undefined }) });
  }
  if (f.q) chips.push({ key: "q", label: `«${f.q}»`, href: without({ q: undefined }) });

  if (f.when && f.when !== "date") chips.push({ key: "when", label: WHEN_LABELS[f.when], href: without({ when: undefined, date: undefined }) });
  else if (f.date) chips.push({ key: "date", label: dayMonthLong(f.date), href: without({ when: undefined, date: undefined }) });
  else if (f.from || f.to) {
    const label = f.from && f.to ? `${dayMonthLong(f.from)} — ${dayMonthLong(f.to)}` : f.from ? `с ${dayMonthLong(f.from)}` : `по ${dayMonthLong(f.to!)}`;
    chips.push({ key: "range", label, href: without({ from: undefined, to: undefined }) });
  }

  if (f.free) chips.push({ key: "free", label: "Бесплатно", href: without({ free: undefined }) });
  else if (f.priceMin !== undefined || f.priceMax !== undefined) {
    const label =
      f.priceMin !== undefined && f.priceMax !== undefined
        ? `${formatPrice(f.priceMin)} — ${formatPrice(f.priceMax)}`
        : f.priceMin !== undefined
          ? `от ${formatPrice(f.priceMin)}`
          : `до ${formatPrice(f.priceMax!)}`;
    chips.push({ key: "price", label, href: without({ priceMin: undefined, priceMax: undefined }) });
  }

  if (f.pushkinCard) chips.push({ key: "pushkinCard", label: "Пушкинская карта", href: without({ pushkinCard: undefined }) });
  if (f.venue) chips.push({ key: "venue", label: `Площадка: ${opts.venueName ?? f.venue}`, href: without({ venue: undefined }) });
  return chips;
}

/** Сколько групп фильтров выбрано (для счётчика на кнопке «Фильтры»); город — не в счёт, он часть адреса страницы */
export function filterCount(f: EventFilters): number {
  const groups = new Set(activeFilters(f).map((c) => c.key.split(":")[0]));
  groups.delete("city");
  return groups.size;
}

// ---------------------------------------------------------------------------
// Панель фильтров ↔ адрес
// ---------------------------------------------------------------------------

/** Значения полей панели фильтров */
export type FilterFormState = {
  q: string;
  category: CategorySlug[];
  /** "" — все города */
  city: CitySlug | "";
  /** быстрый выбор даты; если задан, поля «с» и «по» пустые */
  when: QuickWhen | "";
  /** YYYY-MM-DD или "" */
  from: string;
  to: string;
  price: [number, number];
  free: boolean;
  pushkinCard: boolean;
};

const { min: PRICE_MIN, max: PRICE_MAX, step: PRICE_STEP } = PRICE_SLIDER;

export function stateFromFilters(f: EventFilters): FilterFormState {
  const quick = f.when && f.when !== "date" ? f.when : "";
  // когда заданы и быстрый выбор, и даты, работает быстрый выбор (так считает и слой данных)
  const from = quick ? "" : (f.date ?? f.from ?? "");
  const to = quick ? "" : (f.date ?? f.to ?? "");
  const lo = Math.min(Math.max(f.priceMin ?? PRICE_MIN, PRICE_MIN), PRICE_MAX - PRICE_STEP);
  const hi = Math.max(Math.min(f.priceMax ?? PRICE_MAX, PRICE_MAX), lo + PRICE_STEP);
  return {
    q: f.q ?? "",
    category: f.category ?? [],
    city: f.city ?? "",
    when: quick,
    from,
    to,
    price: [lo, hi],
    free: f.free ?? false,
    pushkinCard: f.pushkinCard ?? false,
  };
}

/**
 * Фильтры из полей панели. Значения «по умолчанию» (ползунок в крайних положениях, пустые поля) в адрес не попадают;
 * сортировка и площадка в панели не редактируются — их переносим из текущих фильтров.
 */
export function filtersFromState(s: FilterFormState, keep: Pick<EventFilters, "sort" | "venue"> = {}): EventFilters {
  const f: EventFilters = {};
  if (s.city) f.city = s.city;
  const chosen = new Set(s.category);
  const category = CATEGORIES.map((c) => c.slug).filter((slug) => chosen.has(slug));
  if (category.length) f.category = category;
  const q = s.q.trim();
  if (q) f.q = q;

  if (s.when) f.when = s.when;
  else {
    const [from, to] = s.from && s.to && s.from > s.to ? [s.to, s.from] : [s.from, s.to];
    if (from && from === to) f.date = from;
    else {
      if (from) f.from = from;
      if (to) f.to = to;
    }
  }

  if (s.free) f.free = true;
  else {
    if (s.price[0] > PRICE_MIN) f.priceMin = s.price[0];
    if (s.price[1] < PRICE_MAX) f.priceMax = s.price[1];
  }
  if (s.pushkinCard) f.pushkinCard = true;
  if (keep.venue) f.venue = keep.venue;
  if (keep.sort) f.sort = keep.sort;
  return f;
}

/** Подпись значения ползунка: верхнее положение — «5 000+ ₽» */
export function priceStepLabel(value: number): string {
  return value >= PRICE_MAX ? `${new Intl.NumberFormat("ru-RU").format(PRICE_MAX)}+ ₽` : formatPrice(value);
}
