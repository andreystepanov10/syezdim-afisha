// Данные Telegram-бота: пользователи (только ID чата), связка подборки с сайтом, ссылки «поделиться», напоминания.
import { randomBytes } from "node:crypto";
import { and, eq, gt, gte, inArray, lt, notExists, sql } from "drizzle-orm";
import { getDb, type Db } from "@/db/client";
import { channelPosts, events, favorites, linkTokens, reminderLog, shareLinks, telegramUsers } from "@/db/schema";
import type { CitySlug } from "@/lib/cities";

export type Ctx = { db?: Db; now?: Date };

export type TelegramUser = {
  chatId: number;
  deviceId: string;
  city: CitySlug | null;
  reminders: boolean;
  lastQuery: string | null;
};

/** Случайный идентификатор — как device_id сайта (src/lib/device.ts), ни с чем не связан */
export function randomId(bytes = 16): string {
  return randomBytes(bytes).toString("hex");
}

const LINK_TTL_MS = 15 * 60 * 1000;

/** Пользователь бота; при первом обращении создаётся со своим случайным device_id */
export async function getOrCreateTelegramUser(chatId: number, ctx: Ctx = {}): Promise<TelegramUser> {
  const db = ctx.db ?? (await getDb());
  await db.insert(telegramUsers).values({ chatId, deviceId: randomId() }).onConflictDoNothing();
  const [row] = await db.select().from(telegramUsers).where(eq(telegramUsers.chatId, chatId)).limit(1);
  return { chatId: row.chatId, deviceId: row.deviceId, city: row.city as CitySlug | null, reminders: row.reminders, lastQuery: row.lastQuery };
}

export async function updateTelegramUser(
  chatId: number,
  patch: Partial<Pick<TelegramUser, "city" | "reminders" | "lastQuery" | "deviceId">>,
  ctx: Ctx = {},
): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.update(telegramUsers).set(patch).where(eq(telegramUsers.chatId, chatId));
}

/** Переносит избранное с одного device_id на другой без дублей (при связке сайта и бота) */
export async function mergeFavorites(fromDeviceId: string, toDeviceId: string, ctx: Ctx = {}): Promise<void> {
  if (fromDeviceId === toDeviceId) return;
  const db = ctx.db ?? (await getDb());
  const rows = await db.select({ eventId: favorites.eventId }).from(favorites).where(eq(favorites.deviceId, fromDeviceId));
  if (rows.length > 0) {
    await db
      .insert(favorites)
      .values(rows.map((r) => ({ deviceId: toDeviceId, eventId: r.eventId })))
      .onConflictDoNothing();
  }
}

/** Одноразовая ссылка связки на 15 минут: purpose to_bot — открыть в боте подборку браузера, to_site — наоборот */
export async function createLinkToken(deviceId: string, purpose: "to_bot" | "to_site", ctx: Ctx = {}): Promise<string> {
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const token = randomId(12);
  await db.delete(linkTokens).where(lt(linkTokens.expiresAt, now));
  await db.insert(linkTokens).values({ token, deviceId, purpose, expiresAt: new Date(now.getTime() + LINK_TTL_MS) });
  return token;
}

/** Забирает токен (одноразово): device_id или null, если токена нет, он просрочен или не того назначения */
export async function consumeLinkToken(token: string, purpose: "to_bot" | "to_site", ctx: Ctx = {}): Promise<string | null> {
  if (!/^[a-f0-9]{24}$/.test(token)) return null;
  const db = ctx.db ?? (await getDb());
  const now = ctx.now ?? new Date();
  const [row] = await db
    .delete(linkTokens)
    .where(and(eq(linkTokens.token, token), eq(linkTokens.purpose, purpose), gt(linkTokens.expiresAt, now)))
    .returning({ deviceId: linkTokens.deviceId });
  return row?.deviceId ?? null;
}

/** id публичной ссылки на подборку устройства (одна на устройство, создаётся при первом запросе) */
export async function getOrCreateShareId(deviceId: string, ctx: Ctx = {}): Promise<string> {
  const db = ctx.db ?? (await getDb());
  await db.insert(shareLinks).values({ id: randomId(8), deviceId }).onConflictDoNothing();
  const [row] = await db.select({ id: shareLinks.id }).from(shareLinks).where(eq(shareLinks.deviceId, deviceId)).limit(1);
  return row.id;
}

export async function getDeviceIdByShareId(id: string, ctx: Ctx = {}): Promise<string | null> {
  if (!/^[a-f0-9]{16}$/.test(id)) return null;
  const db = ctx.db ?? (await getDb());
  const [row] = await db.select({ deviceId: shareLinks.deviceId }).from(shareLinks).where(eq(shareLinks.id, id)).limit(1);
  return row?.deviceId ?? null;
}

/** id ↔ slug: в callback_data Telegram помещается только 64 байта, поэтому кнопки ссылаются на id события */
export async function getEventIds(slugs: string[], ctx: Ctx = {}): Promise<Map<string, number>> {
  if (slugs.length === 0) return new Map();
  const db = ctx.db ?? (await getDb());
  const rows = await db.select({ id: events.id, slug: events.slug }).from(events).where(inArray(events.slug, slugs));
  return new Map(rows.map((r) => [r.slug, r.id]));
}

export async function getEventSlug(id: number, ctx: Ctx = {}): Promise<string | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db.select({ slug: events.slug }).from(events).where(eq(events.id, id)).limit(1);
  return row?.slug ?? null;
}

export type DueReminder = { chatId: number; eventId: number; slug: string };

/**
 * Напоминания к отправке: избранные события пользователей с включёнными напоминаниями,
 * которые начинаются в интервале [from, to), и по которым напоминание ещё не отправлялось.
 */
export async function listDueReminders(range: { from: Date; to: Date }, ctx: Ctx = {}): Promise<DueReminder[]> {
  const db = ctx.db ?? (await getDb());
  return db
    .select({ chatId: telegramUsers.chatId, eventId: events.id, slug: events.slug })
    .from(telegramUsers)
    .innerJoin(favorites, eq(favorites.deviceId, telegramUsers.deviceId))
    .innerJoin(events, eq(events.id, favorites.eventId))
    .where(
      and(
        eq(telegramUsers.reminders, true),
        eq(events.status, "published"),
        gte(events.startsAt, sql`${range.from.toISOString()}::timestamptz`),
        lt(events.startsAt, sql`${range.to.toISOString()}::timestamptz`),
        notExists(
          db
            .select({ one: sql`1` })
            .from(reminderLog)
            .where(and(eq(reminderLog.chatId, telegramUsers.chatId), eq(reminderLog.eventId, events.id))),
        ),
      ),
    );
}

export async function markReminderSent(chatId: number, eventId: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.insert(reminderLog).values({ chatId, eventId }).onConflictDoNothing();
}

/** Пользователь заблокировал бота — удаляем его запись (и вместе с ней единственное, что о нём знали: ID чата) */
export async function deleteTelegramUser(chatId: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.delete(reminderLog).where(eq(reminderLog.chatId, chatId));
  await db.delete(telegramUsers).where(eq(telegramUsers.chatId, chatId));
}

/** id событий, уже опубликованных в канале города (автопостинг не повторяет их) */
export async function getPostedEventIds(city: string, ctx: Ctx = {}): Promise<Set<number>> {
  const db = ctx.db ?? (await getDb());
  const rows = await db.select({ eventId: channelPosts.eventId }).from(channelPosts).where(eq(channelPosts.city, city));
  return new Set(rows.map((r) => r.eventId));
}

export async function markEventPosted(city: string, eventId: number, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  await db.insert(channelPosts).values({ city, eventId }).onConflictDoNothing();
}
