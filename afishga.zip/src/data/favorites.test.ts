import { beforeAll, describe, expect, it } from "vitest";
import { createDemoDb, type Db } from "@/db/client";
import { getFavoriteEvents } from "./events";
import { getFavoriteSlugs, toggleFavorite } from "./favorites";

let db: Db;
beforeAll(async () => {
  db = await createDemoDb();
});

describe("избранное (анонимно, по device_id)", () => {
  it("переключается туда-обратно; неизвестный slug — false и без изменений", async () => {
    const device = "device-a";
    expect(await getFavoriteSlugs(device, { db })).toEqual(new Set());
    expect(await toggleFavorite(device, "voronezh-revizor", { db })).toBe(true);
    expect(await getFavoriteSlugs(device, { db })).toEqual(new Set(["voronezh-revizor"]));
    expect(await toggleFavorite(device, "voronezh-revizor", { db })).toBe(false);
    expect(await getFavoriteSlugs(device, { db })).toEqual(new Set());

    expect(await toggleFavorite(device, "net-takogo-sobytiya", { db })).toBe(false);
  });

  it("избранное разных устройств не пересекается", async () => {
    await toggleFavorite("device-b", "voronezh-revizor", { db });
    expect(await getFavoriteSlugs("device-c", { db })).toEqual(new Set());
  });

  it("getFavoriteEvents отдаёт полные карточки, последние добавленные — первыми", async () => {
    const device = "device-d";
    await toggleFavorite(device, "voronezh-revizor", { db });
    await toggleFavorite(device, "voronezh-dzhaz", { db });

    const list = await getFavoriteEvents(device, { db });
    expect(list.map((e) => e.slug)).toEqual(["voronezh-dzhaz", "voronezh-revizor"]);
    expect(list[0].title).toContain("Джаз");
  });

  it("устройство без cookie (незнакомый deviceId) — пустой список, без ошибок", async () => {
    expect(await getFavoriteEvents("net-takogo-ustroistva", { db })).toEqual([]);
  });
});
