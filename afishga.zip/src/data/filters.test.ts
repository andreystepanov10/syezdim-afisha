import { describe, expect, it } from "vitest";
import { parseFilters, resolveRange, toTsQuery } from "./filters";

// Среда 23.09.2026 10:00 МСК; суббота 26.09.2026 15:00 МСК; воскресенье 27.09.2026 15:00 МСК
const WED = new Date("2026-09-23T07:00:00Z");
const SAT = new Date("2026-09-26T12:00:00Z");
const SUN = new Date("2026-09-27T12:00:00Z");

describe("parseFilters", () => {
  it("собирает параметры из URL, category — и через запятую, и повторяющимся ключом", () => {
    const a = parseFilters({ city: "kursk", category: "concerts,theatre", q: " джаз ", priceMax: "1500", free: "1", page: "2" }, { strict: true });
    expect(a).toEqual({ ok: true, value: { city: "kursk", category: ["concerts", "theatre"], q: "джаз", priceMax: 1500, free: true, page: 2, pageSize: 12 } });
    const b = parseFilters({ category: ["kids", "cinema"] }, { strict: true });
    expect(b.ok && b.value.category).toEqual(["kids", "cinema"]);
  });

  it("пустые значения игнорируются, значения по умолчанию подставляются", () => {
    const r = parseFilters({ q: "", city: "", when: undefined }, { strict: true });
    expect(r).toEqual({ ok: true, value: { page: 1, pageSize: 12 } });
  });

  it("strict (API): некорректные значения — ошибка со списком проблем", () => {
    const r = parseFilters({ city: "moscow", page: "0", date: "2026-02-31", category: "nope" }, { strict: true });
    expect(r.ok).toBe(false);
    if (!r.ok) for (const key of ["city", "page", "date", "category"]) expect(r.issues.some((i) => i.startsWith(key))).toBe(true);
  });

  it("не strict (страницы): некорректное отбрасывается, остальное сохраняется", () => {
    const r = parseFilters({ city: "moscow", category: "concerts", page: "-5", pageSize: "1000" }, { strict: false });
    expect(r).toEqual({ ok: true, value: { category: ["concerts"], page: 1, pageSize: 12 } });
  });

  it("ограничивает размер страницы и длину запроса", () => {
    expect(parseFilters({ pageSize: "49" }, { strict: true }).ok).toBe(false);
    expect(parseFilters({ q: "я".repeat(101) }, { strict: true }).ok).toBe(false);
  });
});

describe("resolveRange (сутки по МСК)", () => {
  it("сегодня: с текущего момента до конца суток", () => {
    const r = resolveRange({ when: "today" }, WED);
    expect(r.from).toEqual(WED);
    expect(r.to?.toISOString()).toBe("2026-09-23T21:00:00.000Z"); // 24.09 00:00 МСК
  });

  it("завтра: целые сутки", () => {
    const r = resolveRange({ when: "tomorrow" }, WED);
    expect(r.from.toISOString()).toBe("2026-09-23T21:00:00.000Z");
    expect(r.to?.toISOString()).toBe("2026-09-24T21:00:00.000Z");
  });

  it("выходные: из среды — ближайшие сб и вс; в субботу — с текущего момента; в воскресенье — только сегодня", () => {
    const fromWed = resolveRange({ when: "weekend" }, WED);
    expect(fromWed.from.toISOString()).toBe("2026-09-25T21:00:00.000Z"); // сб 26.09 00:00 МСК
    expect(fromWed.to?.toISOString()).toBe("2026-09-27T21:00:00.000Z"); // пн 28.09 00:00 МСК

    const fromSat = resolveRange({ when: "weekend" }, SAT);
    expect(fromSat.from).toEqual(SAT);
    expect(fromSat.to?.toISOString()).toBe("2026-09-27T21:00:00.000Z");

    const fromSun = resolveRange({ when: "weekend" }, SUN);
    expect(fromSun.from).toEqual(SUN);
    expect(fromSun.to?.toISOString()).toBe("2026-09-27T21:00:00.000Z");
  });

  it("конкретная дата и период (to включительно)", () => {
    const day = resolveRange({ date: "2026-10-15" }, WED);
    expect(day.from.toISOString()).toBe("2026-10-14T21:00:00.000Z");
    expect(day.to?.toISOString()).toBe("2026-10-15T21:00:00.000Z");
    const span = resolveRange({ from: "2026-10-01", to: "2026-10-03" }, WED);
    expect(span.from.toISOString()).toBe("2026-09-30T21:00:00.000Z");
    expect(span.to?.toISOString()).toBe("2026-10-03T21:00:00.000Z");
  });

  it("нижняя граница никогда не раньше «сейчас»", () => {
    expect(resolveRange({ date: "2020-01-01" }, WED).from).toEqual(WED);
    expect(resolveRange({}, WED)).toEqual({ from: WED, to: undefined });
  });
});

describe("toTsQuery", () => {
  it("слова через AND, у каждого префикс", () => {
    expect(toTsQuery("Джаз, вечер!")).toBe("джаз:* & вечер:*");
  });
  it("выбрасывает всё, кроме букв и цифр (защита от спецсимволов tsquery)", () => {
    expect(toTsQuery("a & b | !c :d (e) 'f' \\g")).toBe("a:* & b:* & c:* & d:* & e:* & f:* & g:*");
    expect(toTsQuery("'; DROP TABLE events; --")).toBe("drop:* & table:* & events:*");
  });
  it("ничего осмысленного — null; слов не больше 8", () => {
    expect(toTsQuery("!!! ??? ---")).toBeNull();
    expect(toTsQuery("а б в г д е ж з и к")?.split(" & ")).toHaveLength(8);
  });
});
