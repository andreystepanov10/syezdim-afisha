// Счётчик переходов к партнёрам за билетами (src/app/go) — без персональных данных, только числа по дням.
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { getDb, type Db } from "@/db/client";
import { events, ticketClicks } from "@/db/schema";
import type { ClickSource } from "@/lib/affiliate";
import { isoDayMsk } from "@/lib/time";

export type Ctx = { db?: Db; now?: Date };

/** Событие для перехода: куда вести и чей id считать. null — нет события или ссылки на билеты */
export async function getTicketTarget(slug: string, ctx: Ctx = {}): Promise<{ id: number; ticketUrl: string } | null> {
  const db = ctx.db ?? (await getDb());
  const [row] = await db.select({ id: events.id, ticketUrl: events.ticketUrl }).from(events).where(eq(events.slug, slug)).limit(1);
  return row?.ticketUrl ? { id: row.id, ticketUrl: row.ticketUrl } : null;
}

export async function recordTicketClick(eventId: number, source: ClickSource, ctx: Ctx = {}): Promise<void> {
  const db = ctx.db ?? (await getDb());
  const day = isoDayMsk(ctx.now ?? new Date());
  await db
    .insert(ticketClicks)
    .values({ day, eventId, source, count: 1 })
    .onConflictDoUpdate({ target: [ticketClicks.day, ticketClicks.eventId, ticketClicks.source], set: { count: sql`${ticketClicks.count} + 1` } });
}

export type ClickStats = {
  total: number;
  bySource: Record<string, number>;
  top: { title: string; slug: string; count: number }[];
};

/** Сводка за последние days дней — для статистики в админке */
export async function getClickStats(days: number, ctx: Ctx = {}): Promise<ClickStats> {
  const db = ctx.db ?? (await getDb());
  const from = isoDayMsk(new Date((ctx.now ?? new Date()).getTime() - (days - 1) * 24 * 60 * 60 * 1000));
  const since = gte(ticketClicks.day, from);
  const [bySourceRows, top] = await Promise.all([
    db.select({ source: ticketClicks.source, n: sql<number>`sum(${ticketClicks.count})::int` }).from(ticketClicks).where(since).groupBy(ticketClicks.source),
    db
      .select({ title: events.title, slug: events.slug, count: sql<number>`sum(${ticketClicks.count})::int` })
      .from(ticketClicks)
      .innerJoin(events, eq(events.id, ticketClicks.eventId))
      .where(and(since))
      .groupBy(events.id)
      .orderBy(desc(sql`sum(${ticketClicks.count})`))
      .limit(10),
  ]);
  const bySource = Object.fromEntries(bySourceRows.map((r) => [r.source, r.n]));
  return { total: bySourceRows.reduce((s, r) => s + r.n, 0), bySource, top };
}
