import { beforeAll, describe, expect, it } from "vitest";
import { createDemoDb, type Db } from "@/db/client";
import { getDailyStats, getTopPaths, recordPageView, type Ctx } from "./analytics";

let db: Db;
let ctx: Ctx;
beforeAll(async () => {
  db = await createDemoDb();
  ctx = { db };
});

describe("аналитика просмотров", () => {
  it("считает просмотры и уникальных посетителей за сегодня", async () => {
    await recordPageView({ path: "/voronezh/events", deviceId: "device-a" }, ctx);
    await recordPageView({ path: "/voronezh/events", deviceId: "device-a" }, ctx);
    await recordPageView({ path: "/voronezh/events", deviceId: "device-b" }, ctx);
    await recordPageView({ path: "/events/some-slug", deviceId: "device-a" }, ctx);

    const daily = await getDailyStats(1, ctx);
    expect(daily).toHaveLength(1);
    expect(daily[0]).toMatchObject({ views: 4, uniqueVisitors: 2 });

    const top = await getTopPaths(1, 10, ctx);
    expect(top[0]).toMatchObject({ path: "/voronezh/events", views: 3 });
  });

  it("для периода без просмотров возвращает пустой список", async () => {
    expect(await getDailyStats(0, ctx)).toEqual([]);
  });
});
