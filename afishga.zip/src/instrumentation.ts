// Выполняется один раз при старте сервера (dev и start): открываем базу заранее, чтобы первый посетитель
// не ждал инициализацию, а ошибка настройки (нет DATABASE_URL, недоступен Postgres) попала в лог сразу.
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const { getDb } = await import("@/db/client");
  try {
    await getDb();
    console.log("[db] база данных готова");
  } catch (error) {
    console.error("[db] не удалось открыть базу данных:", error instanceof Error ? error.message : error);
  }
}
