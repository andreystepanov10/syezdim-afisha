"use client";

import { useSyncExternalStore } from "react";
import { CITY_COOKIE, DEFAULT_CITY, isCitySlug, type CitySlug } from "./cities";

// Выбранный город хранится в cookie. Читаем через useSyncExternalStore:
// на сервере и при гидратации — город по умолчанию, дальше — из cookie, без мигания ошибок гидратации.
const CHANGE_EVENT = "radius:city";

function read(): CitySlug {
  const match = document.cookie.match(new RegExp(`(?:^|; )${CITY_COOKIE}=([^;]*)`));
  const value = match?.[1];
  return value && isCitySlug(value) ? value : DEFAULT_CITY;
}

/** Текущий город без подписки — для обработчиков и эффектов (только в браузере) */
export const getCity = read;

function subscribe(onChange: () => void) {
  window.addEventListener(CHANGE_EVENT, onChange);
  return () => window.removeEventListener(CHANGE_EVENT, onChange);
}

export function setCity(slug: CitySlug) {
  document.cookie = `${CITY_COOKIE}=${slug}; path=/; max-age=31536000; samesite=lax`;
  window.dispatchEvent(new Event(CHANGE_EVENT));
}

export function useCity(): CitySlug {
  return useSyncExternalStore(subscribe, read, () => DEFAULT_CITY);
}
