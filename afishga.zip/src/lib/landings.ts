// Посадочные страницы под частые поисковые запросы: «куда сходить в Воронеже сегодня», «афиша на выходные»,
// «афиша Старого Оскола». Каталог с фильтрами (/voronezh/events?when=today) закрыт от индексации — это его
// открытые двойники с собственным заголовком и текстом. Маршрут — app/[city]/[page].
import type { When } from "@/data/filters";
import { cityGenitive, cityLocative, cityRegion, type CitySlug } from "@/lib/cities";
import { addDays, startOfDayMsk, weekdayMsk } from "@/lib/time";

export type DateLanding = { slug: string; when: When; label: string };

/** Порядок — как в ссылках на странице города */
export const DATE_LANDINGS: DateLanding[] = [
  { slug: "segodnya", when: "today", label: "Сегодня" },
  { slug: "zavtra", when: "tomorrow", label: "Завтра" },
  { slug: "vyhodnye", when: "weekend", label: "На выходных" },
  { slug: "na-nedele", when: "week", label: "На неделе" },
];

export function findDateLanding(slug: string): DateLanding | undefined {
  return DATE_LANDINGS.find((d) => d.slug === slug);
}

const dayMonth = (d: Date) => new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", timeZone: "Europe/Moscow" }).format(d);

/** «15 октября», «17–18 октября», «15–21 октября» — даты страницы на сегодня (МСК) */
export function landingDates(when: When, now: Date): string {
  const today = startOfDayMsk(now);
  switch (when) {
    case "today":
      return dayMonth(now);
    case "tomorrow":
      return dayMonth(addDays(today, 1));
    case "weekend": {
      const dow = weekdayMsk(now);
      const sat = dow === 6 ? today : dow === 0 ? addDays(today, -1) : addDays(today, 6 - dow);
      return `${dayMonth(sat)} — ${dayMonth(addDays(sat, 1))}`;
    }
    case "week":
      return `${dayMonth(now)} — ${dayMonth(addDays(today, 6))}`;
    default:
      return "";
  }
}

/** Заголовок = <title> и H1: так и ищут — «Куда сходить в Воронеже сегодня» */
export function dateLandingTitle(landing: DateLanding, city: CitySlug): string {
  const phrase = { today: "сегодня", tomorrow: "завтра", weekend: "на выходных", week: "на этой неделе", date: "" }[landing.when];
  return `Куда сходить ${cityLocative(city)} ${phrase}`;
}

export function dateLandingDescription(landing: DateLanding, city: CitySlug, now: Date): string {
  const dates = landingDates(landing.when, now);
  return `Афиша ${cityLocative(city)} и области на ${dates}: концерты, спектакли, кино, выставки, детские события. Время, цены и билеты — в одном месте.`;
}

/** Населённый пункт области: склонять названия («Старого Оскола») без словаря ненадёжно — пишем через двоеточие */
export function localityTitle(name: string): string {
  return `${name}: афиша событий — концерты, спектакли, кино`;
}

export function localityDescription(name: string, city: CitySlug): string {
  return `Куда сходить: ${name}, ${cityRegion(city)}. Концерты, спектакли, выставки и детские события — даты, цены и билеты. Афиша ${cityGenitive(city)} и области на «Съездим».`;
}
