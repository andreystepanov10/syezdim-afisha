// Партнёрские ссылки на билеты. Шаблон диплинка партнёрской сети (Admitad и т. п.) задаётся переменной окружения
// на источник, {url} заменяется ссылкой на событие: AFFILIATE_KASSIR="https://ad.admitad.com/g/xxxx/?ulp={url}".
// Без шаблона ссылка остаётся как есть — переходы всё равно считаются (/go/<slug>).

const RULES: { host: RegExp; env: string }[] = [
  { host: /(^|\.)kassir\.ru$/i, env: "AFFILIATE_KASSIR" },
  { host: /(^|\.)afishagoroda\.ru$/i, env: "AFFILIATE_AFISHAGORODA" },
  { host: /(^|\.)afisha\.ru$/i, env: "AFFILIATE_AFISHA_RU" },
];

function ruleFor(url: string): string | undefined {
  try {
    const host = new URL(url).hostname;
    return RULES.find((r) => r.host.test(host))?.env;
  } catch {
    return undefined;
  }
}

export function affiliateUrl(url: string): string {
  const env = ruleFor(url);
  const template = env ? process.env[env] : undefined;
  return template?.includes("{url}") ? template.replace("{url}", encodeURIComponent(url)) : url;
}

/**
 * Маркировка рекламы (38-ФЗ «О рекламе», правила программ Admitad): партнёрская ссылка — реклама, рядом нужна пометка
 * «Реклама» с рекламодателем и токеном erid. Текст пометки — из AFFILIATE_<ИСТОЧНИК>_MARK (его выдаёт Admitad вместе с
 * диплинком), например «Реклама. ООО «Кассир.ру», ИНН …, erid: …». null — ссылка не партнёрская, пометка не нужна
 */
export function affiliateMark(url: string | undefined | null): string | null {
  const env = url ? ruleFor(url) : undefined;
  if (!env || !process.env[env]?.includes("{url}")) return null;
  return process.env[`${env}_MARK`] || "Реклама";
}

export type ClickSource = "site" | "channel" | "bot";

/** Ссылка «Купить билет»: через наш счётчик /go/<slug>, а он уже ведёт к партнёру */
export function ticketHref(slug: string, source: ClickSource = "site", absolute = ""): string {
  return `${absolute}/go/${slug}${source === "site" ? "" : `?from=${source}`}`;
}
