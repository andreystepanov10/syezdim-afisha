// Анонимный ID устройства для избранного — случайная строка ни с чем не связана (не email, не имя, не IP),
// поэтому не является персональными данными по 152-ФЗ и не требует согласия/учётной записи.
import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";

export const DEVICE_COOKIE = "radius_device";
const MAX_AGE = 2 * 365 * 24 * 60 * 60; // 2 года

/** Только чтение — безопасно вызывать при рендере страницы. null — на этом устройстве ещё ничего не выбирали */
export async function getDeviceId(): Promise<string | null> {
  return (await cookies()).get(DEVICE_COOKIE)?.value ?? null;
}

const COOKIE_OPTIONS = { httpOnly: true, sameSite: "lax", path: "/", maxAge: MAX_AGE } as const;

/** Создаёт cookie при первом обращении — только из Server Action/Route Handler (cookies().set нельзя во время рендера) */
export async function getOrCreateDeviceId(): Promise<string> {
  const store = await cookies();
  const existing = store.get(DEVICE_COOKIE)?.value;
  if (existing) return existing;
  const id = randomBytes(16).toString("hex");
  store.set(DEVICE_COOKIE, id, COOKIE_OPTIONS);
  return id;
}

/** Переключает браузер на другой device_id — после связки подборки с Telegram-ботом (api/telegram/open). Только Route Handler */
export async function switchDeviceId(id: string): Promise<void> {
  (await cookies()).set(DEVICE_COOKIE, id, COOKIE_OPTIONS);
}
