import { describe, expect, it } from "vitest";
import type { EventDetails } from "@/data/events";
import { absoluteUrl, eventDescription, eventJsonLd, eventTitle, jsonLdString, truncate } from "./seo";

const event: EventDetails = {
  slug: "osennyaya-sonata",
  title: "Спектакль «Осенняя соната»",
  startsAt: "2026-10-15T16:00:00.000Z",
  city: "voronezh",
  category: "theatre",
  priceFrom: 800,
  priceTo: 2500,
  image: "/uploads/sonata.jpg",
  ticketUrl: "https://vrn.kassir.ru/teatr/sonata",
  description: "Шарлотта только что потеряла человека, с которым жила многие годы. ".repeat(5),
  venue: { slug: "dramteatr", name: "Драмтеатр им. Кольцова", address: "пр. Революции, 55", lat: 51.66, lon: 39.2 },
  ticketTypes: [],
};

describe("truncate", () => {
  it("короткий текст не трогает, только схлопывает пробелы", () => {
    expect(truncate("  Концерт \n\n в парке ")).toBe("Концерт в парке");
  });

  it("длинный режет по границе слова и ставит многоточие", () => {
    const result = truncate("слово ".repeat(50), 40);
    expect(result.length).toBeLessThanOrEqual(40);
    expect(result.endsWith("слово…")).toBe(true);
  });
});

describe("absoluteUrl", () => {
  it("делает абсолютными свои пути и не трогает чужие ссылки", () => {
    expect(absoluteUrl("/uploads/a.jpg")).toBe("https://syezdim.ru/uploads/a.jpg");
    expect(absoluteUrl("https://cdn.example.com/a.jpg")).toBe("https://cdn.example.com/a.jpg");
  });
});

describe("eventTitle / eventDescription", () => {
  it("в заголовке — название, город и дата по МСК", () => {
    expect(eventTitle(event)).toBe("Спектакль «Осенняя соната» — Воронеж, 15 октября");
  });

  it("описание начинается с фактов и укладывается в сниппет", () => {
    const d = eventDescription(event);
    // Формат даты зависит от версии ICU в Node («15 октября 2026 г. в 19:00» / «…, 19:00») — проверяем факты, не разделители
    expect(d).toMatch(/^15 октября 2026.*19:00, Драмтеатр им\. Кольцова, Воронеж\. от 800 ₽\. Шарлотта/);
    expect(d.length).toBeLessThanOrEqual(160);
  });
});

describe("eventJsonLd", () => {
  it("собирает Schema.org Event с местом и ценой", () => {
    const ld = eventJsonLd(event);
    expect(ld["@type"]).toBe("Event");
    expect(ld.url).toBe("https://syezdim.ru/events/osennyaya-sonata");
    expect(ld.image).toEqual(["https://syezdim.ru/uploads/sonata.jpg"]);
    expect(ld.location).toMatchObject({ name: "Драмтеатр им. Кольцова", address: { addressLocality: "Воронеж" } });
    expect(ld.offers).toMatchObject({ price: 800, priceCurrency: "RUB", url: event.ticketUrl });
  });

  it("без цены не выдумывает offers", () => {
    expect(eventJsonLd({ ...event, priceFrom: null }).offers).toBeUndefined();
  });

  it("экранирует «<», чтобы текст не закрыл <script>", () => {
    expect(jsonLdString({ name: "</script><b>" })).not.toContain("</script>");
  });
});

describe("eventTitle для периодов", () => {
  it("фильм — «в кино», выставка — «до …»", () => {
    expect(eventTitle({ ...event, category: "cinema", endsAt: "2026-10-20T20:59:00.000Z" })).toBe("Спектакль «Осенняя соната» — в кино, Воронеж");
    expect(eventTitle({ ...event, category: "exhibitions", endsAt: "2026-12-06T17:00:00.000Z" })).toBe("Спектакль «Осенняя соната» — Воронеж, до 6 декабря");
  });

  it("площадка в области — населённый пункт вместо областного центра", () => {
    expect(eventTitle({ ...event, locality: "Россошь" })).toBe("Спектакль «Осенняя соната» — Россошь, 15 октября");
  });
});
