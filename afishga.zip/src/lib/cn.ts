import { clsx, type ClassValue } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

// Учим tailwind-merge нашим токенам (тени и радиусы из дизайн-системы)
const twMerge = extendTailwindMerge({
  extend: {
    theme: {
      shadow: ["soft", "medium", "hover"],
      radius: ["xs", "sm", "md", "lg", "xl", "pill"],
    },
  },
});

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
