"use client";

import { useEffect, useRef, useState } from "react";

/**
 * true, как только элемент оказался рядом с экраном (с запасом rootMargin) — раз и навсегда.
 * Нужен, чтобы откладывать монтирование тяжёлых клиентских виджетов (например, карты Leaflet)
 * до момента, когда они реально понадобятся.
 */
export function useLazyVisible<T extends HTMLElement>(rootMargin = "400px") {
  const ref = useRef<T>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || visible) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [visible, rootMargin]);

  return { ref, visible };
}
