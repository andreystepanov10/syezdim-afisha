import { beforeAll, describe, expect, it } from "vitest";
import { createDemoDb, type Db } from "@/db/client";
import { buildDigest, buildEventPost, parseChannels } from "./digest";

const NOW = new Date("2026-10-14T06:00:00Z"); // среда, 9:00 МСК
let db: Db;
beforeAll(async () => {
  db = await createDemoDb({ now: NOW });
});

describe("parseChannels", () => {
  it("разбирает «город=канал», неизвестные города пропускает", () => {
    const m = parseChannels("voronezh=@syezdim_vrn, belgorod=-1001234,moscow=@x");
    expect([...m]).toEqual([
      ["voronezh", "@syezdim_vrn"],
      ["belgorod", "-1001234"],
    ]);
  });
});

describe("buildDigest", () => {
  it("пост на неделю вперёд: заголовок, ссылки с utm, без кино и выставок", async () => {
    const d = await buildDigest("voronezh", "weekend", { db, now: NOW });
    if (!d) return; // в демо-данных на выходные может быть мало событий
    expect(d.text).toContain("Куда сходить в Воронеже на выходных");
    expect(d.text).toContain("utm_source=telegram");
    expect(d.text).not.toContain("<script");
    expect(d.reply_markup.inline_keyboard[0][0]).toMatchObject({ text: "Все события" });
  });

  it("когда событий мало — null, пост не публикуется", async () => {
    const empty = await createDemoDb({ now: new Date("2030-01-01T00:00:00Z") });
    expect(await buildDigest("orel", "today", { db: empty, now: new Date("2031-01-01T00:00:00Z") })).toBeNull();
  });
});

describe("подпись к альбому", () => {
  it("укладывается в лимит Telegram 1024 символа", async () => {
    const d = await buildDigest("voronezh", "weekend", { db, now: NOW });
    if (!d) return;
    expect(d.caption.replace(/<[^>]+>/g, "").length).toBeLessThanOrEqual(1024);
    expect(d.photos.every((p) => p.startsWith("http") && !p.endsWith(".svg"))).toBe(true);
  });
});

describe("buildEventPost", () => {
  it("берёт событие с картинкой, кнопки «Билеты/На сайте/Сохранить», не повторяет опубликованное", async () => {
    const { markEventPosted } = await import("@/data/telegram");
    const post = await buildEventPost("voronezh", { db, now: NOW });
    if (!post) return; // у демо-событий картинки-заглушки SVG — тогда публиковать нечего, это тоже верно
    expect(post.photo.startsWith("http")).toBe(true);
    expect(post.caption.replace(/<[^>]+>/g, "").length).toBeLessThanOrEqual(1024);
    await markEventPosted("voronezh", post.eventId, { db });
    const next = await buildEventPost("voronezh", { db, now: NOW });
    expect(next?.eventId).not.toBe(post.eventId);
  });
});
