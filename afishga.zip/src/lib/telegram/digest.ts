// Посты для Telegram-каналов: «Куда сходить в Воронеже сегодня» (каждое утро) и «…на выходных» (по пятницам).
// Публикует scripts/telegram.mts post — по cron. Каналы задаются TELEGRAM_CHANNELS: «voronezh=@syezdim_vrn,belgorod=@…»
import { getEventBySlug, listEvents, type Ctx } from "@/data/events";
import { getEventIds, getPostedEventIds } from "@/data/telegram";
import type { CategorySlug } from "@/lib/categories";
import { cityLocative, cityName, isCitySlug, type CitySlug } from "@/lib/cities";
import { dateShort, priceLabel, timeShort } from "@/lib/format";
import { findDateLanding, landingDates } from "@/lib/landings";
import { ticketHref } from "@/lib/affiliate";
import { isArtPlaceholder } from "@/lib/art";
import { absoluteUrl, truncate } from "@/lib/seo";
import { addDays, isoDayMsk, MSK_OFFSET_MS } from "@/lib/time";
import { SITE_URL } from "@/lib/site";
import type { EventSummary } from "@/lib/types";
import { botUsername, escapeHtml, type InlineKeyboard } from "./api";

export type DigestKind = "today" | "weekend";

const EMOJI: Record<CategorySlug, string> = {
  concerts: "🎵",
  theatre: "🎭",
  exhibitions: "🖼",
  cinema: "🎬",
  kids: "🧸",
  festivals: "🎪",
  workshops: "✂️",
  sport: "⚽",
};

/** Сколько событий в посте: больше — пост превращается в простыню, которую пролистывают */
const MAX_ITEMS = 8;
/** Меньше — не публикуем: пост из одного события выглядит как заброшенный канал */
const MIN_ITEMS = 3;

/** Каналы по городам из TELEGRAM_CHANNELS: «voronezh=@syezdim_vrn,belgorod=-100123…» */
export function parseChannels(raw = process.env.TELEGRAM_CHANNELS ?? ""): Map<CitySlug, string> {
  const out = new Map<CitySlug, string>();
  for (const part of raw.split(",")) {
    const [city, chat] = part.split("=").map((s) => s.trim());
    if (city && chat && isCitySlug(city)) out.set(city, chat);
  }
  return out;
}

/** Метка для Метрики: видно, сколько людей пришло из канала */
function withUtm(path: string): string {
  return `${SITE_URL}${path}?utm_source=telegram&utm_medium=channel`;
}

function line(e: EventSummary, kind: DigestKind): string {
  const when = kind === "today" ? timeShort(e.startsAt) : `${dateShort(e.startsAt).toLowerCase()}, ${timeShort(e.startsAt)}`;
  const emoji = e.category ? EMOJI[e.category] : "📍";
  return `${emoji} <a href="${withUtm(`/events/${e.slug}`)}">${escapeHtml(e.title)}</a>\n${when} · ${escapeHtml(e.subtitle ?? "")} · ${priceLabel(e.priceFrom)}`;
}

export type Digest = {
  text: string;
  reply_markup: InlineKeyboard;
  link_preview_options: Record<string, unknown>;
  /** Постеры событий из поста (абсолютные адреса) — для альбома; SVG-заглушки Telegram не показывает */
  photos: string[];
  /** Короткий вариант текста для подписи к альбому: у Telegram лимит подписи — 1024 символа */
  caption: string;
};

/** Лимит подписи к фото в Telegram считается по видимому тексту, без HTML-тегов */
const CAPTION_LIMIT = 1024;
const MAX_PHOTOS = 6;

function visibleLength(html: string): number {
  return html.replace(/<[^>]+>/g, "").replace(/&(amp|lt|gt);/g, "x").length;
}

/** «🎭 Серёжа очень тупой — сб 12:00, Театр «Кот»»: одна строка на событие, чтобы влезть в подпись */
function shortLine(e: EventSummary, kind: DigestKind): string {
  const weekday = dateShort(e.startsAt).split(", ")[1]?.toLowerCase() ?? "";
  const when = kind === "today" ? timeShort(e.startsAt) : `${weekday} ${timeShort(e.startsAt)}`;
  const title = e.title.length > 48 ? `${e.title.slice(0, 47).trimEnd()}…` : e.title;
  const emoji = e.category ? EMOJI[e.category] : "📍";
  return `${emoji} <a href="${withUtm(`/events/${e.slug}`)}">${escapeHtml(title)}</a> — ${when}, ${escapeHtml(e.subtitle ?? "")}`;
}

/**
 * Пост на сегодня или выходные: разовые события (концерты, спектакли, детское) по времени. Фильмы в прокате
 * не берём — они идут неделями и заняли бы весь пост; для них есть страница по кнопке.
 * null — событий слишком мало, публиковать нечего.
 */
export async function buildDigest(city: CitySlug, kind: DigestKind, ctx: Ctx = {}): Promise<Digest | null> {
  const now = ctx.now ?? new Date();
  const landing = findDateLanding(kind === "today" ? "segodnya" : "vyhodnye")!;
  const { items, total } = await listEvents({ city, when: landing.when, pageSize: 40, groupSessions: true }, ctx);
  const picked = items.filter((e) => e.category !== "cinema" && e.category !== "exhibitions").slice(0, MAX_ITEMS);
  if (picked.length < MIN_ITEMS) return null;

  const title = kind === "today" ? `Куда сходить ${cityLocative(city)} сегодня, ${landingDates("today", now)}` : `Куда сходить ${cityLocative(city)} на выходных, ${landingDates("weekend", now)}`;
  const landingUrl = withUtm(`/${city}/${landing.slug}`);
  const bot = botUsername();
  const text = [
    `<b>${escapeHtml(title)}</b>`,
    "",
    picked.map((e) => line(e, kind)).join("\n\n"),
    "",
    `👉 <a href="${landingUrl}">Все события ${kind === "today" ? "на сегодня" : "на выходные"}</a> — ${total}, включая кино и выставки`,
    ...(bot ? [`⭐ Сохраняйте события и получайте напоминания в @${bot}`] : []),
  ].join("\n");

  // Подпись к альбому: заголовок, короткие строки (сколько влезет в лимит) и ссылка на все события
  const footer = `👉 <a href="${landingUrl}">Все события ${kind === "today" ? "на сегодня" : "на выходные"} (${total})</a>${bot ? ` · бот @${bot}` : ""}`;
  let lines = picked.map((e) => shortLine(e, kind));
  const compose = () => [`<b>${escapeHtml(title)}</b>`, "", lines.join("\n"), "", footer].join("\n");
  while (lines.length > MIN_ITEMS && visibleLength(compose()) > CAPTION_LIMIT) lines = lines.slice(0, -1);
  const photos = picked
    .map((e) => e.image)
    .filter((img): img is string => Boolean(img) && !img?.endsWith(".svg") && !isArtPlaceholder(img!))
    .map(absoluteUrl)
    .slice(0, MAX_PHOTOS);

  const buttons = [{ text: "Все события", url: landingUrl }, ...(bot ? [{ text: "🤖 Бот афиши", url: `https://t.me/${bot}` }] : [])];
  return {
    text,
    reply_markup: { inline_keyboard: [buttons] },
    // Превью — картинка страницы «сегодня/выходные», а не первой ссылки на событие
    link_preview_options: { url: landingUrl, prefer_large_media: true },
    photos,
    caption: compose(),
  };
}

export type EventPost = { eventId: number; slug: string; photo: string; caption: string; reply_markup: InlineKeyboard };

/** «Сегодня в 19:00», «Завтра в 12:00», «Сб, 17 октября, 12:00» — как говорят люди, а не как пишет календарь */
function whenLabel(startsAt: string, now: Date): string {
  const day = isoDayMsk(new Date(startsAt));
  if (day === isoDayMsk(now)) return `Сегодня в ${timeShort(startsAt)}`;
  if (day === isoDayMsk(addDays(now, 1))) return `Завтра в ${timeShort(startsAt)}`;
  return `${dateShort(startsAt).toLowerCase()}, ${timeShort(startsAt)}`;
}

/**
 * Пост об одном событии: постер, когда/где/сколько, пара предложений и кнопки «Билеты», «На сайте»,
 * «Сохранить в боте». Берём ближайшее неопубликованное разовое событие с картинкой: сегодня (не раньше чем
 * через час, чтобы успели собраться), а вечером — уже на завтра. «Hot» — вперёд. null — публиковать нечего.
 */
export async function buildEventPost(city: CitySlug, ctx: Ctx = {}): Promise<EventPost | null> {
  const now = ctx.now ?? new Date();
  const posted = await getPostedEventIds(city, ctx);
  const soon = now.getTime() + 60 * 60 * 1000;
  const lateEvening = new Date(now.getTime() + MSK_OFFSET_MS).getUTCHours() >= 20;

  const ok = (e: EventSummary) =>
    e.category !== "cinema" &&
    e.category !== "exhibitions" &&
    Boolean(e.image) &&
    !e.image!.endsWith(".svg") &&
    !isArtPlaceholder(e.image!) &&
    new Date(e.startsAt).getTime() > soon;
  const pool: EventSummary[] = [];
  for (const when of lateEvening ? (["tomorrow"] as const) : (["today", "tomorrow"] as const)) {
    pool.push(...(await listEvents({ city, when, pageSize: 48 }, ctx)).items.filter(ok));
    if (pool.length) break;
  }
  const ids = await getEventIds(pool.map((e) => e.slug), ctx);
  const fresh = pool.filter((e) => !posted.has(ids.get(e.slug)!));
  const pick = fresh.find((e) => e.badges?.includes("hot")) ?? fresh[0];
  if (!pick) return null;

  const event = await getEventBySlug(pick.slug, ctx);
  if (!event?.image) return null;
  const eventId = ids.get(pick.slug)!;
  const where = [event.venue.name, event.venue.address].filter(Boolean).join(", ");
  const place = event.locality ?? (event.venue.address.includes(cityName(city)) ? "" : cityName(city));
  const caption = [
    `<b>${escapeHtml(event.title)}</b>`,
    "",
    `📅 ${whenLabel(event.startsAt, now)}`,
    `📍 ${escapeHtml([where, place].filter(Boolean).join(", "))}`,
    `💳 ${priceLabel(event.priceFrom)}`,
    ...(event.description ? ["", escapeHtml(truncate(event.description, 350))] : []),
  ].join("\n");

  const links: { text: string; url: string }[] = [];
  if (event.ticketUrl) links.push({ text: "🎟 Билеты", url: ticketHref(event.slug, "channel", SITE_URL) });
  links.push({ text: "На сайте", url: withUtm(`/events/${event.slug}`) });
  const bot = botUsername();
  return {
    eventId,
    slug: event.slug,
    photo: absoluteUrl(event.image),
    caption,
    reply_markup: { inline_keyboard: [links, ...(bot ? [[{ text: "⭐ Сохранить и получить напоминание", url: `https://t.me/${bot}?start=e_${eventId}` }]] : [])] },
  };
}
