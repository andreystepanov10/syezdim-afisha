// Логика Telegram-бота афиши: поиск событий, карточки, подборка (общая с сайтом), «поделиться», напоминания.
// Обрабатывает одно обновление Telegram (webhook: src/app/api/telegram/webhook). Всё общение с Telegram — через
// ctx.api, поэтому логику можно гонять в тестах без сети.
import { getEventBySlug, getFavoriteEvents, listEvents } from "@/data/events";
import type { Db } from "@/db/client";
import {
  consumeLinkToken,
  createLinkToken,
  deleteTelegramUser,
  getEventIds,
  getEventSlug,
  getOrCreateShareId,
  getOrCreateTelegramUser,
  mergeFavorites,
  updateTelegramUser,
  type TelegramUser,
} from "@/data/telegram";
import { toggleFavorite, getFavoriteSlugs } from "@/data/favorites";
import { CATEGORIES, categoryName, isCategorySlug } from "@/lib/categories";
import { CITIES, cityLocative, cityName, isCitySlug } from "@/lib/cities";
import { dateShort, dateTimeLong, plural, priceLabel, timeShort } from "@/lib/format";
import { groupFavoritesByDay } from "@/lib/plan";
import { ticketHref } from "@/lib/affiliate";
import { absoluteUrl, eventPlace, truncate } from "@/lib/seo";
import { SITE_URL } from "@/lib/site";
import type { EventSummary } from "@/lib/types";
import { escapeHtml, TelegramError, type InlineButton, type InlineKeyboard, type ReplyKeyboard, type TelegramApi } from "./api";
import { parseBotQuery, type BotQuery } from "./parse";

export type BotCtx = { api: TelegramApi; db?: Db; now?: Date };

/** Минимум полей Update, которые бот разбирает (https://core.telegram.org/bots/api#update) */
export type Update = {
  message?: { message_id: number; chat: { id: number; type: string }; text?: string };
  callback_query?: { id: string; data?: string; message?: { message_id: number; chat: { id: number; type: string } } };
  my_chat_member?: { chat: { id: number; type: string }; new_chat_member: { status: string } };
};

const PAGE_SIZE = 6;
const EVENT_FORMS: [string, string, string] = ["событие", "события", "событий"];

const BUTTONS = {
  today: "📅 Сегодня",
  tomorrow: "🗓 Завтра",
  weekend: "🎉 Выходные",
  categories: "🎭 Категории",
  saved: "⭐ Моя подборка",
  city: "🏙 Город",
} as const;

const MAIN_KEYBOARD: ReplyKeyboard = {
  keyboard: [
    [{ text: BUTTONS.today }, { text: BUTTONS.tomorrow }, { text: BUTTONS.weekend }],
    [{ text: BUTTONS.categories }, { text: BUTTONS.saved }, { text: BUTTONS.city }],
  ],
  resize_keyboard: true,
  is_persistent: true,
};

const HELP = [
  "Я помогу найти, куда сходить в городах Черноземья.",
  "",
  "• Кнопки внизу — события на сегодня, завтра, выходные или по категории.",
  "• Или просто напишите, что ищете: <i>концерты на выходных</i>, <i>бесплатно завтра</i>, <i>с ребёнком</i>, имя артиста.",
  "• ⭐ — сохранить событие в подборку. Подборку можно открыть на сайте и отправить друзьям.",
  "• За день до сохранённого события пришлю напоминание (/reminders — включить или выключить).",
  "",
  "/city — сменить город, /saved — моя подборка, /help — эта подсказка.",
].join("\n");

type StoredQuery = { mode: "list"; query: BotQuery } | { mode: "saved" };

// ---------------------------------------------------------------------------
// Вход: одно обновление от Telegram
// ---------------------------------------------------------------------------

export async function handleUpdate(update: Update, ctx: BotCtx): Promise<void> {
  if (update.my_chat_member) {
    // Пользователь остановил/заблокировал бота — забываем его (единственное, что храним, — ID чата)
    if (update.my_chat_member.new_chat_member.status === "kicked") await deleteTelegramUser(update.my_chat_member.chat.id, ctx);
    return;
  }

  if (update.callback_query) {
    const cb = update.callback_query;
    // Снимаем «часики» с кнопки сразу, даже если дальше что-то пойдёт не так
    await ctx.api("answerCallbackQuery", { callback_query_id: cb.id }).catch(() => {});
    if (!cb.message || cb.message.chat.type !== "private" || !cb.data) return;
    const user = await getOrCreateTelegramUser(cb.message.chat.id, ctx);
    await handleCallback(user, cb.data, cb.message.message_id, ctx);
    return;
  }

  const msg = update.message;
  // Только личные чаты: в группах бот ничего не читает и не отвечает
  if (!msg || msg.chat.type !== "private" || !msg.text) return;
  const user = await getOrCreateTelegramUser(msg.chat.id, ctx);
  await handleText(user, msg.text.trim(), ctx);
}

async function handleText(user: TelegramUser, text: string, ctx: BotCtx): Promise<void> {
  const [command, payload] = text.split(/\s+/, 2);

  if (command === "/start") return start(user, payload, ctx);
  if (command === "/help" || text === "Помощь") return send(ctx, user.chatId, HELP, { reply_markup: MAIN_KEYBOARD });
  if (command === "/city" || text === BUTTONS.city) return askCity(user, ctx);
  if (command === "/saved" || text === BUTTONS.saved) return showSaved(user, ctx);
  if (command === "/reminders") return toggleReminders(user, ctx);
  if (text === BUTTONS.categories) return askCategory(user, ctx);

  if (!user.city) return askCity(user, ctx, "Сначала выберите город — потом повторите запрос:");

  if (text === BUTTONS.today) return showList(user, { when: "today" }, 1, ctx);
  if (text === BUTTONS.tomorrow) return showList(user, { when: "tomorrow" }, 1, ctx);
  if (text === BUTTONS.weekend) return showList(user, { when: "weekend" }, 1, ctx);
  if (text.startsWith("/")) return send(ctx, user.chatId, "Не знаю такой команды.\n\n" + HELP, { reply_markup: MAIN_KEYBOARD });

  const query = parseBotQuery(text);
  if (!query.q && !query.when && !query.category && !query.free) return send(ctx, user.chatId, HELP, { reply_markup: MAIN_KEYBOARD });
  return showList(user, query, 1, ctx);
}

async function handleCallback(user: TelegramUser, data: string, messageId: number, ctx: BotCtx): Promise<void> {
  const [kind, arg = ""] = data.split(":", 2);
  switch (kind) {
    case "city":
      if (!isCitySlug(arg)) return;
      await updateTelegramUser(user.chatId, { city: arg }, ctx);
      await edit(ctx, user.chatId, messageId, `Город: <b>${cityName(arg)}</b> ✅`);
      return send(ctx, user.chatId, `Что ищем ${cityLocative(arg)}? Нажмите кнопку внизу или напишите запрос, например <i>концерты на выходных</i>.`, {
        reply_markup: MAIN_KEYBOARD,
      });
    case "cat":
      if (!isCategorySlug(arg)) return;
      if (!user.city) return askCity(user, ctx);
      return showList(user, { category: [arg] }, 1, ctx);
    case "p": {
      const stored = parseStored(user.lastQuery);
      if (stored?.mode !== "list" || !user.city) return;
      return showList(user, stored.query, Math.max(1, Number(arg) || 1), ctx, messageId);
    }
    case "e":
      return showEvent(user, Number(arg), ctx);
    case "f":
      return toggleSaved(user, Number(arg), messageId, ctx);
    case "saved":
      return showSaved(user, ctx);
    case "share":
      return share(user, ctx);
    case "site":
      return openOnSite(user, ctx);
    case "rem":
      return toggleReminders(user, ctx);
  }
}

// ---------------------------------------------------------------------------
// Сценарии
// ---------------------------------------------------------------------------

async function start(user: TelegramUser, payload: string | undefined, ctx: BotCtx): Promise<void> {
  // t.me/<бот>?start=e_<id> — кнопка «Сохранить» под постом о событии в канале: сразу карточка с ⭐
  if (payload?.startsWith("e_")) {
    const isNew = !user.city && !user.lastQuery;
    await showEvent(user, Number(payload.slice(2)), ctx);
    if (isNew) await send(ctx, user.chatId, `Нажмите ⭐, чтобы сохранить событие — напомню за день.\n\n${HELP}`, { reply_markup: MAIN_KEYBOARD });
    return;
  }
  // t.me/<бот>?start=l_<токен> — кнопка «Открыть в Telegram» на сайте: забираем подборку браузера
  if (payload?.startsWith("l_")) {
    const siteDeviceId = await consumeLinkToken(payload.slice(2), "to_bot", ctx);
    if (siteDeviceId) {
      await mergeFavorites(user.deviceId, siteDeviceId, ctx);
      await updateTelegramUser(user.chatId, { deviceId: siteDeviceId }, ctx);
      user = { ...user, deviceId: siteDeviceId };
      const count = (await getFavoriteSlugs(siteDeviceId, ctx)).size;
      await send(ctx, user.chatId, `Подборка связана с сайтом ✅ Событий в ней: ${count}. Сохраняйте здесь или на сайте — список общий.`);
    } else {
      await send(ctx, user.chatId, "Ссылка устарела — нажмите «Открыть в Telegram» на сайте ещё раз.");
    }
  }

  await send(ctx, user.chatId, `Привет! Это бот афиши «Съездим» 👋\n\n${HELP}`, { reply_markup: MAIN_KEYBOARD });
  if (!user.city) await askCity(user, ctx);
}

async function askCity(user: TelegramUser, ctx: BotCtx, text = "Выберите город:"): Promise<void> {
  const rows = chunk(
    CITIES.map((c) => ({ text: c.slug === user.city ? `✅ ${c.name}` : c.name, callback_data: `city:${c.slug}` })),
    3,
  );
  await send(ctx, user.chatId, text, { reply_markup: { inline_keyboard: rows } });
}

async function askCategory(user: TelegramUser, ctx: BotCtx): Promise<void> {
  const rows = chunk(
    CATEGORIES.map((c) => ({ text: c.name, callback_data: `cat:${c.slug}` })),
    2,
  );
  await send(ctx, user.chatId, "Какая категория?", { reply_markup: { inline_keyboard: rows } });
}

/** Список событий страницами по 6: текст со списком + кнопки-номера (открыть карточку) и «назад/дальше» */
async function showList(user: TelegramUser, query: BotQuery, page: number, ctx: BotCtx, editMessageId?: number): Promise<void> {
  const city = user.city!;
  const list = await listEvents({ ...query, city, page, pageSize: PAGE_SIZE, groupSessions: true }, ctx);
  await updateTelegramUser(user.chatId, { lastQuery: JSON.stringify({ mode: "list", query } satisfies StoredQuery) }, ctx);

  const title = describeQuery(query, city);
  if (list.total === 0) {
    const text = `${title}: ничего не нашлось 🤷\n\nПопробуйте другой день или категорию — или напишите запрос короче.`;
    return editMessageId ? edit(ctx, user.chatId, editMessageId, text) : send(ctx, user.chatId, text, { reply_markup: MAIN_KEYBOARD });
  }

  const ids = await getEventIds(list.items.map((e) => e.slug), ctx);
  const offset = (list.page - 1) * PAGE_SIZE;
  const lines = list.items.map((e, i) => `<b>${offset + i + 1}. ${escapeHtml(e.title)}</b>\n${eventLine(e)}`);
  const pages = list.pageCount > 1 ? ` · стр. ${list.page} из ${list.pageCount}` : "";
  const text = `${title} — ${list.total} ${plural(list.total, EVENT_FORMS)}${pages}\n\n${lines.join("\n\n")}\n\nНажмите номер, чтобы открыть событие.`;

  const numbers = list.items.map((e, i) => ({ text: String(offset + i + 1), callback_data: `e:${ids.get(e.slug)}` }));
  const nav: InlineButton[] = [];
  if (list.page > 1) nav.push({ text: "← Назад", callback_data: `p:${list.page - 1}` });
  if (list.page < list.pageCount) nav.push({ text: "Дальше →", callback_data: `p:${list.page + 1}` });
  const keyboard: InlineKeyboard = { inline_keyboard: [...chunk(numbers, 3), ...(nav.length ? [nav] : [])] };

  return editMessageId ? edit(ctx, user.chatId, editMessageId, text, keyboard) : send(ctx, user.chatId, text, { reply_markup: keyboard });
}

/** Карточка события: картинка, когда/где/сколько, кнопки «сохранить», «купить», «на сайте» */
async function showEvent(user: TelegramUser, id: number, ctx: BotCtx): Promise<void> {
  const slug = Number.isInteger(id) ? await getEventSlug(id, ctx) : null;
  const event = slug ? await getEventBySlug(slug, ctx) : null;
  if (!event) return send(ctx, user.chatId, "Это событие уже снято с афиши.");

  const saved = (await getFavoriteSlugs(user.deviceId, ctx)).has(event.slug);
  const when = event.endsAt ? `${dateShort(event.startsAt)} — ${dateShort(event.endsAt)}` : dateTimeLong(event.startsAt);
  const where = [event.venue.name, event.venue.address].filter(Boolean).join(", ");
  const caption = [
    `<b>${escapeHtml(event.title)}</b>`,
    "",
    `📅 ${when}`,
    `📍 ${escapeHtml(where)}, ${eventPlace(event)}`,
    `💳 ${priceLabel(event.priceFrom)}`,
    ...(event.description ? ["", escapeHtml(truncate(event.description, 450))] : []),
  ].join("\n");
  const reply_markup = cardKeyboard(id, saved, event.ticketUrl, event.slug);

  // Telegram сам скачивает картинку по ссылке; SVG-заглушки он не понимает — тогда шлём текстом
  if (event.image && !event.image.endsWith(".svg")) {
    try {
      await ctx.api("sendPhoto", { chat_id: user.chatId, photo: absoluteUrl(event.image), caption, parse_mode: "HTML", reply_markup });
      return;
    } catch (error) {
      if (error instanceof TelegramError && error.code === 403) throw error;
      // Картинка недоступна или не подошла по формату — карточка важнее картинки
    }
  }
  await send(ctx, user.chatId, caption, { reply_markup, link_preview_options: { is_disabled: true } });
}

function cardKeyboard(id: number, saved: boolean, ticketUrl: string | undefined, slug: string): InlineKeyboard {
  const links: InlineButton[] = [];
  if (ticketUrl) links.push({ text: "🎟 Билеты", url: ticketHref(slug, "bot", SITE_URL) });
  links.push({ text: "На сайте", url: `${SITE_URL}/events/${slug}` });
  return {
    inline_keyboard: [[{ text: saved ? "✅ В подборке — убрать" : "⭐ Сохранить в подборку", callback_data: `f:${id}` }], links],
  };
}

async function toggleSaved(user: TelegramUser, id: number, messageId: number, ctx: BotCtx): Promise<void> {
  const slug = Number.isInteger(id) ? await getEventSlug(id, ctx) : null;
  if (!slug) return;
  const event = await getEventBySlug(slug, ctx);
  const saved = await toggleFavorite(user.deviceId, slug, ctx);
  await ctx
    .api("editMessageReplyMarkup", { chat_id: user.chatId, message_id: messageId, reply_markup: cardKeyboard(id, saved, event?.ticketUrl, slug) })
    .catch(() => {});
  if (saved) {
    await send(ctx, user.chatId, "Сохранено в подборку ⭐ Напомню за день до события.", {
      reply_markup: { inline_keyboard: [[{ text: "⭐ Моя подборка", callback_data: "saved" }]] },
    });
  }
}

/** Подборка: предстоящие сохранённые события по датам + «поделиться», «на сайте», напоминания */
async function showSaved(user: TelegramUser, ctx: BotCtx): Promise<void> {
  const now = ctx.now ?? new Date();
  const { upcoming } = groupFavoritesByDay(await getFavoriteEvents(user.deviceId, ctx), now);
  const events = upcoming.flatMap((d) => d.events).slice(0, 30);
  await updateTelegramUser(user.chatId, { lastQuery: JSON.stringify({ mode: "saved" } satisfies StoredQuery) }, ctx);

  const actions: InlineButton[][] = [
    [
      { text: "🌐 Открыть на сайте", callback_data: "site" },
      { text: "📤 Поделиться", callback_data: "share" },
    ],
    [{ text: user.reminders ? "🔔 Напоминания: вкл" : "🔕 Напоминания: выкл", callback_data: "rem" }],
  ];

  if (events.length === 0) {
    return send(ctx, user.chatId, "В подборке пока пусто. Открывайте события и жмите ⭐ — они появятся здесь.", {
      reply_markup: { inline_keyboard: actions.slice(0, 1).map((row) => row.filter((b) => b.callback_data === "site")) },
    });
  }

  const ids = await getEventIds(events.map((e) => e.slug), ctx);
  const lines = events.map((e, i) => `<b>${i + 1}. ${escapeHtml(e.title)}</b>\n${eventLine(e)}`);
  const numbers = events.map((e, i) => ({ text: String(i + 1), callback_data: `e:${ids.get(e.slug)}` }));
  return send(ctx, user.chatId, `⭐ <b>Моя подборка</b> — ${events.length} ${plural(events.length, EVENT_FORMS)}\n\n${lines.join("\n\n")}`, {
    reply_markup: { inline_keyboard: [...chunk(numbers, 5), ...actions] },
  });
}

async function share(user: TelegramUser, ctx: BotCtx): Promise<void> {
  const url = `${SITE_URL}/shared/${await getOrCreateShareId(user.deviceId, ctx)}`;
  const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent("Куда сходим? Моя подборка событий 👇")}`;
  await send(ctx, user.chatId, `Ссылка на вашу подборку — её можно отправить друзьям:\n${url}\n\nПо ссылке подборку можно только посмотреть, менять её можете только вы.`, {
    reply_markup: { inline_keyboard: [[{ text: "📤 Отправить в чат", url: shareUrl }]] },
    link_preview_options: { is_disabled: true },
  });
}

async function openOnSite(user: TelegramUser, ctx: BotCtx): Promise<void> {
  const token = await createLinkToken(user.deviceId, "to_site", ctx);
  await send(ctx, user.chatId, "Откройте ссылку — подборка появится в «Моих билетах» на сайте и будет общей с ботом. Ссылка одноразовая и действует 15 минут.", {
    reply_markup: { inline_keyboard: [[{ text: "🌐 Открыть подборку на сайте", url: `${SITE_URL}/api/telegram/open?t=${token}` }]] },
  });
}

async function toggleReminders(user: TelegramUser, ctx: BotCtx): Promise<void> {
  const reminders = !user.reminders;
  await updateTelegramUser(user.chatId, { reminders }, ctx);
  await send(ctx, user.chatId, reminders ? "🔔 Напоминания включены: напишу за день до сохранённых событий." : "🔕 Напоминания выключены.");
}

// ---------------------------------------------------------------------------
// Напоминания (рассылка раз в день — scripts/telegram.mts remind)
// ---------------------------------------------------------------------------

/** Текст напоминания о событии завтра; null — событие уже снято с публикации */
export async function reminderMessage(slug: string, ctx: Omit<BotCtx, "api">): Promise<{ text: string; reply_markup: InlineKeyboard } | null> {
  const event = await getEventBySlug(slug, ctx);
  if (!event) return null;
  const links: InlineButton[] = [];
  if (event.ticketUrl) links.push({ text: "🎟 Билеты", url: ticketHref(event.slug, "bot", SITE_URL) });
  links.push({ text: "На сайте", url: `${SITE_URL}/events/${event.slug}` });
  return {
    text: `⏰ Завтра в ${timeShort(event.startsAt)}: <b>${escapeHtml(event.title)}</b>\n📍 ${escapeHtml(event.venue.name)}, ${eventPlace(event)}`,
    reply_markup: { inline_keyboard: [links] },
  };
}

// ---------------------------------------------------------------------------
// Помощники
// ---------------------------------------------------------------------------

async function send(ctx: BotCtx, chatId: number, text: string, extra: Record<string, unknown> = {}): Promise<void> {
  await ctx.api("sendMessage", { chat_id: chatId, text, parse_mode: "HTML", link_preview_options: { is_disabled: true }, ...extra });
}

async function edit(ctx: BotCtx, chatId: number, messageId: number, text: string, reply_markup?: InlineKeyboard): Promise<void> {
  await ctx
    .api("editMessageText", { chat_id: chatId, message_id: messageId, text, parse_mode: "HTML", link_preview_options: { is_disabled: true }, reply_markup })
    // «message is not modified» и подобное — не повод падать
    .catch(() => {});
}

function eventLine(e: EventSummary): string {
  return `${dateShort(e.startsAt)}, ${timeShort(e.startsAt)} · ${escapeHtml(e.subtitle ?? "")} · ${priceLabel(e.priceFrom)}`;
}

function describeQuery(query: BotQuery, city: Parameters<typeof cityLocative>[0]): string {
  const when = { today: "Сегодня", tomorrow: "Завтра", weekend: "На выходных", week: "На неделе", date: "" }[query.when ?? "date"] || "Ближайшие события";
  const parts = [when];
  if (query.category?.length) parts.push(query.category.map((c) => categoryName(c).toLowerCase()).join(", "));
  if (query.free) parts.push("бесплатно");
  if (query.q) parts.push(`«${escapeHtml(query.q)}»`);
  return `<b>${parts.join(" · ")} ${cityLocative(city)}</b>`;
}

function parseStored(raw: string | null): StoredQuery | null {
  try {
    return raw ? (JSON.parse(raw) as StoredQuery) : null;
  } catch {
    return null;
  }
}

function chunk<T>(items: T[], size: number): T[][] {
  const rows: T[][] = [];
  for (let i = 0; i < items.length; i += size) rows.push(items.slice(i, i + size));
  return rows;
}
