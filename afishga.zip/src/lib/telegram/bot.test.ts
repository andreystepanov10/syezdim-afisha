import { beforeAll, describe, expect, it } from "vitest";
import { listEvents } from "@/data/events";
import { getFavoriteSlugs } from "@/data/favorites";
import { consumeLinkToken, createLinkToken, getEventIds, getOrCreateTelegramUser, listDueReminders } from "@/data/telegram";
import { createDemoDb, type Db } from "@/db/client";
import { addDays, startOfDayMsk } from "@/lib/time";
import type { TelegramApi } from "./api";
import { handleUpdate, type BotCtx, type Update } from "./bot";

const NOW = new Date("2026-10-14T09:00:00Z"); // среда
const CHAT = 777;

let db: Db;
let calls: { method: string; params: Record<string, unknown> }[] = [];
const api: TelegramApi = async (method, params) => {
  calls.push({ method, params });
  return {};
};
let ctx: BotCtx;

const text = (t: string, chatType = "private"): Update => ({ message: { message_id: 1, chat: { id: CHAT, type: chatType }, text: t } });
const button = (data: string): Update => ({ callback_query: { id: "cb", data, message: { message_id: 5, chat: { id: CHAT, type: "private" } } } });
const sent = () => calls.filter((c) => c.method === "sendMessage" || c.method === "sendPhoto" || c.method === "editMessageText");
const lastText = () => {
  const c = sent().at(-1)!;
  return String(c.params.text ?? c.params.caption);
};

beforeAll(async () => {
  db = await createDemoDb({ now: NOW });
  ctx = { api, db, now: NOW };
});

describe("Telegram-бот", () => {
  it("на /start здоровается и просит выбрать город", async () => {
    calls = [];
    await handleUpdate(text("/start"), ctx);
    expect(sent()).toHaveLength(2);
    expect(String(sent()[0].params.text)).toContain("Привет");
    expect(lastText()).toContain("Выберите город");
  });

  it("не отвечает в группах", async () => {
    calls = [];
    await handleUpdate(text("/start", "group"), ctx);
    expect(calls).toHaveLength(0);
  });

  it("запоминает город по кнопке", async () => {
    calls = [];
    await handleUpdate(button("city:voronezh"), ctx);
    expect((await getOrCreateTelegramUser(CHAT, { db })).city).toBe("voronezh");
    expect(calls[0].method).toBe("answerCallbackQuery");
  });

  it("ищет по свободному тексту и показывает список с кнопками-номерами", async () => {
    calls = [];
    await handleUpdate(text("что есть на неделе"), ctx);
    const msg = sent().at(-1)!;
    expect(String(msg.params.text)).toContain("На неделе");
    const keyboard = (msg.params.reply_markup as { inline_keyboard: { callback_data?: string }[][] }).inline_keyboard;
    expect(keyboard[0][0].callback_data).toMatch(/^e:\d+$/);
  });

  it("открывает карточку, сохраняет в подборку и показывает её", async () => {
    const { items } = await listEvents({ city: "voronezh", when: "week" }, { db, now: NOW });
    const id = (await getEventIds([items[0].slug], { db })).get(items[0].slug)!;

    calls = [];
    await handleUpdate(button(`e:${id}`), ctx);
    expect(lastText()).toContain(items[0].title);

    await handleUpdate(button(`f:${id}`), ctx);
    const user = await getOrCreateTelegramUser(CHAT, { db });
    expect((await getFavoriteSlugs(user.deviceId, { db })).has(items[0].slug)).toBe(true);

    calls = [];
    await handleUpdate(text("/saved"), ctx);
    expect(lastText()).toContain("Моя подборка");
    expect(lastText()).toContain(items[0].title);
  });

  it("«Поделиться» даёт ссылку на страницу подборки", async () => {
    calls = [];
    await handleUpdate(button("share"), ctx);
    expect(lastText()).toMatch(/https:\/\/syezdim\.ru\/shared\/[a-f0-9]{16}/);
  });

  it("связывает подборку сайта с ботом по одноразовой ссылке и переносит сохранённое", async () => {
    const siteDevice = "site-device-1";
    const token = await createLinkToken(siteDevice, "to_bot", { db, now: NOW });
    const before = await getOrCreateTelegramUser(CHAT, { db });
    const botSaved = await getFavoriteSlugs(before.deviceId, { db });

    calls = [];
    await handleUpdate(text(`/start l_${token}`), ctx);
    expect(String(sent()[0].params.text)).toContain("Подборка связана с сайтом");

    const after = await getOrCreateTelegramUser(CHAT, { db });
    expect(after.deviceId).toBe(siteDevice);
    expect(await getFavoriteSlugs(siteDevice, { db })).toEqual(botSaved);
    // Токен одноразовый
    expect(await consumeLinkToken(token, "to_bot", { db, now: NOW })).toBeNull();
  });

  it("находит напоминания о завтрашних сохранённых событиях", async () => {
    const tomorrow = addDays(startOfDayMsk(NOW), 1);
    const { items } = await listEvents({ city: "voronezh", when: "tomorrow" }, { db, now: NOW });
    if (items.length === 0) return; // в демо-данных на завтра может ничего не быть
    const id = (await getEventIds([items[0].slug], { db })).get(items[0].slug)!;
    // Кнопка ⭐ — переключатель: жмём, только если события ещё нет в подборке (его мог сохранить тест выше)
    const user = await getOrCreateTelegramUser(CHAT, { db });
    if (!(await getFavoriteSlugs(user.deviceId, { db })).has(items[0].slug)) await handleUpdate(button(`f:${id}`), ctx);
    const due = await listDueReminders({ from: tomorrow, to: addDays(tomorrow, 1) }, { db });
    expect(due.some((r) => r.chatId === CHAT && r.eventId === id)).toBe(true);
  });

  it("выключает напоминания командой", async () => {
    calls = [];
    await handleUpdate(text("/reminders"), ctx);
    expect(lastText()).toContain("выключены");
    expect((await getOrCreateTelegramUser(CHAT, { db })).reminders).toBe(false);
  });
});

describe("ссылка из поста в канале", () => {
  it("/start e_<id> сразу показывает карточку события", async () => {
    const { items } = await listEvents({ city: "voronezh", when: "week" }, { db, now: NOW });
    const id = (await getEventIds([items[0].slug], { db })).get(items[0].slug)!;
    calls = [];
    await handleUpdate({ message: { message_id: 1, chat: { id: 999, type: "private" }, text: `/start e_${id}` } }, ctx);
    const first = sent()[0];
    expect(String(first.params.text ?? first.params.caption)).toContain(items[0].title);
  });
});
