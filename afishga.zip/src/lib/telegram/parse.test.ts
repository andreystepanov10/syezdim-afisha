import { describe, expect, it } from "vitest";
import { parseBotQuery } from "./parse";

describe("parseBotQuery", () => {
  it("дата + категория без поисковой строки", () => {
    expect(parseBotQuery("Концерты на выходных")).toEqual({ when: "weekend", category: ["concerts"] });
  });

  it("служебные слова не уходят в поиск", () => {
    expect(parseBotQuery("куда сходить завтра с ребенком?")).toEqual({ when: "tomorrow", category: ["kids"] });
  });

  it("имя артиста — поисковая строка", () => {
    expect(parseBotQuery("Гуф")).toEqual({ q: "гуф" });
  });

  it("бесплатно + сегодня + остаток в поиск", () => {
    expect(parseBotQuery("бесплатно сегодня джаз")).toEqual({ when: "today", free: true, q: "джаз" });
  });

  it("спектакль и театр — одна категория", () => {
    expect(parseBotQuery("спектакль в театре на этой неделе")).toEqual({ when: "week", category: ["theatre"] });
  });

  it("похожие по началу слова не ловятся как категории", () => {
    // «детектив» начинается с «дет», но это не про детей
    expect(parseBotQuery("детектив")).toEqual({ q: "детектив" });
    expect(parseBotQuery("мастер класс по керамике")).toEqual({ category: ["workshops"], q: "керамике" });
  });
});
