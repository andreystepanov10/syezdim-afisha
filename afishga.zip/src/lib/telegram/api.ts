// Тонкий клиент Telegram Bot API (https://core.telegram.org/bots/api) — без сторонних библиотек.

export type InlineButton = { text: string; callback_data?: string; url?: string };
export type InlineKeyboard = { inline_keyboard: InlineButton[][] };
export type ReplyKeyboard = { keyboard: { text: string }[][]; resize_keyboard: true; is_persistent?: boolean };
export type ReplyMarkup = InlineKeyboard | ReplyKeyboard;

/** Ошибка от Telegram с кодом ответа: 403 — пользователь заблокировал бота */
export class TelegramError extends Error {
  constructor(
    message: string,
    readonly code: number,
  ) {
    super(message);
  }
}

/** Всё, что бот делает в Telegram, — через этот интерфейс: в тестах его подменяет запись вызовов */
export type TelegramApi = (method: string, params: Record<string, unknown>) => Promise<unknown>;

export function isTelegramConfigured(): boolean {
  return Boolean(process.env.TELEGRAM_BOT_TOKEN);
}

/** Имя бота без @ — для ссылок t.me/<имя> на сайте */
export function botUsername(): string | null {
  return process.env.TELEGRAM_BOT_USERNAME?.replace(/^@/, "") || null;
}

export function createTelegramApi(token = process.env.TELEGRAM_BOT_TOKEN): TelegramApi {
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN не задан");
  return async (method, params) => {
    const request = () =>
      fetch(`https://api.telegram.org/bot${token}/${method}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
        signal: AbortSignal.timeout(30_000),
      });
    // С VPS запросы к api.telegram.org изредка обрываются («fetch failed») — повторяем сетевую ошибку дважды.
    // Ответ Telegram с ошибкой (400, 403) не повторяем: он не изменится
    let res: Response | undefined;
    for (let attempt = 0; !res; attempt++) {
      try {
        res = await request();
      } catch (error) {
        if (attempt >= 2) throw error;
        await new Promise((resolve) => setTimeout(resolve, 3000 * (attempt + 1)));
      }
    }
    const data = (await res.json().catch(() => null)) as { ok?: boolean; result?: unknown; description?: string; error_code?: number } | null;
    if (!data?.ok) throw new TelegramError(`Telegram ${method}: ${data?.description ?? res.status}`, data?.error_code ?? res.status);
    return data.result;
  };
}

/** Экранирование для parse_mode=HTML — текст событий приходит с чужих сайтов */
export function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
