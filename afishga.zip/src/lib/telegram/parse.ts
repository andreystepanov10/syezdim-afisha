// Разбор свободного текста из чата в фильтры афиши: «стендап на выходных», «бесплатно завтра», «Гуф».
// Пословно, а не регулярками по всей строке: \b в JS не понимает кириллицу.
import type { EventFilters, When } from "@/data/filters";
import type { CategorySlug } from "@/lib/categories";

export type BotQuery = Pick<EventFilters, "q" | "when" | "category" | "free">;

/** Начало слова → дата. Проверяются по порядку, побеждает первое найденное в тексте */
const WHEN_WORDS: [RegExp, When][] = [
  [/^сегодня$/, "today"],
  [/^завтра$/, "tomorrow"],
  [/^выходн/, "weekend"],
  [/^недел/, "week"],
];

/** Начало слова → категория (ловит падежи: «концерты», «на концерт», «спектакле») */
const CATEGORY_WORDS: [RegExp, CategorySlug][] = [
  [/^концерт/, "concerts"],
  [/^(театр|спектакл)/, "theatre"],
  [/^выстав/, "exhibitions"],
  [/^(кино|фильм)/, "cinema"],
  [/^(дет(и|ей|ям|ск)|ребен)/, "kids"],
  [/^фестивал/, "festivals"],
  [/^мастер-?класс/, "workshops"],
  [/^(спорт|матч|хоккей|футбол)/, "sport"],
];

const FREE_WORD = /^(бесплатн|даром)/;

/** Служебные слова, которые не стоит отправлять в полнотекстовый поиск */
const STOP_WORDS = new Set(
  "куда сходить пойти сходим что где есть в во на и с со по для мне нам хочу хотим афиша событие события мероприятие мероприятия эту этой эти ближайшие ближайших какие какой".split(" "),
);

export function parseBotQuery(text: string): BotQuery {
  const words = text
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/мастер\s+класс/g, "мастер-класс")
    .replace(/свободный\s+вход/g, "бесплатно")
    .split(/[^\p{L}\d-]+/u)
    .filter(Boolean);

  const query: BotQuery = {};
  const categories = new Set<CategorySlug>();
  const rest: string[] = [];

  for (const word of words) {
    const when = WHEN_WORDS.find(([re]) => re.test(word))?.[1];
    if (when) {
      query.when ??= when;
      continue;
    }
    const category = CATEGORY_WORDS.find(([re]) => re.test(word))?.[1];
    if (category) {
      categories.add(category);
      continue;
    }
    if (FREE_WORD.test(word)) {
      query.free = true;
      continue;
    }
    if (!STOP_WORDS.has(word)) rest.push(word);
  }

  if (categories.size) query.category = [...categories];
  const q = rest.join(" ").slice(0, 100).trim();
  if (q) query.q = q;
  return query;
}
