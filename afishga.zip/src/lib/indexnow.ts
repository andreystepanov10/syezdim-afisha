// IndexNow — сообщаем Яндексу о новых и изменённых страницах сразу, а не ждём, пока робот сам дойдёт до sitemap.
// Робот Яндекса заходил на сайт раз в несколько дней и ни разу не открыл страницу события — без этого
// свежие события попадали бы в поиск, когда уже прошли. https://yandex.ru/support/webmaster/indexnow/
import { SITE_URL } from "@/lib/site";

const ENDPOINT = "https://yandex.com/indexnow";
/** Лимит протокола — 10 000 адресов в одном запросе */
const BATCH = 10_000;

export function isIndexNowConfigured(): boolean {
  return /^[a-zA-Z0-9-]{8,128}$/.test(process.env.INDEXNOW_KEY ?? "");
}

/** Отправляет адреса (абсолютные или пути вида /events/...) — возвращает число принятых */
export async function submitToIndexNow(urls: string[]): Promise<number> {
  const key = process.env.INDEXNOW_KEY;
  if (!key || !isIndexNowConfigured() || urls.length === 0) return 0;
  const host = new URL(SITE_URL).host;
  const absolute = [...new Set(urls.map((u) => (u.startsWith("http") ? u : `${SITE_URL}${u}`)))];
  let sent = 0;
  for (let i = 0; i < absolute.length; i += BATCH) {
    const urlList = absolute.slice(i, i + BATCH);
    const res = await fetch(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({ host, key, keyLocation: `${SITE_URL}/indexnow.txt`, urlList }),
      signal: AbortSignal.timeout(30_000),
    });
    // 200 — принято, 202 — принято, ключ ещё проверяется
    if (res.status !== 200 && res.status !== 202) throw new Error(`IndexNow ответил ${res.status}: ${await res.text().catch(() => "")}`);
    sent += urlList.length;
  }
  return sent;
}
