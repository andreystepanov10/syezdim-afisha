// Категории событий. Одни и те же slug используются в поиске, фильтрах и (с этапа 2) в БД.
// genitive — для фраз вида «афиша концертов»/«афиша для детей» на страницах категорий (SEO).
export const CATEGORIES = [
  { slug: "concerts", name: "Концерты", genitive: "концертов" },
  { slug: "theatre", name: "Театр", genitive: "спектаклей" },
  { slug: "exhibitions", name: "Выставки", genitive: "выставок" },
  { slug: "cinema", name: "Кино", genitive: "фильмов" },
  { slug: "kids", name: "Детям", genitive: "для детей" },
  { slug: "festivals", name: "Фестивали", genitive: "фестивалей" },
  { slug: "workshops", name: "Мастер-классы", genitive: "мастер-классов" },
  { slug: "sport", name: "Спорт", genitive: "спортивных событий" },
] as const;

export type CategorySlug = (typeof CATEGORIES)[number]["slug"];

export function isCategorySlug(value: string): value is CategorySlug {
  return CATEGORIES.some((c) => c.slug === value);
}

export function categoryName(slug: string): string {
  return CATEGORIES.find((c) => c.slug === slug)?.name ?? "";
}

/** «концертов» — для заголовков вида «Афиша концертов в Воронеже» */
export function categoryGenitive(slug: string): string {
  return CATEGORIES.find((c) => c.slug === slug)?.genitive ?? "";
}
