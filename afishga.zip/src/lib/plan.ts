// Группировка избранного по дням для «Моих билетов» — план на сегодня/завтра/дальше, а не плоский список.
import { dateShort } from "./format";
import { isoDayMsk } from "./time";
import type { EventSummary } from "./types";

export type PlanDay = { key: string; label: string; events: EventSummary[] };

/** Делит избранное на предстоящее (сгруппировано по дню, по возрастанию времени) и прошедшее (свежее сверху) */
export function groupFavoritesByDay(events: EventSummary[], now: Date): { upcoming: PlanDay[]; past: EventSummary[] } {
  const upcoming = [...events].filter((e) => new Date(e.startsAt) >= now).sort((a, b) => +new Date(a.startsAt) - +new Date(b.startsAt));
  const past = [...events].filter((e) => new Date(e.startsAt) < now).sort((a, b) => +new Date(b.startsAt) - +new Date(a.startsAt));

  const todayKey = isoDayMsk(now);
  const tomorrowKey = isoDayMsk(new Date(now.getTime() + 24 * 60 * 60 * 1000));

  const days = new Map<string, PlanDay>();
  for (const e of upcoming) {
    const startsAt = new Date(e.startsAt);
    const key = isoDayMsk(startsAt);
    let day = days.get(key);
    if (!day) {
      const label = key === todayKey ? "Сегодня" : key === tomorrowKey ? "Завтра" : dateShort(startsAt);
      day = { key, label, events: [] };
      days.set(key, day);
    }
    day.events.push(e);
  }

  return { upcoming: [...days.values()], past };
}
