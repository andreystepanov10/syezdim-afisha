// Ссылки на наши соцсети для подвала. Пока канала или группы нет — кнопку не показываем (раньше были заглушки
// https://t.me и https://vk.com, которые никуда не вели). Telegram без канала ведёт в бота.
import { botUsername } from "@/lib/telegram/api";

// Канал пока один — воронежский; когда появятся каналы других городов, note убрать
export type SocialLinks = { telegram: { href: string; label: string; note?: string } | null; bot: string | null; vk: string | null };

export function socialLinks(): SocialLinks {
  const channel = process.env.TELEGRAM_CHANNEL_URL;
  const bot = botUsername();
  return {
    telegram: channel ? { href: channel, label: "Telegram-канал Воронежа", note: "Telegram-канал пока только для Воронежа — другие города на подходе." } : bot ? { href: `https://t.me/${bot}`, label: "Telegram-бот" } : null,
    // Бот — отдельной кнопкой, когда telegram уже занят каналом (иначе бот и так в telegram)
    bot: channel && bot ? `https://t.me/${bot}` : null,
    vk: process.env.VK_URL || null,
  };
}
