import { describe, expect, it } from "vitest";
import { buildIcsCalendar } from "./ics";

describe("buildIcsCalendar", () => {
  it("собирает валидный VCALENDAR с одним VEVENT", () => {
    const ics = buildIcsCalendar([
      { uid: "test-event", title: "Концерт", startsAt: new Date("2026-10-15T16:00:00Z") },
    ]);
    expect(ics).toContain("BEGIN:VCALENDAR");
    expect(ics).toContain("VERSION:2.0");
    expect(ics).toContain("BEGIN:VEVENT");
    expect(ics).toContain("UID:test-event@syezdim.ru");
    expect(ics).toContain("SUMMARY:Концерт");
    expect(ics).toContain("DTSTART:20261015T160000Z");
    expect(ics).toContain("END:VEVENT");
    expect(ics).toContain("END:VCALENDAR");
  });

  it("по умолчанию ставит длительность 2 часа, если endsAt не передан", () => {
    const ics = buildIcsCalendar([{ uid: "a", title: "Событие", startsAt: new Date("2026-10-15T16:00:00Z") }]);
    expect(ics).toContain("DTEND:20261015T180000Z");
  });

  it("использует переданный endsAt вместо длительности по умолчанию", () => {
    const ics = buildIcsCalendar([
      { uid: "a", title: "Выставка", startsAt: new Date("2026-10-15T09:00:00Z"), endsAt: new Date("2026-10-20T18:00:00Z") },
    ]);
    expect(ics).toContain("DTEND:20261020T180000Z");
  });

  it("экранирует запятые, точку с запятой и переносы строк в тексте", () => {
    const ics = buildIcsCalendar([
      { uid: "a", title: "Рок, поп; и джаз\nвторая строка", startsAt: new Date("2026-10-15T16:00:00Z") },
    ]);
    expect(ics).toContain("SUMMARY:Рок\\, поп\\; и джаз\\nвторая строка");
  });

  it("складывает длинную строку по границе 75 октетов, не разрезая символ", () => {
    const longTitle = "А".repeat(120);
    const ics = buildIcsCalendar([{ uid: "a", title: longTitle, startsAt: new Date("2026-10-15T16:00:00Z") }]);
    const summaryLine = ics.split("\r\n").find((l) => l.startsWith("SUMMARY:"));
    expect(summaryLine).toBeDefined();
    // строка сложена: следующая физическая строка начинается с пробела-продолжения
    const idx = ics.indexOf("SUMMARY:");
    const after = ics.slice(idx, idx + 200);
    expect(after).toContain("\r\n ");
    // ни один символ «А» не потерян и не превратился в мусор при сборке
    expect(ics).toContain("А".repeat(10));
  });

  it("несколько событий дают несколько VEVENT-блоков", () => {
    const ics = buildIcsCalendar([
      { uid: "a", title: "Первое", startsAt: new Date("2026-10-15T16:00:00Z") },
      { uid: "b", title: "Второе", startsAt: new Date("2026-10-16T16:00:00Z") },
    ]);
    expect(ics.match(/BEGIN:VEVENT/g)).toHaveLength(2);
    expect(ics).toContain("UID:a@syezdim.ru");
    expect(ics).toContain("UID:b@syezdim.ru");
  });

  it("добавляет LOCATION и URL, только если они переданы", () => {
    const withExtras = buildIcsCalendar([
      { uid: "a", title: "Событие", startsAt: new Date("2026-10-15T16:00:00Z"), location: "Клуб «Ноты»", url: "https://syezdim.ru/events/a" },
    ]);
    expect(withExtras).toContain("LOCATION:Клуб «Ноты»");
    expect(withExtras).toContain("URL:https://syezdim.ru/events/a");

    const withoutExtras = buildIcsCalendar([{ uid: "b", title: "Событие", startsAt: new Date("2026-10-15T16:00:00Z") }]);
    expect(withoutExtras).not.toContain("LOCATION:");
    expect(withoutExtras).not.toContain("URL:");
  });
});
