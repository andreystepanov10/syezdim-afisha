import { describe, expect, it } from "vitest";
import { slugify } from "./slug";

describe("slugify", () => {
  it("транслитерирует кириллицу и заменяет всё лишнее на дефисы", () => {
    expect(slugify("Джазовый вечер в филармонии")).toBe("dzhazovyy-vecher-v-filarmonii");
    expect(slugify("Спектакль «Ревизор»")).toBe("spektakl-revizor");
  });

  it("схлопывает подряд идущие разделители и обрезает по краям", () => {
    expect(slugify("  Ёлка -- №2!!  ")).toBe("elka-2");
  });

  it("латиница и цифры проходят как есть, в нижнем регистре", () => {
    expect(slugify("Rock Fest 2026")).toBe("rock-fest-2026");
  });
});
