// Экспорт событий в .ics (RFC 5545): напоминания через собственный календарь пользователя
// (Google/Apple/Яндекс), без пуш-инфраструктуры и без хранения контактов на нашей стороне.

export type IcsEvent = {
  /** Стабильный идентификатор (slug события) — при повторном скачивании обновляет ту же запись, а не дублирует */
  uid: string;
  title: string;
  startsAt: Date;
  endsAt?: Date;
  location?: string;
  url?: string;
  description?: string;
};

const DEFAULT_DURATION_MS = 2 * 60 * 60 * 1000;
const FOLD_LIMIT_OCTETS = 74;

function icsDate(d: Date): string {
  return d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

/** Экранирует спецсимволы текстовых полей ICS (запятая, точка с запятой, обратный слэш, перевод строки) */
function escapeText(s: string): string {
  return s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
}

/** ICS требует не больше 75 октетов в физической строке — складываем по границе символа, не разрезая многобайтовые */
function foldLine(line: string): string {
  let out = "";
  let lineBytes = 0;
  for (const ch of line) {
    const chBytes = Buffer.byteLength(ch, "utf8");
    if (lineBytes + chBytes > FOLD_LIMIT_OCTETS) {
      out += "\r\n ";
      lineBytes = 1; // ведущий пробел продолжения — тоже октет
    }
    out += ch;
    lineBytes += chBytes;
  }
  return out;
}

function field(name: string, value: string): string {
  return foldLine(`${name}:${escapeText(value)}`);
}

/** Собирает .ics с одним или несколькими событиями (VCALENDAR может содержать много VEVENT) */
export function buildIcsCalendar(events: IcsEvent[]): string {
  const stamp = icsDate(new Date());
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Syezdim//Plan//RU", "CALSCALE:GREGORIAN", "METHOD:PUBLISH"];

  for (const e of events) {
    lines.push("BEGIN:VEVENT");
    lines.push(`UID:${e.uid}@syezdim.ru`);
    lines.push(`DTSTAMP:${stamp}`);
    lines.push(`DTSTART:${icsDate(e.startsAt)}`);
    lines.push(`DTEND:${icsDate(e.endsAt ?? new Date(e.startsAt.getTime() + DEFAULT_DURATION_MS))}`);
    lines.push(field("SUMMARY", e.title));
    if (e.location) lines.push(field("LOCATION", e.location));
    if (e.url) lines.push(field("URL", e.url));
    if (e.description) lines.push(field("DESCRIPTION", e.description));
    lines.push("END:VEVENT");
  }

  lines.push("END:VCALENDAR");
  return lines.join("\r\n") + "\r\n";
}
