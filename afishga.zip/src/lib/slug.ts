// Транслитерация кириллицы в ASCII-slug — для авто-подсказки slug по названию в формах админки.
// Стандартная посимвольная схема (без словарных исключений — этого достаточно для названий событий/площадок).
const MAP: Record<string, string> = {
  а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh", з: "z", и: "i",
  й: "y", к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t",
  у: "u", ф: "f", х: "h", ц: "ts", ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "",
  э: "e", ю: "yu", я: "ya",
};

/** «Джазовый вечер №2» → «dzhazovyy-vecher-2» */
export function slugify(text: string): string {
  const transliterated = [...text.toLowerCase()].map((ch) => MAP[ch] ?? ch).join("");
  return transliterated
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}
