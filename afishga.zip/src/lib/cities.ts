// Города Черноземья, для которых собираем афишу
export const CITIES = [
  { slug: "voronezh", name: "Воронеж", locative: "в Воронеже", genitive: "Воронежа", region: "Воронежская область", lat: 51.6606, lon: 39.2003 },
  { slug: "belgorod", name: "Белгород", locative: "в Белгороде", genitive: "Белгорода", region: "Белгородская область", lat: 50.5997, lon: 36.5983 },
  { slug: "kursk", name: "Курск", locative: "в Курске", genitive: "Курска", region: "Курская область", lat: 51.7304, lon: 36.1926 },
  { slug: "lipetsk", name: "Липецк", locative: "в Липецке", genitive: "Липецка", region: "Липецкая область", lat: 52.6088, lon: 39.5992 },
  { slug: "tambov", name: "Тамбов", locative: "в Тамбове", genitive: "Тамбова", region: "Тамбовская область", lat: 52.7212, lon: 41.4523 },
  { slug: "orel", name: "Орёл", locative: "в Орле", genitive: "Орла", region: "Орловская область", lat: 52.9703, lon: 36.0635 },
] as const;

export type CitySlug = (typeof CITIES)[number]["slug"];

export const DEFAULT_CITY: CitySlug = "voronezh";
export const CITY_COOKIE = "radius_city";

export function isCitySlug(value: string): value is CitySlug {
  return CITIES.some((c) => c.slug === value);
}

export function cityName(slug: CitySlug): string {
  return CITIES.find((c) => c.slug === slug)?.name ?? "";
}

/** «в Воронеже» — для заголовков вида «Популярные события в Воронеже» */
export function cityLocative(slug: CitySlug): string {
  return CITIES.find((c) => c.slug === slug)?.locative ?? "";
}

/** «Воронежа» — для заголовков вида «Афиша Воронежа» (так реально ищут в Яндексе/Google) */
/** «Белгородская область» — для страниц населённых пунктов области */
export function cityRegion(slug: CitySlug): string {
  return CITIES.find((c) => c.slug === slug)?.region ?? "";
}

export function cityGenitive(slug: CitySlug): string {
  return CITIES.find((c) => c.slug === slug)?.genitive ?? "";
}
