import { describe, expect, it } from "vitest";
import { dateLandingTitle, findDateLanding, landingDates, localityTitle } from "./landings";

// Четверг, 15 октября 2026, 12:00 МСК
const NOW = new Date("2026-10-15T09:00:00Z");

describe("посадочные по датам", () => {
  it("заголовки под запросы «куда сходить в … сегодня / на выходных»", () => {
    expect(dateLandingTitle(findDateLanding("segodnya")!, "voronezh")).toBe("Куда сходить в Воронеже сегодня");
    expect(dateLandingTitle(findDateLanding("vyhodnye")!, "orel")).toBe("Куда сходить в Орле на выходных");
    expect(findDateLanding("events")).toBeUndefined();
  });

  it("даты страницы по МСК: сегодня, завтра, ближайшие выходные, неделя", () => {
    expect(landingDates("today", NOW)).toBe("15 октября");
    expect(landingDates("tomorrow", NOW)).toBe("16 октября");
    expect(landingDates("weekend", NOW)).toBe("17 октября — 18 октября");
    expect(landingDates("week", NOW)).toBe("15 октября — 21 октября");
  });

  it("в воскресенье «выходные» — это вчера и сегодня", () => {
    expect(landingDates("weekend", new Date("2026-10-18T09:00:00Z"))).toBe("17 октября — 18 октября");
  });

  it("населённый пункт — без склонения названия", () => {
    expect(localityTitle("Старый Оскол")).toBe("Старый Оскол: афиша событий — концерты, спектакли, кино");
  });
});
