import { afterEach, describe, expect, it, vi } from "vitest";
import { affiliateMark, affiliateUrl, ticketHref } from "./affiliate";

afterEach(() => vi.unstubAllEnvs());

describe("affiliateUrl", () => {
  it("без шаблона ссылка остаётся как есть", () => {
    vi.stubEnv("AFFILIATE_KASSIR", "");
    expect(affiliateUrl("https://vrn.kassir.ru/koncert/x")).toBe("https://vrn.kassir.ru/koncert/x");
  });

  it("с шаблоном подставляет закодированную ссылку в диплинк — для любого поддомена источника", () => {
    vi.stubEnv("AFFILIATE_KASSIR", "https://ad.admitad.com/g/abc/?ulp={url}");
    expect(affiliateUrl("https://vrn.kassir.ru/koncert/x?a=1")).toBe("https://ad.admitad.com/g/abc/?ulp=https%3A%2F%2Fvrn.kassir.ru%2Fkoncert%2Fx%3Fa%3D1");
    expect(affiliateUrl("https://example.com/x")).toBe("https://example.com/x");
  });
});

describe("ticketHref", () => {
  it("ведёт через счётчик и помечает источник", () => {
    expect(ticketHref("kino")).toBe("/go/kino");
    expect(ticketHref("kino", "channel", "https://syezdim.ru")).toBe("https://syezdim.ru/go/kino?from=channel");
  });
});

describe("affiliateMark", () => {
  it("пометка «Реклама» только у партнёрских ссылок; полный текст — из настроек", () => {
    vi.stubEnv("AFFILIATE_KASSIR", "");
    expect(affiliateMark("https://vrn.kassir.ru/x")).toBeNull();
    vi.stubEnv("AFFILIATE_KASSIR", "https://ad.admitad.com/g/abc/?ulp={url}");
    expect(affiliateMark("https://vrn.kassir.ru/x")).toBe("Реклама");
    vi.stubEnv("AFFILIATE_KASSIR_MARK", "Реклама. ООО «Пример», erid: 2Vtz");
    expect(affiliateMark("https://vrn.kassir.ru/x")).toBe("Реклама. ООО «Пример», erid: 2Vtz");
    expect(affiliateMark("https://vrn.afishagoroda.ru/x")).toBeNull();
  });
});
