// SEO-помощники: короткие описания для сниппетов и разметка Schema.org для событий.
import type { EventDetails } from "@/data/events";
import { cityName } from "@/lib/cities";
import { dateTimeLong, dayMonthLong, periodLong, priceLabel } from "@/lib/format";
import { SITE_URL } from "@/lib/site";

/** Яндекс и Google показывают в сниппете ~160 символов — длиннее обрезают на полуслове */
const SNIPPET_MAX = 160;

/** Обрезает текст до границы слова с многоточием; переносы и двойные пробелы схлопывает */
export function truncate(text: string, max = SNIPPET_MAX): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max - 1);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.6 ? cut.slice(0, lastSpace) : cut).replace(/[\s,.;:—-]+$/, "")}…`;
}

/** Абсолютный адрес: картинки событий лежат и у нас (/uploads/...), и на сайтах источников */
export function absoluteUrl(pathOrUrl: string): string {
  return /^https?:\/\//.test(pathOrUrl) ? pathOrUrl : `${SITE_URL}${pathOrUrl.startsWith("/") ? "" : "/"}${pathOrUrl}`;
}

/** Где проходит: населённый пункт области («Старый Оскол») или областной центр */
export function eventPlace(event: Pick<EventDetails, "city" | "locality">): string {
  return event.locality ?? cityName(event.city);
}

/**
 * «Осенняя соната — Воронеж, 15 октября»: так и ищут — название + город, дата отличает повторные показы.
 * Фильм — «в кино» (идёт много дней), выставка — «до 6 декабря».
 */
export function eventTitle(event: Pick<EventDetails, "title" | "city" | "locality" | "startsAt" | "endsAt" | "category">): string {
  if (event.category === "cinema") return `${event.title} — в кино, ${eventPlace(event)}`;
  if (event.endsAt) return `${event.title} — ${eventPlace(event)}, до ${dayMonthLong(event.endsAt)}`;
  return `${event.title} — ${eventPlace(event)}, ${dayMonthLong(event.startsAt)}`;
}

/** Факты в начале (когда, где, сколько) — их и ищут; затем начало описания, если остаётся место */
export function eventDescription(event: Pick<EventDetails, "title" | "city" | "locality" | "startsAt" | "endsAt" | "venue" | "priceFrom" | "description">): string {
  const when = event.endsAt ? periodLong(event.startsAt, event.endsAt) : dateTimeLong(event.startsAt);
  const facts = `${when}, ${event.venue.name}, ${eventPlace(event)}. ${priceLabel(event.priceFrom)}.`;
  const about = event.description.replace(/\s+/g, " ").trim();
  return truncate(about ? `${facts} ${about}` : `${event.title}: ${facts} Билеты у партнёров.`);
}

/**
 * Schema.org Event — по нему Яндекс и Google показывают событие с датой, местом и ценой прямо в выдаче.
 * https://developers.google.com/search/docs/appearance/structured-data/event
 */
export function eventJsonLd(event: EventDetails): Record<string, unknown> {
  const url = `${SITE_URL}/events/${event.slug}`;
  return {
    "@context": "https://schema.org",
    "@type": "Event",
    name: event.title,
    url,
    startDate: event.startsAt,
    ...(event.endsAt ? { endDate: event.endsAt } : {}),
    eventStatus: "https://schema.org/EventScheduled",
    eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
    ...(event.description ? { description: truncate(event.description, 500) } : {}),
    ...(event.image ? { image: [absoluteUrl(event.image)] } : {}),
    location: {
      "@type": "Place",
      name: event.venue.name,
      address: {
        "@type": "PostalAddress",
        ...(event.venue.address ? { streetAddress: event.venue.address } : {}),
        addressLocality: eventPlace(event),
        addressCountry: "RU",
      },
      geo: { "@type": "GeoCoordinates", latitude: event.venue.lat, longitude: event.venue.lon },
    },
    ...(event.priceFrom != null
      ? {
          offers: {
            "@type": "Offer",
            url: event.ticketUrl ?? url,
            price: event.priceFrom,
            priceCurrency: "RUB",
            availability: "https://schema.org/InStock",
          },
        }
      : {}),
    ...(event.ageLimit != null ? { typicalAgeRange: `${event.ageLimit}+` } : {}),
  };
}

/** JSON для <script type="application/ld+json">: «<» экранируем, чтобы текст из источника не закрыл тег (XSS) */
export function jsonLdString(data: unknown): string {
  return JSON.stringify(data).replace(/</g, "\\u003c");
}
