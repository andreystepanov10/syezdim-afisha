// Вход в админку — один общий пароль (ADMIN_PASSWORD), без таблицы пользователей: сессия — cookie,
// подписанная HMAC от самого пароля, поэтому её не нужно хранить в базе, чтобы проверить.
import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

const COOKIE = "radius_admin";
const TTL_MS = 12 * 60 * 60 * 1000; // 12 часов

function secret(): string {
  const value = process.env.ADMIN_PASSWORD;
  if (!value) throw new Error("ADMIN_PASSWORD не задан — см. .env.example");
  return value;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("hex");
}

function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  return bufA.length === bufB.length && timingSafeEqual(bufA, bufB);
}

/** Сравнение введённого пароля с ADMIN_PASSWORD — без утечки времени сравнения */
export function verifyAdminPassword(password: string): boolean {
  return safeEqual(password, secret());
}

/** Ставит cookie сессии — только из Server Action/Route Handler */
export async function startAdminSession(): Promise<void> {
  const payload = String(Date.now() + TTL_MS);
  const token = `${payload}.${sign(payload)}`;
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    secure: process.env.NODE_ENV === "production",
    maxAge: TTL_MS / 1000,
  });
}

export async function endAdminSession(): Promise<void> {
  (await cookies()).delete(COOKIE);
}

/** true — в этой сессии есть действующий (не истёкший, не подделанный) admin-токен */
export async function isAdmin(): Promise<boolean> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig || !safeEqual(sig, sign(payload))) return false;
  return Number(payload) > Date.now();
}
