const ENDPOINT = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion";
const MODEL = "yandexgpt-lite";

export function isYandexGptConfigured(): boolean {
  return Boolean(process.env.YANDEX_GPT_API_KEY && process.env.YANDEX_GPT_FOLDER_ID);
}

export type EventFacts = {
  title: string;
  category: string;
  venueName: string;
  cityName: string;
};

type CompletionResponse = {
  result?: { alternatives?: { message?: { text?: string } }[] };
};

/**
 * Переписывает описание своими словами по факту и (если есть) исходному тексту с сайта-источника —
 * решение переписывать чужой текст, а не писать с нуля по фактам, принято осознанно (см. память проекта).
 * YandexGPT, а не Gemini: серверы в России, Gemini API их не обслуживает (геоблокировка).
 */
export async function rewriteDescription(facts: EventFacts, sourceText: string | null): Promise<string> {
  const apiKey = process.env.YANDEX_GPT_API_KEY;
  const folderId = process.env.YANDEX_GPT_FOLDER_ID;
  if (!apiKey || !folderId) throw new Error("YANDEX_GPT_API_KEY/YANDEX_GPT_FOLDER_ID не заданы");

  const prompt = sourceText
    ? `Перепиши своими словами описание события для афиши сайта, сохранив ключевые факты. Не копируй фразы дословно.\n\nИсходный текст с другого сайта:\n${sourceText}`
    : `Напиши короткое привлекательное описание события для афиши сайта по этим фактам (исходного текста нет).`;

  const res = await fetch(ENDPOINT, {
    method: "POST",
    headers: { Authorization: `Api-Key ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      modelUri: `gpt://${folderId}/${MODEL}/latest`,
      completionOptions: { temperature: 0.3, maxTokens: "400" },
      messages: [
        {
          role: "user",
          text: `${prompt}\n\nНазвание: ${facts.title}\nКатегория: ${facts.category}\nПлощадка: ${facts.venueName}\nГород: ${facts.cityName}\n\nОтвет — только текст описания на русском, 2-4 предложения, без заголовков и кавычек.`,
        },
      ],
    }),
  });

  if (!res.ok) throw new Error(`YandexGPT ответил ${res.status}: ${await res.text()}`);
  const data = (await res.json()) as CompletionResponse;
  const text = data.result?.alternatives?.[0]?.message?.text?.trim();
  if (!text) throw new Error("YandexGPT не вернул текст");
  return text;
}
