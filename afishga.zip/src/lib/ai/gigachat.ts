import { randomUUID } from "node:crypto";
import { gigachatFetch } from "./gigachat-fetch";

const OAUTH_URL = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth";
const CHAT_URL = "https://api.giga.chat/v1/chat/completions";
const MODEL = "GigaChat-3-Lightning";
const TOKEN_MARGIN_MS = 60_000; // обновляем токен на минуту раньше формального истечения

export function isGigaChatConfigured(): boolean {
  return Boolean(process.env.GIGACHAT_AUTH_KEY);
}

let cachedToken: { value: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now()) return cachedToken.value;

  const authKey = process.env.GIGACHAT_AUTH_KEY;
  if (!authKey) throw new Error("GIGACHAT_AUTH_KEY не задан");

  const res = await gigachatFetch(OAUTH_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
      RqUID: randomUUID(),
      Authorization: `Basic ${authKey}`,
    },
    body: "scope=GIGACHAT_API_PERS",
  });
  if (!res.ok) throw new Error(`GigaChat OAuth ответил ${res.status}: ${await res.text()}`);

  const data = (await res.json()) as { access_token?: string; expires_at?: number };
  if (!data.access_token) throw new Error("GigaChat OAuth не вернул access_token");

  // expires_at — unix-время в мс от GigaChat; про запас берём чуть раньше
  const expiresAt = (data.expires_at ?? Date.now() + 30 * 60_000) - TOKEN_MARGIN_MS;
  cachedToken = { value: data.access_token, expiresAt };
  return data.access_token;
}

export type EventFacts = {
  title: string;
  category: string;
  venueName: string;
  cityName: string;
};

type ChatResponse = {
  choices?: { message?: { content?: string } }[];
};

/**
 * Переписывает описание своими словами по факту и (если есть) исходному тексту с сайта-источника —
 * решение переписывать чужой текст, а не писать с нуля по фактам, принято осознанно (см. память проекта).
 * GigaChat, а не Gemini/YandexGPT: бесплатный лимит 1 млн токенов/год, российский сервис.
 */
export async function rewriteDescription(facts: EventFacts, sourceText: string | null): Promise<string> {
  const token = await getAccessToken();

  const prompt = sourceText
    ? `Перепиши своими словами описание события для афиши сайта, сохранив ключевые факты. Не копируй фразы дословно.\n\nИсходный текст с другого сайта:\n${sourceText}`
    : `Напиши короткое привлекательное описание события для афиши сайта по этим фактам (исходного текста нет).`;

  const res = await gigachatFetch(CHAT_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      temperature: 0.3,
      messages: [
        {
          role: "user",
          content: `${prompt}\n\nНазвание: ${facts.title}\nКатегория: ${facts.category}\nПлощадка: ${facts.venueName}\nГород: ${facts.cityName}\n\nОтвет — только текст описания на русском, 2-4 предложения, без заголовков и кавычек.`,
        },
      ],
    }),
  });
  if (!res.ok) throw new Error(`GigaChat ответил ${res.status}: ${await res.text()}`);

  const data = (await res.json()) as ChatResponse;
  const text = data.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("GigaChat не вернул текст");
  return text;
}
