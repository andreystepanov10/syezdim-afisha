import { GoogleGenAI } from "@google/genai";

const TEXT_MODEL = "gemini-3.5-flash-lite";
const IMAGE_MODEL = "gemini-3.1-flash-image";

export function isGeminiConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY);
}

function client(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY не задан");
  return new GoogleGenAI({ apiKey });
}

export type EventFacts = {
  title: string;
  category: string;
  venueName: string;
  cityName: string;
};

/**
 * Переписывает описание своими словами по факту и (если есть) исходному тексту с сайта-источника —
 * решение переписывать чужой текст, а не писать с нуля по фактам, принято осознанно (см. память проекта).
 */
export async function rewriteDescription(facts: EventFacts, sourceText: string | null): Promise<string> {
  const ai = client();
  const prompt = sourceText
    ? `Перепиши своими словами описание события для афиши сайта, сохранив ключевые факты. Не копируй фразы дословно.\n\nИсходный текст с другого сайта:\n${sourceText}`
    : `Напиши короткое привлекательное описание события для афиши сайта по этим фактам (исходного текста нет).`;

  const interaction = await ai.models.generateContent({
    model: TEXT_MODEL,
    contents: `${prompt}\n\nНазвание: ${facts.title}\nКатегория: ${facts.category}\nПлощадка: ${facts.venueName}\nГород: ${facts.cityName}\n\nОтвет — только текст описания на русском, 2-4 предложения, без заголовков и кавычек.`,
  });

  const text = interaction.text?.trim();
  if (!text) throw new Error("Gemini не вернул текст");
  return text;
}

/** Генерирует иллюстрацию к событию с нуля (не редактирует чужие фото) — по названию и категории */
export async function generateEventImage(facts: EventFacts): Promise<{ bytes: Buffer; ext: string }> {
  const ai = client();
  const prompt = `Яркая афишная иллюстрация для события «${facts.title}» (категория: ${facts.category}, город: ${facts.cityName}). Без текста и надписей на изображении, современный плоский стиль, вертикальная афиша.`;

  const response = await ai.models.generateContent({
    model: IMAGE_MODEL,
    contents: prompt,
  });

  if (!response.data) throw new Error("Gemini не вернул изображение");
  return { bytes: Buffer.from(response.data, "base64"), ext: "png" };
}
