import { afterEach, describe, expect, it, vi } from "vitest";
import { isGigaChatConfigured, rewriteDescription } from "./gigachat";

const facts = { title: "Концерт", category: "Концерты", venueName: "ДК Октябрь", cityName: "Воронеж" };

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("isGigaChatConfigured", () => {
  it("false без ключа", () => {
    vi.stubEnv("GIGACHAT_AUTH_KEY", "");
    expect(isGigaChatConfigured()).toBe(false);
  });

  it("true с ключом", () => {
    vi.stubEnv("GIGACHAT_AUTH_KEY", "base64key");
    expect(isGigaChatConfigured()).toBe(true);
  });
});

describe("rewriteDescription", () => {
  it("без ключа — понятная ошибка", async () => {
    vi.stubEnv("GIGACHAT_AUTH_KEY", "");
    await expect(rewriteDescription(facts, "исходный текст")).rejects.toThrow(/GIGACHAT_AUTH_KEY/);
  });

  it("получает токен и разбирает успешный ответ чата", async () => {
    vi.stubEnv("GIGACHAT_AUTH_KEY", "base64key");
    const fetchMock = vi.fn(async (url: string) => {
      if (url.includes("oauth")) {
        return new Response(JSON.stringify({ access_token: "tok-123", expires_at: Date.now() + 30 * 60_000 }), { status: 200 });
      }
      return new Response(JSON.stringify({ choices: [{ message: { content: "  Переписанное описание  " } }] }), { status: 200 });
    });
    vi.doMock("./gigachat-fetch", () => ({ gigachatFetch: fetchMock }));
    vi.resetModules();
    const mod = await import("./gigachat");
    await expect(mod.rewriteDescription(facts, "исходный текст")).resolves.toBe("Переписанное описание");
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("ошибка OAuth — понятное сообщение", async () => {
    vi.stubEnv("GIGACHAT_AUTH_KEY", "base64key");
    const fetchMock = vi.fn(async () => new Response("bad auth key", { status: 401 }));
    vi.doMock("./gigachat-fetch", () => ({ gigachatFetch: fetchMock }));
    vi.resetModules();
    const mod = await import("./gigachat");
    await expect(mod.rewriteDescription(facts, "исходный текст")).rejects.toThrow(/401/);
  });
});
