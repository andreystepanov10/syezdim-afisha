import { afterEach, describe, expect, it, vi } from "vitest";
import { isYandexGptConfigured, rewriteDescription } from "./yandexgpt";

const facts = { title: "Концерт", category: "Концерты", venueName: "ДК Октябрь", cityName: "Воронеж" };

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("isYandexGptConfigured", () => {
  it("false, пока не заданы оба значения", () => {
    vi.stubEnv("YANDEX_GPT_API_KEY", "");
    vi.stubEnv("YANDEX_GPT_FOLDER_ID", "");
    expect(isYandexGptConfigured()).toBe(false);
    vi.stubEnv("YANDEX_GPT_API_KEY", "key");
    expect(isYandexGptConfigured()).toBe(false);
  });

  it("true, когда заданы и ключ, и id каталога", () => {
    vi.stubEnv("YANDEX_GPT_API_KEY", "key");
    vi.stubEnv("YANDEX_GPT_FOLDER_ID", "folder");
    expect(isYandexGptConfigured()).toBe(true);
  });
});

describe("rewriteDescription", () => {
  it("без ключа — понятная ошибка, а не падение с чужим сообщением", async () => {
    vi.stubEnv("YANDEX_GPT_API_KEY", "");
    vi.stubEnv("YANDEX_GPT_FOLDER_ID", "");
    await expect(rewriteDescription(facts, "исходный текст")).rejects.toThrow(/YANDEX_GPT/);
  });

  it("разбирает успешный ответ API", async () => {
    vi.stubEnv("YANDEX_GPT_API_KEY", "key");
    vi.stubEnv("YANDEX_GPT_FOLDER_ID", "folder");
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response(JSON.stringify({ result: { alternatives: [{ message: { text: "  Переписанное описание  " } }] } }), { status: 200 })),
    );
    await expect(rewriteDescription(facts, "исходный текст")).resolves.toBe("Переписанное описание");
  });

  it("код ответа не 200 — ошибка", async () => {
    vi.stubEnv("YANDEX_GPT_API_KEY", "key");
    vi.stubEnv("YANDEX_GPT_FOLDER_ID", "folder");
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response("bad request", { status: 400 })),
    );
    await expect(rewriteDescription(facts, "исходный текст")).rejects.toThrow(/400/);
  });

  it("пустой текст в ответе — ошибка", async () => {
    vi.stubEnv("YANDEX_GPT_API_KEY", "key");
    vi.stubEnv("YANDEX_GPT_FOLDER_ID", "folder");
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response(JSON.stringify({ result: { alternatives: [] } }), { status: 200 })),
    );
    await expect(rewriteDescription(facts, "исходный текст")).rejects.toThrow(/не вернул текст/);
  });
});
