import { describe, expect, it } from "vitest";
import { DuplicateIndex, titleKey } from "./dedupe";

describe("titleKey", () => {
  it("склеивает варианты названий одного события из разных источников", () => {
    const k = titleKey("Мастер и Маргарита");
    expect(titleKey("Спектакль «Мастер и Маргарита»")).toBe(k);
    expect(titleKey("Мастер и Маргарита (Белгород)")).toBe(k);
    expect(titleKey("Спектакль Мастер и Маргарита")).toBe(k);
    expect(titleKey("Спектакль «Мастер и Маргарита», Старый Оскол")).toBe(k);
    expect(titleKey("Идеальная жена")).toBe(titleKey("Спектакль «Идеальная жена» 16+"));
    expect(titleKey("Сольный концерт Ева Власова")).toBe(titleKey("Ева Власова"));
  });

  it("разные события не склеивает", () => {
    expect(titleKey("Мастер и Маргарита")).not.toBe(titleKey("Собачье сердце"));
    expect(titleKey("Война и мир, часть 1")).not.toBe(titleKey("Война и мир"));
  });
});

describe("DuplicateIndex", () => {
  it("дубль — то же название в пределах 45 минут, другой сеанс того же спектакля — не дубль", () => {
    const idx = new DuplicateIndex();
    idx.add("Спектакль «Мастер и Маргарита»", new Date("2026-11-15T15:00:00Z"));
    expect(idx.has("Мастер и Маргарита (Белгород)", new Date("2026-11-15T15:30:00Z"))).toBe(true);
    expect(idx.has("Мастер и Маргарита", new Date("2026-12-17T16:00:00Z"))).toBe(false);
    expect(idx.has("Собачье сердце", new Date("2026-11-15T15:00:00Z"))).toBe(false);
  });
});
