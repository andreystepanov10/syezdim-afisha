// Площадки при импорте: сопоставление названий из разных источников и автосоздание новых через геокодер.
import * as cheerio from "cheerio";
import { CITIES, type CitySlug } from "@/lib/cities";
import { fetchSource } from "./http";

/**
 * Ключ для сравнения названий площадок: источники пишут одно и то же по-разному —
 * «Авторский театр «Саквояж»» / «Авторский театр Саквояж», «Scandy Park (Белгород)», «Воронежский концертный зал (ВКЗ)».
 */
export function venueKey(name: string): string {
  const city = new RegExp(`\\((${CITIES.map((c) => c.name).join("|")})\\)`, "giu");
  return name
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(city, " ")
    .replace(/\([^)]{1,8}\)/g, " ") // короткие пометки-аббревиатуры: «(ВКЗ)», «(ДК)»
    .replace(/[«»"'„“”`.,:;!?()–—-]/g, " ")
    .replace(/(^|\s)(г|город)(?=\s|$)/g, " ") // «ДК Железнодорожников г. Елец» = «ДК Железнодорожников, Елец»
    .replace(/\s+/g, " ")
    .trim();
}

/** Названия-заглушки, которые нельзя геокодировать: это не площадка */
const NOT_A_VENUE = /^(неизвестно|разные площадки|онлайн|online|место уточняется|по месту|выездное)/i;

/** Области Черноземья: афиша города включает события всей его области (Старый Оскол — в афише Белгорода) */
export const REGION_NAME = Object.fromEntries(CITIES.map((c) => [c.slug, c.region])) as Record<CitySlug, string>;

export type GeocodedVenue = {
  name: string;
  address: string;
  lat: number;
  lon: number;
  /** Населённый пункт, если это не областной центр: «Старый Оскол», «Елец» */
  locality: string | null;
  /** Точного места нет — координаты центра города/посёлка (см. venues.approx) */
  approx?: boolean;
};

/** Область поиска вокруг центра, градусы: с запасом покрывает каждую из областей; точную принадлежность проверяем по адресу */
const BOX_LON = 2.6;
const BOX_LAT = 1.6;
const USER_AGENT = "syezdim.ru event import (https://syezdim.ru)";
let lastRequestAt = 0;

/**
 * «ДК «Горняк», Старый Оскол» / «ДК Железнодорожников г. Елец» → название и населённый пункт отдельно.
 * Населённый пункт в названии сильно помогает геокодеру, а на сайте показываем его отдельной строкой.
 */
export function splitLocality(name: string): { name: string; locality: string | null } {
  const g = /^(.*?)[,\s]+(?:г\.|город)\s*([А-ЯЁ][а-яё-]+(?:\s[А-ЯЁ][а-яё-]+)?)$/u.exec(name);
  if (g) return { name: g[1].trim(), locality: g[2] };
  const comma = /^(.*\S),\s*([А-ЯЁ][а-яё-]+(?:[\s-][А-ЯЁ][а-яё-]+)?)$/u.exec(name);
  if (comma) return { name: comma[1].trim(), locality: comma[2] };
  return { name: name.trim(), locality: null };
}

type NominatimHit = { lat: string; lon: string; address?: Record<string, string> };

/** Один запрос к Nominatim в пределах области; находку из другой области отбрасываем */
async function searchInRegion(q: string, city: CitySlug): Promise<NominatimHit | null> {
  const c = CITIES.find((x) => x.slug === city)!;
  const wait = lastRequestAt + 1100 - Date.now();
  if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  lastRequestAt = Date.now();

  const params = new URLSearchParams({
    q,
    format: "jsonv2",
    limit: "3",
    countrycodes: "ru",
    "accept-language": "ru",
    addressdetails: "1",
    viewbox: `${c.lon - BOX_LON},${c.lat + BOX_LAT},${c.lon + BOX_LON},${c.lat - BOX_LAT}`,
    bounded: "1",
  });
  const res = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
    headers: { "User-Agent": USER_AGENT },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) return null;
  const hits = (await res.json()) as NominatimHit[];
  return hits.find((h) => h.address?.state === REGION_NAME[city]) ?? null;
}

/** Населённый пункт из ответа Nominatim. Иногда вместо города приходит муниципалитет — «городской округ Курск» */
export function placeOf(hit: NominatimHit): string | null {
  const a = hit.address ?? {};
  const raw = a.city ?? a.town ?? a.village ?? a.hamlet ?? a.municipality ?? null;
  return raw?.replace(/^(городской округ|городское поселение|сельское поселение|муниципальный округ)\s+(город\s+)?/iu, "").trim() || null;
}

/**
 * Адрес со страницы площадки на источнике. Сейчас умеем Афишу Города: «г. Воронеж, ул. Ленина, 43»
 * в блоке .info-block рядом с иконкой метки.
 */
export function extractVenueAddress(html: string): string | null {
  const $ = cheerio.load(html);
  const li = $(".info-block li")
    .filter((_, el) => $(el).find(".icon-location-pin").length > 0)
    .first();
  const text = li.text().replace(/\s+/g, " ").trim();
  return text || null;
}

/** Сокращения в адресах источников, на которых Nominatim спотыкается: «г. Воронеж, просп. Революции, 56» не находит */
const ABBREVIATIONS: [RegExp, string][] = [
  [/(^|[\s,])(просп|пр-т|пр-кт)\.?(?=\s)/giu, "$1проспект"],
  [/(^|[\s,])ул\.(?=\s)/giu, "$1улица"],
  [/(^|[\s,])пер\.(?=\s)/giu, "$1переулок"],
  [/(^|[\s,])пл\.(?=\s)/giu, "$1площадь"],
  [/(^|[\s,])(б-р|бул\.)(?=\s)/giu, "$1бульвар"],
  [/(^|[\s,])наб\.(?=\s)/giu, "$1набережная"],
  [/(^|[\s,])ш\.(?=\s)/giu, "$1шоссе"],
  [/(^|[\s,])(г|д|стр|корп)\.\s*/giu, "$1"],
];

/** «г. Воронеж, просп. Революции, 56» → «Воронеж, проспект Революции, 56» */
export function normalizeAddress(address: string): string {
  let out = address;
  for (const [re, to] of ABBREVIATIONS) out = out.replace(re, to);
  return out.replace(/\s+/g, " ").replace(/\s+,/g, ",").trim();
}

/**
 * Ищет площадку в OpenStreetMap (Nominatim) в пределах области города: сначала по названию, а если не нашлась
 * (у многих клубов и арт-пространств в OSM нет названия) — по адресу со страницы площадки на источнике.
 * null — не нашлась, это не площадка или она в другой области (kassir в Орле показывает и Новомосковск
 * Тульской области): событие тогда пропускается, а не ставится в случайную точку на карте.
 * Правила Nominatim: не чаще 1 запроса в секунду и с понятным User-Agent — соблюдаем.
 */
export async function geocodeVenue(rawName: string, city: CitySlug, venueUrl?: string, allowApprox = false): Promise<GeocodedVenue | null> {
  const withoutCity = rawName.replace(new RegExp(`\s*\((${CITIES.map((c) => c.name).join("|")})\)\s*$`, "u"), "").trim();
  if (!withoutCity || NOT_A_VENUE.test(withoutCity)) return null;
  const { name, locality: hinted } = splitLocality(withoutCity);
  const c = CITIES.find((x) => x.slug === city)!;

  // 1. По названию. Без подсказки населённого пункта ищем в областном центре — большинство площадок там
  const byName = await searchInRegion(`${name}, ${hinted ?? c.name}, ${REGION_NAME[city]}`, city);
  if (byName) {
    const place = placeOf(byName);
    const locality = place && place !== c.name ? place : null;
    // Искали в центре (источник не назвал другой город), а нашлось где-то в области — скорее всего, это другое
    // место с похожим названием; не берём, попробуем по адресу
    if (!(locality && !hinted)) {
      const a = byName.address ?? {};
      const street = [a.road, a.house_number].filter(Boolean).join(", ");
      return { name, address: street || place || c.name, lat: Number(byName.lat), lon: Number(byName.lon), locality };
    }
  }

  // 2. По адресу со страницы площадки
  let address: string | null = null;
  if (venueUrl) {
    const res = await fetchSource(venueUrl, { headers: { "User-Agent": USER_AGENT } }).catch(() => null);
    address = res?.ok ? extractVenueAddress(await res.text()) : null;
  }
  const byAddress = address ? await searchInRegion(normalizeAddress(address), city) : null;
  if (!byAddress || !address) return allowApprox ? approximate(name, hinted, address, city) : null;
  const place = placeOf(byAddress);
  const locality = place && place !== c.name ? place : null;
  // Адрес без «г. …» с источника — вида «ул. Ленина, 43»; храним его без названия города
  const street = address.replace(/^г\.?\s*[А-ЯЁ][а-яё-]+(?:\s[А-ЯЁ][а-яё-]+)?,\s*/u, "");
  return { name, address: street, lat: Number(byAddress.lat), lon: Number(byAddress.lon), locality };
}

/**
 * Примерная площадка, когда точного места на карте нет: центр посёлка из названия («ДК, Лиски») или центр
 * областного города. Событие попадает на сайт, а на карте и в «Рядом со мной» площадку не показываем.
 */
async function approximate(name: string, hinted: string | null, address: string | null, city: CitySlug): Promise<GeocodedVenue | null> {
  const c = CITIES.find((x) => x.slug === city)!;
  const street = address ? address.replace(/^г\.?\s*[А-ЯЁ][а-яё-]+(?:\s[А-ЯЁ][а-яё-]+)?,\s*/u, "") : "";
  if (!hinted) return { name, address: street, lat: c.lat, lon: c.lon, locality: null, approx: true };
  const town = await searchInRegion(`${hinted}, ${REGION_NAME[city]}`, city);
  if (!town) return null; // посёлок не нашёлся даже по названию — значит, что-то не так с данными
  return { name, address: street, lat: Number(town.lat), lon: Number(town.lon), locality: hinted, approx: true };
}
