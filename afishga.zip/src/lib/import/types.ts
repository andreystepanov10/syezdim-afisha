import type { CategorySlug } from "@/lib/categories";
import type { CitySlug } from "@/lib/cities";

/** Событие, как его отдаёт внешний источник — до сопоставления с нашими площадками/категориями */
export type ScrapedEvent = {
  /** Стабильный идентификатор на источнике (для дедупликации при повторном импорте) */
  externalId: string;
  title: string;
  startsAt: Date;
  /** Конец периода — у выставок и экспозиций («11 октября – 6 декабря»); у разовых событий нет */
  endsAt?: Date | null;
  category: CategorySlug;
  priceFrom: number | null;
  /** Абсолютный URL постера на сайте-источнике — при импорте скачивается и сохраняется на наш сервер */
  imageUrl: string | null;
  venueName: string;
  /** Страница площадки на источнике — там адрес, если по названию площадка в OpenStreetMap не находится */
  venueUrl?: string;
  /**
   * Источник надёжно привязан к городу (отдельный сайт на город, как у Афиши Города): если площадку не нашли на
   * карте, её можно завести с примерной точкой. У kassir в афише Белгорода бывают концерты Воронежа — там нельзя
   */
  cityReliable?: boolean;
  /**
   * Где площадка, если источник это знает и геокодер не нужен. Кино: фильм идёт во многих кинотеатрах города,
   * площадка условная — «Кинотеатры Воронежа» в центре города
   */
  venueGeo?: { lat: number; lon: number; address: string };
  /** Описание прямо из листинга источника (кино) — тогда страницу события отдельно не загружаем */
  description?: string;
  detailUrl: string;
};

export type ImportAdapter = {
  /** Короткий ключ источника — используется в slug импортированных событий и как slug партнёра */
  key: string;
  name: string;
  siteUrl: string;
  fetchEvents(city: CitySlug): Promise<ScrapedEvent[]>;
  /** externalId событий из отдельной подборки «Пушкинская карта» на источнике — если он такую ведёт */
  fetchPushkinCardIds?(city: CitySlug): Promise<Set<string>>;
};

export type ImportReport = {
  source: string;
  imported: number;
  updated: number;
  skippedDuplicate: number;
  skippedNoVenue: string[];
  errors: number;
};
