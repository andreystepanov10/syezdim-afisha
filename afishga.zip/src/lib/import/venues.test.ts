import { describe, expect, it } from "vitest";
import { splitLocality, venueKey } from "./venues";

describe("venueKey", () => {
  it("склеивает варианты написания одной площадки", () => {
    expect(venueKey("Авторский театр «Саквояж»")).toBe(venueKey("Авторский театр Саквояж"));
    expect(venueKey("Воронежский концертный зал (ВКЗ)")).toBe(venueKey("Воронежский концертный зал"));
    expect(venueKey("Scandy Park (Белгород)")).toBe(venueKey("Scandy Park"));
    expect(venueKey("Театр «Кот»")).toBe(venueKey("театр кот"));
  });

  it("разные площадки не путает", () => {
    expect(venueKey("Театр кукол")).not.toBe(venueKey("Театр драмы"));
  });
});

describe("splitLocality", () => {
  it("отделяет населённый пункт области от названия площадки", () => {
    expect(splitLocality("ДК «Горняк», Старый Оскол")).toEqual({ name: "ДК «Горняк»", locality: "Старый Оскол" });
    expect(splitLocality("ДК Железнодорожников г. Елец")).toEqual({ name: "ДК Железнодорожников", locality: "Елец" });
    expect(splitLocality("Театр кукол")).toEqual({ name: "Театр кукол", locality: null });
  });

  it("«…, Город» и «… г. Город» дают один ключ площадки", () => {
    expect(venueKey("ДК Железнодорожников г. Елец")).toBe(venueKey("ДК Железнодорожников, Елец"));
  });
});
