import { createEvent, createPartner, createVenue, extendEventEnd, getEventMediaBySlug, listCityEventTimes, listPartners, listVenues, updateEventMedia, type Ctx as AdminCtx } from "@/data/admin";
import { categoryName } from "@/lib/categories";
import { cityName, type CitySlug } from "@/lib/cities";
import { isGigaChatConfigured, rewriteDescription } from "@/lib/ai/gigachat";
import { slugify } from "@/lib/slug";
import { fetchSourceDescription } from "./detail-fetch";
import { downloadImage } from "./download-image";
import { createAfishaRuAdapter } from "./sources/afisha-ru";
import { createAfishaRuCinemaAdapter } from "./sources/afisha-ru-cinema";
import { createAfishagorodaAdapter } from "./sources/afishagoroda";
import { createKassirAdapter } from "./sources/kassir";
import type { ImportAdapter, ImportReport, ScrapedEvent } from "./types";
import { DuplicateIndex } from "./dedupe";
import { venueKey, type GeocodedVenue } from "./venues";

/**
 * publish — сразу публиковать то, что готово к показу (есть картинка и ссылка на билеты): так работает ежедневный
 * автоимпорт (scripts/import.mts). Без флага, как из админки, всё приходит черновиками на проверку.
 * geocode — найти незнакомую площадку и завести её автоматически (автоимпорт передаёт geocodeVenue из ./venues);
 * без него событие с незнакомой площадкой пропускается и попадает в отчёт.
 */
export type Ctx = AdminCtx & {
  adapters?: ImportAdapter[];
  publish?: boolean;
  geocode?: (name: string, city: CitySlug, venueUrl?: string, allowApprox?: boolean) => Promise<GeocodedVenue | null>;
};

function defaultAdapters(): ImportAdapter[] {
  return [createAfishagorodaAdapter(), createKassirAdapter(), createAfishaRuAdapter(), createAfishaRuCinemaAdapter()];
}

/** Drizzle оборачивает ошибку Postgres в DrizzleQueryError — настоящий код лежит в `.cause` */
function isUniqueViolation(error: unknown): boolean {
  const code = (error as { code?: unknown; cause?: { code?: unknown } } | null)?.code;
  const causeCode = (error as { cause?: { code?: unknown } } | null)?.cause?.code;
  return code === "23505" || causeCode === "23505";
}

async function findOrCreatePartner(adapter: ImportAdapter, ctx: Ctx): Promise<number> {
  const existing = await listPartners(ctx);
  const found = existing.find((p) => p.slug === adapter.key);
  if (found) return found.id;
  return createPartner({ slug: adapter.key, name: adapter.name, siteUrl: adapter.siteUrl }, ctx);
}

/**
 * Картинка — как есть с источника. Описание — тоже читаем с источника, но, если настроен GigaChat,
 * переписываем своими словами (не дословную копию чужого текста); без ключа или при сбое — используем
 * копию как есть, импорт не должен ломаться из-за недоступности ИИ.
 */
async function resolveMedia(item: ScrapedEvent, adapter: ImportAdapter, city: CitySlug): Promise<{ image: string | null; description: string }> {
  const [image, sourceText] = await Promise.all([
    item.imageUrl ? downloadImage(item.imageUrl) : Promise.resolve(null),
    item.description ? Promise.resolve(item.description) : fetchSourceDescription(item.detailUrl, adapter.key).catch(() => null),
  ]);

  if (isGigaChatConfigured()) {
    try {
      const facts = { title: item.title, category: categoryName(item.category), venueName: item.venueName, cityName: cityName(city) };
      return { image, description: await rewriteDescription(facts, sourceText) };
    } catch {
      // ИИ недоступен/споткнулся — не блокируем импорт, используем то, что скопировали с источника
    }
  }

  return { image, description: sourceText ?? "" };
}

/** Импортирует свежие события для города из всех источников — черновиками для проверки в админке (или сразу публикует, см. Ctx.publish) */
export async function runImport(city: CitySlug, ctx: Ctx = {}): Promise<ImportReport[]> {
  const adapters = ctx.adapters ?? defaultAdapters();
  const allVenues = await listVenues(ctx);
  const venues = allVenues.filter((v) => v.city === city);
  // Площадка в области узнаётся по «названию, населённому пункту» — так её и пишут источники («ДК «Горняк», Старый Оскол»)
  const venueIdByKey = new Map(venues.map((v) => [venueKey(v.locality ? `${v.name}, ${v.locality}` : v.name), v.id]));
  const takenSlugs = new Set(allVenues.map((v) => v.slug));
  // Площадка не нашлась геокодером — не спрашиваем снова в этом запуске (её же встретим у других источников)
  const geocodeMisses = new Set<string>();

  async function resolveVenue(name: string, geo?: ScrapedEvent["venueGeo"], venueUrl?: string, allowApprox?: boolean): Promise<number | null> {
    const key = venueKey(name);
    const known = venueIdByKey.get(key);
    if (known) return known;
    let found: GeocodedVenue | null = geo ? { name, ...geo, locality: null } : null;
    if (!found) {
      if (!ctx.geocode || geocodeMisses.has(key)) return null;
      found = await ctx.geocode(name, city, venueUrl, allowApprox).catch(() => null);
    }
    if (!found) {
      geocodeMisses.add(key);
      return null;
    }
    const base = slugify(found.locality ? `${found.name} ${found.locality}` : found.name);
    let slug = `${base}-${city}`.slice(0, 90);
    for (let i = 2; takenSlugs.has(slug); i++) slug = `${base}-${city}-${i}`.slice(0, 90);
    takenSlugs.add(slug);
    const id = await createVenue({ slug, name: found.name, address: found.address, lat: found.lat, lon: found.lon, city, locality: found.locality, approx: found.approx }, ctx);
    venueIdByKey.set(key, id);
    return id;
  }

  // То же событие из другого источника (или другого раздела того же) — не создаём второй раз
  const known = new DuplicateIndex();
  for (const e of await listCityEventTimes(city, new Date(Date.now() - 24 * 60 * 60 * 1000), ctx)) known.add(e.title, e.startsAt);

  const reports: ImportReport[] = [];

  for (const adapter of adapters) {
    const report: ImportReport = { source: adapter.name, imported: 0, updated: 0, skippedDuplicate: 0, skippedNoVenue: [], errors: 0 };
    const missingVenues = new Set<string>();

    let scraped: Awaited<ReturnType<ImportAdapter["fetchEvents"]>>;
    try {
      scraped = await adapter.fetchEvents(city);
    } catch {
      report.errors++;
      reports.push(report);
      continue;
    }

    const partnerId = await findOrCreatePartner(adapter, ctx);
    const pushkinIds = await adapter.fetchPushkinCardIds?.(city).catch(() => new Set<string>()) ?? new Set<string>();

    for (const item of scraped) {
      const venueId = await resolveVenue(item.venueName, item.venueGeo, item.venueUrl, item.cityReliable);
      if (!venueId) {
        missingVenues.add(item.venueName);
        continue;
      }

      const slug = `${adapter.key}-${slugify(item.title)}-${slugify(item.externalId)}`.slice(0, 96);

      // Уже импортировали раньше? Дозаполняем картинку/описание черновику без них, не трогая опубликованное
      // и не перезаписывая то, что admin уже отредактировал вручную.
      const existing = await getEventMediaBySlug(slug, ctx);
      if (existing) {
        // Фильм ещё в прокате, выставку продлили — источник даёт более позднюю дату окончания: продлеваем
        if (item.endsAt && existing.endsAt && item.endsAt > existing.endsAt) {
          await extendEventEnd(existing.id, item.endsAt, ctx);
          report.updated++;
          continue;
        }
        const needsBackfill = existing.status === "draft" && !existing.image && !existing.description;
        if (!needsBackfill) {
          report.skippedDuplicate++;
          continue;
        }
        const { image, description } = await resolveMedia(item, adapter, city);
        await updateEventMedia(existing.id, { image, description }, ctx);
        report.updated++;
        continue;
      }

      if (known.has(item.title, item.startsAt)) {
        report.skippedDuplicate++;
        continue;
      }

      const { image, description } = await resolveMedia(item, adapter, city);
      try {
        await createEvent(
          {
            slug,
            title: item.title,
            description,
            city,
            venueId,
            category: item.category,
            partnerId,
            startsAt: item.startsAt,
            endsAt: item.endsAt ?? null,
            priceFrom: item.priceFrom,
            priceTo: null,
            ageLimit: null,
            image,
            isHot: false,
            pushkinCard: pushkinIds.has(item.externalId),
            ticketUrl: item.detailUrl,
            status: ctx.publish && image && item.detailUrl ? "published" : "draft",
            ticketTypes: [],
          },
          ctx,
        );
        report.imported++;
        known.add(item.title, item.startsAt);
      } catch (error) {
        if (isUniqueViolation(error)) report.skippedDuplicate++;
        else report.errors++;
      }
    }

    report.skippedNoVenue = [...missingVenues].sort();
    reports.push(report);
  }

  return reports;
}
