import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { extractDescription } from "./detail-fetch";

const read = (name: string) => readFileSync(path.join(__dirname, "__fixtures__", name), "utf-8");

describe("extractDescription", () => {
  it("читает описание со страницы Афиши Города", () => {
    const text = extractDescription(read("afishagoroda-detail.fixture.html"), "afishagoroda");
    expect(text).toContain("По билету можно пройти");
  });

  it("читает описание со страницы Kassir.ru", () => {
    const text = extractDescription(read("kassir-detail.fixture.html"), "kassir");
    expect(text).toContain("Кай Метов");
  });

  it("читает описание со страницы Афиша.ру (из JSON-LD)", () => {
    const text = extractDescription(read("afisha-ru-detail.fixture.html"), "afisha-ru");
    expect(text).toContain("авантюрная мелодрама");
  });

  it("возвращает null для неизвестного источника", () => {
    expect(extractDescription("<html></html>", "unknown-source")).toBeNull();
  });
});
