// Одно и то же событие приходит из разных источников (и даже из разных разделов одного): «Спектакль «Мастер и
// Маргарита»», «Мастер и Маргарита (Белгород)», «Мастер и Маргарита». Считаем дублем совпадение города, названия
// после нормализации и времени начала с точностью до 45 минут (у источников время иногда расходится).

/** Слова-типы в начале названия, которых у другого источника может не быть */
const TYPE_PREFIX =
  /^(?:(?:большой|сольный|детский|кукольный|музыкальный|юбилейный|новогодний)\s+)*(?:спектакль|моноспектакль|концерт|мюзикл|шоу|опера|рок-опера|балет|премьера|стендап|stand[\s-]?up|standup|сказка|оперетта)\s+/u;

/** Ключ названия для сравнения: регистр, кавычки, пунктуация, приписки города и возраста не важны */
export function titleKey(title: string): string {
  let t = title
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/\([^)]*\)/g, " ") // «(Белгород)», «(16+)»
    .replace(/\d{1,2}\+/g, " ");
  // «…, Старый Оскол» — приписка населённого пункта в конце (с заглавной буквы в исходном названии)
  const comma = /,\s*([А-ЯЁ][а-яё-]+(?:\s[А-ЯЁ][а-яё-]+){0,2})\s*$/u.exec(title);
  if (comma) t = t.slice(0, t.length - comma[0].length).trim() || t;
  t = t.replace(/[«»"'„“”`.,:;!?–—]/g, " ").replace(/\s+/g, " ").trim();
  for (let i = 0; i < 2; i++) t = t.replace(TYPE_PREFIX, "");
  return t.trim();
}

const TOLERANCE_MS = 45 * 60 * 1000;

/** Учёт уже известных событий города: «есть ли такое же в пределах 45 минут» */
export class DuplicateIndex {
  private byTitle = new Map<string, number[]>();

  add(title: string, startsAt: Date): void {
    const key = titleKey(title);
    if (!key) return;
    const list = this.byTitle.get(key) ?? [];
    list.push(startsAt.getTime());
    this.byTitle.set(key, list);
  }

  has(title: string, startsAt: Date): boolean {
    const list = this.byTitle.get(titleKey(title));
    const t = startsAt.getTime();
    return Boolean(list?.some((s) => Math.abs(s - t) <= TOLERANCE_MS));
  }
}
