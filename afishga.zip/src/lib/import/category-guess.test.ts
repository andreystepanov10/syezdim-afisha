import { describe, expect, it } from "vitest";
import { guessCategoryFromText, guessCategoryFromUrlSegment } from "./category-guess";

describe("guessCategoryFromUrlSegment", () => {
  it("распознаёт festivali (множественное число) как фестивали", () => {
    expect(guessCategoryFromUrlSegment("/festivali/den-goroda")).toBe("festivals");
  });

  it("распознаёт sport как отдельную категорию", () => {
    expect(guessCategoryFromUrlSegment("/sport/hokkey-match")).toBe("sport");
  });

  it("неизвестный сегмент — null", () => {
    expect(guessCategoryFromUrlSegment("/что-то-незнакомое/event")).toBeNull();
  });
});

describe("guessCategoryFromText", () => {
  it("узнаёт спортивные события по ключевым словам", () => {
    expect(guessCategoryFromText("Чемпионат России по хоккею")).toBe("sport");
    expect(guessCategoryFromText("Кубок города по волейболу")).toBe("sport");
  });

  it("по умолчанию — концерт", () => {
    expect(guessCategoryFromText("Название без ключевых слов")).toBe("concerts");
  });
});
