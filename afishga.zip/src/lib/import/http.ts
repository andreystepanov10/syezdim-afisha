// Загрузка страниц сайтов-источников «вежливо»: пауза между запросами к одному сайту и повтор после 429.
// Без пауз kassir.ru после пары десятков быстрых запросов отвечает 429 Too Many Requests, и разделы приходят пустыми.

const MIN_INTERVAL_MS = 1500;
const MAX_RETRIES = 2;
const lastRequestAt = new Map<string, number>();
/** Сайты, которые и после повторов отвечают 429: до конца запуска к ним не ходим, чтобы не ждать минутами на каждой странице */
const blockedHosts = new Set<string>();

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function fetchSource(url: string, init: RequestInit = {}): Promise<Response> {
  const host = new URL(url).host;
  if (blockedHosts.has(host)) return new Response(null, { status: 429 });
  for (let attempt = 0; ; attempt++) {
    const wait = (lastRequestAt.get(host) ?? 0) + MIN_INTERVAL_MS - Date.now();
    if (wait > 0) await sleep(wait);
    lastRequestAt.set(host, Date.now());

    const res = await fetch(url, { ...init, signal: init.signal ?? AbortSignal.timeout(30_000) });
    if (res.status !== 429) return res;
    if (attempt >= MAX_RETRIES) {
      blockedHosts.add(host);
      return res;
    }

    // Retry-After в секундах, если источник его прислал; иначе 20 с, 40 с
    const retryAfter = Number(res.headers.get("retry-after"));
    await sleep(Number.isFinite(retryAfter) && retryAfter > 0 ? Math.min(retryAfter, 60) * 1000 : 20_000 * (attempt + 1));
  }
}
