import type { CategorySlug } from "@/lib/categories";

// Категория не всегда есть в разметке источника — угадываем по ключевым словам в названии
// или по первому сегменту URL (у kassir.ru он обычно совпадает с типом события).
const KEYWORD_MAP: [RegExp, CategorySlug][] = [
  [/театр|спектакл|драм/i, "theatre"],
  [/выставк|музе/i, "exhibitions"],
  [/кино|фильм/i, "cinema"],
  [/детям|детск|мультфильм|цирк/i, "kids"],
  [/фестивал/i, "festivals"],
  [/мастер-класс|воркшоп/i, "workshops"],
  [/матч|турнир|чемпионат|кубок|хоккей|футбол|баскетбол|волейбол/i, "sport"],
];

/**
 * Запасной вариант, если по URL категория не определилась. fallback — категория раздела источника, откуда взято
 * событие («Детская афиша», «Музеи»); без него по умолчанию считаем концертом.
 */
export function guessCategoryFromText(text: string, fallback: CategorySlug = "concerts"): CategorySlug {
  for (const [re, slug] of KEYWORD_MAP) if (re.test(text)) return slug;
  return fallback;
}

const URL_SEGMENT_MAP: Record<string, CategorySlug> = {
  teatr: "theatre",
  vystavka: "exhibitions",
  vystavki: "exhibitions",
  muzei: "exhibitions",
  muzey: "exhibitions",
  kino: "cinema",
  detyam: "kids",
  cirk: "kids",
  festival: "festivals",
  festivali: "festivals",
  "master-klass": "workshops",
  obrazovanie: "workshops",
  koncert: "concerts",
  kontsert: "concerts",
  shou: "concerts",
  standup: "concerts",
  sport: "sport",
};

export function guessCategoryFromUrlSegment(pathname: string): CategorySlug | null {
  const seg = pathname.split("/").filter(Boolean)[0]?.toLowerCase();
  return seg ? (URL_SEGMENT_MAP[seg] ?? null) : null;
}
