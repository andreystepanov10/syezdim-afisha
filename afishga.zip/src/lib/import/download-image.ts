import { saveUpload } from "@/lib/uploads";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

const EXT_BY_TYPE: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

/** Ширина, которой хватает и карточке, и странице события (там картинка ~1120px); постеры кино бывают по 3000px */
const MAX_WIDTH = 1200;

/** Уменьшает большую картинку и пережимает в JPEG. null — не нужно или sharp недоступен: тогда сохраняем как есть */
async function shrink(bytes: Buffer): Promise<{ bytes: Buffer; ext: string } | null> {
  try {
    const sharp = (await import("sharp")).default;
    const meta = await sharp(bytes).metadata();
    if (!meta.width || meta.width <= MAX_WIDTH || meta.format === "gif") return null;
    const out = await sharp(bytes).rotate().resize({ width: MAX_WIDTH, withoutEnlargement: true }).flatten({ background: "#ffffff" }).jpeg({ quality: 82, mozjpeg: true }).toBuffer();
    return { bytes: out, ext: "jpg" };
  } catch {
    return null;
  }
}

/** Скачивает постер с сайта-источника и сохраняет на нашем сервере — по решению админа копировать картинки как есть */
export async function downloadImage(url: string): Promise<string | null> {
  try {
    const res = await fetch(url, { headers: { "User-Agent": UA } });
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type")?.split(";")[0].trim() ?? "";
    const ext = EXT_BY_TYPE[contentType];
    if (!ext) return null;
    const bytes = Buffer.from(await res.arrayBuffer());
    const resized = await shrink(bytes);
    return await saveUpload(resized?.bytes ?? bytes, resized?.ext ?? ext);
  } catch {
    return null;
  }
}
