import { describe, expect, it } from "vitest";
import { extractVenueAddress, normalizeAddress, placeOf } from "./venues";

describe("extractVenueAddress", () => {
  it("берёт адрес со страницы площадки Афиши Города", () => {
    const html = `<div class="info-block"><ul><li><span class="icon icon-location-pin"></span>г. Воронеж, ул. Ленина, 43</li></ul></div>`;
    expect(extractVenueAddress(html)).toBe("г. Воронеж, ул. Ленина, 43");
  });

  it("без адреса — null", () => {
    expect(extractVenueAddress(`<div class="info-block"><ul><li>Телефон</li></ul></div>`)).toBeNull();
  });
});

describe("normalizeAddress", () => {
  it("расшифровывает сокращения, на которых спотыкается геокодер", () => {
    expect(normalizeAddress("г. Воронеж, просп. Революции, 56")).toBe("Воронеж, проспект Революции, 56");
    expect(normalizeAddress("г. Воронеж, ул. 20 лет Октября, 75а")).toBe("Воронеж, улица 20 лет Октября, 75а");
    expect(normalizeAddress("г. Старый Оскол, пл. Победы, д. 1")).toBe("Старый Оскол, площадь Победы, 1");
  });
});

describe("normalizeAddress — латиница", () => {
  it("не трогает латинские буквы в адресе", () => {
    expect(normalizeAddress("г. Воронеж, ул. Кольцовская, 35, ТЦ Galereya")).toBe("Воронеж, улица Кольцовская, 35, ТЦ Galereya");
  });
});

describe("placeOf", () => {
  it("муниципалитет вместо города превращает в название населённого пункта", () => {
    expect(placeOf({ lat: "0", lon: "0", address: { municipality: "городской округ Курск" } })).toBe("Курск");
    expect(placeOf({ lat: "0", lon: "0", address: { municipality: "городское поселение Хомутово" } })).toBe("Хомутово");
    expect(placeOf({ lat: "0", lon: "0", address: { town: "Старый Оскол" } })).toBe("Старый Оскол");
  });
});
