import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { parseAfishagorodaHtml, parseDateRange, parseSingleDate } from "./afishagoroda";

const fixture = readFileSync(path.join(__dirname, "__fixtures__/afishagoroda.fixture.html"), "utf-8");
const now = new Date("2026-09-22T12:00:00+03:00");

describe("parseSingleDate", () => {
  it("разбирает «23 сентября | 18:15» на будущую дату этого года", () => {
    const d = parseSingleDate("23 сентября |  18:15", now);
    expect(d?.toISOString()).toBe("2026-09-23T15:15:00.000Z");
  });

  it("если дата уже прошла в этом году — переносит на следующий", () => {
    const d = parseSingleDate("01 марта | 10:00", now);
    expect(d?.getUTCFullYear()).toBe(2027);
  });

  it("возвращает null для диапазона или нераспознанного текста", () => {
    expect(parseSingleDate("Разные даты", now)).toBeNull();
    expect(parseSingleDate("01 сентября", now)).toBeNull();
  });
});

describe("parseDateRange", () => {
  it("«11 октября –» + «06 декабря» — с 10:00 до 20:00 по МСК", () => {
    const r = parseDateRange("11 октября –", "06 декабря", now);
    expect(r?.startsAt.toISOString()).toBe("2026-10-11T07:00:00.000Z");
    expect(r?.endsAt.toISOString()).toBe("2026-12-06T17:00:00.000Z");
  });

  it("уже идущая выставка: начало в прошлом, конец в будущем — один год", () => {
    const r = parseDateRange("01 сентября –", "30 ноября", now);
    expect(r?.startsAt.getUTCFullYear()).toBe(2026);
    expect(r?.endsAt.getUTCFullYear()).toBe(2026);
  });

  it("период через Новый год", () => {
    const r = parseDateRange("01 декабря –", "15 января", now);
    expect(r?.startsAt.toISOString()).toBe("2026-12-01T07:00:00.000Z");
    expect(r?.endsAt.getUTCFullYear()).toBe(2027);
  });
});

describe("parseAfishagorodaHtml", () => {
  it("берёт разовые события и периоды, пропускает «Разные даты»", () => {
    const events = parseAfishagorodaHtml(fixture, "https://vrn.afishagoroda.ru", now);
    // в фикстуре 2 периода, 1 «Разные даты» и 3 с одной датой+временем (одна — в вёрстке .date--date-start)
    expect(events).toHaveLength(5);
    expect(events.filter((e) => e.endsAt)).toHaveLength(2);
  });

  it("период без категории раздела считается выставкой, с разделом — категорией раздела", () => {
    const ranges = parseAfishagorodaHtml(fixture, "https://vrn.afishagoroda.ru", now).filter((e) => e.endsAt);
    expect(ranges.every((e) => e.category !== "concerts")).toBe(true);
    const kids = parseAfishagorodaHtml(fixture, "https://vrn.afishagoroda.ru", now, "kids").filter((e) => e.endsAt);
    expect(kids.length).toBeGreaterThan(0);
  });

  it("извлекает название, площадку и абсолютную ссылку", () => {
    const [event] = parseAfishagorodaHtml(fixture, "https://vrn.afishagoroda.ru", now);
    expect(event.title).toBeTruthy();
    expect(event.venueName).toBeTruthy();
    expect(event.detailUrl.startsWith("https://vrn.afishagoroda.ru/events/")).toBe(true);
  });
});
