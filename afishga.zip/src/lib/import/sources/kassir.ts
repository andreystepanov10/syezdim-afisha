import * as cheerio from "cheerio";
import type { CategorySlug } from "@/lib/categories";
import type { CitySlug } from "@/lib/cities";
import { parseDateTimeLocalMsk } from "@/lib/time";
import { guessCategoryFromText, guessCategoryFromUrlSegment } from "../category-guess";
import { fetchSource } from "../http";
import type { ImportAdapter, ScrapedEvent } from "../types";

const SUBDOMAIN: Record<CitySlug, string> = {
  voronezh: "vrn",
  belgorod: "belgorod",
  kursk: "kursk",
  lipetsk: "lipetsk",
  tambov: "tambov",
  orel: "orel",
};

/**
 * Разделы kassir.ru с той же вёрсткой карточек, что и на главной. category — если тип события не понятен ни по
 * ссылке, ни по названию. Кино здесь нет: у фильмов сеансы, а не одна дата, — карточки устроены иначе.
 */
const SECTIONS: { path: string; category: CategorySlug }[] = [
  { path: "bilety-v-teatr", category: "theatre" },
  { path: "detskaya-afisha", category: "kids" },
  { path: "bilety-v-muzei", category: "exhibitions" },
  { path: "bilety-na-sportivnye-meropriyatiya", category: "sport" },
  { path: "obrazovanie-i-kursy", category: "workshops" },
  { path: "bilety-na-shou", category: "concerts" },
];

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

function parsePrice(text: string | undefined): number | null {
  if (!text) return null;
  const m = text.replace(/\s+/g, "").match(/\d+/);
  return m ? Number(m[0]) : null;
}

/** Извлекает данные события из карточки листинга kassir.ru. Экспортируется отдельно для юнит-тестов на фикстуре. */
export function parseKassirHtml(html: string, siteUrl: string, sectionCategory?: CategorySlug): ScrapedEvent[] {
  const $ = cheerio.load(html);
  const out: ScrapedEvent[] = [];

  $("article.compilation-tile").each((_, el) => {
    const card = $(el);
    const link = card.find("a[href]").first();
    const href = link.attr("href");
    const title = card.find(".compilation-tile__title").first().text().trim();
    const iso = card.find("time.compilation-tile__date").attr("datetime");
    const venueName = card.find(".compilation-tile__venue").first().text().trim();
    if (!href || !title || !iso || !venueName) return;

    // datetime у kassir — московское время с ошибочной пометкой «+00:00» (на карточке «10 октября 18:00»,
    // в атрибуте 18:00+00:00): берём часы как МСК, иначе все события съезжали на 3 часа вперёд
    const startsAt = parseDateTimeLocalMsk(iso);
    if (!startsAt) return;

    const priceText = card.find('[class*="__price"]').first().text();
    const absoluteUrl = new URL(href, siteUrl);
    const externalId = href.split("#").pop() || href;
    const imgSrc = card.find(".compilation-tile__img-block img").first().attr("src");

    out.push({
      externalId,
      title,
      startsAt,
      category: guessCategoryFromUrlSegment(absoluteUrl.pathname) ?? guessCategoryFromText(title, sectionCategory),
      priceFrom: parsePrice(priceText),
      imageUrl: imgSrc ? new URL(imgSrc, siteUrl).toString() : null,
      venueName,
      detailUrl: absoluteUrl.toString(),
    });
  });

  return out;
}

export function createKassirAdapter(): ImportAdapter {
  return {
    key: "kassir",
    // Партнёрская программа KASSIR разрешает писать бренд только так — «KASSIR.RU»
    name: "KASSIR.RU",
    siteUrl: "https://kassir.ru/",
    async fetchEvents(city: CitySlug): Promise<ScrapedEvent[]> {
      const siteUrl = `https://${SUBDOMAIN[city]}.kassir.ru/`;
      const res = await fetchSource(siteUrl, { headers: { "User-Agent": UA } });
      if (!res.ok) throw new Error(`kassir.ru ответил ${res.status}`);
      const byId = new Map(parseKassirHtml(await res.text(), siteUrl).map((e) => [e.externalId, e]));

      // Главная — только ~30 популярных событий, почти одни концерты; остальные категории — в разделах
      for (const section of SECTIONS) {
        try {
          const r = await fetchSource(siteUrl + section.path, { headers: { "User-Agent": UA } });
          // Раздела нет в этом городе — kassir перенаправляет на главную: категорию раздела ей не приписываем
          if (!r.ok || new URL(r.url).pathname !== `/${section.path}`) continue;
          for (const e of parseKassirHtml(await r.text(), siteUrl, section.category)) if (!byId.has(e.externalId)) byId.set(e.externalId, e);
        } catch {
          // Один недоступный раздел не должен срывать импорт остальных
        }
      }
      return [...byId.values()];
    },
    /** У KASSIR.RU отдельная подборка под Пушкинскую карту — та же вёрстка, что и на главной */
    async fetchPushkinCardIds(city: CitySlug): Promise<Set<string>> {
      const siteUrl = `https://${SUBDOMAIN[city]}.kassir.ru/`;
      const res = await fetchSource(`${siteUrl}selection/pushkinskaya-karta`, { headers: { "User-Agent": UA } });
      if (!res.ok) return new Set();
      return new Set(parseKassirHtml(await res.text(), siteUrl).map((e) => e.externalId));
    },
  };
}
