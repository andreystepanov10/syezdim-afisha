import { describe, expect, it } from "vitest";
import { parseAfishaCinemaHtml } from "./afisha-ru-cinema";

const ld = {
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "WebSite", name: "Афиша" },
    {
      "@type": "Movie",
      name: "Битва моторов",
      url: "https://www.afisha.ru/movie/bitva-motorov-306960/",
      description: "История первого российского серийного автомобиля",
      image: { url: "https://s1.afisha.ru/poster.jpg" },
      startDate: "2026-10-11T00:00:00+03:00",
      endDate: "2026-10-14T00:00:00+03:00",
      offers: { price: 200, url: "https://www.afisha.ru/voronezh/schedule_cinema_product/bitva-motorov-306960/" },
    },
  ],
};
const html = `<html><head><script type="application/ld+json">${JSON.stringify(ld)}</script></head></html>`;

describe("parseAfishaCinemaHtml", () => {
  it("фильм в прокате — событие-период на условной площадке города со ссылкой на расписание", () => {
    const [movie, ...rest] = parseAfishaCinemaHtml(html, "voronezh");
    expect(rest).toHaveLength(0);
    expect(movie).toMatchObject({
      externalId: "voronezh-bitva-motorov-306960",
      title: "Битва моторов",
      category: "cinema",
      priceFrom: 200,
      venueName: "Кинотеатры Воронежа",
      detailUrl: "https://www.afisha.ru/voronezh/schedule_cinema_product/bitva-motorov-306960/",
      description: "История первого российского серийного автомобиля",
    });
    expect(movie.startsAt.toISOString()).toBe("2026-10-10T21:00:00.000Z");
    // До конца последнего дня сеансов (14 октября, 23:59 МСК)
    expect(movie.endsAt?.toISOString()).toBe("2026-10-14T20:59:00.000Z");
    expect(movie.venueGeo).toMatchObject({ lat: 51.6606, lon: 39.2003 });
  });
});

describe("parseAfishaCinemaTiles (мобильная вёрстка без JSON-LD)", () => {
  const tile = {
    Tile: {
      Poster: { Url: "https://s1.afisha.ru/poster.jpg" },
      ScheduleInfo: { MinScheduleDate: "2026-10-15T00:00:00", MaxScheduleDate: "2026-10-21T00:00:00", TimeZoneOffset: "+03:00", MinPrice: 200.0, Url: "/voronezh/schedule_cinema_product/bitva-motorov-306960/#rcmrclid=x" },
      Name: "Битва моторов",
      Url: "/movie/bitva-motorov-306960/#rcmrclid=x",
      Verdict: "История первого {серийного} автомобиля",
      Type: "Movie",
    },
    Type: "CreationTile",
  };
  const page = `<script>window.__DATA__ = {"Items":[${JSON.stringify(tile)},${JSON.stringify(tile)},{"Tile":{"Type":"Performance","Name":"Спектакль"}}]};</script>`;

  it("берёт фильмы с тем же идентификатором, что и JSON-LD, без дублей", () => {
    const films = parseAfishaCinemaHtml(page, "voronezh");
    expect(films).toHaveLength(1);
    expect(films[0]).toMatchObject({
      externalId: "voronezh-bitva-motorov-306960",
      title: "Битва моторов",
      priceFrom: 200,
      detailUrl: "https://www.afisha.ru/voronezh/schedule_cinema_product/bitva-motorov-306960/",
      description: "История первого {серийного} автомобиля",
      imageUrl: "https://s1.afisha.ru/poster.jpg",
    });
    expect(films[0].startsAt.toISOString()).toBe("2026-10-14T21:00:00.000Z");
    expect(films[0].endsAt?.toISOString()).toBe("2026-10-21T20:59:00.000Z");
  });
});
