import { readFileSync } from "node:fs";
import path from "node:path";
import * as cheerio from "cheerio";
import { describe, expect, it } from "vitest";
import { parseAfishaRuHtml } from "./afisha-ru";

const fixture = readFileSync(path.join(__dirname, "__fixtures__/afisha-ru.fixture.html"), "utf-8");

describe("parseAfishaRuHtml", () => {
  it("извлекает события из JSON-LD разметки", () => {
    const events = parseAfishaRuHtml(fixture);
    expect(events.length).toBeGreaterThan(0);

    const first = events[0];
    expect(first.title).toBeTruthy();
    expect(first.venueName).toBeTruthy();
    expect(first.startsAt).toBeInstanceOf(Date);
    expect(Number.isNaN(first.startsAt.getTime())).toBe(false);
    expect(first.detailUrl.startsWith("https://www.afisha.ru/")).toBe(true);
  });

  it("сопоставляет schema.org тип с нашей категорией", () => {
    const events = parseAfishaRuHtml(fixture);
    const theatre = events.find((e) => e.title.includes("Ночь ее откровений"));
    expect(theatre?.category).toBe("theatre");
  });

  it("берёт дату из startDate, а не из текста", () => {
    const events = parseAfishaRuHtml(fixture);
    const theatre = events.find((e) => e.title.includes("Ночь ее откровений"));
    expect(theatre?.startsAt.toISOString()).toBe("2026-10-23T16:00:00.000Z");
  });

  it("не включает фильмы (Movie) — тип не заканчивается на Event", () => {
    const $ = cheerio.load(fixture);
    const graph = JSON.parse($('script[type="application/ld+json"]').first().html()!)["@graph"] as { "@type"?: string }[];
    const movieCount = graph.filter((n) => n["@type"] === "Movie").length;
    expect(movieCount).toBeGreaterThan(0); // фикстура точно содержит фильмы — иначе тест ничего не проверяет

    const expectedEvents = graph.filter((n) => typeof n["@type"] === "string" && n["@type"].endsWith("Event")).length;
    const events = parseAfishaRuHtml(fixture);
    expect(events).toHaveLength(expectedEvents);
  });
});
