import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { parseKassirHtml } from "./kassir";

const fixture = readFileSync(path.join(__dirname, "__fixtures__/kassir.fixture.html"), "utf-8");

describe("parseKassirHtml", () => {
  it("извлекает название, дату, площадку, цену и абсолютную ссылку", () => {
    const events = parseKassirHtml(fixture, "https://vrn.kassir.ru/");
    expect(events.length).toBeGreaterThan(0);

    const first = events[0];
    expect(first.title).toBeTruthy();
    expect(first.venueName).toBeTruthy();
    expect(first.startsAt).toBeInstanceOf(Date);
    expect(Number.isNaN(first.startsAt.getTime())).toBe(false);
    expect(first.detailUrl.startsWith("https://vrn.kassir.ru/")).toBe(true);
    expect(first.externalId).toBeTruthy();
  });

  it("берёт дату из атрибута datetime как московское время (пометка +00:00 у kassir ошибочная)", () => {
    const events = parseKassirHtml(fixture, "https://vrn.kassir.ru/");
    const kayMetov = events.find((e) => e.title.includes("Кай Метов"));
    // На карточке «10 октября 18:00» — это 18:00 МСК = 15:00 UTC
    expect(kayMetov?.startsAt.toISOString()).toBe("2026-10-10T15:00:00.000Z");
  });

  it("распознаёт цену «от N ₽»", () => {
    const events = parseKassirHtml(fixture, "https://vrn.kassir.ru/");
    const withPrice = events.find((e) => e.priceFrom !== null);
    expect(withPrice?.priceFrom).toBeGreaterThan(0);
  });
});
