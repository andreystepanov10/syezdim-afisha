import * as cheerio from "cheerio";
import type { CategorySlug } from "@/lib/categories";
import type { CitySlug } from "@/lib/cities";
import { DAY_MS, MSK_OFFSET_MS } from "@/lib/time";
import { guessCategoryFromText } from "../category-guess";
import { fetchSource } from "../http";
import type { ImportAdapter, ScrapedEvent } from "../types";

const SUBDOMAIN: Record<CitySlug, string> = {
  voronezh: "vrn",
  belgorod: "bel",
  kursk: "kursk",
  lipetsk: "lip",
  tambov: "tambov",
  orel: "orel",
};

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";
const PAGES_TO_FETCH = 2;

const MONTHS: Record<string, number> = {
  января: 1,
  февраля: 2,
  марта: 3,
  апреля: 4,
  мая: 5,
  июня: 6,
  июля: 7,
  августа: 8,
  сентября: 9,
  октября: 10,
  ноября: 11,
  декабря: 12,
};

function parsePrice(text: string | undefined): number | null {
  if (!text) return null;
  const m = text.replace(/\s+/g, "").match(/\d+/);
  return m ? Number(m[0]) : null;
}

/** День и месяц без года → момент по МСК; если он заметно в прошлом — это следующий год */
function resolveDay(day: number, month: number, hour: number, minute: number, now: Date): Date {
  const nowMsk = new Date(now.getTime() + MSK_OFFSET_MS);
  let year = nowMsk.getUTCFullYear();
  let candidate = Date.UTC(year, month - 1, day, hour, minute) - MSK_OFFSET_MS;
  if (candidate < now.getTime() - 3 * DAY_MS) {
    year += 1;
    candidate = Date.UTC(year, month - 1, day, hour, minute) - MSK_OFFSET_MS;
  }
  return new Date(candidate);
}

const normalize = (text: string) => text.replace(/ /g, " ").replace(/\s+/g, " ").trim();

/** «23 сентября | 18:15» → момент начала. Без времени («01 сентября») и «Разные даты» — null */
export function parseSingleDate(text: string, now: Date): Date | null {
  const m = /^(\d{1,2})\s+([а-яё]+)\s*\|\s*(\d{1,2}):(\d{2})$/i.exec(normalize(text));
  if (!m) return null;
  const month = MONTHS[m[2].toLowerCase()];
  if (!month) return null;
  return resolveDay(Number(m[1]), month, Number(m[3]), Number(m[4]), now);
}

/**
 * Период «11 октября –» + «06 декабря» (выставки, экспозиции) → начало и конец. Время на источнике не указано —
 * ставим часы работы музея по умолчанию (10:00–20:00 МСК), в афише период показывается датами.
 */
export function parseDateRange(startText: string, endText: string, now: Date): { startsAt: Date; endsAt: Date } | null {
  const s = /^(\d{1,2})\s+([а-яё]+)\s*[–—-]?$/i.exec(normalize(startText));
  const e = /^(\d{1,2})\s+([а-яё]+)$/i.exec(normalize(endText));
  if (!s || !e) return null;
  const startMonth = MONTHS[s[2].toLowerCase()];
  const endMonth = MONTHS[e[2].toLowerCase()];
  if (!startMonth || !endMonth) return null;

  // Год определяем по концу (он не может быть в прошлом), начало — в том же году или в предыдущем
  const endsAt = resolveDay(Number(e[1]), endMonth, 20, 0, now);
  const endYear = new Date(endsAt.getTime() + MSK_OFFSET_MS).getUTCFullYear();
  let startsAt = new Date(Date.UTC(endYear, startMonth - 1, Number(s[1]), 10, 0) - MSK_OFFSET_MS);
  if (startsAt > endsAt) startsAt = new Date(Date.UTC(endYear - 1, startMonth - 1, Number(s[1]), 10, 0) - MSK_OFFSET_MS);
  return { startsAt, endsAt };
}

/** Даты карточки: одна дата со временем или период. «Разные даты» (много сеансов) — null, такое заводят вручную */
function parseCardDates(texts: string[], now: Date): { startsAt: Date; endsAt: Date | null } | null {
  if (texts.length === 1) {
    const startsAt = parseSingleDate(texts[0], now);
    return startsAt ? { startsAt, endsAt: null } : null;
  }
  if (texts.length === 2) return parseDateRange(texts[0], texts[1], now);
  return null;
}

/** Разбор одной страницы листинга. Экспортируется отдельно для юнит-тестов на фикстуре. */
export function parseAfishagorodaHtml(html: string, siteUrl: string, now = new Date(), sectionCategory?: CategorySlug): ScrapedEvent[] {
  const $ = cheerio.load(html);
  const out: ScrapedEvent[] = [];

  $(".events-elem").each((_, el) => {
    const card = $(el);
    const titleLink = card.find("a.title").first();
    const href = titleLink.attr("href");
    const title = titleLink.text().trim();
    if (!href || !title) return;

    // Дата бывает в двух вариантах вёрстки: .date--date-start (одна дата) и .date--wrap (одна дата или период)
    const dateTexts = card
      .find(".date--date-start, .date--wrap")
      .map((_, d) => $(d).text())
      .get();
    const dates = parseCardDates(dateTexts, now);
    if (!dates) return;

    const venueLink = card.find(".place a").first();
    const venueName = venueLink.text().trim();
    if (!venueName) return;
    const venueHref = venueLink.attr("href");

    const priceText = card.find(".events-elem_content .price").first().text();
    const imgSrc = card.find("a.img-wrap img").first().attr("src");

    out.push({
      externalId: href,
      title,
      startsAt: dates.startsAt,
      endsAt: dates.endsAt,
      category: guessCategoryFromText(title, sectionCategory ?? (dates.endsAt ? "exhibitions" : "concerts")),
      priceFrom: parsePrice(priceText),
      imageUrl: imgSrc ? new URL(imgSrc, siteUrl).toString() : null,
      venueName,
      venueUrl: venueHref ? new URL(venueHref, siteUrl).toString() : undefined,
      cityReliable: true,
      detailUrl: new URL(href, siteUrl).toString(),
    });
  });

  return out;
}

/** Разделы по категориям: в общем листинге всё вперемешку (квесты, экскурсии), а здесь тип события известен */
const SECTIONS: { path: string; category: CategorySlug }[] = [
  { path: "koncert", category: "concerts" },
  { path: "show", category: "concerts" },
  { path: "stand-up", category: "concerts" },
  { path: "teatr", category: "theatre" },
  { path: "detiam", category: "kids" },
  { path: "circuses", category: "kids" },
  { path: "muzei", category: "exhibitions" },
  { path: "education", category: "workshops" },
  { path: "sport", category: "sport" },
];

export function createAfishagorodaAdapter(): ImportAdapter {
  return {
    key: "afishagoroda",
    name: "Афиша Города",
    siteUrl: "https://afishagoroda.ru/",
    async fetchEvents(city: CitySlug): Promise<ScrapedEvent[]> {
      const siteUrl = `https://${SUBDOMAIN[city]}.afishagoroda.ru`;
      const byId = new Map<string, ScrapedEvent>();
      for (const section of SECTIONS) {
        for (let page = 1; page <= PAGES_TO_FETCH; page++) {
          try {
            const path = `/events/${section.path}`;
            const res = await fetchSource(`${siteUrl}${path}?page=${page}`, { headers: { "User-Agent": UA } });
            if (!res.ok || new URL(res.url).pathname !== path) break;
            const events = parseAfishagorodaHtml(await res.text(), siteUrl, new Date(), section.category);
            if (events.length === 0) break;
            for (const e of events) if (!byId.has(e.externalId)) byId.set(e.externalId, e);
          } catch {
            break; // недоступная страница раздела не срывает импорт остальных
          }
        }
      }
      return [...byId.values()];
    },
  };
}
