import * as cheerio from "cheerio";
import type { CategorySlug } from "@/lib/categories";
import type { CitySlug } from "@/lib/cities";
import { guessCategoryFromText } from "../category-guess";
import { fetchSource } from "../http";
import type { ImportAdapter, ScrapedEvent } from "../types";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

const TYPE_CATEGORY: Record<string, CategorySlug> = {
  TheaterEvent: "theatre",
  MusicEvent: "concerts",
  ExhibitionEvent: "exhibitions",
  ComedyEvent: "concerts",
  Festival: "festivals",
  ChildrensEvent: "kids",
};

type LdEventNode = {
  "@type"?: string;
  name?: string;
  url?: string;
  startDate?: string;
  description?: string;
  image?: { url?: string } | string;
  location?: { name?: string };
  offers?: { price?: number } | { price?: number }[];
};

function extractGraphNodes(html: string): LdEventNode[] {
  const $ = cheerio.load(html);
  const nodes: LdEventNode[] = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const data = JSON.parse($(el).html() ?? "");
      const graph = Array.isArray(data["@graph"]) ? data["@graph"] : [data];
      for (const node of graph) nodes.push(node);
    } catch {
      // не JSON или битый — пропускаем
    }
  });
  return nodes;
}

function imageUrl(image: LdEventNode["image"]): string | null {
  if (!image) return null;
  return typeof image === "string" ? image : (image.url ?? null);
}

/** Афиша.ру отдаёт список событий как schema.org Event-разметку прямо в HTML — надёжнее, чем парсить вёрстку */
export function parseAfishaRuHtml(html: string): ScrapedEvent[] {
  const out: ScrapedEvent[] = [];
  for (const node of extractGraphNodes(html)) {
    const type = node["@type"];
    if (typeof type !== "string" || !type.endsWith("Event")) continue;
    const { name: title, url, startDate, location } = node;
    const venueName = location?.name?.trim();
    if (!title || !url || !startDate || !venueName) continue;

    const startsAt = new Date(startDate);
    if (Number.isNaN(startsAt.getTime())) continue;

    const offers = Array.isArray(node.offers) ? node.offers[0] : node.offers;
    const priceFrom = typeof offers?.price === "number" ? offers.price : null;

    out.push({
      externalId: url,
      title,
      startsAt,
      category: TYPE_CATEGORY[type] ?? guessCategoryFromText(title),
      priceFrom,
      imageUrl: imageUrl(node.image),
      venueName,
      detailUrl: url,
    });
  }
  return out;
}

/** Описание со страницы события — тоже берём из JSON-LD, а не из вёрстки */
export function extractAfishaRuDescription(html: string): string | null {
  for (const node of extractGraphNodes(html)) {
    if (typeof node["@type"] === "string" && node["@type"].endsWith("Event") && node.description) {
      return node.description.trim();
    }
  }
  return null;
}

export function createAfishaRuAdapter(): ImportAdapter {
  return {
    key: "afisha-ru",
    name: "Афиша.ру",
    siteUrl: "https://www.afisha.ru/",
    async fetchEvents(city: CitySlug): Promise<ScrapedEvent[]> {
      const url = `https://www.afisha.ru/${city}/events/`;
      const res = await fetchSource(url, { headers: { "User-Agent": UA } });
      if (!res.ok) throw new Error(`afisha.ru ответил ${res.status}`);
      return parseAfishaRuHtml(await res.text());
    },
    /** У Афиши.ру отдельная подборка под Пушкинскую карту — та же JSON-LD разметка, что и на общей странице */
    async fetchPushkinCardIds(city: CitySlug): Promise<Set<string>> {
      const res = await fetchSource(`https://www.afisha.ru/${city}/events/pushkincard/`, { headers: { "User-Agent": UA } });
      if (!res.ok) return new Set();
      return new Set(parseAfishaRuHtml(await res.text()).map((e) => e.externalId));
    },
  };
}
