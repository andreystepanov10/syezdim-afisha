import * as cheerio from "cheerio";
import { CITIES, cityGenitive, type CitySlug } from "@/lib/cities";
import { DAY_MS } from "@/lib/time";
import { fetchSource } from "../http";
import type { ImportAdapter, ScrapedEvent } from "../types";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

type LdMovie = {
  "@type"?: string;
  name?: string;
  url?: string;
  description?: string;
  image?: { url?: string } | string;
  startDate?: string;
  endDate?: string;
  offers?: { price?: number | string; url?: string };
};

/**
 * Фильмы в прокате города из JSON-LD страницы «Расписание кинотеатров» Афиши.ру.
 *
 * Фильм идёт во многих кинотеатрах и десятками сеансов в день — заводить каждый сеанс событием бессмысленно.
 * Поэтому один фильм в городе = одно событие «в прокате с … по …» на условной площадке «Кинотеатры Воронежа»,
 * а кнопка билетов ведёт на расписание всех кинотеатров города у Афиши. Ежедневный импорт продлевает дату
 * окончания, пока фильм остаётся в прокате (см. run.ts).
 */
export function parseAfishaCinemaHtml(html: string, city: CitySlug): ScrapedEvent[] {
  const $ = cheerio.load(html);
  const c = CITIES.find((x) => x.slug === city)!;
  const out: ScrapedEvent[] = [];

  $('script[type="application/ld+json"]').each((_, el) => {
    let data: { "@graph"?: LdMovie[] };
    try {
      data = JSON.parse($(el).html() ?? "");
    } catch {
      return;
    }
    for (const m of data["@graph"] ?? []) {
      if (m["@type"] !== "Movie" || !m.name || !m.url || !m.startDate || !m.endDate) continue;
      const startsAt = new Date(m.startDate);
      // endDate — день последних известных сеансов (полночь): событие идёт до конца этого дня
      const endsAt = new Date(new Date(m.endDate).getTime() + DAY_MS - 60_000);
      if (Number.isNaN(startsAt.getTime()) || Number.isNaN(endsAt.getTime())) continue;
      // Страница фильма у Афиши общая для всех городов — город в идентификаторе, иначе фильм в Белгороде
      // посчитался бы уже загруженным вместе с Воронежем
      const externalId = `${city}-${new URL(m.url).pathname.split("/").filter(Boolean).pop() ?? m.url}`;
      const image = typeof m.image === "string" ? m.image : m.image?.url;
      const price = Number(m.offers?.price);

      out.push({
        externalId,
        title: m.name,
        startsAt,
        endsAt,
        category: "cinema",
        priceFrom: Number.isFinite(price) && price > 0 ? price : null,
        imageUrl: image ?? null,
        venueName: `Кинотеатры ${cityGenitive(city)}`,
        venueGeo: { lat: c.lat, lon: c.lon, address: "Все кинотеатры города — расписание по кнопке «Билеты»" },
        detailUrl: m.offers?.url ?? m.url,
        description: m.description,
      });
    }
  });

  // С октября 2026 Афиша отдаёт серверу мобильную вёрстку без JSON-LD — фильмы там во встроенном JSON плиток
  return out.length > 0 ? out : parseAfishaCinemaTiles(html, city);
}

type Tile = {
  Type?: string;
  Name?: string;
  Url?: string;
  Verdict?: string | null;
  Poster?: { Url?: string } | null;
  ScheduleInfo?: { MinScheduleDate?: string; MaxScheduleDate?: string; TimeZoneOffset?: string; MinPrice?: number | null; Url?: string } | null;
};

/** Все объекты {"Tile":{…}} из встроенного в страницу JSON — вырезаем по балансу скобок с учётом строк */
export function extractTiles(html: string): Tile[] {
  const tiles: Tile[] = [];
  const marker = '{"Tile":';
  for (let start = html.indexOf(marker); start !== -1; start = html.indexOf(marker, start + 1)) {
    let depth = 0;
    let inString = false;
    for (let i = start; i < html.length; i++) {
      const ch = html[i];
      if (inString) {
        if (ch === "\\") i++;
        else if (ch === '"') inString = false;
      } else if (ch === '"') inString = true;
      else if (ch === "{") depth++;
      else if (ch === "}" && --depth === 0) {
        try {
          const obj = JSON.parse(html.slice(start, i + 1)) as { Tile?: Tile };
          if (obj.Tile) tiles.push(obj.Tile);
        } catch {
          // не JSON — пропускаем
        }
        break;
      }
    }
  }
  return tiles;
}

/** Фильмы из плиток мобильной вёрстки: те же поля, что в JSON-LD, плюс даты сеансов и цена «от» */
export function parseAfishaCinemaTiles(html: string, city: CitySlug): ScrapedEvent[] {
  const c = CITIES.find((x) => x.slug === city)!;
  const seen = new Set<string>();
  const out: ScrapedEvent[] = [];
  for (const t of extractTiles(html)) {
    const s = t.ScheduleInfo;
    if (t.Type !== "Movie" || !t.Name || !t.Url || !s?.MinScheduleDate || !s.MaxScheduleDate) continue;
    const tz = s.TimeZoneOffset ?? "+03:00";
    const startsAt = new Date(`${s.MinScheduleDate}${tz}`);
    const endsAt = new Date(new Date(`${s.MaxScheduleDate}${tz}`).getTime() + DAY_MS - 60_000);
    if (Number.isNaN(startsAt.getTime()) || Number.isNaN(endsAt.getTime())) continue;
    const movieUrl = new URL(t.Url, "https://www.afisha.ru");
    // Тот же идентификатор, что и в JSON-LD-разборе, — уже загруженные фильмы продлеваются, а не дублируются
    const externalId = `${city}-${movieUrl.pathname.split("/").filter(Boolean).pop()}`;
    if (seen.has(externalId)) continue;
    seen.add(externalId);
    const scheduleUrl = s.Url ? new URL(s.Url, "https://www.afisha.ru") : null;
    if (scheduleUrl) scheduleUrl.hash = "";
    movieUrl.hash = "";
    out.push({
      externalId,
      title: t.Name,
      startsAt,
      endsAt,
      category: "cinema",
      priceFrom: s.MinPrice && s.MinPrice > 0 ? Math.round(s.MinPrice) : null,
      imageUrl: t.Poster?.Url ?? null,
      venueName: `Кинотеатры ${cityGenitive(city)}`,
      venueGeo: { lat: c.lat, lon: c.lon, address: "Все кинотеатры города — расписание по кнопке «Билеты»" },
      detailUrl: (scheduleUrl ?? movieUrl).toString(),
      description: t.Verdict ?? undefined,
    });
  }
  return out;
}

export function createAfishaRuCinemaAdapter(): ImportAdapter {
  return {
    key: "afisha-kino",
    name: "Афиша-Кино",
    siteUrl: "https://www.afisha.ru/",
    async fetchEvents(city: CitySlug): Promise<ScrapedEvent[]> {
      const res = await fetchSource(`https://www.afisha.ru/${city}/schedule_cinema/`, { headers: { "User-Agent": UA } });
      if (!res.ok) throw new Error(`afisha.ru (кино) ответил ${res.status}`);
      return parseAfishaCinemaHtml(await res.text(), city);
    },
  };
}
