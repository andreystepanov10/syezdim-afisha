import { beforeAll, describe, expect, it, vi } from "vitest";
import { createVenue, getEventForAdmin, listEventsForAdmin, listPartners, updateEventMedia, type Ctx as AdminCtx } from "@/data/admin";
import { createDemoDb, type Db } from "@/db/client";
import type { ImportAdapter, ScrapedEvent } from "./types";
import { runImport } from "./run";

// Картинку не качаем из сети: в остальных тестах imageUrl = null, и сюда они не доходят
vi.mock("./download-image", () => ({ downloadImage: async () => "/uploads/test.jpg" }));

let db: Db;
let ctx: AdminCtx;

function fakeAdapter(key: string, events: ScrapedEvent[]): ImportAdapter {
  return { key, name: `Источник ${key}`, siteUrl: `https://${key}.example`, fetchEvents: async () => events };
}

const sample: ScrapedEvent = {
  externalId: "abc-1",
  title: "Тестовый концерт",
  startsAt: new Date("2027-05-01T18:00:00+03:00"),
  category: "concerts",
  priceFrom: 500,
  imageUrl: null,
  venueName: "Известный зал",
  detailUrl: "https://source.example/event/abc-1",
};

beforeAll(async () => {
  db = await createDemoDb();
  ctx = { db };
  await createVenue({ slug: "izvestnyy-zal", name: "Известный зал", address: "", lat: 51.6, lon: 39.2, city: "voronezh" }, ctx);
});

describe("runImport", () => {
  it("создаёт черновик события, когда площадка найдена по имени", async () => {
    const reports = await runImport("voronezh", { ...ctx, adapters: [fakeAdapter("fake1", [sample])] });
    expect(reports[0]).toMatchObject({ source: "Источник fake1", imported: 1, skippedDuplicate: 0, skippedNoVenue: [] });

    const events = await listEventsForAdmin(ctx);
    const created = events.find((e) => e.title === "Тестовый концерт");
    expect(created).toBeTruthy();
    expect(created?.status).toBe("draft");

    const partners = await listPartners(ctx);
    expect(partners.some((p) => p.slug === "fake1")).toBe(true);
  });

  it("с publish сразу публикует событие с картинкой и ссылкой на билеты, без картинки — оставляет черновиком", async () => {
    const ready: ScrapedEvent = { ...sample, externalId: "pub-1", title: "Готовое событие", imageUrl: "https://source.example/a.jpg" };
    const noImage: ScrapedEvent = { ...sample, externalId: "pub-2", title: "Событие без картинки" };
    await runImport("voronezh", { ...ctx, publish: true, adapters: [fakeAdapter("fake-pub", [ready, noImage])] });

    const events = await listEventsForAdmin(ctx);
    expect(events.find((e) => e.title === "Готовое событие")?.status).toBe("published");
    expect(events.find((e) => e.title === "Событие без картинки")?.status).toBe("draft");
  });

  it("при повторном запуске дозаполняет пустые картинку/описание, а не создаёт дубликат", async () => {
    const adapter = fakeAdapter("fake1", [sample]);
    const reports = await runImport("voronezh", { ...ctx, adapters: [adapter] });
    expect(reports[0]).toMatchObject({ imported: 0, updated: 1, skippedDuplicate: 0 });
  });

  it("не трогает событие, у которого картинка/описание уже заполнены", async () => {
    const events = await listEventsForAdmin(ctx);
    const created = events.find((e) => e.title === "Тестовый концерт")!;
    await updateEventMedia(created.id, { image: "/uploads/already-there.png", description: "Уже есть описание" }, ctx);

    const adapter = fakeAdapter("fake1", [sample]);
    const reports = await runImport("voronezh", { ...ctx, adapters: [adapter] });
    expect(reports[0]).toMatchObject({ imported: 0, updated: 0, skippedDuplicate: 1 });
  });

  it("находит площадку при другом написании названия", async () => {
    const item: ScrapedEvent = { ...sample, externalId: "spelling-1", title: "Событие с кавычками", venueName: "«Известный зал»" };
    const reports = await runImport("voronezh", { ...ctx, adapters: [fakeAdapter("fake-spelling", [item])] });
    expect(reports[0]).toMatchObject({ imported: 1, skippedNoVenue: [] });
  });

  it("с geocode заводит новую площадку и спрашивает геокодер один раз на название", async () => {
    const calls: string[] = [];
    const geocode = async (name: string) => {
      calls.push(name);
      return { name, address: "ул. Новая, 1", lat: 51.67, lon: 39.21, locality: null };
    };
    const a: ScrapedEvent = { ...sample, externalId: "geo-1", title: "Первое в новом клубе", venueName: "Новый клуб" };
    const b: ScrapedEvent = { ...sample, externalId: "geo-2", title: "Второе в новом клубе", venueName: "Новый клуб" };
    const reports = await runImport("voronezh", { ...ctx, geocode, adapters: [fakeAdapter("fake-geo", [a, b])] });
    expect(reports[0]).toMatchObject({ imported: 2, skippedNoVenue: [] });
    expect(calls).toEqual(["Новый клуб"]);
  });

  it("площадку, которую геокодер не нашёл, пропускает", async () => {
    const item: ScrapedEvent = { ...sample, externalId: "geo-3", title: "Где-то", venueName: "Несуществующее место" };
    const reports = await runImport("voronezh", { ...ctx, geocode: async () => null, adapters: [fakeAdapter("fake-geo2", [item])] });
    expect(reports[0]).toMatchObject({ imported: 0, skippedNoVenue: ["Несуществующее место"] });
  });

  it("пропускает событие с неизвестной площадкой и называет её в отчёте", async () => {
    const unknown: ScrapedEvent = { ...sample, externalId: "abc-2", title: "Другое событие", venueName: "Совсем незнакомый клуб" };
    const reports = await runImport("voronezh", { ...ctx, adapters: [fakeAdapter("fake2", [unknown])] });
    expect(reports[0]).toMatchObject({ imported: 0, skippedNoVenue: ["Совсем незнакомый клуб"] });
  });

  it("помечает событие «Пушкинская карта», если оно есть в отдельной подборке источника", async () => {
    const item: ScrapedEvent = { ...sample, externalId: "pushkin-1", title: "Событие по Пушкинской карте" };
    const adapter: ImportAdapter = {
      ...fakeAdapter("fake-pushkin", [item]),
      fetchPushkinCardIds: async () => new Set(["pushkin-1"]),
    };
    await runImport("voronezh", { ...ctx, adapters: [adapter] });

    const events = await listEventsForAdmin(ctx);
    const created = events.find((e) => e.title === "Событие по Пушкинской карте")!;
    expect((await getEventForAdmin(created.id, ctx))?.pushkinCard).toBe(true);
  });

  it("не помечает событие, которого нет в подборке «Пушкинская карта»", async () => {
    const item: ScrapedEvent = { ...sample, externalId: "not-pushkin-1", title: "Обычное событие без карты" };
    const adapter: ImportAdapter = {
      ...fakeAdapter("fake-no-pushkin", [item]),
      fetchPushkinCardIds: async () => new Set(["какой-то-другой-id"]),
    };
    await runImport("voronezh", { ...ctx, adapters: [adapter] });

    const events = await listEventsForAdmin(ctx);
    const created = events.find((e) => e.title === "Обычное событие без карты")!;
    expect((await getEventForAdmin(created.id, ctx))?.pushkinCard).toBe(false);
  });

  it("при ошибке источника отчёт содержит ошибку, но не падает целиком", async () => {
    const broken: ImportAdapter = {
      key: "broken",
      name: "Ломающийся",
      siteUrl: "https://broken.example",
      fetchEvents: async () => {
        throw new Error("network down");
      },
    };
    const reports = await runImport("voronezh", { ...ctx, adapters: [broken] });
    expect(reports[0]).toMatchObject({ source: "Ломающийся", errors: 1, imported: 0 });
  });
});

describe("дубли между источниками", () => {
  it("не создаёт то же событие из другого источника с другим написанием названия", async () => {
    const a: ScrapedEvent = { ...sample, externalId: "dup-a", title: "Спектакль «Тестовая пьеса»", startsAt: new Date("2027-06-01T16:00:00Z") };
    const b: ScrapedEvent = { ...sample, externalId: "dup-b", title: "Тестовая пьеса (Воронеж)", startsAt: new Date("2027-06-01T16:30:00Z") };
    const r1 = await runImport("voronezh", { ...ctx, adapters: [fakeAdapter("src-a", [a])] });
    const r2 = await runImport("voronezh", { ...ctx, adapters: [fakeAdapter("src-b", [b])] });
    expect(r1[0].imported).toBe(1);
    expect(r2[0]).toMatchObject({ imported: 0, skippedDuplicate: 1 });
  });
});

describe("примерные площадки", () => {
  it("разрешает примерную точку только источнику, надёжно привязанному к городу", async () => {
    const seen: (boolean | undefined)[] = [];
    const geocode = async (name: string, _city: string, _url?: string, allowApprox?: boolean) => {
      seen.push(allowApprox);
      return allowApprox ? { name, address: "", lat: 51.66, lon: 39.2, locality: null, approx: true } : null;
    };
    const reliable: ScrapedEvent = { ...sample, externalId: "apx-1", title: "Событие в клубе без карты", venueName: "Клуб без карты", cityReliable: true };
    const unreliable: ScrapedEvent = { ...sample, externalId: "apx-2", title: "Чужой город", venueName: "Площадка из другого города" };
    const r = await runImport("voronezh", { ...ctx, geocode, adapters: [fakeAdapter("fake-apx", [reliable, unreliable])] });
    expect(seen).toEqual([true, undefined]);
    expect(r[0]).toMatchObject({ imported: 1, skippedNoVenue: ["Площадка из другого города"] });
  });
});
