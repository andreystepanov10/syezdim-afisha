import * as cheerio from "cheerio";
import { fetchSource } from "./http";
import { extractAfishaRuDescription } from "./sources/afisha-ru";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

const CSS_SELECTOR: Record<string, string> = {
  afishagoroda: ".events-one .redactor.content",
  kassir: ".content-block",
};

const CUSTOM_EXTRACTOR: Record<string, (html: string) => string | null> = {
  "afisha-ru": extractAfishaRuDescription,
};

/** Экспортируется отдельно для юнит-тестов на фикстуре */
export function extractDescription(html: string, sourceKey: string): string | null {
  const custom = CUSTOM_EXTRACTOR[sourceKey];
  if (custom) return custom(html);

  const selector = CSS_SELECTOR[sourceKey];
  if (!selector) return null;
  const $ = cheerio.load(html);
  const text = $(selector).first().text().replace(/\s+/g, " ").trim();
  return text || null;
}

/** Читает оригинальное описание со страницы события источника — только для последующего переписывания через ИИ */
export async function fetchSourceDescription(detailUrl: string, sourceKey: string): Promise<string | null> {
  if (!CSS_SELECTOR[sourceKey] && !CUSTOM_EXTRACTOR[sourceKey]) return null;
  const res = await fetchSource(detailUrl, { headers: { "User-Agent": UA } });
  if (!res.ok) return null;
  return extractDescription(await res.text(), sourceKey);
}
