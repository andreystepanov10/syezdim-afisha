// Московское время. Черноземье живёт по МСК (UTC+3, без перехода на летнее время с 2014 года),
// поэтому смещение можно держать константой — и на сервере, и в тестах результат один и тот же.
export const MSK_OFFSET_MS = 3 * 60 * 60 * 1000;
export const DAY_MS = 24 * 60 * 60 * 1000;

/** Начало календарных суток по МСК для момента `date` (как момент времени в UTC) */
export function startOfDayMsk(date: Date): Date {
  const shifted = new Date(date.getTime() + MSK_OFFSET_MS);
  return new Date(Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate()) - MSK_OFFSET_MS);
}

export function addDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * DAY_MS);
}

/** День недели по МСК: 0 — воскресенье … 6 — суббота */
export function weekdayMsk(date: Date): number {
  return new Date(date.getTime() + MSK_OFFSET_MS).getUTCDay();
}

/** «2026-10-15» → начало этих суток по МСК. Возвращает null для некорректной даты */
export function parseDayMsk(isoDate: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoDate);
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const ms = Date.UTC(y, mo - 1, d);
  const check = new Date(ms);
  if (check.getUTCFullYear() !== y || check.getUTCMonth() !== mo - 1 || check.getUTCDate() !== d) return null;
  return new Date(ms - MSK_OFFSET_MS);
}

/** Обратное к parseDayMsk: сутки по МСК → «2026-10-15» */
export function isoDayMsk(date: Date): string {
  const shifted = new Date(date.getTime() + MSK_OFFSET_MS);
  const y = shifted.getUTCFullYear();
  const mo = String(shifted.getUTCMonth() + 1).padStart(2, "0");
  const d = String(shifted.getUTCDate()).padStart(2, "0");
  return `${y}-${mo}-${d}`;
}

/** Начало месяца (1-е число, полночь) по МСК для суток, в которые попадает `date` */
export function startOfMonthMsk(date: Date): Date {
  const shifted = new Date(date.getTime() + MSK_OFFSET_MS);
  return new Date(Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), 1) - MSK_OFFSET_MS);
}

/** Сдвиг на `months` месяцев по МСК. Ожидает `date` в начале месяца (см. startOfMonthMsk) */
export function addMonths(date: Date, months: number): Date {
  const shifted = new Date(date.getTime() + MSK_OFFSET_MS);
  return new Date(Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth() + months, 1) - MSK_OFFSET_MS);
}

/**
 * «2026-10-01T18:30» из <input type="datetime-local"> — читаем как время по МСК, а не по часовому поясу
 * сервера/браузера (для них это просто числа без пояса). Для форм админки. null — некорректная строка.
 */
export function parseDateTimeLocalMsk(value: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(value);
  if (!m) return null;
  const [y, mo, d, h, mi] = [m[1], m[2], m[3], m[4], m[5]].map(Number);
  return new Date(Date.UTC(y, mo - 1, d, h, mi) - MSK_OFFSET_MS);
}

/** Обратное к parseDateTimeLocalMsk — Date → «2026-10-01T18:30» по МСК, для value инпута datetime-local */
export function toDateTimeLocalMsk(date: Date): string {
  const shifted = new Date(date.getTime() + MSK_OFFSET_MS);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${shifted.getUTCFullYear()}-${pad(shifted.getUTCMonth() + 1)}-${pad(shifted.getUTCDate())}T${pad(shifted.getUTCHours())}:${pad(shifted.getUTCMinutes())}`;
}
