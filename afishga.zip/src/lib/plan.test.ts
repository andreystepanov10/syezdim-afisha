import { describe, expect, it } from "vitest";
import { groupFavoritesByDay } from "./plan";
import type { EventSummary } from "./types";

function event(slug: string, startsAt: string): EventSummary {
  return { slug, title: slug, startsAt, city: "voronezh", priceFrom: null };
}

// «Сейчас» — 26 сентября, 08:00 МСК (раньше всех тестовых событий этого дня)
const now = new Date("2026-09-26T05:00:00Z");

describe("groupFavoritesByDay", () => {
  it("делит на предстоящие и прошедшие относительно now", () => {
    const past = event("past", "2026-09-25T10:00:00+03:00");
    const future = event("future", "2026-09-27T10:00:00+03:00");
    const { upcoming, past: pastList } = groupFavoritesByDay([past, future], now);
    expect(upcoming.flatMap((d) => d.events).map((e) => e.slug)).toEqual(["future"]);
    expect(pastList.map((e) => e.slug)).toEqual(["past"]);
  });

  it("группирует несколько событий одного дня вместе, по возрастанию времени", () => {
    const sport = event("sport", "2026-09-26T13:00:00+03:00");
    const theatre = event("theatre", "2026-09-26T10:00:00+03:00");
    const { upcoming } = groupFavoritesByDay([sport, theatre], now);
    expect(upcoming).toHaveLength(1);
    expect(upcoming[0].events.map((e) => e.slug)).toEqual(["theatre", "sport"]);
  });

  it("подписывает сегодняшний день «Сегодня», завтрашний — «Завтра», остальные — датой", () => {
    const today = event("today", "2026-09-26T13:00:00+03:00");
    const tomorrow = event("tomorrow", "2026-09-27T13:00:00+03:00");
    const later = event("later", "2026-10-03T13:00:00+03:00");
    const { upcoming } = groupFavoritesByDay([today, tomorrow, later], now);
    expect(upcoming.map((d) => d.label)).toEqual(["Сегодня", "Завтра", "3 ОКТ, СБ"]);
  });

  it("сортирует прошедшие по убыванию — самое недавнее сверху", () => {
    const older = event("older", "2026-09-20T10:00:00+03:00");
    const recent = event("recent", "2026-09-25T10:00:00+03:00");
    const { past } = groupFavoritesByDay([older, recent], now);
    expect(past.map((e) => e.slug)).toEqual(["recent", "older"]);
  });

  it("пустой список избранного — пустые группы без ошибок", () => {
    expect(groupFavoritesByDay([], now)).toEqual({ upcoming: [], past: [] });
  });
});
