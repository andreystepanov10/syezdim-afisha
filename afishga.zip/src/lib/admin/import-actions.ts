"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { runImport } from "@/lib/import/run";
import { isCitySlug } from "@/lib/cities";
import type { ImportReport } from "@/lib/import/types";
import { isAdmin } from "@/lib/admin-session";

export type ImportFormState = { reports: ImportReport[]; error?: string } | undefined;

export async function runImportAction(_prev: ImportFormState, formData: FormData): Promise<ImportFormState> {
  if (!(await isAdmin())) redirect("/admin/login");

  const city = String(formData.get("city") ?? "");
  if (!isCitySlug(city)) return { reports: [], error: "Выберите город" };

  const reports = await runImport(city);
  revalidatePath("/admin/events");
  return { reports };
}
