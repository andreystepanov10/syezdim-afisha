"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { createPartner, deletePartner, updatePartner, type PartnerInput } from "@/data/admin";
import { isAdmin } from "@/lib/admin-session";
import { slugify } from "@/lib/slug";

export type PartnerFormState = { error: string } | undefined;

const schema = z.object({
  name: z.string().trim().min(1, "Укажите название"),
  slug: z.string().trim().min(1, "Укажите slug"),
  siteUrl: z.union([z.literal(""), z.url("Некорректная ссылка")]),
});

function parse(formData: FormData): { ok: true; value: PartnerInput } | { ok: false; error: string } {
  const name = String(formData.get("name") ?? "").trim();
  const slugRaw = String(formData.get("slug") ?? "").trim();
  const result = schema.safeParse({
    name,
    slug: slugRaw || slugify(name),
    siteUrl: String(formData.get("siteUrl") ?? "").trim(),
  });
  if (!result.success) return { ok: false, error: result.error.issues[0].message };
  return { ok: true, value: result.data };
}

export async function createPartnerAction(_prev: PartnerFormState, formData: FormData): Promise<PartnerFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await createPartner(parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/partners");
}

export async function updatePartnerAction(id: number, _prev: PartnerFormState, formData: FormData): Promise<PartnerFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await updatePartner(id, parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/partners");
}

export async function deletePartnerAction(id: number): Promise<void> {
  if (!(await isAdmin())) redirect("/admin/login");
  try {
    await deletePartner(id);
  } catch {
    // партнёр используется в событиях — FK не даёт удалить; просто возвращаемся, список покажет его снова
  }
  redirect("/admin/partners");
}
