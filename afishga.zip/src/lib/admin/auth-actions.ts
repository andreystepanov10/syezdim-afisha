"use server";

import { redirect } from "next/navigation";
import { endAdminSession, startAdminSession, verifyAdminPassword } from "@/lib/admin-session";

export type AdminLoginState = { error: string } | undefined;

export async function adminLoginAction(_prev: AdminLoginState, formData: FormData): Promise<AdminLoginState> {
  const password = String(formData.get("password") ?? "");
  if (!verifyAdminPassword(password)) return { error: "Неверный пароль" };
  await startAdminSession();
  redirect("/admin");
}

export async function adminLogoutAction(): Promise<void> {
  await endAdminSession();
  redirect("/admin/login");
}
