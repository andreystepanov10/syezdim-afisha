"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createEvent, deleteEvent, updateEvent, updateEventsStatus, type EventInput } from "@/data/admin";
import { CATEGORIES } from "@/lib/categories";
import { isAdmin } from "@/lib/admin-session";
import { CITIES, isCitySlug } from "@/lib/cities";
import { slugify } from "@/lib/slug";
import { parseDateTimeLocalMsk } from "@/lib/time";

export type EventFormState = { error: string } | undefined;

const optionalInt = z.union([z.literal(""), z.coerce.number().int()]).transform((v) => (v === "" ? null : v));
const ticketTypeSchema = z.object({ name: z.string().trim().min(1), priceRub: z.coerce.number().int().min(0) });

const schema = z.object({
  title: z.string().trim().min(1, "Укажите название"),
  slug: z.string().trim().min(1, "Укажите slug"),
  description: z.string().trim(),
  city: z.enum(CITIES.map((c) => c.slug) as [string, ...string[]], "Выберите город"),
  venueId: z.coerce.number().int().positive("Выберите площадку"),
  category: z.enum(CATEGORIES.map((c) => c.slug) as [string, ...string[]], "Выберите категорию"),
  partnerId: z.union([z.literal(""), z.coerce.number().int().positive()]).transform((v) => (v === "" ? null : v)),
  startsAt: z.string().min(1, "Укажите дату и время начала"),
  endsAt: z.string(),
  priceFrom: optionalInt,
  priceTo: optionalInt,
  ageLimit: optionalInt,
  image: z.string().trim(),
  isHot: z.union([z.literal("on"), z.literal(null)]).transform((v) => v === "on"),
  pushkinCard: z.union([z.literal("on"), z.literal(null)]).transform((v) => v === "on"),
  ticketUrl: z.string().trim(),
  status: z.enum(["draft", "published", "archived"] as const),
  ticketTypes: z.string(),
});

function parse(formData: FormData): { ok: true; value: EventInput } | { ok: false; error: string } {
  const title = String(formData.get("title") ?? "").trim();
  const slugRaw = String(formData.get("slug") ?? "").trim();
  const raw = {
    title,
    slug: slugRaw || slugify(title),
    description: String(formData.get("description") ?? ""),
    city: String(formData.get("city") ?? ""),
    venueId: formData.get("venueId"),
    category: String(formData.get("category") ?? ""),
    partnerId: formData.get("partnerId"),
    startsAt: String(formData.get("startsAt") ?? ""),
    endsAt: String(formData.get("endsAt") ?? ""),
    priceFrom: formData.get("priceFrom"),
    priceTo: formData.get("priceTo"),
    ageLimit: formData.get("ageLimit"),
    image: String(formData.get("image") ?? ""),
    isHot: formData.get("isHot"),
    pushkinCard: formData.get("pushkinCard"),
    ticketUrl: String(formData.get("ticketUrl") ?? ""),
    status: String(formData.get("status") ?? "published"),
    ticketTypes: String(formData.get("ticketTypes") ?? "[]"),
  };
  const result = schema.safeParse(raw);
  if (!result.success) return { ok: false, error: result.error.issues[0].message };
  if (!isCitySlug(result.data.city)) return { ok: false, error: "Выберите город" };

  const startsAt = parseDateTimeLocalMsk(result.data.startsAt);
  if (!startsAt) return { ok: false, error: "Некорректная дата начала" };
  const endsAt = result.data.endsAt ? parseDateTimeLocalMsk(result.data.endsAt) : null;

  let ticketTypes: { name: string; priceRub: number }[] = [];
  try {
    const parsedTypes = JSON.parse(result.data.ticketTypes);
    ticketTypes = z.array(ticketTypeSchema).parse(parsedTypes);
  } catch {
    return { ok: false, error: "Некорректный список билетов" };
  }

  return {
    ok: true,
    value: {
      title: result.data.title,
      slug: result.data.slug,
      description: result.data.description,
      city: result.data.city,
      venueId: result.data.venueId,
      category: result.data.category as EventInput["category"],
      partnerId: result.data.partnerId,
      startsAt,
      endsAt,
      priceFrom: result.data.priceFrom,
      priceTo: result.data.priceTo,
      ageLimit: result.data.ageLimit,
      image: result.data.image || null,
      isHot: result.data.isHot,
      pushkinCard: result.data.pushkinCard,
      ticketUrl: result.data.ticketUrl || null,
      status: result.data.status,
      ticketTypes,
    },
  };
}

export async function createEventAction(_prev: EventFormState, formData: FormData): Promise<EventFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await createEvent(parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/events");
}

export async function updateEventAction(id: number, _prev: EventFormState, formData: FormData): Promise<EventFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await updateEvent(id, parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/events");
}

export async function deleteEventAction(id: number): Promise<void> {
  if (!(await isAdmin())) redirect("/admin/login");
  await deleteEvent(id);
  redirect("/admin/events");
}

export async function bulkPublishEventsAction(ids: number[]): Promise<void> {
  if (!(await isAdmin())) redirect("/admin/login");
  await updateEventsStatus(ids, "published");
  revalidatePath("/admin/events");
}
