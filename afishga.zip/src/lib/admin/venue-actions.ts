"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { createVenue, deleteVenue, updateVenue, type VenueInput } from "@/data/admin";
import { isAdmin } from "@/lib/admin-session";
import { CITIES, isCitySlug } from "@/lib/cities";
import { slugify } from "@/lib/slug";

export type VenueFormState = { error: string } | undefined;

const schema = z.object({
  name: z.string().trim().min(1, "Укажите название"),
  slug: z.string().trim().min(1, "Укажите slug"),
  address: z.string().trim(),
  city: z.enum(CITIES.map((c) => c.slug) as [string, ...string[]], "Выберите город"),
  lat: z.coerce.number().min(-90).max(90, "Некорректная широта"),
  lon: z.coerce.number().min(-180).max(180, "Некорректная долгота"),
});

function parse(formData: FormData): { ok: true; value: VenueInput } | { ok: false; error: string } {
  const name = String(formData.get("name") ?? "").trim();
  const slugRaw = String(formData.get("slug") ?? "").trim();
  const result = schema.safeParse({
    name,
    slug: slugRaw || slugify(name),
    address: String(formData.get("address") ?? "").trim(),
    city: String(formData.get("city") ?? ""),
    lat: formData.get("lat"),
    lon: formData.get("lon"),
  });
  if (!result.success) return { ok: false, error: result.error.issues[0].message };
  if (!isCitySlug(result.data.city)) return { ok: false, error: "Выберите город" };
  return { ok: true, value: { ...result.data, city: result.data.city } };
}

export async function createVenueAction(_prev: VenueFormState, formData: FormData): Promise<VenueFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await createVenue(parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/venues");
}

export async function updateVenueAction(id: number, _prev: VenueFormState, formData: FormData): Promise<VenueFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await updateVenue(id, parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/venues");
}

export async function deleteVenueAction(id: number): Promise<void> {
  if (!(await isAdmin())) redirect("/admin/login");
  try {
    await deleteVenue(id);
  } catch {
    // площадка используется в событиях — FK не даёт удалить
  }
  redirect("/admin/venues");
}
