"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getEventForAdmin, getPartner, getVenue, updateEvent } from "@/data/admin";
import { isAdmin } from "@/lib/admin-session";
import { generateEventImage, isGeminiConfigured, rewriteDescription } from "@/lib/ai/gemini";
import { cityName } from "@/lib/cities";
import { categoryName } from "@/lib/categories";
import { fetchSourceDescription } from "@/lib/import/detail-fetch";
import { saveUpload } from "@/lib/uploads";

export type AiGenerateState = { error?: string } | undefined;

export async function generateAiContentAction(eventId: number): Promise<AiGenerateState> {
  if (!(await isAdmin())) redirect("/admin/login");
  if (!isGeminiConfigured()) return { error: "GEMINI_API_KEY не настроен на сервере" };

  const event = await getEventForAdmin(eventId);
  if (!event) return { error: "Событие не найдено" };

  const [partner, venue] = await Promise.all([
    event.partnerId ? getPartner(event.partnerId) : Promise.resolve(null),
    getVenue(event.venueId),
  ]);

  const facts = {
    title: event.title,
    category: categoryName(event.category),
    venueName: venue?.name ?? "",
    cityName: cityName(event.city),
  };

  let sourceText: string | null = null;
  if (partner && event.ticketUrl) {
    try {
      sourceText = await fetchSourceDescription(event.ticketUrl, partner.slug);
    } catch {
      sourceText = null; // не смогли прочитать источник — сгенерируем по фактам
    }
  }

  let description: string;
  try {
    description = await rewriteDescription(facts, sourceText);
  } catch (error) {
    console.error("[ai-actions] rewriteDescription failed:", error);
    return { error: "Не удалось сгенерировать описание — проверьте GEMINI_API_KEY" };
  }

  let image = event.image;
  try {
    const { bytes, ext } = await generateEventImage(facts);
    image = await saveUpload(bytes, ext);
  } catch (error) {
    console.error("[ai-actions] generateEventImage failed:", error);
    // Изображение не сгенерировалось (например, не подключён биллинг) — описание всё равно сохраняем
  }

  await updateEvent(eventId, { ...event, description, image });
  revalidatePath(`/admin/events/${eventId}`);
  redirect(`/admin/events/${eventId}`);
}
