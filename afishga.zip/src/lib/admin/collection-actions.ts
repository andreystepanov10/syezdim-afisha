"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { createCollection, deleteCollection, updateCollection, type CollectionInput } from "@/data/admin";
import { isAdmin } from "@/lib/admin-session";
import { slugify } from "@/lib/slug";

export type CollectionFormState = { error: string } | undefined;

const schema = z.object({
  title: z.string().trim().min(1, "Укажите название"),
  slug: z.string().trim().min(1, "Укажите slug"),
  description: z.string().trim(),
  image: z.string().trim(),
});

function parse(formData: FormData): { ok: true; value: CollectionInput } | { ok: false; error: string } {
  const title = String(formData.get("title") ?? "").trim();
  const slugRaw = String(formData.get("slug") ?? "").trim();
  const result = schema.safeParse({
    title,
    slug: slugRaw || slugify(title),
    description: String(formData.get("description") ?? ""),
    image: String(formData.get("image") ?? ""),
  });
  if (!result.success) return { ok: false, error: result.error.issues[0].message };
  const eventIds = formData
    .getAll("eventIds")
    .map((v) => Number(v))
    .filter((n) => Number.isInteger(n));
  return { ok: true, value: { ...result.data, image: result.data.image || null, eventIds } };
}

export async function createCollectionAction(_prev: CollectionFormState, formData: FormData): Promise<CollectionFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await createCollection(parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/collections");
}

export async function updateCollectionAction(id: number, _prev: CollectionFormState, formData: FormData): Promise<CollectionFormState> {
  if (!(await isAdmin())) redirect("/admin/login");
  const parsed = parse(formData);
  if (!parsed.ok) return { error: parsed.error };
  try {
    await updateCollection(id, parsed.value);
  } catch {
    return { error: "Не удалось сохранить — возможно, такой slug уже занят" };
  }
  redirect("/admin/collections");
}

export async function deleteCollectionAction(id: number): Promise<void> {
  if (!(await isAdmin())) redirect("/admin/login");
  await deleteCollection(id);
  redirect("/admin/collections");
}
