"use server";

import { toggleFavorite as toggleFavoriteDb } from "@/data/favorites";
import { getOrCreateDeviceId } from "@/lib/device";

/** Возвращает новое состояние (true — добавлено в избранное). Несуществующий slug — false, без изменений */
export async function toggleFavoriteAction(slug: string): Promise<boolean> {
  const deviceId = await getOrCreateDeviceId();
  return toggleFavoriteDb(deviceId, slug);
}
