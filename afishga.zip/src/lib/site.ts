import type { Metadata } from "next";

/** Публичный адрес сайта — для sitemap.xml, robots.txt и metadataBase (абсолютные ссылки в OG-тегах) */
export const SITE_URL = "https://syezdim.ru";

export const SITE_NAME = "Радиус «Съездим»";

/**
 * Общие поля Open Graph (превью ссылки в Telegram, VK, WhatsApp). Next.js не сливает openGraph страницы
 * с layout — если страница задаёт свой openGraph, общие поля надо подмешивать явно: { ...OPEN_GRAPH_DEFAULTS, ... }
 */
export const OPEN_GRAPH_DEFAULTS = {
  type: "website",
  siteName: SITE_NAME,
  locale: "ru_RU",
  // JPG 1200×630 — формат, который понимают все мессенджеры (webp VK и часть клиентов не показывают)
  images: [{ url: "/brand/og.jpg", width: 1200, height: 630, alt: "Афиша Черноземья — Радиус «Съездим»" }],
} satisfies NonNullable<Metadata["openGraph"]>;

/** Почта для вопросов посетителей, площадок и организаторов — политика, соглашение, «О проекте», «Организаторам» */
export const CONTACT_EMAIL = "radius-syezdim@mail.ru";

/** Telegram для связи по размещению (страница «Организаторам», «О проекте») */
export const CONTACT_TELEGRAM = "https://t.me/andreystepanov36";
