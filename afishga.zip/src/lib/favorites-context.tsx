"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { toggleFavoriteAction } from "./favorites-actions";

type FavoritesState = {
  isFavorite: (slug: string) => boolean;
  toggleFavorite: (slug: string) => Promise<void>;
};

const FavoritesContext = createContext<FavoritesState | null>(null);

export function useFavorites(): FavoritesState {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error("useFavorites нужно вызывать внутри <FavoritesProvider>");
  return ctx;
}

/** Избранное анонимно (по cookie устройства, см. lib/device.ts) — без входа и без персональных данных */
export function FavoritesProvider({ children }: { children: ReactNode }) {
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    fetch("/api/favorites")
      .then((r) => r.json())
      .then((data: { slugs: string[] }) => {
        if (!cancelled) setFavorites(new Set(data.slugs));
      })
      .catch(() => {}); // сеть недоступна — считаем, что избранного пока нет; не блокируем интерфейс
    return () => {
      cancelled = true;
    };
  }, []);

  const isFavorite = useCallback((slug: string) => favorites.has(slug), [favorites]);

  const toggleFavorite = useCallback(async (slug: string) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(slug)) next.delete(slug);
      else next.add(slug);
      return next;
    });
    const on = await toggleFavoriteAction(slug);
    // сервер — источник истины: подчищаем расхождение, если оптимистичное обновление не совпало
    setFavorites((prev) => {
      if (prev.has(slug) === on) return prev;
      const next = new Set(prev);
      if (on) next.add(slug);
      else next.delete(slug);
      return next;
    });
  }, []);

  const value = useMemo(() => ({ isFavorite, toggleFavorite }), [isFavorite, toggleFavorite]);

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}
