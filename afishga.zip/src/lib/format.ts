// Форматирование дат и цен. Часовой пояс фиксируем (Черноземье = МСК),
// чтобы сервер и браузер выводили одно и то же.
const TZ = "Europe/Moscow";

type DateInput = Date | string;
const toDate = (d: DateInput) => (d instanceof Date ? d : new Date(d));

export function formatPrice(rub: number): string {
  return `${new Intl.NumberFormat("ru-RU").format(rub)} ₽`;
}

/** «от 1 200 ₽», «Бесплатно», «Цена уточняется» */
export function priceLabel(priceFrom: number | null | undefined): string {
  if (priceFrom == null) return "Цена уточняется";
  if (priceFrom === 0) return "Бесплатно";
  return `от ${formatPrice(priceFrom)}`;
}

export function dayNumber(d: DateInput): string {
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", timeZone: TZ }).format(toDate(d));
}

/** «ОКТ, СБ» */
export function monthWeekdayShort(d: DateInput): string {
  const date = toDate(d);
  const month = new Intl.DateTimeFormat("ru-RU", { month: "short", timeZone: TZ }).format(date).replace(".", "");
  const weekday = new Intl.DateTimeFormat("ru-RU", { weekday: "short", timeZone: TZ }).format(date).replace(".", "");
  return `${month}, ${weekday}`.toUpperCase();
}

/** «15 ОКТ, СБ» */
export function dateShort(d: DateInput): string {
  return `${dayNumber(d)} ${monthWeekdayShort(d)}`;
}

/** «10:00» */
export function timeShort(d: DateInput): string {
  return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit", timeZone: TZ }).format(toDate(d));
}

/** «15 октября» — для дат из фильтров (строка YYYY-MM-DD) */
export function dayMonthLong(isoDate: string): string {
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", timeZone: TZ }).format(new Date(isoDate));
}

/** «Октябрь 2026» — заголовок месяца в календаре */
export function monthYearLong(d: DateInput): string {
  const s = new Intl.DateTimeFormat("ru-RU", { month: "long", year: "numeric", timeZone: TZ }).format(toDate(d));
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** «15 октября 2026, 19:00» */
export function dateTimeLong(d: DateInput): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: TZ,
  }).format(toDate(d));
}

/** Склонение: plural(3, ["событие", "события", "событий"]) → «события» */
export function plural(n: number, forms: [string, string, string]): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return forms[0];
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return forms[1];
  return forms[2];
}

/** «11 октября — 6 декабря» — период выставки или проката фильма (время у таких событий не указано) */
export function periodLong(start: DateInput, end: DateInput): string {
  const f = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", timeZone: TZ });
  return `${f.format(toDate(start))} — ${f.format(toDate(end))}`;
}
