import type { CategorySlug } from "./categories";
import type { CitySlug } from "./cities";

// Типы данных для карточек и блоков. С этапа 2 значения приходят из БД.
export type EventBadge = "hot" | "free" | "18+" | "pushkin";

export type EventSummary = {
  slug: string;
  title: string;
  /** Площадка / исполнитель — вторая строка в карточке */
  subtitle?: string;
  image?: string;
  /** ISO-строка с часовым поясом, напр. 2026-10-15T19:00:00+03:00 */
  startsAt: string;
  city: CitySlug;
  /** Населённый пункт области, если событие не в областном центре («Старый Оскол») */
  locality?: string;
  category?: CategorySlug;
  /** Координаты площадки — для клиентского «Рядом со мной» (расстояние считаем в браузере, координаты пользователя на сервер не уходят) */
  lat?: number;
  lon?: number;
  /** Минимальная цена в рублях; 0 — бесплатно; null — неизвестна */
  priceFrom: number | null;
  rating?: number;
  ratingCount?: number;
  badges?: EventBadge[];
  /** Ссылка на покупку у партнёра */
  ticketUrl?: string;
  /** Сколько ещё сеансов того же события в той же площадке за период (при groupSessions) */
  moreDates?: number;
  /** Пометка рекламы у кнопки «Купить», если ссылка партнёрская (src/lib/affiliate.ts affiliateMark) */
  adMark?: string;
};

export type CollectionSummary = {
  slug: string;
  title: string;
  image?: string;
  count?: number;
};

/** Площадка на карте вместе с ближайшими событиями */
export type MapVenue = {
  id: string;
  name: string;
  city: CitySlug;
  lat: number;
  lon: number;
  events: Pick<EventSummary, "slug" | "title" | "image" | "startsAt" | "priceFrom">[];
};

/** Площадка в каталоге «Места»: адрес и число ближайших событий */
export type VenueSummary = {
  slug: string;
  name: string;
  address: string;
  city: CitySlug;
  lat: number;
  lon: number;
  upcomingCount: number;
};

export type HomeData = {
  popularByCity: Record<CitySlug, EventSummary[]>;
  exhibitionsByCity: Record<CitySlug, EventSummary[]>;
  mapVenues: MapVenue[];
  collections: CollectionSummary[];
  /** Тематические подборки по городам (src/data/auto-collections) — блок «Подборки» на главной */
  autoCollectionsByCity: Record<CitySlug, { slug: string; title: string; hint: string; href: string; image?: string; count: number }[]>;
};
