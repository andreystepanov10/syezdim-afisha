// Фирменные иллюстрации сайта (public/art, сгенерированы в стиле главной — scripts/art-process.mjs):
// обложки тематических подборок, заглушки категорий для событий без постера, обложки городов.
import { existsSync } from "node:fs";
import path from "node:path";

const cache = new Map<string, string | undefined>();

/** Адрес картинки, если файл есть в public/art (иначе undefined — показываем то, что было раньше) */
function art(dir: string, slug: string): string | undefined {
  const key = `${dir}/${slug}`;
  if (!cache.has(key)) cache.set(key, existsSync(path.join(process.cwd(), "public/art", dir, `${slug}.jpg`)) ? `/art/${key}.jpg` : undefined);
  return cache.get(key);
}

export const collectionArt = (slug: string) => art("collections", slug);
export const categoryArt = (slug: string) => art("categories", slug);
export const cityArt = (slug: string) => art("cities", slug);

/** Заглушка ли это, а не постер события — в Telegram-посты такие картинки не ставим */
export const isArtPlaceholder = (image: string) => image.startsWith("/art/");
