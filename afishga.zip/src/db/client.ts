import { mkdirSync } from "node:fs";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { drizzle as drizzlePg } from "drizzle-orm/node-postgres";
import type { PgDatabase, PgQueryResultHKT } from "drizzle-orm/pg-core";
import { drizzle as drizzlePglite } from "drizzle-orm/pglite";
import { migrate as migratePglite } from "drizzle-orm/pglite/migrator";
import { Pool } from "pg";
import { count } from "drizzle-orm";
import * as schema from "./schema";
import { seedDemo } from "./seed";

/** Общий тип базы: одинаково работает и с PostgreSQL (pg), и с PGlite */
export type Db = PgDatabase<PgQueryResultHKT, typeof schema>;

export const MIGRATIONS_FOLDER = path.join(process.cwd(), "drizzle");

/**
 * Демо-база в PGlite (настоящий Postgres в WebAssembly, устанавливать ничего не нужно):
 * миграции + демо-события. Без dataDir живёт в памяти процесса и заполняется заново при каждом старте.
 */
export async function createDemoDb(options: { dataDir?: string; now?: Date } = {}): Promise<Db> {
  if (options.dataDir) mkdirSync(options.dataDir, { recursive: true }); // PGlite сам родительские папки не создаёт
  const db = drizzlePglite(new PGlite(options.dataDir), { schema });
  await migratePglite(db, { migrationsFolder: MIGRATIONS_FOLDER });
  const [{ n }] = await db.select({ n: count() }).from(schema.events);
  if (n === 0) await seedDemo(db as unknown as Db, options.now);
  return db as unknown as Db;
}

async function open(): Promise<Db> {
  const url = process.env.DATABASE_URL;
  if (url) return drizzlePg(new Pool({ connectionString: url, max: 10 }), { schema }) as unknown as Db;

  // Без DATABASE_URL база — демо в PGlite. В продакшне это надо включать осознанно (ALLOW_DEMO_DB=1),
  // чтобы сайт случайно не поднялся на демо-данных вместо настоящей базы.
  if (process.env.NODE_ENV === "production" && process.env.ALLOW_DEMO_DB !== "1") {
    throw new Error("DATABASE_URL не задан. Укажите строку подключения к PostgreSQL или ALLOW_DEMO_DB=1 для демо-режима.");
  }
  return createDemoDb({ dataDir: process.env.PGLITE_DIR });
}

// Одно подключение на процесс; кэш в globalThis переживает горячую перезагрузку модулей в dev
const globalForDb = globalThis as unknown as { __radiusDb?: Promise<Db> };

export function getDb(): Promise<Db> {
  globalForDb.__radiusDb ??= open().catch((error) => {
    globalForDb.__radiusDb = undefined;
    throw error;
  });
  return globalForDb.__radiusDb;
}
