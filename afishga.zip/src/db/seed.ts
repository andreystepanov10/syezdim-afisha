import { and, eq, notExists, sql } from "drizzle-orm";
import { buildFixtures } from "@/data/fixtures";
import { CATEGORIES } from "@/lib/categories";
import { CITIES } from "@/lib/cities";
import type { Db } from "./client";
import { categories, cities, collectionEvents, collections, events, partners, ticketTypes, venues } from "./schema";

export const DEMO_PARTNER = { slug: "demo-partner", name: "Демо-партнёр", siteUrl: "https://example.com" };

/** Справочники: города и категории. Нужны в любой базе (и в продакшне), идемпотентно */
export async function seedReference(db: Db) {
  await db
    .insert(cities)
    .values(CITIES.map((c) => ({ slug: c.slug, name: c.name, locative: c.locative, lat: c.lat, lon: c.lon })))
    .onConflictDoUpdate({
      target: cities.slug,
      set: { name: sql`excluded.name`, locative: sql`excluded.locative`, lat: sql`excluded.lat`, lon: sql`excluded.lon` },
    });
  await db
    .insert(categories)
    .values(CATEGORIES.map((c, i) => ({ slug: c.slug, name: c.name, sort: i })))
    .onConflictDoUpdate({ target: categories.slug, set: { name: sql`excluded.name`, sort: sql`excluded.sort` } });
}

/** Демо-данные: площадки, события, типы билетов, подборки. Все записи помечены is_demo */
export async function seedDemo(db: Db, now: Date = new Date()) {
  await seedReference(db);
  const fx = buildFixtures(now);

  const cityId = new Map((await db.select({ id: cities.id, slug: cities.slug }).from(cities)).map((r) => [r.slug, r.id]));
  const categoryId = new Map((await db.select({ id: categories.id, slug: categories.slug }).from(categories)).map((r) => [r.slug, r.id]));

  await db.transaction(async (tx) => {
    const [partner] = await tx
      .insert(partners)
      .values({ ...DEMO_PARTNER, isDemo: true })
      .onConflictDoUpdate({ target: partners.slug, set: { name: DEMO_PARTNER.name } })
      .returning({ id: partners.id });

    const venueRows = await tx
      .insert(venues)
      .values(fx.venues.map((v) => ({ slug: v.slug, cityId: cityId.get(v.citySlug)!, name: v.name, address: v.address, lat: v.lat, lon: v.lon, isDemo: true })))
      .returning({ id: venues.id, slug: venues.slug });
    const venueId = new Map(venueRows.map((r) => [r.slug, r.id]));

    const eventRows = await tx
      .insert(events)
      .values(
        fx.events.map((e) => ({
          slug: e.slug,
          title: e.title,
          description: e.description,
          cityId: cityId.get(e.citySlug)!,
          venueId: venueId.get(e.venueSlug)!,
          categoryId: categoryId.get(e.categorySlug)!,
          partnerId: partner.id,
          startsAt: e.startsAt,
          endsAt: e.endsAt ?? null,
          priceFrom: e.priceFrom,
          priceTo: e.priceTo,
          ageLimit: e.ageLimit ?? null,
          image: e.image,
          rating: e.rating,
          ratingCount: e.ratingCount,
          isHot: e.isHot,
          ticketUrl: e.ticketUrl,
          status: "published" as const,
          isDemo: true,
        })),
      )
      .returning({ id: events.id, slug: events.slug });
    const eventId = new Map(eventRows.map((r) => [r.slug, r.id]));

    const types = fx.events.flatMap((e) => e.ticketTypes.map((t, i) => ({ eventId: eventId.get(e.slug)!, name: t.name, priceRub: t.priceRub, sort: i })));
    if (types.length) await tx.insert(ticketTypes).values(types);

    const collectionRows = await tx
      .insert(collections)
      .values(fx.collections.map((c, i) => ({ slug: c.slug, title: c.title, description: c.description, image: c.image, sort: i, isDemo: true })))
      .returning({ id: collections.id, slug: collections.slug });
    const collectionId = new Map(collectionRows.map((r) => [r.slug, r.id]));

    const links = fx.collections.flatMap((c) => c.eventSlugs.map((slug, i) => ({ collectionId: collectionId.get(c.slug)!, eventId: eventId.get(slug)!, sort: i })));
    if (links.length) await tx.insert(collectionEvents).values(links);
  });

  return { events: fx.events.length, venues: fx.venues.length, collections: fx.collections.length };
}

/** Удаляет все демо-записи (перед запуском сайта с настоящими данными). Настоящие события не трогает */
export async function purgeDemo(db: Db) {
  await db.transaction(async (tx) => {
    await tx.delete(events).where(eq(events.isDemo, true)); // билеты и связи с подборками удаляются каскадом
    await tx.delete(collections).where(eq(collections.isDemo, true));
    await tx.delete(venues).where(and(eq(venues.isDemo, true), notExists(tx.select({ one: sql`1` }).from(events).where(eq(events.venueId, venues.id)))));
    await tx.delete(partners).where(and(eq(partners.isDemo, true), notExists(tx.select({ one: sql`1` }).from(events).where(eq(events.partnerId, partners.id)))));
  });
}
