import { sql, type SQL } from "drizzle-orm";
import {
  bigint,
  boolean,
  customType,
  doublePrecision,
  index,
  integer,
  pgEnum,
  pgTable,
  primaryKey,
  real,
  serial,
  smallint,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

// Полнотекстовый вектор Postgres (drizzle не имеет встроенного типа)
const tsvector = customType<{ data: string }>({
  dataType() {
    return "tsvector";
  },
});

export const eventStatus = pgEnum("event_status", ["draft", "published", "archived"]);

/** Города Черноземья */
export const cities = pgTable("cities", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  /** «в Воронеже» — для заголовков */
  locative: text("locative").notNull(),
  lat: doublePrecision("lat").notNull(),
  lon: doublePrecision("lon").notNull(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  sort: smallint("sort").notNull().default(0),
});

/** Площадки: театры, залы, музеи, парки */
export const venues = pgTable(
  "venues",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    cityId: integer("city_id")
      .notNull()
      .references(() => cities.id),
    name: text("name").notNull(),
    address: text("address").notNull().default(""),
    lat: doublePrecision("lat").notNull(),
    lon: doublePrecision("lon").notNull(),
    /** Населённый пункт области, если площадка не в областном центре: «Старый Оскол», «Елец». null — сам центр */
    locality: text("locality"),
    /**
     * Точного места нет (площадку не нашли в OpenStreetMap ни по названию, ни по адресу): координаты — центр
     * города или посёлка. Такие площадки не показываем на карте и в «Рядом со мной»
     */
    approx: boolean("approx").notNull().default(false),
    /** Демо-запись: удаляется командой db:purge-demo перед запуском */
    isDemo: boolean("is_demo").notNull().default(false),
  },
  (t) => [index("venues_city_idx").on(t.cityId)],
);

/** Партнёры-билетные операторы: у них покупают билеты, мы ведём на их сайт */
export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  siteUrl: text("site_url"),
  isDemo: boolean("is_demo").notNull().default(false),
});

export const events = pgTable(
  "events",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    cityId: integer("city_id")
      .notNull()
      .references(() => cities.id),
    venueId: integer("venue_id")
      .notNull()
      .references(() => venues.id),
    categoryId: integer("category_id")
      .notNull()
      .references(() => categories.id),
    partnerId: integer("partner_id").references(() => partners.id),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    /** Для выставок и фестивалей — дата окончания */
    endsAt: timestamp("ends_at", { withTimezone: true }),
    /** Рубли. 0 — бесплатно, null — цена не указана */
    priceFrom: integer("price_from"),
    priceTo: integer("price_to"),
    ageLimit: smallint("age_limit"),
    image: text("image"),
    rating: real("rating"),
    ratingCount: integer("rating_count").notNull().default(0),
    /** Бейдж «Hot» */
    isHot: boolean("is_hot").notNull().default(false),
    /** Принимают Пушкинскую карту — берём из отдельных подборок источников, не выдумываем сами */
    pushkinCard: boolean("pushkin_card").notNull().default(false),
    /** Ссылка на покупку билета у партнёра */
    ticketUrl: text("ticket_url"),
    status: eventStatus("status").notNull().default("published"),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    /** Индекс полнотекстового поиска по-русски: заголовок (вес A) + описание (вес B) */
    search: tsvector("search").generatedAlwaysAs(
      (): SQL =>
        sql`setweight(to_tsvector('russian', coalesce(${events.title}, '')), 'A') || setweight(to_tsvector('russian', coalesce(${events.description}, '')), 'B')`,
    ),
  },
  (t) => [
    index("events_city_starts_idx").on(t.cityId, t.startsAt),
    index("events_category_idx").on(t.categoryId),
    index("events_status_starts_idx").on(t.status, t.startsAt),
    index("events_venue_idx").on(t.venueId),
    index("events_search_idx").using("gin", t.search),
  ],
);

/** Категории билетов на событие: «Стандарт», «VIP», «Студенческий» */
export const ticketTypes = pgTable(
  "ticket_types",
  {
    id: serial("id").primaryKey(),
    eventId: integer("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    priceRub: integer("price_rub").notNull(),
    sort: smallint("sort").notNull().default(0),
  },
  (t) => [index("ticket_types_event_idx").on(t.eventId)],
);

/** Редакционные подборки */
export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  image: text("image"),
  sort: smallint("sort").notNull().default(0),
  isDemo: boolean("is_demo").notNull().default(false),
});

export const collectionEvents = pgTable(
  "collection_events",
  {
    collectionId: integer("collection_id")
      .notNull()
      .references(() => collections.id, { onDelete: "cascade" }),
    eventId: integer("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    sort: smallint("sort").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.collectionId, t.eventId] })],
);

// ---------------------------------------------------------------------------
// Избранное: без аккаунтов и без входа — сознательное решение не собирать персональные данные
// (152-ФЗ регулирует данные, идентифицирующие человека; анонимный ID устройства ими не является).
// Раньше здесь были users/sessions (вход по email+паролю) — убраны, см. память проекта.
// ---------------------------------------------------------------------------

/** «Мои билеты» показывают избранное — своей продажи билетов у сайта нет, покупка происходит у партнёра */
export const favorites = pgTable(
  "favorites",
  {
    /** Случайный ID в cookie устройства (src/lib/device.ts) — не привязан к личности */
    deviceId: text("device_id").notNull(),
    eventId: integer("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.deviceId, t.eventId] })],
);

// Рассылки по email на сайте нет (сознательно — не хотим собирать email вообще, см. память проекта):
// вместо формы подписки в подвале — ссылки на публичные каналы в Telegram/VK.

/**
 * Просмотры страниц для статистики в админке. Только анонимный device_id (см. favorites выше) —
 * ни IP, ни User-Agent не пишем, чтобы не завести персональные данные ради счётчика посещений.
 */
export const pageViews = pgTable(
  "page_views",
  {
    id: serial("id").primaryKey(),
    /** Календарный день по МСК, «2026-09-22» (src/lib/time.ts isoDayMsk) — для группировки без SQL-таймзон */
    day: text("day").notNull(),
    path: text("path").notNull(),
    deviceId: text("device_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("page_views_day_idx").on(t.day)],
);

// ---------------------------------------------------------------------------
// Telegram-бот (src/lib/telegram). Храним только числовой ID чата — без имени, ника и телефона:
// он нужен, чтобы ответить и прислать напоминание. Подборка бота — то же избранное (favorites) по device_id,
// поэтому сайт и бот могут делить одну подборку после связки (link_tokens).
// ---------------------------------------------------------------------------

export const telegramUsers = pgTable("telegram_users", {
  chatId: bigint("chat_id", { mode: "number" }).primaryKey(),
  /** device_id подборки: свой случайный у бота или взятый у браузера после связки с сайтом */
  deviceId: text("device_id").notNull(),
  city: text("city"),
  reminders: boolean("reminders").notNull().default(true),
  /** Последний запрос списка (JSON) — для кнопок «дальше/назад» без длинных callback_data */
  lastQuery: text("last_query"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Одноразовые короткоживущие ссылки связки: сайт → бот (to_bot) и бот → сайт (to_site) */
export const linkTokens = pgTable("link_tokens", {
  token: text("token").primaryKey(),
  deviceId: text("device_id").notNull(),
  purpose: text("purpose").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

/** Публичная ссылка «Поделиться подборкой» — случайный id вместо device_id, чтобы по ссылке нельзя было менять подборку */
export const shareLinks = pgTable("share_links", {
  id: text("id").primaryKey(),
  deviceId: text("device_id").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Какие напоминания уже отправлены — чтобы повторный запуск рассылки не дублировал сообщения */
export const reminderLog = pgTable(
  "reminder_log",
  {
    chatId: bigint("chat_id", { mode: "number" }).notNull(),
    eventId: integer("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.chatId, t.eventId] })],
);

/** Какие события уже публиковались в Telegram-каналах — чтобы автопостинг не повторялся (src/lib/telegram/digest.ts) */
export const channelPosts = pgTable(
  "channel_posts",
  {
    city: text("city").notNull(),
    eventId: integer("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    postedAt: timestamp("posted_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.city, t.eventId] })],
);

/**
 * Переходы «Купить билет» к партнёрам (через /go/<slug>) — по дням, событию и источнику, только счётчик:
 * ни device_id, ни IP не пишем. Показывает, какие события продают, и сверяется с отчётом партнёрской программы.
 */
export const ticketClicks = pgTable(
  "ticket_clicks",
  {
    /** День по МСК, «2026-10-20» */
    day: text("day").notNull(),
    eventId: integer("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    /** site | channel | bot */
    source: text("source").notNull(),
    count: integer("count").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.day, t.eventId, t.source] })],
);
