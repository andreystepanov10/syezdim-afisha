import { count } from "drizzle-orm";
import { afterEach, describe, expect, it, vi } from "vitest";
import { getDb } from "./client";
import { events } from "./schema";

const cache = globalThis as unknown as { __radiusDb?: unknown };

describe("выбор базы данных", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    delete cache.__radiusDb;
  });

  it("в продакшне без DATABASE_URL и ALLOW_DEMO_DB — понятная ошибка, а не тихий запуск на демо-данных", async () => {
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("DATABASE_URL", "");
    vi.stubEnv("ALLOW_DEMO_DB", "");
    await expect(getDb()).rejects.toThrow(/DATABASE_URL/);
  });

  it("после ошибки следующая попытка не залипает на «плохом» результате", async () => {
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("DATABASE_URL", "");
    vi.stubEnv("ALLOW_DEMO_DB", "");
    await expect(getDb()).rejects.toThrow();
    vi.stubEnv("ALLOW_DEMO_DB", "1");
    const db = await getDb();
    const [{ n }] = await db.select({ n: count() }).from(events);
    expect(n).toBeGreaterThan(0);
  });

  it("одно подключение на процесс: повторные вызовы возвращают ту же базу", async () => {
    vi.stubEnv("NODE_ENV", "development");
    vi.stubEnv("DATABASE_URL", "");
    expect(await getDb()).toBe(await getDb());
  });
});
