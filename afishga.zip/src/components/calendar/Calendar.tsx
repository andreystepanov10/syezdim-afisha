import type { Metadata } from "next";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { Select } from "@/components/ui/Input";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { WEEKDAY_LABELS, calendarHref, monthGrid } from "@/data/calendar";
import { getDailyCounts, listEvents } from "@/data/events";
import type { RawParams } from "@/data/filters";
import { CITIES, cityLocative, cityName, isCitySlug, type CitySlug } from "@/lib/cities";
import { cn } from "@/lib/cn";
import { dayMonthLong, dayNumber, monthYearLong } from "@/lib/format";
import { addMonths, isoDayMsk, parseDayMsk, startOfDayMsk, startOfMonthMsk } from "@/lib/time";

const DAY_SIZE = 12; // размер выдачи дня — у демо-данных на день редко больше нескольких событий

function parseCalendarParams(raw: RawParams, now: Date): { selected: Date; city?: CitySlug } {
  const dateRaw = Array.isArray(raw.date) ? raw.date[0] : raw.date;
  const cityRaw = Array.isArray(raw.city) ? raw.city[0] : raw.city;
  const selected = (dateRaw && parseDayMsk(dateRaw)) || startOfDayMsk(now);
  return { selected, city: cityRaw && isCitySlug(cityRaw) ? cityRaw : undefined };
}

export function calendarMetadata(): Metadata {
  return {
    title: "Календарь",
    description: "Афиша по дням: выберите дату и город — увидите, что проходит в этот день в городах Черноземья.",
  };
}

export async function Calendar({ searchParams }: { searchParams: RawParams }) {
  const now = new Date();
  const { selected, city } = parseCalendarParams(searchParams, now);
  const selectedIso = isoDayMsk(selected);
  const monthStart = startOfMonthMsk(selected);
  const today = startOfDayMsk(now);
  const grid = monthGrid(monthStart);

  const [counts, day] = await Promise.all([
    getDailyCounts({ from: grid[0].date, to: addDaysExclusive(grid) }, city),
    listEvents({ date: selectedIso, city, sort: "date", pageSize: DAY_SIZE }),
  ]);

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Календарь" }]} className="mb-6" />
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="type-h2">Календарь событий</h1>
        <form action="/calendar" className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="date" value={selectedIso} />
          <Select label="Город" name="city" defaultValue={city ?? ""} className="min-w-0 flex-1 sm:w-48 sm:flex-none">
            <option value="">Все города</option>
            {CITIES.map((c) => (
              <option key={c.slug} value={c.slug}>
                {c.name}
              </option>
            ))}
          </Select>
          <Button type="submit" variant="secondary">
            Показать
          </Button>
        </form>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[22rem_1fr]">
        <div className="rounded-xl bg-white p-5 shadow-soft lg:sticky lg:top-24 lg:self-start">
          <div className="flex items-center justify-between">
            <Link
              href={calendarHref({ city, date: isoDayMsk(addMonths(monthStart, -1)) })}
              aria-label="Предыдущий месяц"
              className="focus-ring inline-flex size-9 items-center justify-center rounded-full text-choco hover:bg-cream"
            >
              <ChevronLeft className="size-5" aria-hidden />
            </Link>
            <p className="type-h6">{monthYearLong(monthStart)}</p>
            <Link
              href={calendarHref({ city, date: isoDayMsk(addMonths(monthStart, 1)) })}
              aria-label="Следующий месяц"
              className="focus-ring inline-flex size-9 items-center justify-center rounded-full text-choco hover:bg-cream"
            >
              <ChevronRight className="size-5" aria-hidden />
            </Link>
          </div>

          <div className="mt-4 grid grid-cols-7 gap-1 text-center text-xs font-semibold text-muted" aria-hidden>
            {WEEKDAY_LABELS.map((w) => (
              <span key={w}>{w}</span>
            ))}
          </div>
          <div role="grid" aria-label="Дни месяца" className="mt-1 grid grid-cols-7 gap-1">
            {grid.map((cell) => {
              const n = counts.get(cell.iso) ?? 0;
              const isSelected = cell.iso === selectedIso;
              const isToday = cell.date.getTime() === today.getTime();
              return (
                <Link
                  key={cell.iso}
                  href={calendarHref({ city, date: cell.iso })}
                  aria-current={isSelected ? "date" : undefined}
                  aria-label={n > 0 ? `${dayMonthLong(cell.iso)}: ${n} ${n === 1 ? "событие" : "события"}` : dayMonthLong(cell.iso)}
                  className={cn(
                    "focus-ring flex aspect-square flex-col items-center justify-center gap-0.5 rounded-md text-sm font-semibold transition duration-200",
                    !cell.inMonth && "text-line",
                    cell.inMonth && !isSelected && "text-ink hover:bg-cream",
                    isSelected && "bg-brick text-white",
                    isToday && !isSelected && "ring-2 ring-inset ring-mustard",
                  )}
                >
                  {dayNumber(cell.date)}
                  <span aria-hidden className={cn("size-1.5 rounded-full", n > 0 ? (isSelected ? "bg-white" : "bg-brick") : "bg-transparent")} />
                </Link>
              );
            })}
          </div>
        </div>

        <div>
          <h2 className="type-h4 mb-5">
            {dayMonthLong(selectedIso)}
            {city && `, ${cityLocative(city)}`}
          </h2>
          {day.items.length > 0 ? (
            <ul className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {day.items.map((event) => (
                <li key={event.slug}>
                  <EventCard
                    event={city ? event : { ...event, subtitle: `${cityName(event.city)} · ${event.subtitle}` }}
                    actions="buy-more"
                    className="h-full"
                  />
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState
              title="В этот день ничего не запланировано"
              description="Выберите другую дату в календаре слева или посмотрите полный каталог событий."
              action={
                <Button href={city ? `/${city}/events` : "/events"} variant="secondary">
                  Смотреть все события
                </Button>
              }
            />
          )}
        </div>
      </div>
    </div>
  );
}

/** Конец сетки месяца (день после последней ячейки) — верхняя граница диапазона для getDailyCounts */
function addDaysExclusive(grid: ReturnType<typeof monthGrid>): Date {
  const last = grid.at(-1)!.date;
  return new Date(last.getTime() + 24 * 60 * 60 * 1000);
}
