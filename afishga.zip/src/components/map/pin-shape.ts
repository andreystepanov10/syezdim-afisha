// Форма метки — общая для React-компонента <MapPin> и для иконок Leaflet (нужна строка SVG)
export const PIN_PATH = "M16 1C7.7 1 1 7.5 1 15.6 1 26.8 16 41 16 41s15-14.2 15-25.4C31 7.5 24.3 1 16 1z";

/** SVG-разметка метки: active — brick с светлой точкой, иначе cream с brick-точкой */
export function pinSvg(active = true): string {
  const fill = active ? "#B54A2B" : "#F5E6C8";
  const dot = active ? "#FBF5E9" : "#B54A2B";
  return (
    `<svg viewBox="0 0 32 42" width="32" height="42" aria-hidden="true" focusable="false" style="display:block;filter:drop-shadow(0 3px 3px rgb(26 15 8 / .3))">` +
    `<path d="${PIN_PATH}" fill="${fill}" stroke="#1A0F08" stroke-width="1.8"/>` +
    `<circle cx="16" cy="15.5" r="5.5" fill="${dot}" stroke="#1A0F08" stroke-width="1.5"/></svg>`
  );
}
