"use client";

// Карта на Leaflet + плитки OpenStreetMap (ключ не нужен). Подключается только на клиенте и лениво —
// см. PopularMap. Позже слой можно заменить на Яндекс.Карты, не трогая остальной код.
import L from "leaflet";
import "leaflet.markercluster";
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster/dist/MarkerCluster.css";
import { useEffect, useRef } from "react";
import { dateShort, plural, priceLabel } from "@/lib/format";
import type { MapVenue } from "@/lib/types";
import { pinSvg } from "./pin-shape";

const OSM_ATTRIBUTION =
  '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">Участники OpenStreetMap</a>';

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, text?: string) {
  const node = document.createElement(tag);
  node.className = className;
  if (text) node.textContent = text; // textContent, а не innerHTML: названия приходят из админки
  return node;
}

/** Содержимое попапа: площадка и до трёх ближайших событий */
function buildPopup(venue: MapVenue): HTMLElement {
  const root = el("div", "p-3");
  root.append(el("p", "pr-9 font-display text-sm font-bold text-ink", venue.name));
  const list = el("ul", "mt-2 space-y-1");
  for (const e of venue.events.slice(0, 3)) {
    const item = el("li", "");
    const link = el("a", "focus-ring flex items-center gap-3 rounded-md p-1 transition hover:bg-cream");
    link.href = `/events/${e.slug}`;
    if (e.image) {
      const img = el("img", "size-14 shrink-0 rounded-sm object-cover");
      img.src = e.image;
      img.alt = "";
      img.width = 56;
      img.height = 56;
      link.append(img);
    }
    const text = el("span", "min-w-0");
    text.append(el("span", "line-clamp-2 block text-[13px] font-semibold leading-tight text-ink", e.title));
    text.append(el("span", "mt-0.5 block text-xs text-muted", `${dateShort(e.startsAt)} · ${priceLabel(e.priceFrom)}`));
    link.append(text);
    item.append(link);
    list.append(item);
  }
  root.append(list);
  if (venue.events.length > 3) root.append(el("p", "mt-1 px-1 text-xs text-muted", `и ещё ${venue.events.length - 3}`));
  return root;
}

const pinIcon = L.divIcon({
  className: "radius-pin",
  html: pinSvg(true),
  iconSize: [32, 42],
  iconAnchor: [16, 41],
  popupAnchor: [0, -38],
});

export default function LeafletMap({ venues, className, fitMaxZoom = 8 }: { venues: MapVenue[]; className?: string; fitMaxZoom?: number }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = ref.current;
    if (!container || venues.length === 0) return;

    const map = L.map(container, { zoomControl: false, attributionControl: false, scrollWheelZoom: false, minZoom: 6, maxZoom: 16 });
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: OSM_ATTRIBUTION }).addTo(map);
    L.control.attribution({ prefix: false }).addTo(map);
    L.control.zoom({ position: "bottomright", zoomInTitle: "Приблизить", zoomOutTitle: "Отдалить" }).addTo(map);

    // Колесо мыши масштабирует карту только когда она в фокусе — иначе страница «залипает» при прокрутке
    map.on("focus", () => map.scrollWheelZoom.enable());
    map.on("blur", () => map.scrollWheelZoom.disable());
    map.on("popupopen", (e) => e.popup.getElement()?.querySelector(".leaflet-popup-close-button")?.setAttribute("aria-label", "Закрыть"));

    const cluster = L.markerClusterGroup({
      showCoverageOnHover: false,
      maxClusterRadius: 60,
      iconCreateFunction: (group) => {
        const total = group.getAllChildMarkers().reduce((sum, m) => sum + ((m.options as { eventCount?: number }).eventCount ?? 1), 0);
        return L.divIcon({
          className: "radius-cluster",
          iconSize: [48, 48],
          html:
            `<span class="inline-flex size-12 items-center justify-center rounded-full border-[3px] border-cream bg-olive-strong font-display text-base font-extrabold text-white shadow-medium">` +
            `<span class="sr-only">Событий: </span>${total}</span>`,
        });
      },
    });

    for (const venue of venues) {
      const count = venue.events.length;
      const marker = L.marker([venue.lat, venue.lon], {
        icon: pinIcon,
        title: `${venue.name}: ${count} ${plural(count, ["событие", "события", "событий"])}`,
        eventCount: count,
      } as L.MarkerOptions);
      marker.bindPopup(buildPopup(venue), { maxWidth: 320 });
      cluster.addLayer(marker);
    }
    map.addLayer(cluster);
    map.fitBounds(L.latLngBounds(venues.map((v) => [v.lat, v.lon] as [number, number])), { padding: [56, 56], maxZoom: fitMaxZoom });

    return () => {
      map.remove();
    };
  }, [venues, fitMaxZoom]);

  return <div ref={ref} className={`radius-map ${className ?? ""}`} role="region" aria-label="Карта событий Черноземья" />;
}
