import { cn } from "@/lib/cn";
import { plural } from "@/lib/format";
import { PIN_PATH } from "./pin-shape";

/** Метка на карте. active — выбранная (brick, крупнее), иначе cream с brick-центром */
export function MapPin({ active = false, label, className }: { active?: boolean; label?: string; className?: string }) {
  return (
    <svg
      viewBox="0 0 32 42"
      width={32}
      height={42}
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      className={cn("drop-shadow-[0_3px_3px_rgb(26_15_8/0.3)] transition duration-200", active && "scale-110", className)}
    >
      <path d={PIN_PATH} fill={active ? "#B54A2B" : "#F5E6C8"} stroke="#1A0F08" strokeWidth="1.8" />
      <circle cx="16" cy="15.5" r="5.5" fill={active ? "#FBF5E9" : "#B54A2B"} stroke="#1A0F08" strokeWidth="1.5" />
    </svg>
  );
}

/** Кластер меток: кружок с числом событий */
export function MapCluster({ count, className }: { count: number; className?: string }) {
  return (
    <span
      role="img"
      aria-label={`${count} ${plural(count, ["событие", "события", "событий"])}`}
      className={cn(
        "inline-flex size-12 items-center justify-center rounded-full border-[3px] border-cream bg-olive-strong font-display text-base font-extrabold text-white shadow-medium",
        className,
      )}
    >
      {count}
    </span>
  );
}
