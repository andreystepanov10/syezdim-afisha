"use client";

// Карта одной площадки (страница события): один маркер, без кластеризации — в отличие от LeafletMap
// (главная), которому нужно показать сразу много площадок по всем городам.
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useRef } from "react";
import { cn } from "@/lib/cn";
import { pinSvg } from "./pin-shape";

const OSM_ATTRIBUTION =
  '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">Участники OpenStreetMap</a>';

const pinIcon = L.divIcon({
  className: "radius-pin",
  html: pinSvg(true),
  iconSize: [32, 42],
  iconAnchor: [16, 41],
  popupAnchor: [0, -38],
});

export default function VenueMap({ lat, lon, name, className }: { lat: number; lon: number; name: string; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = ref.current;
    if (!container) return;

    const map = L.map(container, { zoomControl: false, attributionControl: false, scrollWheelZoom: false, minZoom: 11, maxZoom: 18 });
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: OSM_ATTRIBUTION }).addTo(map);
    L.control.attribution({ prefix: false }).addTo(map);
    L.control.zoom({ position: "bottomright", zoomInTitle: "Приблизить", zoomOutTitle: "Отдалить" }).addTo(map);
    // Колесо мыши масштабирует карту только когда она в фокусе — иначе страница «залипает» при прокрутке
    map.on("focus", () => map.scrollWheelZoom.enable());
    map.on("blur", () => map.scrollWheelZoom.disable());

    map.setView([lat, lon], 16);
    // textContent, а не innerHTML: название площадки приходит из админки
    const popup = document.createElement("p");
    popup.className = "p-1 font-display text-sm font-bold text-ink";
    popup.textContent = name;
    L.marker([lat, lon], { icon: pinIcon, title: name }).addTo(map).bindPopup(popup);

    return () => {
      map.remove();
    };
  }, [lat, lon, name]);

  return <div ref={ref} className={cn("radius-map", className)} role="region" aria-label={`Карта: ${name}`} />;
}
