import { Suspense } from "react";
import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { SlidersHorizontal } from "lucide-react";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { EmptyState } from "@/components/ui/EmptyState";
import { SearchInput } from "@/components/ui/Input";
import { Breadcrumbs, Pagination } from "@/components/ui/Navigation";
import { EventCardSkeleton, Skeleton } from "@/components/ui/Skeleton";
import { catalogHref, searchHref } from "@/data/catalog-url";
import { listEvents } from "@/data/events";
import { parseFilters, type RawParams } from "@/data/filters";
import { CATEGORIES } from "@/lib/categories";
import { cityName } from "@/lib/cities";
import { plural } from "@/lib/format";

const PAGE_SIZE = 12;

/** Из параметров адреса нас интересуют только запрос и страница — остальное поиск не принимает */
function searchQuery(raw: RawParams): { q: string; page: number } {
  const parsed = parseFilters(raw, { strict: false });
  const f = parsed.ok ? parsed.value : {};
  return { q: f.q ?? "", page: f.page ?? 1 };
}

export function searchMetadata(raw: RawParams): Metadata {
  const { q } = searchQuery(raw);
  return {
    title: q ? `Поиск: «${q}»` : "Поиск",
    description: "Поиск концертов, спектаклей, выставок и других событий в городах Черноземья.",
    // Выдача дублирует каталог с тем же q — индексируем только пустой стартовый экран
    robots: { index: !q, follow: true },
  };
}

/** Страница поиска: строка запроса + результаты по всем городам сразу. Без запроса — подсказки по категориям */
export function Search({ searchParams }: { searchParams: RawParams }) {
  const { q, page } = searchQuery(searchParams);

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Поиск" }]} className="mb-6" />
      <h1 className="type-h2 mb-6">Поиск</h1>

      <form action="/search" role="search" aria-label="Поиск по афише" className="flex flex-col gap-3 sm:flex-row">
        <SearchInput
          name="q"
          aria-label="Что ищем?"
          placeholder="Название, площадка или исполнитель"
          defaultValue={q}
          autoComplete="off"
          autoFocus={!q}
          className="flex-1"
        />
        <Button type="submit" fullWidth className="sm:w-auto sm:min-w-32">
          Найти
        </Button>
      </form>

      <div className="mt-10">
        {q ? (
          <Suspense key={searchHref({ q, page })} fallback={<ResultsSkeleton />}>
            <Results q={q} page={page} />
          </Suspense>
        ) : (
          <Suggestions />
        )}
      </div>
    </div>
  );
}

function Suggestions() {
  return (
    <div>
      <h2 className="type-h5 mb-4">Ищите по категориям</h2>
      <ul className="flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <li key={c.slug}>
            <Chip href={catalogHref({ category: [c.slug] })}>{c.name}</Chip>
          </li>
        ))}
      </ul>
    </div>
  );
}

async function Results({ q, page }: { q: string; page: number }) {
  const result = await listEvents({ q, sort: "relevance", page, pageSize: PAGE_SIZE });
  // Страница за концом выдачи (сменился запрос из старой ссылки) — ведём на последнюю, а не показываем «ничего нет»
  if (result.items.length === 0 && result.total > 0) redirect(searchHref({ q, page: result.pageCount }));

  return (
    <section aria-label="Результаты поиска">
      <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3">
        <p className="font-display font-semibold text-ink" aria-live="polite">
          {result.total > 0
            ? `Найдено ${result.total} ${plural(result.total, ["событие", "события", "событий"])} по запросу «${q}»`
            : `Ничего не найдено по запросу «${q}»`}
        </p>
        {result.total > 0 && (
          <Button href={catalogHref({ q })} variant="ghost" iconRight={<SlidersHorizontal className="size-4" aria-hidden />}>
            Уточнить фильтрами
          </Button>
        )}
      </div>

      {result.items.length > 0 ? (
        <>
          <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {result.items.map((event) => (
              <li key={event.slug}>
                <EventCard event={{ ...event, subtitle: `${cityName(event.city)} · ${event.subtitle}` }} actions="buy-more" className="h-full" />
              </li>
            ))}
          </ul>
          <Pagination page={result.page} pageCount={result.pageCount} hrefFor={(p) => searchHref({ q, page: p })} className="mt-10 justify-center" />
        </>
      ) : (
        <EmptyState
          className="mt-8"
          title="Ничего не нашлось"
          description="Проверьте, нет ли опечатки, попробуйте другое слово или посмотрите каталог событий целиком."
          action={
            <Button href="/events" variant="secondary">
              Смотреть все события
            </Button>
          }
        />
      )}
    </section>
  );
}

function ResultsSkeleton() {
  return (
    <div role="status" aria-label="Идёт поиск">
      <Skeleton className="h-6 w-64" />
      <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }, (_, i) => (
          <li key={i}>
            <EventCardSkeleton decorative />
          </li>
        ))}
      </ul>
    </div>
  );
}
