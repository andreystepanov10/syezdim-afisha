"use client";

import { ArrowRight } from "lucide-react";
import { CollectionTile } from "@/components/cards/MoreCards";
import { Button } from "@/components/ui/Button";
import { cityLocative, type CitySlug } from "@/lib/cities";
import { useCity } from "@/lib/city-store";
import type { HomeData } from "@/lib/types";
import { SectionHeader } from "./SectionHeader";

/**
 * «Подборки»: шесть тематических списков выбранного города («На выходных», «Бесплатно», «С детьми»…).
 * Раньше здесь были редакционные подборки — их одна, и блок выглядел пустым. Город — из общего переключателя.
 */
export function CollectionsSection({ byCity }: { byCity: HomeData["autoCollectionsByCity"] }) {
  const city: CitySlug = useCity();
  const collections = byCity[city] ?? [];
  if (collections.length === 0) return null;
  return (
    <section aria-labelledby="collections-title" className="container-page py-10 md:py-14">
      <SectionHeader
        id="collections-title"
        title={`Подборки ${cityLocative(city)}`}
        description="Нет плана? Готовые списки событий по теме — обновляются каждый день."
        action={
          <Button href={`/collections?city=${city}`} variant="secondary" iconRight={<ArrowRight className="size-4" aria-hidden />}>
            Все подборки
          </Button>
        }
      />
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-5">
        {collections.map((c) => (
          <li key={c.slug}>
            <CollectionTile title={c.title} href={c.href} image={c.image} count={c.count} />
          </li>
        ))}
      </ul>
    </section>
  );
}
