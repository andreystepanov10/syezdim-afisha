import type { ReactNode } from "react";

/** Заголовок секции главной: H2, необязательное пояснение и действие справа («Все события») */
export function SectionHeader({ id, title, description, action }: { id: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-x-6 gap-y-3 md:mb-8">
      <div className="min-w-0">
        <h2 id={id} className="type-h3">
          {title}
        </h2>
        {description && <p className="mt-1 max-w-2xl text-muted">{description}</p>}
      </div>
      {action}
    </div>
  );
}
