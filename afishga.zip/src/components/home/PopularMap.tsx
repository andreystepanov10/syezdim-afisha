"use client";

import dynamic from "next/dynamic";
import type { MapVenue } from "@/lib/types";
import { useLazyVisible } from "@/lib/use-lazy-visible";
import { SectionHeader } from "./SectionHeader";

function MapPlaceholder() {
  return (
    <div role="status" className="grid h-full place-items-center bg-[linear-gradient(135deg,var(--color-beige),var(--color-cream))] text-muted">
      Загружаем карту…
    </div>
  );
}

// Leaflet работает только в браузере, поэтому грузим его отдельным куском и только когда блок приближается к экрану
const LeafletMap = dynamic(() => import("@/components/map/LeafletMap"), { ssr: false, loading: () => <MapPlaceholder /> });

export function PopularMap({ venues }: { venues: MapVenue[] }) {
  const { ref, visible } = useLazyVisible<HTMLDivElement>();

  return (
    <section aria-labelledby="map-title" className="container-page py-10 md:py-14">
      <SectionHeader
        id="map-title"
        title="Популярные события на карте"
        description="Нажмите на метку — увидите события площадки. Цифра в кружке — сколько событий рядом."
      />
      {/* isolate: у Leaflet внутри свои z-index до 1000, они не должны перекрывать шапку и модальные окна */}
      <div ref={ref} className="isolate h-[22rem] overflow-hidden rounded-xl border border-line bg-beige shadow-soft md:h-[30rem]">
        {visible ? <LeafletMap venues={venues} className="h-full w-full" /> : <MapPlaceholder />}
      </div>
      <p className="sr-only">Все события с карты также перечислены в списках на этой странице и в каталоге.</p>
    </section>
  );
}
