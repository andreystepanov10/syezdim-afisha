"use client";

import { ArrowRight } from "lucide-react";
import { SmallCard } from "@/components/cards/MoreCards";
import { Button } from "@/components/ui/Button";
import { Carousel } from "@/components/ui/Carousel";
import { catalogHref } from "@/data/catalog-url";
import { cityName, type CitySlug } from "@/lib/cities";
import { useCity } from "@/lib/city-store";
import type { EventSummary } from "@/lib/types";
import { SectionHeader } from "./SectionHeader";

// Ширина карточки: на телефоне ~2.3 (виден «хвост» следующей), дальше 3 / 4 / 5 в видимой области
const ITEM = "w-[42%] sm:w-[30%] md:w-[calc((100%-2.5rem)/3)] lg:w-[calc((100%-3.75rem)/4)] xl:w-[calc((100%-5rem)/5)]";

/** «Предстоящие выставки» выбранного города — лента карточек с прокруткой */
export function UpcomingExhibitions({ byCity }: { byCity: Record<CitySlug, EventSummary[]> }) {
  const city = useCity();
  const items = byCity[city] ?? [];
  if (items.length === 0) return null;
  return (
    <section aria-labelledby="expo-title" className="container-page py-10 md:py-14">
      <SectionHeader
        id="expo-title"
        title="Предстоящие выставки"
        description={`Ближайшие выставки: ${cityName(city)}`}
        action={
          <Button href={catalogHref({ city, category: ["exhibitions"] })} variant="secondary" iconRight={<ArrowRight className="size-4" aria-hidden />}>
            Все выставки
          </Button>
        }
      />
      <Carousel label="Предстоящие выставки" itemClassName={ITEM}>
        {items.map((event) => (
          <SmallCard key={event.slug} event={event} className="h-full" />
        ))}
      </Carousel>
    </section>
  );
}
