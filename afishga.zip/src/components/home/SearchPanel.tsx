"use client";

import { useId, useState } from "react";
import type { FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { QUICK_WHEN, catalogHref, type QuickWhen } from "@/data/catalog-url";
import type { EventFilters } from "@/data/filters";
import { CATEGORIES, type CategorySlug } from "@/lib/categories";
import { CITIES, isCitySlug } from "@/lib/cities";
import { setCity, useCity } from "@/lib/city-store";
import { cn } from "@/lib/cn";

const WHEN = [
  { value: "today", label: "Сегодня" },
  { value: "tomorrow", label: "Завтра" },
  { value: "weekend", label: "На выходных" },
  { value: "date", label: "Выбрать дату…" },
] as const;

/**
 * Панель поиска из макета: «Что ищем?», «Когда?», город, категория и кнопка «Найти».
 * Без JavaScript это обычная GET-форма на /events (город из поля ловит редирект на /<город>/events); с JavaScript —
 * сразу переход на /<город>/events с чистым адресом (пустые поля в URL не попадают). Город общий с переключателем в шапке.
 */
export function SearchPanel({ className }: { className?: string }) {
  const router = useRouter();
  const city = useCity();
  const [when, setWhen] = useState("");
  const uid = useId();
  const id = (name: string) => `${uid}-${name}`;

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const text = (key: string) => String(data.get(key) ?? "").trim();
    const filters: EventFilters = {};
    const cityValue = text("city");
    if (isCitySlug(cityValue)) filters.city = cityValue;
    if (text("q")) filters.q = text("q");
    // «Выбрать дату…» — это конкретный день (date), остальные варианты — быстрый выбор (when)
    const whenValue = text("when");
    if (whenValue === "date") {
      if (text("date")) filters.date = text("date");
    } else if ((QUICK_WHEN as readonly string[]).includes(whenValue)) {
      filters.when = whenValue as QuickWhen;
    }
    const categoryValue = text("category");
    if (CATEGORIES.some((c) => c.slug === categoryValue)) filters.category = [categoryValue as CategorySlug];
    router.push(catalogHref(filters));
  };

  return (
    <form
      role="search"
      aria-label="Поиск по афише"
      action="/events"
      onSubmit={onSubmit}
      className={cn("grid grid-cols-2 gap-2 rounded-lg bg-white p-3 shadow-medium md:grid-cols-12", className)}
    >
      <div className="relative col-span-2 md:col-span-5">
        <label htmlFor={id("q")} className="sr-only">
          Что ищем?
        </label>
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted" aria-hidden />
        <input id={id("q")} name="q" type="search" placeholder="Что ищем?" autoComplete="off" className="ui-field pl-11" />
      </div>

      {/* «Когда?»: быстрые варианты, а при «Выбрать дату…» рядом появляется поле даты */}
      <div className={cn("grid gap-2 md:col-span-7", when === "date" ? "col-span-2 grid-cols-2" : "col-span-1 grid-cols-1")}>
        <label htmlFor={id("when")} className="sr-only">
          Когда?
        </label>
        <select id={id("when")} name="when" value={when} onChange={(e) => setWhen(e.target.value)} className="ui-field">
          <option value="">Когда?</option>
          {WHEN.map((w) => (
            <option key={w.value} value={w.value}>
              {w.label}
            </option>
          ))}
        </select>
        {when === "date" && (
          <>
            <label htmlFor={id("date")} className="sr-only">
              Дата события
            </label>
            <input id={id("date")} name="date" type="date" required className="ui-field" />
          </>
        )}
      </div>

      {/* На телефоне город уже выбран в шапке — поле остаётся в форме, но скрыто */}
      <div className="hidden md:col-span-3 md:block">
        <label htmlFor={id("city")} className="sr-only">
          Город
        </label>
        <select
          id={id("city")}
          name="city"
          value={city}
          onChange={(e) => {
            if (isCitySlug(e.target.value)) setCity(e.target.value);
          }}
          className="ui-field"
        >
          {CITIES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <div className={cn("md:col-span-5", when === "date" ? "col-span-2" : "col-span-1")}>
        <label htmlFor={id("category")} className="sr-only">
          Категория
        </label>
        <select id={id("category")} name="category" defaultValue="" className="ui-field">
          <option value="">Категория</option>
          {CATEGORIES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <div className="col-span-2 md:col-span-4">
        <Button type="submit" size="lg" fullWidth className="min-h-12">
          Найти
        </Button>
      </div>
    </form>
  );
}
