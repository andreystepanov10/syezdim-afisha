import Image from "next/image";
import { SearchPanel } from "./SearchPanel";

/**
 * Hero по макету: иллюстрация целиком (без растяжения и обрезки, в родных пропорциях 1815×592),
 * заголовок лежит на «небе» над машиной, панель поиска наплывает на нижний край картинки.
 * На телефоне «неба» мало — заголовок стоит над иллюстрацией на фоне того же цвета.
 */
export function Hero() {
  return (
    <section aria-labelledby="hero-title">
      <div className="bg-sky">
        <div className="relative mx-auto max-w-[1600px] min-[1600px]:[mask-image:linear-gradient(to_right,transparent,#000_5%,#000_95%,transparent)]">
          <div className="container-page pb-4 pt-8 md:absolute md:inset-x-0 md:top-0 md:z-10 md:pb-0 md:pt-8 lg:pt-10 xl:pt-12">
            <h1 id="hero-title" className="type-hero max-w-[15ch] md:max-w-[22ch]">
              Все события Черноземья в одном месте.
            </h1>
          </div>
          <Image
            src="/brand/hero.webp"
            alt=""
            width={1815}
            height={592}
            priority
            sizes="(min-width: 1600px) 1600px, 100vw"
            className="block h-auto w-full"
          />
        </div>
      </div>
      {/* Наплыв на картинку минимальный (12–16px): колёса машины и кончики меток остаются видны */}
      <div className="container-page relative z-20 -mt-3 md:-mt-4">
        <SearchPanel />
      </div>
    </section>
  );
}
