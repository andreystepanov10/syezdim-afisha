"use client";

import { ArrowRight } from "lucide-react";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { catalogHref } from "@/data/catalog-url";
import { cityLocative, type CitySlug } from "@/lib/cities";
import { useCity } from "@/lib/city-store";
import type { EventSummary } from "@/lib/types";
import { SectionHeader } from "./SectionHeader";

/**
 * «Популярные события в {городе}»: 8 карточек на десктопе (4×2), по 6 на планшете и телефоне.
 * Город берётся из общего переключателя, поэтому блок клиентский; данные всех городов приходят с сервера.
 */
export function PopularEvents({ byCity }: { byCity: Record<CitySlug, EventSummary[]> }) {
  const city = useCity();
  const events = byCity[city] ?? [];
  return (
    <section aria-labelledby="popular-title" className="container-page py-10 md:py-14">
      <SectionHeader
        id="popular-title"
        title={`Популярные события ${cityLocative(city)}`}
        action={
          <Button href={catalogHref({ city })} variant="secondary" iconRight={<ArrowRight className="size-4" aria-hidden />}>
            Все события
          </Button>
        }
      />
      {events.length > 0 ? (
        <ul className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 xl:grid-cols-4 [&>li:nth-child(n+7)]:hidden xl:[&>li:nth-child(n+7)]:block">
          {events.map((event) => (
            <li key={event.slug}>
              <EventCard event={event} className="h-full" />
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState title="Пока нет событий" description="Для этого города афиша ещё наполняется — загляните позже или выберите другой город." />
      )}
    </section>
  );
}
