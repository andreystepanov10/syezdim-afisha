import { describe, expect, it } from "vitest";
import { distanceKm, formatDistance } from "./NearMeButton";

describe("distanceKm", () => {
  it("расстояние от точки до самой себя — ноль", () => {
    expect(distanceKm(51.6606, 39.2003, 51.6606, 39.2003)).toBe(0);
  });

  it("Воронеж — Белгород примерно 210 км по прямой", () => {
    const km = distanceKm(51.6606, 39.2003, 50.5997, 36.5983);
    expect(km).toBeGreaterThan(190);
    expect(km).toBeLessThan(230);
  });
});

describe("formatDistance", () => {
  it("до километра — в метрах", () => {
    expect(formatDistance(0.35)).toBe("350 м");
  });

  it("километр и больше — в км с одним знаком после запятой", () => {
    expect(formatDistance(2.34)).toBe("2.3 км");
  });
});
