import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Send, X } from "lucide-react";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { EmptyState } from "@/components/ui/EmptyState";
import { Breadcrumbs, Pagination, type Crumb } from "@/components/ui/Navigation";
import { SORT_LABELS, activeFilters, catalogHref, defaultSort, filterCount, sortOptions } from "@/data/catalog-url";
import { getLocalities, getVenueName, listEvents } from "@/data/events";
import { parseFilters, type EventFilters, type RawParams } from "@/data/filters";
import { categoryGenitive, categoryName } from "@/lib/categories";
import { cityGenitive, cityLocative, cityName, type CitySlug } from "@/lib/cities";
import { plural } from "@/lib/format";
import { socialLinks } from "@/lib/social";
import { CatalogFilters } from "./CatalogFilters";
import { cityArt } from "@/lib/art";
import { CitySync } from "./CitySync";
import { LandingLinks } from "./Landing";

/** События на странице каталога (3 колонки × 4 ряда) */
const PAGE_SIZE = 12;

/**
 * Фильтры страницы каталога: параметры адреса + город из пути (/voronezh/events).
 * Некорректные параметры молча отбрасываются — страница открывается всегда; размер страницы задаёт сайт, а не адрес.
 */
export function catalogFilters(raw: RawParams, city?: CitySlug): EventFilters {
  const parsed = parseFilters(raw, { strict: false });
  const base: EventFilters = parsed.ok ? parsed.value : {};
  return { ...base, city, pageSize: PAGE_SIZE };
}

/** Если выбрана ровно одна категория — заголовок и описание должны говорить именно про неё, а не общими словами */
function singleCategory(f: EventFilters) {
  return f.category?.length === 1 ? f.category[0] : null;
}

// Заголовок = <title> и H1 страницы одновременно: «Афиша Воронежа» / «Концерты в Воронеже» — так реально ищут
// в Яндексе/Google (в отличие от нейтрального «События Воронежа», которое никто не вводит в поиске).
function heading(f: EventFilters) {
  if (f.q) return `Поиск: «${f.q}»`;
  const cat = singleCategory(f);
  if (cat) return f.city ? `${categoryName(cat)} ${cityLocative(f.city)}` : `${categoryName(cat)} в Черноземье`;
  return f.city ? `Афиша ${cityGenitive(f.city)}` : "Афиша Черноземья";
}

export function catalogMetadata(raw: RawParams, city?: CitySlug): Metadata {
  const f = catalogFilters(raw, city);
  const cat = singleCategory(f);
  const description = cat
    ? `Афиша ${categoryGenitive(cat)}${f.city ? ` ${cityLocative(f.city)}` : " в городах Черноземья"}: даты, цены, ссылки на билеты у партнёров.`
    : f.city
      ? `Куда сходить ${cityLocative(f.city)} и области: афиша концертов, спектаклей, кино, выставок и фестивалей. Фильтры по дате, цене и категории, ссылки на билеты у партнёров.`
      : "Куда сходить в городах Черноземья: афиша концертов, спектаклей, выставок и фестивалей в Воронеже, Белгороде, Курске, Липецке, Тамбове и Орле.";
  return {
    title: heading(f),
    description,
    // В индекс — только чистые списки города: поиск, фильтры, сортировка и вторые страницы дают дубли.
    // Одна категория без города в пути (?category=concerts) тоже не индексируем — у неё есть красивый адрес-двойник
    // (/город/events/категория, см. app/[city]/events/[category]), нельзя пускать в индекс оба сразу.
    robots: { index: filterCount(f) === 0 && !f.sort && (f.page ?? 1) === 1, follow: true },
    // Канонический адрес — чистый список без фильтров: склеивает дубли с ?page=, ?sort= и т. п.
    alternates: { canonical: f.city ? `/${f.city}/events` : "/events" },
  };
}

/**
 * Страница каталога (/events — все города, /<город>/events — один город): шапка, панель фильтров и выдача.
 * Шапка и фильтры показываются сразу, выдача подгружается вслед за ними.
 */
export function Catalog({ city, searchParams }: { city?: CitySlug; searchParams: RawParams }) {
  const filters = catalogFilters(searchParams, city);
  return (
    <>
      {city && <CitySync city={city} />}
      <CatalogHeader filters={filters} />
      {/* Панель фильтров наплывает на нижний край шапки, как в макете */}
      <div className="container-page relative z-20 -mt-14 pb-16 md:-mt-16 md:pb-20">
        <CatalogFilters filters={filters} />
        {/* Без Suspense: иначе выдача приходит отдельным потоком в <div hidden> и переносится скриптом — робот Яндекса
            видел страницу без событий и признал страницы городов «малоценными». Запрос к базе быстрый, ждать его не страшно */}
        <Results filters={filters} />
      </div>
    </>
  );
}

async function CatalogHeader({ filters }: { filters: EventFilters }) {
  // На чистой странице города — ссылки на посадочные «Сегодня / На выходных» и города области (по ним их находит робот)
  const localities = filters.city && filterCount(filters) === 0 ? await getLocalities(filters.city) : null;
  const crumbs: Crumb[] = [{ label: "Главная", href: "/" }];
  if (filters.city) crumbs.push({ label: "События", href: "/events" }, { label: cityName(filters.city) });
  else crumbs.push({ label: "События" });
  // Telegram-канал есть только у Воронежа — показываем его на странице этого города
  const telegram = filters.city === "voronezh" ? socialLinks().telegram : null;

  return (
    <section aria-labelledby="catalog-title" className="relative overflow-hidden bg-sky">
      <div className="container-page relative z-10 pb-16 pt-6 md:pb-24 md:pt-8 lg:pb-28">
        <Breadcrumbs items={crumbs} />
        <h1 id="catalog-title" className="type-h2 mt-3 md:mt-5 md:max-w-[60%]">
          {heading(filters)}
        </h1>
        {filters.city && localities && <LandingLinks city={filters.city} localities={localities} className="relative z-10 mt-4 md:max-w-[60%]" />}
        {telegram && (
          <Button href={telegram.href} external size="sm" iconLeft={<Send className="size-4" aria-hidden />} className="mt-5">
            Афиша Воронежа в Telegram
          </Button>
        )}
      </div>
      {/* Силуэт города и метка из hero (scripts/make-skyline.mjs): стоит на верхнем краю панели фильтров (наплыв панели —
          4rem, поэтому bottom-16) и слева растворяется в цвет «неба». Высота — по шапке, но не больше натуральной (298px): раньше картинка тянулась на всю
          высоту шапки и, когда под заголовком появились ссылки и кнопка Telegram, раздувалась и обрезалась справа */}
      <Image
        src={(filters.city && cityArt(filters.city)) || "/brand/skyline.webp"}
        alt=""
        width={filters.city && cityArt(filters.city) ? 1600 : 715}
        height={filters.city && cityArt(filters.city) ? 686 : 298}
        sizes="(min-width: 1280px) 715px, 45vw"
        className="pointer-events-none absolute bottom-16 right-0 hidden h-[calc(100%-4rem)] max-h-[298px] w-auto max-w-[45%] object-contain object-right-bottom [mask-image:linear-gradient(to_right,transparent,#000_35%)] md:block"
      />
    </section>
  );
}

async function Results({ filters }: { filters: EventFilters }) {
  const [result, venueName] = await Promise.all([listEvents({ ...filters, groupSessions: true }), filters.venue ? getVenueName(filters.venue) : Promise.resolve(null)]);
  // Страница за концом выдачи (после смены фильтров, из старой ссылки) — ведём на последнюю, а не показываем «ничего нет»
  if (result.items.length === 0 && result.total > 0) redirect(catalogHref({ ...filters, page: result.pageCount }));

  const chips = activeFilters(filters, { venueName });
  const resetHref = catalogHref({ city: filters.city });
  const showCity = !filters.city;

  return (
    <section aria-label="Результаты" className="mt-8">
      <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3">
        <p className="font-display font-semibold text-ink" aria-live="polite">
          {result.total > 0 ? `Найдено ${result.total} ${plural(result.total, ["событие", "события", "событий"])}` : "Ничего не найдено"}
        </p>
        {result.total > 0 && <SortLinks filters={filters} />}
      </div>

      {chips.length > 0 && (
        <ul className="mt-4 flex flex-wrap items-center gap-2" aria-label="Выбранные фильтры">
          {chips.map((chip) => (
            <li key={chip.key}>
              <Chip href={chip.href} active aria-label={`Убрать фильтр: ${chip.label}`}>
                {chip.label}
                <X className="size-3.5" aria-hidden />
              </Chip>
            </li>
          ))}
          {filterCount(filters) > 1 && (
            <li>
              <Link href={resetHref} className="focus-ring inline-flex min-h-11 items-center rounded-xs px-2 text-sm font-semibold text-brick underline-offset-4 hover:underline">
                Сбросить все
              </Link>
            </li>
          )}
        </ul>
      )}

      {result.items.length > 0 ? (
        <>
          <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {result.items.map((event) => (
              <li key={event.slug}>
                <EventCard
                  event={showCity ? { ...event, subtitle: `${cityName(event.city)} · ${event.subtitle}` } : event}
                  actions="buy-more"
                  className="h-full"
                />
              </li>
            ))}
          </ul>
          <Pagination
            page={result.page}
            pageCount={result.pageCount}
            hrefFor={(page) => catalogHref({ ...filters, page })}
            className="mt-10 justify-center"
          />
        </>
      ) : (
        <EmptyState
          className="mt-8"
          title="Ничего не нашлось"
          description="Попробуйте изменить запрос, выбрать другую дату или город — рядом наверняка что-то происходит."
          action={
            <div className="flex flex-wrap justify-center gap-3">
              <Button href={resetHref} variant="secondary">
                Сбросить фильтры
              </Button>
              {filters.city && (
                <Button href={catalogHref({ ...filters, city: undefined, page: undefined })} variant="ghost">
                  Искать во всех городах
                </Button>
              )}
            </div>
          }
        />
      )}
    </section>
  );
}

/** Сортировка ссылками (без JavaScript): выбранная подсвечена, порядок по умолчанию в адрес не пишется */
function SortLinks({ filters }: { filters: EventFilters }) {
  const current = filters.sort ?? defaultSort(filters);
  return (
    <nav aria-label="Сортировка" className="flex flex-wrap items-center gap-2">
      <span className="text-sm text-muted max-sm:sr-only">Сортировка:</span>
      {sortOptions(filters).map((option) => (
        <Chip key={option} href={catalogHref({ ...filters, sort: option === defaultSort(filters) ? undefined : option, page: undefined })} active={current === option}>
          {SORT_LABELS[option]}
        </Chip>
      ))}
    </nav>
  );
}
