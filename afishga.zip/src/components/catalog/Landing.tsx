import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { EmptyState } from "@/components/ui/EmptyState";
import { Breadcrumbs, Pagination } from "@/components/ui/Navigation";
import type { EventList, Locality } from "@/data/events";
import { cityName, type CitySlug } from "@/lib/cities";
import { plural } from "@/lib/format";
import { DATE_LANDINGS } from "@/lib/landings";

/**
 * Посадочная страница под поисковый запрос («Куда сходить в Воронеже сегодня», «Старый Оскол: афиша»):
 * заголовок, короткий текст, выдача и перелинковка на соседние посадочные — по этим ссылкам их находит робот.
 */
export function Landing({
  city,
  path,
  title,
  intro,
  list,
  localities,
  activeSlug,
  moreHref,
}: {
  city: CitySlug;
  /** Адрес самой страницы — для пагинации */
  path: string;
  title: string;
  intro: string;
  list: EventList;
  /** Населённые пункты области — ссылки внизу */
  localities: Locality[];
  /** slug текущей посадочной — подсветить в ссылках */
  activeSlug: string;
  /** «Все события» — каталог с фильтрами */
  moreHref: string;
}) {
  return (
    <>
      <section aria-labelledby="landing-title" className="bg-sky">
        <div className="container-page pb-10 pt-6 md:pb-14 md:pt-8">
          <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: cityName(city), href: `/${city}/events` }, { label: title }]} />
          <h1 id="landing-title" className="type-h2 mt-3 md:mt-5 md:max-w-[70%]">
            {title}
          </h1>
          <p className="mt-3 max-w-2xl text-muted">{intro}</p>
          <LandingLinks city={city} localities={localities} activeSlug={activeSlug} className="mt-5" />
        </div>
      </section>

      <div className="container-page pb-16 pt-8 md:pb-20">
        <p className="font-display font-semibold text-ink" aria-live="polite">
          {list.total > 0 ? `${list.total} ${plural(list.total, ["событие", "события", "событий"])}` : "Пока ничего"}
        </p>
        {list.items.length > 0 ? (
          <>
            <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {list.items.map((event) => (
                <li key={event.slug}>
                  <EventCard event={event} actions="buy-more" className="h-full" />
                </li>
              ))}
            </ul>
            <Pagination page={list.page} pageCount={list.pageCount} hrefFor={(page) => (page === 1 ? path : `${path}?page=${page}`)} className="mt-10 justify-center" />
          </>
        ) : (
          <EmptyState
            className="mt-8"
            title="Здесь пока пусто"
            description="Афиша обновляется каждый день — загляните позже или посмотрите все события города."
            action={
              <Button href={moreHref} variant="secondary">
                Все события
              </Button>
            }
          />
        )}
      </div>
    </>
  );
}

/** Ссылки «Сегодня · Завтра · На выходных · На неделе» и города области — на странице города и на посадочных */
export function LandingLinks({
  city,
  localities,
  activeSlug,
  className,
}: {
  city: CitySlug;
  localities: Locality[];
  activeSlug?: string;
  className?: string;
}) {
  return (
    <nav aria-label="Подборки по датам и городам области" className={className}>
      <ul className="flex flex-wrap gap-2">
        {DATE_LANDINGS.map((d) => (
          <li key={d.slug}>
            <Chip href={`/${city}/${d.slug}`} active={d.slug === activeSlug}>
              {d.label}
            </Chip>
          </li>
        ))}
      </ul>
      {localities.length > 0 && (
        <ul className="mt-2 flex flex-wrap gap-2" aria-label="Города области">
          {localities.map((l) => (
            <li key={l.slug}>
              <Chip href={`/${city}/${l.slug}`} active={l.slug === activeSlug} count={l.count}>
                {l.name}
              </Chip>
            </li>
          ))}
        </ul>
      )}
    </nav>
  );
}
