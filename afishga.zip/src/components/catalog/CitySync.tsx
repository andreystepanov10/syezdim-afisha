"use client";

import { useEffect } from "react";
import type { CitySlug } from "@/lib/cities";
import { getCity, setCity } from "@/lib/city-store";

/**
 * Город страницы (/kursk/events) становится городом сайта: шапка, главная и «Популярные события» показывают тот же.
 * Срабатывает, только когда меняется город страницы. Если бы он следил и за cookie, то при выборе другого города
 * в шапке успел бы вернуть старый до перехода на новую страницу.
 */
export function CitySync({ city }: { city: CitySlug }) {
  useEffect(() => {
    if (getCity() !== city) setCity(city);
  }, [city]);
  return null;
}
