"use client";

import { useId, useState, useTransition } from "react";
import type { FormEvent } from "react";
import { useRouter } from "next/navigation";
import { SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Chip, ChipCheckbox } from "@/components/ui/Chip";
import { Switch } from "@/components/ui/Choice";
import { SearchInput, Select } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { RangeSlider } from "@/components/ui/Slider";
import {
  PRICE_SLIDER,
  QUICK_WHEN,
  WHEN_LABELS,
  catalogHref,
  filterCount,
  filtersFromState,
  priceStepLabel,
  stateFromFilters,
  type FilterFormState,
} from "@/data/catalog-url";
import type { EventFilters } from "@/data/filters";
import { CATEGORIES } from "@/lib/categories";
import { CITIES, isCitySlug } from "@/lib/cities";
import { cn } from "@/lib/cn";
import { NearMeButton } from "./NearMeButton";

/**
 * Панель фильтров каталога. На десктопе — карточка над выдачей (как в макете), на телефоне — кнопка «Фильтры»,
 * которая открывает шторку с теми же полями. Применяется кнопкой: собирает чистый адрес и переходит на него.
 * Без JavaScript это обычная GET-форма на /events (город из поля ловит редирект на /<город>/events).
 */
export function CatalogFilters({ filters }: { filters: EventFilters }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const sheetFormId = useId();
  const count = filterCount(filters);
  // Поля панели заново заполняются из адреса, когда выдача перешла на другие фильтры (чип, «Сбросить», назад в истории)
  const formKey = catalogHref(filters);

  const apply = (href: string) => {
    startTransition(() => router.push(href));
    setOpen(false);
  };
  const resetHref = catalogHref({ city: filters.city });

  return (
    <>
      <div className="hidden rounded-xl bg-white p-6 shadow-medium lg:block">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <h2 className="type-h5">Фильтр событий</h2>
          <NearMeButton />
        </div>
        <FilterForm key={`card-${formKey}`} filters={filters} onApply={apply} pending={pending} resetHref={resetHref} />
      </div>

      <div className="flex flex-wrap items-center gap-3 lg:hidden">
        <Button
          variant="ghost"
          className="flex-1"
          aria-haspopup="dialog"
          onClick={() => setOpen(true)}
          iconLeft={<SlidersHorizontal className="size-4" aria-hidden />}
        >
          Фильтры
          {count > 0 && (
            <span aria-label={`выбрано: ${count}`} className="inline-flex size-6 items-center justify-center rounded-full bg-brick text-xs font-bold text-white">
              {count}
            </span>
          )}
        </Button>
        <NearMeButton />
        <Modal
          open={open}
          onClose={() => setOpen(false)}
          title="Фильтры"
          sheet
          footer={
            <>
              <Button href={resetHref} variant="secondary" onClick={() => setOpen(false)}>
                Сбросить
              </Button>
              <Button type="submit" form={sheetFormId} loading={pending} className="min-w-40">
                Показать события
              </Button>
            </>
          }
        >
          <FilterForm
            key={`sheet-${formKey}`}
            id={sheetFormId}
            filters={filters}
            onApply={apply}
            pending={pending}
            resetHref={resetHref}
            hideActions
          />
        </Modal>
      </div>
    </>
  );
}

function FilterForm({
  id,
  filters,
  onApply,
  pending,
  resetHref,
  hideActions,
}: {
  id?: string;
  filters: EventFilters;
  onApply: (href: string) => void;
  pending: boolean;
  resetHref: string;
  hideActions?: boolean;
}) {
  const uid = useId();
  const [s, setS] = useState<FilterFormState>(() => stateFromFilters(filters));
  const patch = (next: Partial<FilterFormState>) => setS((prev) => ({ ...prev, ...next }));

  const submit = (e: FormEvent) => {
    e.preventDefault();
    onApply(catalogHref(filtersFromState(s, filters)));
  };

  return (
    <form id={id} action="/events" role="search" aria-label="Фильтры каталога" onSubmit={submit} className="grid gap-x-6 gap-y-5 lg:grid-cols-12">
      <fieldset className="min-w-0 lg:col-span-12">
        <legend className="mb-2 text-sm font-semibold text-ink">Категория</legend>
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <ChipCheckbox
              key={c.slug}
              name="category"
              value={c.slug}
              checked={s.category.includes(c.slug)}
              onChange={(on) => patch({ category: on ? [...s.category, c.slug] : s.category.filter((x) => x !== c.slug) })}
            >
              {c.name}
            </ChipCheckbox>
          ))}
        </div>
      </fieldset>

      <fieldset className="min-w-0 lg:col-span-5">
        <legend className="mb-2 text-sm font-semibold text-ink">Дата</legend>
        <div className="flex items-center gap-2">
          <label htmlFor={`${uid}-from`} className="sr-only">
            Дата: с
          </label>
          <input
            id={`${uid}-from`}
            name="from"
            type="date"
            className="ui-field min-w-0"
            value={s.from}
            onChange={(e) => patch({ from: e.target.value, when: "" })}
          />
          <span aria-hidden className="text-muted">
            —
          </span>
          <label htmlFor={`${uid}-to`} className="sr-only">
            Дата: по
          </label>
          <input id={`${uid}-to`} name="to" type="date" className="ui-field min-w-0" value={s.to} onChange={(e) => patch({ to: e.target.value, when: "" })} />
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {QUICK_WHEN.map((w) => (
            <Chip key={w} active={s.when === w} onClick={() => patch(s.when === w ? { when: "" } : { when: w, from: "", to: "" })}>
              {WHEN_LABELS[w]}
            </Chip>
          ))}
        </div>
      </fieldset>

      <div className="min-w-0 lg:col-span-4">
        <div inert={s.free} className={cn("transition-opacity duration-200", s.free && "opacity-40")}>
          <RangeSlider
            label="Цена"
            min={PRICE_SLIDER.min}
            max={PRICE_SLIDER.max}
            step={PRICE_SLIDER.step}
            defaultValue={s.price}
            onChange={(price) => patch({ price })}
            format={priceStepLabel}
          />
        </div>
        <Switch label="Только бесплатные" name="free" value="1" checked={s.free} onChange={(e) => patch({ free: e.target.checked })} />
        <Switch
          label="Пушкинская карта"
          name="pushkinCard"
          value="1"
          checked={s.pushkinCard}
          onChange={(e) => patch({ pushkinCard: e.target.checked })}
          className="mt-2"
        />
      </div>

      <Select
        label="Город"
        name="city"
        className="lg:col-span-3"
        value={s.city}
        onChange={(e) => patch({ city: isCitySlug(e.target.value) ? e.target.value : "" })}
      >
        <option value="">Все города</option>
        {CITIES.map((c) => (
          <option key={c.slug} value={c.slug}>
            {c.name}
          </option>
        ))}
      </Select>

      <SearchInput
        label="Название или площадка"
        name="q"
        placeholder="Например, джаз или филармония"
        autoComplete="off"
        className="lg:col-span-8"
        value={s.q}
        onChange={(e) => patch({ q: e.target.value })}
      />

      {!hideActions && (
        <div className="flex flex-wrap items-end gap-3 lg:col-span-4">
          <Button type="submit" loading={pending} className="flex-1">
            Применить фильтры
          </Button>
          <Button href={resetHref} variant="secondary">
            Сбросить
          </Button>
        </div>
      )}
    </form>
  );
}
