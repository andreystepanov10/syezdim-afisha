"use client";

import { useState } from "react";
import { MapPin } from "lucide-react";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { useToast } from "@/components/ui/Toast";
import { cityName } from "@/lib/cities";
import type { EventSummary } from "@/lib/types";

const EARTH_RADIUS_KM = 6371;
const RESULTS_LIMIT = 10;

export function distanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function formatDistance(km: number): string {
  return km < 1 ? `${Math.round(km * 1000)} м` : `${km.toFixed(1)} км`;
}

function isPermissionDenied(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && (error as { code: unknown }).code === 1;
}

type NearbyEvent = EventSummary & { distanceKm: number };

/**
 * «Рядом со мной»: координаты пользователя нигде не сохраняются и на сервер не уходят —
 * расстояние до площадок считается прямо в браузере, на сервер идёт обычный публичный запрос списка событий.
 */
export function NearMeButton() {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<NearbyEvent[] | null>(null);

  async function handleClick() {
    if (!("geolocation" in navigator)) {
      toast({ title: "Геолокация недоступна в этом браузере", variant: "error" });
      return;
    }
    setOpen(true);
    setLoading(true);
    setItems(null);
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 10_000 }),
      );
      const { latitude, longitude } = position.coords;

      const res = await fetch("/api/events?pageSize=48&sort=date");
      if (!res.ok) throw new Error(`events fetch failed: ${res.status}`);
      const data = (await res.json()) as { items: EventSummary[] };

      const withDistance = data.items
        .filter((e): e is EventSummary & { lat: number; lon: number } => e.lat !== undefined && e.lon !== undefined)
        .map((e) => ({ ...e, distanceKm: distanceKm(latitude, longitude, e.lat, e.lon) }))
        .sort((a, b) => a.distanceKm - b.distanceKm)
        .slice(0, RESULTS_LIMIT);
      setItems(withDistance);
    } catch (error) {
      setOpen(false);
      toast({
        title: isPermissionDenied(error) ? "Доступ к геолокации не разрешён" : "Не удалось определить местоположение",
        description: isPermissionDenied(error) ? "Разрешите доступ к местоположению в браузере и попробуйте снова." : undefined,
        variant: "error",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Button type="button" variant="secondary" size="sm" onClick={handleClick} iconLeft={<MapPin className="size-4" aria-hidden />}>
        Рядом со мной
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Рядом со мной" sheet>
        {loading && <p className="text-muted">Определяем ближайшие события…</p>}
        {!loading && items?.length === 0 && <p className="text-muted">Ничего не нашлось поблизости.</p>}
        {!loading && items && items.length > 0 && (
          <ul className="space-y-4">
            {items.map((event) => (
              <li key={event.slug}>
                <EventCard
                  event={{ ...event, subtitle: `${cityName(event.city)} · ${event.subtitle} · ${formatDistance(event.distanceKm)}` }}
                  actions="buy-more"
                />
              </li>
            ))}
          </ul>
        )}
      </Modal>
    </>
  );
}
