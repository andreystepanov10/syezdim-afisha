import Script from "next/script";

/**
 * Счётчик Яндекс Метрики — источники трафика и поисковые запросы, которых нет во внутренней статистике.
 * Включается только переменной YANDEX_METRIKA_ID (номер счётчика): без неё на сайт ничего не грузится.
 * Вебвизор выключен — записи сессий не нужны и лишние данные о посетителях не собираем.
 * Переходы внутри сайта (Next.js без перезагрузки страницы) tag.js учитывает сам — он следит за history.
 * Клик «Купить билет» (ссылки /go/…) — цель buy_ticket: сама /go/ — мгновенная переадресация к кассе, без кода Метрики.
 */
export function YandexMetrika() {
  const id = process.env.YANDEX_METRIKA_ID;
  if (!id || !/^\d+$/.test(id)) return null;

  return (
    <>
      <Script id="yandex-metrika" strategy="afterInteractive">
        {`(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};m[i].l=1*new Date();for(var j=0;j<document.scripts.length;j++){if(document.scripts[j].src===r){return;}}k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})(window,document,"script","https://mc.yandex.ru/metrika/tag.js?id=${id}","ym");ym(${id},"init",{ssr:true,clickmap:true,referrer:document.referrer,url:location.href,accurateTrackBounce:true,trackLinks:true,webvisor:false});document.addEventListener("click",function(e){var a=e.target&&e.target.closest&&e.target.closest('a[href^="/go/"]');if(a)ym(${id},"reachGoal","buy_ticket");},true);`}
      </Script>
      <noscript>
        <div>
          {/* eslint-disable-next-line @next/next/no-img-element -- пиксель Метрики для посетителей без JS */}
          <img src={`https://mc.yandex.ru/watch/${id}`} style={{ position: "absolute", left: "-9999px" }} alt="" />
        </div>
      </noscript>
    </>
  );
}
