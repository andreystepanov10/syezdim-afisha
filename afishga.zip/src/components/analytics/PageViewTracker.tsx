"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

/** Шлёт анонимный маячок просмотра на каждую смену маршрута, кроме /admin (см. src/app/api/track) */
export function PageViewTracker() {
  const pathname = usePathname();

  useEffect(() => {
    if (pathname.startsWith("/admin")) return;
    fetch("/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: pathname }),
      keepalive: true,
    }).catch(() => {});
  }, [pathname]);

  return null;
}
