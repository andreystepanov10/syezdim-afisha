import type { Metadata } from "next";
import { MapPin } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Select } from "@/components/ui/Input";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { catalogHref } from "@/data/catalog-url";
import { getMapVenues, getVenues } from "@/data/events";
import type { RawParams } from "@/data/filters";
import { CITIES, cityLocative, cityName, isCitySlug, type CitySlug } from "@/lib/cities";
import { plural } from "@/lib/format";
import type { VenueSummary } from "@/lib/types";
import { VenuesMap } from "./VenuesMap";

function parseCity(raw: RawParams): CitySlug | undefined {
  const v = Array.isArray(raw.city) ? raw.city[0] : raw.city;
  return v && isCitySlug(v) ? v : undefined;
}

export function venuesMetadata(raw: RawParams): Metadata {
  const city = parseCity(raw);
  return {
    title: "Места",
    description: city
      ? `Площадки ${cityLocative(city)}: концертные залы, театры, музеи и парки — адреса и ближайшие события.`
      : "Площадки Черноземья: концертные залы, театры, музеи и парки — адреса и ближайшие события.",
  };
}

export async function Venues({ searchParams }: { searchParams: RawParams }) {
  const city = parseCity(searchParams);
  const [venues, mapVenues] = await Promise.all([getVenues(city), getMapVenues(city)]);

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Места" }]} className="mb-6" />
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="type-h2">{city ? `Места ${cityLocative(city)}` : "Места"}</h1>
        <form action="/venues" className="flex flex-wrap items-end gap-3">
          <Select label="Город" name="city" defaultValue={city ?? ""} className="min-w-0 flex-1 sm:w-48 sm:flex-none">
            <option value="">Все города</option>
            {CITIES.map((c) => (
              <option key={c.slug} value={c.slug}>
                {c.name}
              </option>
            ))}
          </Select>
          <Button type="submit" variant="secondary">
            Показать
          </Button>
        </form>
      </div>

      {mapVenues.length > 0 && (
        // isolate: у Leaflet внутри свои z-index до 1000, они не должны перекрывать шапку и модальные окна
        <VenuesMap venues={mapVenues} scoped={Boolean(city)} className="isolate mt-6 h-[22rem] overflow-hidden rounded-xl border border-line bg-beige shadow-soft md:h-[26rem]" />
      )}

      <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {venues.map((v) => (
          <li key={v.slug} className="min-w-0">
            <VenueCard venue={v} />
          </li>
        ))}
      </ul>
    </div>
  );
}

function VenueCard({ venue }: { venue: VenueSummary }) {
  return (
    <article className="flex h-full min-w-0 flex-col gap-4 rounded-lg bg-white p-4 shadow-soft transition duration-300 ease-soft hover:-translate-y-1 hover:shadow-hover">
      <div className="flex min-w-0 items-start gap-3">
        <span aria-hidden className="grid size-11 shrink-0 place-items-center rounded-full bg-beige text-brick">
          <MapPin className="size-5" />
        </span>
        <div className="min-w-0">
          <h2 className="type-h6 line-clamp-2">{venue.name}</h2>
          <p className="truncate text-sm text-muted">
            {cityName(venue.city)}
            {venue.address && ` · ${venue.address}`}
          </p>
        </div>
      </div>
      <div className="mt-auto flex min-w-0 items-center justify-between gap-3">
        <span className="min-w-0 truncate text-sm font-semibold text-ink">
          {venue.upcomingCount > 0 ? `${venue.upcomingCount} ${plural(venue.upcomingCount, ["событие", "события", "событий"])}` : "Нет ближайших событий"}
        </span>
        <Button
          href={catalogHref({ city: venue.city, venue: venue.slug })}
          variant="secondary"
          size="sm"
          className="shrink-0"
          disabled={venue.upcomingCount === 0}
        >
          Смотреть
        </Button>
      </div>
    </article>
  );
}
