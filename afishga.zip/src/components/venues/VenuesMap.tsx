"use client";

import dynamic from "next/dynamic";
import type { MapVenue } from "@/lib/types";
import { useLazyVisible } from "@/lib/use-lazy-visible";

function MapPlaceholder() {
  return (
    <div role="status" className="grid h-full place-items-center bg-[linear-gradient(135deg,var(--color-beige),var(--color-cream))] text-muted">
      Загружаем карту…
    </div>
  );
}

const LeafletMap = dynamic(() => import("@/components/map/LeafletMap"), { ssr: false, loading: () => <MapPlaceholder /> });

/** Карта каталога площадок: один город — приближена к нему, все города — вид на весь регион (как на главной) */
export function VenuesMap({ venues, scoped, className }: { venues: MapVenue[]; scoped: boolean; className?: string }) {
  const { ref, visible } = useLazyVisible<HTMLDivElement>();
  return (
    <div ref={ref} className={className}>
      {visible ? <LeafletMap venues={venues} fitMaxZoom={scoped ? 13 : 8} className="h-full w-full" /> : <MapPlaceholder />}
    </div>
  );
}
