import type { Metadata } from "next";
import { CoverImage } from "@/components/cards/CoverImage";
import { EventCard } from "@/components/cards/EventCard";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { Breadcrumbs } from "@/components/ui/Navigation";
import type { CollectionDetails } from "@/data/events";
import { truncate } from "@/lib/seo";

export function collectionMetadata(collection: CollectionDetails | null): Metadata {
  if (!collection) return { title: "Подборка не найдена" };
  return {
    title: collection.title,
    description: truncate(collection.description || `Подборка событий «${collection.title}» — афиша Черноземья.`),
    alternates: { canonical: `/collections/${collection.slug}` },
  };
}

export function CollectionDetail({ collection }: { collection: CollectionDetails }) {
  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs
        items={[{ label: "Главная", href: "/" }, { label: "Подборки", href: "/collections" }, { label: collection.title }]}
        className="mb-6"
      />

      <div className="relative flex min-h-40 items-end overflow-hidden rounded-xl bg-beige sm:aspect-[21/9]">
        <CoverImage src={collection.image} sizes="(min-width: 1280px) 1120px, 100vw" priority />
        <div aria-hidden className="absolute inset-0 bg-linear-to-t from-ink/85 via-ink/25 to-transparent" />
        <h1 className="type-h2 relative p-6 text-white md:p-10">{collection.title}</h1>
      </div>
      {collection.description && (
        <div className="mt-6 max-w-3xl space-y-4 text-lg text-muted">
          {collection.description
            .split(/\n\s*\n/)
            .map((p) => p.trim())
            .filter(Boolean)
            .map((paragraph, i) => (
              <p key={i}>{paragraph}</p>
            ))}
        </div>
      )}

      <div className="mt-10">
        {collection.events.length > 0 ? (
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {collection.events.map((event) => (
              <li key={event.slug}>
                <EventCard event={event} actions="buy-more" className="h-full" />
              </li>
            ))}
          </ul>
        ) : (
          <EmptyState
            title="В подборке пока нет актуальных событий"
            description="Редакция обновляет подборки по мере появления новых событий — загляните позже."
            action={
              <Button href="/collections" variant="secondary">
                Другие подборки
              </Button>
            }
          />
        )}
      </div>
    </div>
  );
}
