import type { Metadata } from "next";
import { cookies } from "next/headers";
import { CollectionTile } from "@/components/cards/MoreCards";
import { Chip } from "@/components/ui/Chip";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { getAutoCollections } from "@/data/auto-collections";
import { getCollections } from "@/data/events";
import { CITIES, CITY_COOKIE, cityLocative, DEFAULT_CITY, isCitySlug, type CitySlug } from "@/lib/cities";

export const collectionsMetadata: Metadata = {
  title: "Подборки событий",
  description: "Готовые подборки событий Черноземья: на выходных, бесплатно, с детьми, по Пушкинской карте, стендап, кино, театр и концерты.",
  alternates: { canonical: "/collections" },
};

/** Город страницы: ?city= из переключателя, иначе выбранный на сайте (cookie), иначе Воронеж */
async function resolveCity(param: string | undefined): Promise<CitySlug> {
  if (param && isCitySlug(param)) return param;
  const saved = (await cookies()).get(CITY_COOKIE)?.value;
  return saved && isCitySlug(saved) ? saved : DEFAULT_CITY;
}

export async function CollectionsIndex({ cityParam }: { cityParam?: string }) {
  const city = await resolveCity(cityParam);
  const [auto, editorial] = await Promise.all([getAutoCollections(city), getCollections()]);
  const editorialWithEvents = editorial.filter((c) => (c.count ?? 0) > 0);

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Подборки" }]} className="mb-6" />
      <h1 className="type-h2">Подборки {cityLocative(city)}</h1>
      <p className="mt-2 max-w-2xl text-muted">
        Готовые списки событий по теме: когда нет плана, откройте подборку — например, что идёт на выходных, куда сходить с ребёнком или
        что можно оплатить Пушкинской картой. Подборки обновляются сами каждый день.
      </p>

      <nav aria-label="Город" className="mt-5">
        <ul className="flex flex-wrap gap-2">
          {CITIES.map((c) => (
            <li key={c.slug}>
              <Chip href={`/collections?city=${c.slug}`} active={c.slug === city}>
                {c.name}
              </Chip>
            </li>
          ))}
        </ul>
      </nav>

      <ul className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-5 lg:grid-cols-4">
        {auto.map((c) => (
          <li key={c.slug} className="flex flex-col gap-1.5">
            <CollectionTile title={c.title} href={c.href} image={c.image} count={c.count} />
            <p className="px-1 text-sm text-muted">{c.hint}</p>
          </li>
        ))}
      </ul>

      {editorialWithEvents.length > 0 && (
        <section aria-labelledby="editorial-title" className="mt-14">
          <h2 id="editorial-title" className="type-h4">
            От редакции
          </h2>
          <p className="mt-1 text-muted">Подборки, которые мы собрали вручную — по всем городам Черноземья.</p>
          <ul className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-5 lg:grid-cols-4">
            {editorialWithEvents.map((c) => (
              <li key={c.slug}>
                <CollectionTile title={c.title} href={`/collections/${c.slug}`} image={c.image} count={c.count} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
