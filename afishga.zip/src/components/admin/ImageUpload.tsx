"use client";

import { useId, useState } from "react";
import Image from "next/image";
import { UploadCloud, X } from "lucide-react";

/** Картинка события/подборки: грузится сразу на /api/admin/upload, в форму уходит только готовый путь */
export function ImageUpload({ name, defaultValue }: { name: string; defaultValue?: string | null }) {
  const inputId = useId();
  const [url, setUrl] = useState(defaultValue ?? "");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string>();

  const onFile = async (file: File) => {
    setUploading(true);
    setError(undefined);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body: formData });
      const data: { url?: string; error?: string } = await res.json();
      if (!res.ok || !data.url) throw new Error(data.error ?? "Не удалось загрузить");
      setUrl(data.url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось загрузить");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-2">
      <input type="hidden" name={name} value={url} />
      <p className="text-sm font-semibold text-ink">Картинка</p>
      {url ? (
        <div className="relative aspect-video w-64 overflow-hidden rounded-md border border-line bg-beige">
          <Image src={url} alt="" fill sizes="256px" unoptimized={url.endsWith(".svg")} className="object-cover" />
          <button
            type="button"
            onClick={() => setUrl("")}
            aria-label="Убрать картинку"
            className="focus-ring absolute right-2 top-2 rounded-full bg-white/90 p-1.5 text-choco hover:text-brick"
          >
            <X className="size-4" aria-hidden />
          </button>
        </div>
      ) : (
        <label
          htmlFor={inputId}
          className="focus-within:border-choco flex aspect-video w-64 cursor-pointer flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed border-line-strong/50 text-muted hover:border-choco"
        >
          <UploadCloud className="size-6" aria-hidden />
          <span className="text-sm">{uploading ? "Загружаю…" : "Выбрать файл"}</span>
          <input
            id={inputId}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml"
            className="sr-only"
            disabled={uploading}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void onFile(file);
            }}
          />
        </label>
      )}
      {error && <p className="text-sm font-semibold text-brick">{error}</p>}
    </div>
  );
}
