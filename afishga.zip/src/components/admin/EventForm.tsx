"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/Button";
import { Checkbox } from "@/components/ui/Choice";
import { Input, Select, Textarea } from "@/components/ui/Input";
import { createEventAction, updateEventAction, type EventFormState } from "@/lib/admin/event-actions";
import type { EventRow, PartnerRow, VenueRow } from "@/data/admin";
import { CATEGORIES } from "@/lib/categories";
import { CITIES, cityName } from "@/lib/cities";
import { toDateTimeLocalMsk } from "@/lib/time";
import { ImageUpload } from "./ImageUpload";
import { TicketTypesEditor } from "./TicketTypesEditor";

export function EventForm({ event, venues, partners }: { event?: EventRow; venues: VenueRow[]; partners: PartnerRow[] }) {
  const action = event ? updateEventAction.bind(null, event.id) : createEventAction;
  const [state, formAction, pending] = useActionState(action, undefined as EventFormState);

  return (
    <form action={formAction} className="max-w-2xl space-y-4">
      <Input label="Название" name="title" defaultValue={event?.title} required />
      <Input label="Slug (латиница, для ссылок)" name="slug" defaultValue={event?.slug} placeholder="автоматически из названия" />
      <Textarea label="Описание" name="description" defaultValue={event?.description} />

      <div className="grid grid-cols-2 gap-4">
        <Select label="Город" name="city" defaultValue={event?.city ?? ""} required>
          <option value="" disabled>
            Выберите город
          </option>
          {CITIES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.name}
            </option>
          ))}
        </Select>
        <Select label="Категория" name="category" defaultValue={event?.category ?? ""} required>
          <option value="" disabled>
            Выберите категорию
          </option>
          {CATEGORIES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.name}
            </option>
          ))}
        </Select>
      </div>

      <Select label="Площадка" name="venueId" defaultValue={event?.venueId ?? ""} required>
        <option value="" disabled>
          Выберите площадку
        </option>
        {venues.map((v) => (
          <option key={v.id} value={v.id}>
            {cityName(v.city)} — {v.name}
          </option>
        ))}
      </Select>

      <div className="grid grid-cols-2 gap-4">
        <Input label="Начало" name="startsAt" type="datetime-local" defaultValue={event ? toDateTimeLocalMsk(event.startsAt) : undefined} required />
        <Input
          label="Окончание (для выставок)"
          name="endsAt"
          type="datetime-local"
          defaultValue={event?.endsAt ? toDateTimeLocalMsk(event.endsAt) : undefined}
          hint="Оставьте пустым для разовых событий"
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Input label="Цена от, ₽" name="priceFrom" type="number" min={0} defaultValue={event?.priceFrom ?? undefined} hint="0 — бесплатно" />
        <Input label="Цена до, ₽" name="priceTo" type="number" min={0} defaultValue={event?.priceTo ?? undefined} />
        <Input label="Возрастное ограничение" name="ageLimit" type="number" min={0} max={21} defaultValue={event?.ageLimit ?? undefined} />
      </div>

      <TicketTypesEditor initial={event?.ticketTypes ?? []} />

      <ImageUpload name="image" defaultValue={event?.image} />

      <Select label="Партнёр (продавец билетов)" name="partnerId" defaultValue={event?.partnerId ?? ""}>
        <option value="">Без партнёра</option>
        {partners.map((p) => (
          <option key={p.id} value={p.id}>
            {p.name}
          </option>
        ))}
      </Select>
      <Input label="Ссылка на покупку билета" name="ticketUrl" type="url" defaultValue={event?.ticketUrl ?? ""} placeholder="https://" />

      <Select label="Статус" name="status" defaultValue={event?.status ?? "published"} required>
        <option value="draft">Черновик (не виден на сайте)</option>
        <option value="published">Опубликовано</option>
        <option value="archived">В архиве</option>
      </Select>

      <Checkbox name="isHot" value="on" defaultChecked={event?.isHot} label="Показывать бейдж «Hot»" />
      <Checkbox
        name="pushkinCard"
        value="on"
        defaultChecked={event?.pushkinCard}
        label="Принимают Пушкинскую карту (ставьте, только если это подтверждено источником)"
      />

      {state?.error && <p className="text-sm font-semibold text-brick">{state.error}</p>}
      <div className="flex gap-3">
        <Button type="submit" loading={pending}>
          Сохранить
        </Button>
        <Button href="/admin/events" variant="secondary">
          Отмена
        </Button>
      </div>
    </form>
  );
}
