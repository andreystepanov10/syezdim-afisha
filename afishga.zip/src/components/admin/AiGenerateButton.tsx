"use client";

import { useActionState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { generateAiContentAction, type AiGenerateState } from "@/lib/admin/ai-actions";

/** Кнопка на карточке события: переписывает описание и генерирует картинку через Gemini */
export function AiGenerateButton({ eventId }: { eventId: number }) {
  const action = generateAiContentAction.bind(null, eventId);
  const [state, formAction, pending] = useActionState(action, undefined as AiGenerateState);

  return (
    <div className="mb-6 flex items-center gap-3">
      <form action={formAction}>
        <Button type="submit" variant="olive" loading={pending} iconLeft={<Sparkles className="size-4" aria-hidden />}>
          Сгенерировать описание и картинку (ИИ)
        </Button>
      </form>
      {state?.error && <p className="text-sm font-semibold text-brick">{state.error}</p>}
    </div>
  );
}
