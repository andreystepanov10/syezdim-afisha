"use client";

import { useActionState, useState } from "react";
import { Button } from "@/components/ui/Button";
import { Checkbox } from "@/components/ui/Choice";
import { Input, Textarea } from "@/components/ui/Input";
import { createCollectionAction, updateCollectionAction, type CollectionFormState } from "@/lib/admin/collection-actions";
import type { CollectionRow } from "@/data/admin";
import { cityName, type CitySlug } from "@/lib/cities";
import { dateShort } from "@/lib/format";
import { ImageUpload } from "./ImageUpload";

type EventOption = { id: number; title: string; city: CitySlug; startsAt: Date };

export function CollectionForm({ collection, events }: { collection?: CollectionRow; events: EventOption[] }) {
  const action = collection ? updateCollectionAction.bind(null, collection.id) : createCollectionAction;
  const [state, formAction, pending] = useActionState(action, undefined as CollectionFormState);
  const [selected, setSelected] = useState<Set<number>>(new Set(collection?.eventIds ?? []));

  const toggle = (id: number) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <form action={formAction} className="max-w-2xl space-y-4">
      <Input label="Название" name="title" defaultValue={collection?.title} required />
      <Input label="Slug (латиница, для ссылок)" name="slug" defaultValue={collection?.slug} placeholder="автоматически из названия" />
      <Textarea
        label="Описание"
        name="description"
        rows={8}
        defaultValue={collection?.description}
        hint="Можно написать несколько абзацев — на странице подборки они разобьются по пустым строкам"
      />
      <ImageUpload name="image" defaultValue={collection?.image} />

      <div>
        <p className="mb-2 text-sm font-semibold text-ink">События в подборке</p>
        <p className="mb-3 text-sm text-muted">
          Порядок в подборке — по дате события. Своя редакционная сортировка появится позже.
        </p>
        <ul className="max-h-96 space-y-1 overflow-y-auto rounded-md border border-line p-3">
          {events.map((e) => (
            <li key={e.id}>
              <Checkbox
                name="eventIds"
                value={e.id}
                checked={selected.has(e.id)}
                onChange={() => toggle(e.id)}
                label={`${cityName(e.city)} · ${dateShort(e.startsAt)} · ${e.title}`}
              />
            </li>
          ))}
          {events.length === 0 && <li className="py-2 text-center text-muted">Пока нет ни одного события</li>}
        </ul>
      </div>

      {state?.error && <p className="text-sm font-semibold text-brick">{state.error}</p>}
      <div className="flex gap-3">
        <Button type="submit" loading={pending}>
          Сохранить
        </Button>
        <Button href="/admin/collections" variant="secondary">
          Отмена
        </Button>
      </div>
    </form>
  );
}
