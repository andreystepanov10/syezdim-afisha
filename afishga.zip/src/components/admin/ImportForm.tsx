"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/Button";
import { Select } from "@/components/ui/Input";
import { runImportAction, type ImportFormState } from "@/lib/admin/import-actions";
import { CITIES } from "@/lib/cities";

export function ImportForm() {
  const [state, formAction, pending] = useActionState(runImportAction, undefined as ImportFormState);

  return (
    <div className="max-w-2xl space-y-6">
      <form action={formAction} className="flex flex-wrap items-end gap-4">
        <Select label="Город" name="city" defaultValue="" required className="min-w-48">
          <option value="" disabled>
            Выберите город
          </option>
          {CITIES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.name}
            </option>
          ))}
        </Select>
        <Button type="submit" loading={pending}>
          Импортировать
        </Button>
      </form>

      {state?.error && <p className="text-sm font-semibold text-brick">{state.error}</p>}

      {state?.reports && (
        <div className="space-y-4">
          {state.reports.map((r) => (
            <div key={r.source} className="rounded-xl bg-white p-5 shadow-soft">
              <p className="font-display font-bold text-ink">{r.source}</p>
              <p className="mt-1 text-sm text-muted">
                Добавлено черновиков: <strong className="text-ink">{r.imported}</strong>
                {r.updated > 0 && <> · дозаполнено картинкой/описанием: {r.updated}</>}
                {r.skippedDuplicate > 0 && <> · уже были раньше: {r.skippedDuplicate}</>}
                {r.errors > 0 && <> · ошибок: {r.errors}</>}
              </p>
              {r.skippedNoVenue.length > 0 && (
                <div className="mt-3 rounded-sm bg-cream p-3 text-sm">
                  <p className="font-semibold text-choco">Площадки не найдены — добавьте их и запустите импорт ещё раз:</p>
                  <ul className="mt-1 list-inside list-disc text-muted">
                    {r.skippedNoVenue.map((name) => (
                      <li key={name}>{name}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
