"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { createPartnerAction, updatePartnerAction, type PartnerFormState } from "@/lib/admin/partner-actions";
import type { PartnerRow } from "@/data/admin";

export function PartnerForm({ partner }: { partner?: PartnerRow }) {
  const action = partner ? updatePartnerAction.bind(null, partner.id) : createPartnerAction;
  const [state, formAction, pending] = useActionState(action, undefined as PartnerFormState);

  return (
    <form action={formAction} className="max-w-lg space-y-4">
      <Input label="Название" name="name" defaultValue={partner?.name} required />
      <Input label="Slug (латиница, для ссылок)" name="slug" defaultValue={partner?.slug} placeholder="автоматически из названия" />
      <Input label="Сайт партнёра" name="siteUrl" type="url" defaultValue={partner?.siteUrl ?? ""} placeholder="https://" />
      {state?.error && <p className="text-sm font-semibold text-brick">{state.error}</p>}
      <div className="flex gap-3">
        <Button type="submit" loading={pending}>
          Сохранить
        </Button>
        <Button href="/admin/partners" variant="secondary">
          Отмена
        </Button>
      </div>
    </form>
  );
}
