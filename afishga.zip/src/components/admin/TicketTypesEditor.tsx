"use client";

import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

type Row = { name: string; priceRub: number };

/** Категории билетов события («Балкон», «Партер»…) — если список пуст, на сайте используются priceFrom/priceTo */
export function TicketTypesEditor({ initial }: { initial: Row[] }) {
  const [rows, setRows] = useState<Row[]>(initial);

  const update = (i: number, patch: Partial<Row>) => setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  const remove = (i: number) => setRows((prev) => prev.filter((_, idx) => idx !== i));
  const add = () => setRows((prev) => [...prev, { name: "", priceRub: 0 }]);

  return (
    <div className="space-y-3">
      <input type="hidden" name="ticketTypes" value={JSON.stringify(rows.filter((r) => r.name.trim()))} />
      <p className="text-sm font-semibold text-ink">Категории билетов</p>
      {rows.map((row, i) => (
        <div key={i} className="flex items-end gap-2">
          <Input label="Название" className="flex-1" value={row.name} onChange={(e) => update(i, { name: e.target.value })} placeholder="Партер" />
          <Input
            label="Цена, ₽"
            type="number"
            min={0}
            className="w-32"
            value={row.priceRub}
            onChange={(e) => update(i, { priceRub: Number(e.target.value) })}
          />
          <Button type="button" variant="ghost" size="sm" onClick={() => remove(i)} aria-label={`Удалить категорию «${row.name || i + 1}»`}>
            <Trash2 className="size-4" aria-hidden />
          </Button>
        </div>
      ))}
      <Button type="button" variant="secondary" size="sm" onClick={add} iconLeft={<Plus className="size-4" aria-hidden />}>
        Добавить категорию
      </Button>
      <p className="text-sm text-muted">Если категорий нет, оставьте список пустым — цену тогда покажут поля «Цена от/до» ниже.</p>
    </div>
  );
}
