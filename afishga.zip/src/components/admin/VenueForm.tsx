"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/Button";
import { Input, Select } from "@/components/ui/Input";
import { createVenueAction, updateVenueAction, type VenueFormState } from "@/lib/admin/venue-actions";
import type { VenueRow } from "@/data/admin";
import { CITIES } from "@/lib/cities";

export function VenueForm({ venue }: { venue?: VenueRow }) {
  const action = venue ? updateVenueAction.bind(null, venue.id) : createVenueAction;
  const [state, formAction, pending] = useActionState(action, undefined as VenueFormState);

  return (
    <form action={formAction} className="max-w-lg space-y-4">
      <Input label="Название" name="name" defaultValue={venue?.name} required />
      <Input label="Slug (латиница, для ссылок)" name="slug" defaultValue={venue?.slug} placeholder="автоматически из названия" />
      <Select label="Город" name="city" defaultValue={venue?.city ?? ""} required>
        <option value="" disabled>
          Выберите город
        </option>
        {CITIES.map((c) => (
          <option key={c.slug} value={c.slug}>
            {c.name}
          </option>
        ))}
      </Select>
      <Input label="Адрес" name="address" defaultValue={venue?.address} placeholder="ул. Ленина, 1" />
      <div className="grid grid-cols-2 gap-4">
        <Input label="Широта" name="lat" type="number" step="any" defaultValue={venue?.lat} required />
        <Input label="Долгота" name="lon" type="number" step="any" defaultValue={venue?.lon} required />
      </div>
      {state?.error && <p className="text-sm font-semibold text-brick">{state.error}</p>}
      <div className="flex gap-3">
        <Button type="submit" loading={pending}>
          Сохранить
        </Button>
        <Button href="/admin/venues" variant="secondary">
          Отмена
        </Button>
      </div>
    </form>
  );
}
