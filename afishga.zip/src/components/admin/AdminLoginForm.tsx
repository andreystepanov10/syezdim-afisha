"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { adminLoginAction } from "@/lib/admin/auth-actions";

export function AdminLoginForm() {
  const [state, formAction, pending] = useActionState(adminLoginAction, undefined);
  return (
    <form action={formAction} className="space-y-4">
      <Input label="Пароль" name="password" type="password" autoComplete="current-password" autoFocus error={state?.error} />
      <Button type="submit" fullWidth loading={pending}>
        Войти
      </Button>
    </form>
  );
}
