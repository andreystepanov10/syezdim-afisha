"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Checkbox } from "@/components/ui/Choice";
import type { EventListItem } from "@/data/admin";
import { bulkPublishEventsAction, deleteEventAction } from "@/lib/admin/event-actions";
import { cityName } from "@/lib/cities";
import { dateTimeLong } from "@/lib/format";

const STATUS_LABEL: Record<string, string> = { draft: "Черновик", published: "Опубликовано", archived: "Архив" };
const STATUS_VARIANT: Record<string, "neutral" | "free" | "mustard"> = { draft: "neutral", published: "free", archived: "mustard" };

export function EventsTable({ events }: { events: EventListItem[] }) {
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const draftIds = useMemo(() => events.filter((e) => e.status === "draft").map((e) => e.id), [events]);
  const allDraftsSelected = draftIds.length > 0 && draftIds.every((id) => selected.has(id));

  function toggle(id: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleAllDrafts() {
    setSelected(allDraftsSelected ? new Set() : new Set(draftIds));
  }

  function publishSelected() {
    const ids = [...selected];
    startTransition(async () => {
      await bulkPublishEventsAction(ids);
      setSelected(new Set());
      router.refresh();
    });
  }

  return (
    <div>
      {selected.size > 0 && (
        <div className="mb-4 flex items-center gap-3 rounded-xl bg-white p-3 shadow-soft">
          <span className="text-sm font-semibold text-ink">Выбрано: {selected.size}</span>
          <Button size="sm" variant="olive" loading={pending} onClick={publishSelected}>
            Опубликовать выбранные
          </Button>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl bg-white shadow-soft">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr>
              <th className="px-4 py-3">
                <Checkbox
                  label={<span className="sr-only">Выбрать все черновики</span>}
                  checked={allDraftsSelected}
                  onChange={toggleAllDrafts}
                  disabled={draftIds.length === 0}
                />
              </th>
              <th className="px-4 py-3 font-semibold">Название</th>
              <th className="px-4 py-3 font-semibold">Город / площадка</th>
              <th className="px-4 py-3 font-semibold">Дата</th>
              <th className="px-4 py-3 font-semibold">Статус</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {events.map((e) => (
              <tr key={e.id}>
                <td className="px-4 py-3">
                  {e.status === "draft" && (
                    <Checkbox
                      label={<span className="sr-only">Выбрать «{e.title}»</span>}
                      checked={selected.has(e.id)}
                      onChange={() => toggle(e.id)}
                    />
                  )}
                </td>
                <td className="px-4 py-3">
                  <Link href={`/admin/events/${e.id}`} className="font-semibold text-ink hover:text-brick hover:underline">
                    {e.title}
                  </Link>
                </td>
                <td className="px-4 py-3 text-muted">
                  {cityName(e.city)} · {e.venueName}
                </td>
                <td className="px-4 py-3 text-muted">{dateTimeLong(e.startsAt)}</td>
                <td className="px-4 py-3">
                  <Badge variant={STATUS_VARIANT[e.status]}>{STATUS_LABEL[e.status]}</Badge>
                </td>
                <td className="px-4 py-3 text-right">
                  <form action={deleteEventAction.bind(null, e.id)}>
                    <button type="submit" aria-label={`Удалить «${e.title}»`} className="focus-ring rounded-xs p-2 text-muted hover:text-brick">
                      <Trash2 className="size-4" aria-hidden />
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {events.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted">
                  Пока нет ни одного события.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
