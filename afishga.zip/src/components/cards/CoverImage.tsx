import Image from "next/image";
import { MapPin } from "lucide-react";
import { cn } from "@/lib/cn";

/** Обложка, заполняющая родителя (родитель — relative + aspect-*). Без картинки — фирменная заглушка */
export function CoverImage({
  src,
  alt = "",
  sizes,
  priority,
  className,
}: {
  src?: string;
  alt?: string;
  sizes: string;
  priority?: boolean;
  className?: string;
}) {
  if (!src) {
    return (
      <div className="absolute inset-0 grid place-items-center bg-[linear-gradient(135deg,var(--color-cream),var(--color-beige))]">
        <MapPin className="size-10 text-brick/50" aria-hidden />
      </div>
    );
  }
  return (
    <Image
      src={src}
      alt={alt}
      fill
      sizes={sizes}
      priority={priority}
      unoptimized={src.endsWith(".svg")}
      className={cn("object-cover transition duration-500 ease-soft group-hover:scale-105", className)}
    />
  );
}
