"use client";

import { Heart } from "lucide-react";
import { useFavorites } from "@/lib/favorites-context";
import { cn } from "@/lib/cn";

/** Сердечко «в избранное» — анонимно, без входа (см. FavoritesProvider), не пропадает при переходах */
export function FavoriteButton({ slug, title, className }: { slug: string; title: string; className?: string }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const on = isFavorite(slug);

  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={on ? `Убрать «${title}» из избранного` : `Добавить «${title}» в избранное`}
      onClick={() => void toggleFavorite(slug)}
      className={cn(
        "focus-ring inline-flex size-11 items-center justify-center rounded-full bg-white/85 text-choco shadow-soft backdrop-blur transition duration-200 hover:bg-white active:scale-90",
        on && "text-brick",
        className,
      )}
    >
      <Heart className={cn("size-5 transition duration-200", on && "scale-110")} fill={on ? "currentColor" : "none"} aria-hidden />
    </button>
  );
}
