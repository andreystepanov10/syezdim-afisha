import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { Badge, DateBadge } from "@/components/ui/Badge";
import { RatingInline } from "@/components/ui/Rating";
import { ticketHref } from "@/lib/affiliate";
import { cn } from "@/lib/cn";
import { dateShort, plural, priceLabel } from "@/lib/format";
import type { EventBadge, EventSummary } from "@/lib/types";
import { CoverImage } from "./CoverImage";
import { FavoriteButton } from "./FavoriteButton";

export const badgeView: Record<EventBadge, { variant: "hot" | "free" | "age" | "pushkin"; text: string }> = {
  hot: { variant: "hot", text: "Hot" },
  free: { variant: "free", text: "Free" },
  "18+": { variant: "age", text: "18+" },
  pushkin: { variant: "pushkin", text: "Пушкинская карта" },
};

/**
 * Карточка события. Вся карточка кликабельна через «растянутую» ссылку на заголовке
 * (одна ссылка на карточку — удобно для скринридера), а сердечко и кнопки лежат поверх неё.
 *
 * actions="buy"       — одна кнопка «Купить билет» (главная)
 * actions="buy-more"  — «Купить билет» + «Ещё» (каталог)
 */
export function EventCard({
  event,
  actions = "buy",
  priority,
  className,
  timeLabel,
}: {
  event: EventSummary;
  actions?: "buy" | "buy-more";
  priority?: boolean;
  className?: string;
  /** Время начала («10:00») — для плана по дням, где дата уже вынесена в заголовок дня */
  timeLabel?: string;
}) {
  const href = `/events/${event.slug}`;
  // «Купить» — через счётчик /go (там же партнёрский код), а не прямой ссылкой на кассу
  const buyHref = event.ticketUrl ? ticketHref(event.slug) : href;
  const external = Boolean(event.ticketUrl);
  // У бесплатных событий билета нет — ссылка партнёра ведёт на запись/регистрацию
  const buyLabel = event.priceFrom === 0 ? (external ? "Записаться" : "Подробнее") : "Купить билет";

  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-lg bg-white shadow-soft transition duration-300 ease-soft hover:-translate-y-1 hover:shadow-hover focus-within:shadow-hover",
        className,
      )}
    >
      <div className="relative aspect-[8/5] overflow-hidden bg-beige">
        <CoverImage src={event.image} sizes="(min-width: 1280px) 300px, (min-width: 768px) 33vw, 50vw" priority={priority} />
        <span aria-hidden className="absolute left-3 top-3">
          <DateBadge date={event.startsAt} />
        </span>
        <FavoriteButton slug={event.slug} title={event.title} className="absolute right-3 top-3 z-10" />
        {event.badges && event.badges.length > 0 && (
          <div className="absolute bottom-3 left-3 flex gap-1.5">
            {event.badges.map((b) => (
              <Badge key={b} variant={badgeView[b].variant}>
                {badgeView[b].text}
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-1.5 p-4">
        <div className="flex items-center justify-between gap-2">
          <time dateTime={event.startsAt} className="type-caption text-muted">
            {dateShort(event.startsAt)}
            {timeLabel && ` · ${timeLabel}`}
          </time>
          {event.rating != null && <RatingInline value={event.rating} count={event.ratingCount} />}
        </div>

        <h3 className="type-h6 line-clamp-2 min-h-[2.75rem]">
          <Link href={href} className="focus-ring rounded-xs after:absolute after:inset-0 after:content-['']">
            {event.title}
          </Link>
        </h3>
        {event.subtitle && <p className="truncate text-sm text-muted">{event.subtitle}</p>}
        {event.moreDates ? (
          <p className="text-sm font-semibold text-brick">
            и ещё {event.moreDates} {plural(event.moreDates, ["дата", "даты", "дат"])}
          </p>
        ) : null}
        <p className="mt-0.5 font-display text-base font-bold text-ink">{priceLabel(event.priceFrom)}</p>

        {/* Партнёрская ссылка — реклама: короткая пометка на карточке, полная (с рекламодателем и erid) — на странице события */}
        {event.adMark && <p className="mt-auto pt-2 text-[11px] leading-none text-muted">Реклама</p>}
        <div className={cn("relative z-10 flex gap-2", event.adMark ? "pt-1.5" : "mt-auto pt-3")}>
          {actions === "buy" ? (
            <Button href={buyHref} external={external} fullWidth aria-label={`${buyLabel}: ${event.title}`}>
              {buyLabel}
            </Button>
          ) : (
            <>
              <Button href={buyHref} external={external} variant="olive" className="flex-1" aria-label={`${buyLabel}: ${event.title}`}>
                {buyLabel}
              </Button>
              <Button href={href} variant="choco" aria-label={`Подробнее: ${event.title}`}>
                Ещё
              </Button>
            </>
          )}
        </div>
      </div>
    </article>
  );
}
