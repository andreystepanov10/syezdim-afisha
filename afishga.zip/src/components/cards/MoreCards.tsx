import Link from "next/link";
import { cn } from "@/lib/cn";
import { dateShort, plural, priceLabel } from "@/lib/format";
import type { EventSummary } from "@/lib/types";
import { CoverImage } from "./CoverImage";

/** Малая карточка: вертикальная («Предстоящие выставки») или горизонтальная (список в календаре) */
export function SmallCard({
  event,
  orientation = "vertical",
  className,
}: {
  event: EventSummary;
  orientation?: "vertical" | "horizontal";
  className?: string;
}) {
  const href = `/events/${event.slug}`;
  const link = "focus-ring rounded-xs after:absolute after:inset-0 after:content-['']";

  if (orientation === "horizontal") {
    return (
      <article
        className={cn(
          "group relative grid grid-cols-[4.5rem_1fr] items-center gap-3 rounded-md bg-white p-2 shadow-soft transition duration-300 ease-soft hover:shadow-hover",
          className,
        )}
      >
        <div className="relative size-[4.5rem] overflow-hidden rounded-sm bg-beige">
          <CoverImage src={event.image} sizes="72px" />
        </div>
        <div className="min-w-0">
          <h3 className="type-h6 line-clamp-2 text-[15px]">
            <Link href={href} className={link}>
              {event.title}
            </Link>
          </h3>
          {event.subtitle && <p className="truncate text-sm text-muted">{event.subtitle}</p>}
          <p className="font-display text-sm font-bold text-ink">{priceLabel(event.priceFrom)}</p>
        </div>
      </article>
    );
  }

  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-lg bg-white shadow-soft transition duration-300 ease-soft hover:-translate-y-1 hover:shadow-hover",
        className,
      )}
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-beige">
        <CoverImage src={event.image} sizes="(min-width: 1280px) 220px, 45vw" />
      </div>
      <div className="space-y-0.5 p-3">
        <time dateTime={event.startsAt} className="type-caption block text-[11px] text-muted">
          {dateShort(event.startsAt)}
        </time>
        <h3 className="type-h6 line-clamp-2 min-h-[2.75rem] text-[15px]">
          <Link href={href} className={link}>
            {event.title}
          </Link>
        </h3>
        {event.subtitle && <p className="truncate text-sm text-muted">{event.subtitle}</p>}
      </div>
    </article>
  );
}

/** Плитка редакционной подборки: иллюстрация + заголовок поверх */
export function CollectionTile({
  title,
  href,
  image,
  count,
  className,
}: {
  title: string;
  href: string;
  image?: string;
  count?: number;
  className?: string;
}) {
  return (
    <Link
      href={href}
      className={cn(
        "focus-ring group relative block aspect-[4/5] overflow-hidden rounded-lg bg-beige shadow-soft transition duration-300 ease-soft hover:-translate-y-1 hover:shadow-hover",
        className,
      )}
    >
      <CoverImage src={image} sizes="(min-width: 1280px) 400px, (min-width: 768px) 33vw, 90vw" />
      <div aria-hidden className="absolute inset-0 bg-linear-to-t from-ink/80 via-ink/15 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-4">
        <h3 className="font-display text-[13px] font-bold leading-tight text-white sm:text-base md:text-xl">{title}</h3>
        {count != null && (
          <p className="hidden text-sm text-cream sm:block">
            {count} {plural(count, ["событие", "события", "событий"])}
          </p>
        )}
      </div>
    </Link>
  );
}
