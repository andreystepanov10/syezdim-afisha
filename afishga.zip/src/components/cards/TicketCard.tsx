"use client";

import { QRCodeSVG } from "qrcode.react";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/cn";
import { dateTimeLong } from "@/lib/format";

/**
 * Билет для «кошелька»: данные события, перфорация и QR-код.
 * qrValue — то, что закодировано в QR партнёра; вырезы по бокам красятся под фон страницы.
 */
export function TicketCard({
  title,
  startsAt,
  venue,
  ticketType,
  qrValue,
  code,
  notchClassName = "bg-paper",
  className,
}: {
  title: string;
  startsAt: string;
  venue: string;
  ticketType: string;
  qrValue: string;
  code: string;
  notchClassName?: string;
  className?: string;
}) {
  return (
    <article className={cn("relative overflow-hidden rounded-lg bg-white shadow-soft", className)}>
      <div className="space-y-1.5 p-5 pb-4">
        <div className="flex items-start justify-between gap-3">
          <h3 className="type-h6">{title}</h3>
          <Badge variant="mustard">{ticketType}</Badge>
        </div>
        <p className="text-sm text-muted">{dateTimeLong(startsAt)}</p>
        <p className="text-sm text-muted">{venue}</p>
      </div>

      <div aria-hidden className="relative flex items-center">
        <span className={cn("absolute -left-3 size-6 rounded-full", notchClassName)} />
        <span className="mx-5 flex-1 border-t-2 border-dashed border-line" />
        <span className={cn("absolute -right-3 size-6 rounded-full", notchClassName)} />
      </div>

      <div className="flex flex-col items-center gap-2.5 p-5 pt-4">
        <div className="rounded-md border border-line bg-white p-3">
          <QRCodeSVG value={qrValue} size={148} level="M" fgColor="#1A0F08" bgColor="#FFFFFF" title={`QR-код билета ${code}`} />
        </div>
        <p className="font-display text-sm font-bold tracking-[0.2em] text-ink">{code}</p>
        <p className="text-center text-xs text-muted">Покажите QR-код на входе</p>
      </div>
    </article>
  );
}
