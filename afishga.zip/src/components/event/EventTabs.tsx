"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import { Tabs } from "@/components/ui/Tabs";

/**
 * Вкладки страницы события. Панель «Место» содержит карту (Leaflet работает только в браузере и требует
 * видимый контейнер с реальными размерами), поэтому монтируем её содержимое только после первого перехода
 * на вкладку — до этого момента панель скрыта через [hidden] и имеет нулевую высоту.
 */
export function EventTabs({ about, place, tickets, className }: { about: ReactNode; place: ReactNode; tickets: ReactNode; className?: string }) {
  const [placeVisited, setPlaceVisited] = useState(false);

  return (
    <Tabs
      label="Разделы события"
      className={className}
      onChange={(id) => {
        if (id === "place") setPlaceVisited(true);
      }}
      tabs={[
        { id: "about", label: "О событии", panel: about },
        { id: "place", label: "Место", panel: placeVisited ? place : null },
        { id: "tickets", label: "Билеты", panel: tickets },
      ]}
    />
  );
}
