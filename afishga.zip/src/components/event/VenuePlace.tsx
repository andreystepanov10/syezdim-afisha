"use client";

import dynamic from "next/dynamic";
import { Navigation } from "lucide-react";
import { Button } from "@/components/ui/Button";

function MapPlaceholder() {
  return (
    <div role="status" className="grid h-full place-items-center bg-[linear-gradient(135deg,var(--color-beige),var(--color-cream))] text-muted">
      Загружаем карту…
    </div>
  );
}

// Leaflet работает только в браузере; этот блок и так монтируется только по клику на вкладку «Место» (см. EventTabs)
const VenueMap = dynamic(() => import("@/components/map/VenueMap"), { ssr: false, loading: () => <MapPlaceholder /> });

/** Вкладка «Место»: адрес площадки, карта и ссылка на маршрут во внешних картах */
export function VenuePlace({ venue }: { venue: { name: string; address: string; lat: number; lon: number; approx?: boolean } }) {
  const routeHref = `https://yandex.ru/maps/?text=${encodeURIComponent(venue.address ? `${venue.name}, ${venue.address}` : venue.name)}`;
  return (
    <div className="max-w-3xl space-y-4">
      <div>
        <p className="type-h6">{venue.name}</p>
        {venue.address && <p className="text-muted">{venue.address}</p>}
      </div>
      {venue.approx ? (
        // Точного места на карте нет (площадки нет в OpenStreetMap) — не ставим метку в случайную точку
        <p className="rounded-lg border border-line bg-beige px-4 py-3 text-sm text-muted">Точное место на нашей карте пока не отмечено — постройте маршрут в Яндекс Картах по названию площадки.</p>
      ) : (
        <div className="isolate h-72 overflow-hidden rounded-lg border border-line bg-beige md:h-96">
          <VenueMap lat={venue.lat} lon={venue.lon} name={venue.name} className="h-full w-full" />
        </div>
      )}
      <Button href={routeHref} external variant="secondary" iconRight={<Navigation className="size-4" aria-hidden />}>
        Проложить маршрут
      </Button>
    </div>
  );
}
