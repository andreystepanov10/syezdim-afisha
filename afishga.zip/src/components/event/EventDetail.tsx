import type { Metadata } from "next";
import { CalendarPlus } from "lucide-react";
import { badgeView, EventCard } from "@/components/cards/EventCard";
import { CoverImage } from "@/components/cards/CoverImage";
import { FavoriteButton } from "@/components/cards/FavoriteButton";
import { Badge, DateBadge } from "@/components/ui/Badge";
import { Button, buttonClasses } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { RatingInline } from "@/components/ui/Rating";
import { catalogHref } from "@/data/catalog-url";
import type { EventDetails } from "@/data/events";
import { categoryName } from "@/lib/categories";
import { dateShort, dateTimeLong, formatPrice, periodLong, timeShort } from "@/lib/format";
import { ticketHref } from "@/lib/affiliate";
import { absoluteUrl, eventDescription, eventPlace, eventTitle } from "@/lib/seo";
import { OPEN_GRAPH_DEFAULTS } from "@/lib/site";
import type { EventSummary } from "@/lib/types";
import { EventTabs } from "./EventTabs";
import { VenuePlace } from "./VenuePlace";

export function eventMetadata(event: EventDetails | null): Metadata {
  if (!event) return { title: "Событие не найдено" };
  const title = eventTitle(event);
  const description = eventDescription(event);
  const path = `/events/${event.slug}`;
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      ...OPEN_GRAPH_DEFAULTS,
      title,
      description,
      url: path,
      ...(event.image ? { images: [{ url: absoluteUrl(event.image), alt: event.title }] } : {}),
    },
  };
}

function priceRangeLabel(event: Pick<EventDetails, "priceFrom" | "priceTo">): string {
  if (event.priceFrom == null) return "Цена уточняется";
  if (event.priceFrom === 0 && (event.priceTo == null || event.priceTo === 0)) return "Бесплатно";
  if (event.priceTo != null && event.priceTo !== event.priceFrom) return `${formatPrice(event.priceFrom)} – ${formatPrice(event.priceTo)}`;
  return `от ${formatPrice(event.priceFrom)}`;
}

/** Купить/записаться: без ссылки партнёра — недоступная кнопка (бесплатные события без регистрации — просто подпись) */
function BuyAction({ event, className }: { event: EventDetails; className?: string }) {
  if (event.priceFrom === 0 && !event.ticketUrl) {
    return <p className={`font-display text-lg font-bold text-olive-strong ${className ?? ""}`}>Вход свободный</p>;
  }
  if (!event.ticketUrl) {
    return (
      <Button type="button" disabled size="lg" className={`min-w-48 ${className ?? ""}`}>
        Билеты скоро
      </Button>
    );
  }
  return (
    <Button href={ticketHref(event.slug)} external size="lg" className={`min-w-48 ${className ?? ""}`}>
      {event.priceFrom === 0 ? "Записаться" : "Купить билет"}
    </Button>
  );
}

function PartnerNote({ event }: { event: EventDetails }) {
  if (!event.partner) return null;
  return (
    <p className="text-sm text-muted">
      Билеты продаёт партнёр —{" "}
      {event.partner.siteUrl ? (
        <a href={event.partner.siteUrl} target="_blank" rel="noopener noreferrer sponsored" className="font-semibold text-brick underline-offset-4 hover:underline">
          {event.partner.name}
        </a>
      ) : (
        event.partner.name
      )}
      . Оплата и получение билета — на его сайте.
    </p>
  );
}

function AboutPanel({ event }: { event: EventDetails }) {
  return (
    <div className="max-w-3xl space-y-5">
      <p className="whitespace-pre-line leading-relaxed text-choco">{event.description || "Организатор пока не добавил описание события."}</p>
      <dl className="grid gap-x-8 gap-y-2 text-sm sm:grid-cols-2">
        {event.endsAt ? (
          <div className="flex items-center justify-between gap-4 sm:block">
            <dt className="text-muted">{event.category === "cinema" ? "В прокате" : "Проходит"}</dt>
            <dd className="font-semibold text-ink">{periodLong(event.startsAt, event.endsAt)}</dd>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-4 sm:block">
            <dt className="text-muted">Начало</dt>
            <dd className="font-semibold text-ink">{dateTimeLong(event.startsAt)}</dd>
          </div>
        )}
        {(event.ageLimit ?? 0) > 0 && (
          <div className="flex items-center justify-between gap-4 sm:block">
            <dt className="text-muted">Возрастное ограничение</dt>
            <dd className="font-semibold text-ink">{event.ageLimit}+</dd>
          </div>
        )}
        <div className="flex items-center justify-between gap-4 sm:block">
          <dt className="text-muted">Место</dt>
          <dd className="font-semibold text-ink">{event.venue.name}</dd>
        </div>
      </dl>
    </div>
  );
}

function TicketsPanel({ event }: { event: EventDetails }) {
  return (
    <div className="max-w-xl space-y-5">
      {event.ticketTypes.length > 0 ? (
        <ul className="divide-y divide-line rounded-lg border border-line bg-white">
          {event.ticketTypes.map((t) => (
            <li key={t.name} className="flex items-center justify-between gap-4 px-4 py-3">
              <span className="font-semibold text-ink">{t.name}</span>
              <span className="font-display font-bold text-ink">{formatPrice(t.priceRub)}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="font-display font-semibold text-ink">{priceRangeLabel(event)}</p>
      )}
      <BuyAction event={event} />
      {event.adMark && <p className="text-xs text-muted">{event.adMark}</p>}
      <PartnerNote event={event} />
    </div>
  );
}

export function EventDetail({
  event,
  similar,
  otherDates = [],
}: {
  event: EventDetails;
  similar: EventSummary[];
  /** Другие сеансы того же события в той же площадке */
  otherDates?: { slug: string; startsAt: string }[];
}) {
  return (
    <div className="container-page py-6 md:py-10">
      <Breadcrumbs
        items={[
          { label: "Главная", href: "/" },
          ...(event.category ? [{ label: categoryName(event.category), href: catalogHref({ category: [event.category] }) }] : []),
          { label: event.title },
        ]}
        className="mb-6"
      />

      <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-beige sm:aspect-[21/9]">
        {/* Постеры у источников вертикальные, а блок широкий: object-cover резал афишу сверху и снизу.
            Постер — целиком по центру, по бокам — он же, размытый, вместо фона */}
        {event.image && <CoverImage src={event.image} sizes="400px" className="scale-110 object-cover opacity-70 blur-2xl group-hover:scale-110" />}
        <CoverImage src={event.image} sizes="(min-width: 1280px) 1120px, 100vw" priority className="object-contain group-hover:scale-100" />
        <span aria-hidden className="absolute left-4 top-4">
          <DateBadge date={event.startsAt} />
        </span>
        <FavoriteButton slug={event.slug} title={event.title} className="absolute right-4 top-4" />
        {event.badges && event.badges.length > 0 && (
          <div className="absolute bottom-4 left-4 flex gap-1.5">
            {event.badges.map((b) => (
              <Badge key={b} variant={badgeView[b].variant}>
                {badgeView[b].text}
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div className="mt-6 flex flex-wrap items-start justify-between gap-x-8 gap-y-6">
        <div className="min-w-0 max-w-2xl">
          <h1 className="type-h2">{event.title}</h1>
          <p className="mt-2 text-lg text-muted">
            {eventPlace(event)} · {event.venue.name}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
            <time dateTime={event.startsAt} className="font-display font-semibold text-ink">
              {event.endsAt ? periodLong(event.startsAt, event.endsAt) : dateTimeLong(event.startsAt)}
            </time>
            {event.rating != null && <RatingInline value={event.rating} count={event.ratingCount} />}
          </div>
        </div>

        <div className="flex flex-col items-start gap-2 sm:items-end">
          <p className="font-display text-2xl font-bold text-ink">{priceRangeLabel(event)}</p>
          <BuyAction event={event} />
          {event.adMark && <p className="max-w-64 text-xs text-muted sm:text-right">{event.adMark}</p>}
          <a href={`/api/events/${event.slug}/ics`} className={buttonClasses({ variant: "link", size: "sm" })}>
            <CalendarPlus className="size-4" aria-hidden />
            Добавить в календарь
          </a>
        </div>
      </div>

      {otherDates.length > 0 && (
        <nav aria-labelledby="other-dates-title" className="mt-6">
          <h2 id="other-dates-title" className="type-h6 mb-2">
            Другие даты
          </h2>
          <ul className="flex flex-wrap gap-2">
            {otherDates.map((d) => (
              <li key={d.slug}>
                <Chip href={`/events/${d.slug}`}>
                  {dateShort(d.startsAt)}, {timeShort(d.startsAt)}
                </Chip>
              </li>
            ))}
          </ul>
        </nav>
      )}

      <EventTabs
        className="mt-10"
        about={<AboutPanel event={event} />}
        place={<VenuePlace venue={event.venue} />}
        tickets={<TicketsPanel event={event} />}
      />

      {similar.length > 0 && (
        <section aria-labelledby="similar-title" className="mt-14">
          <h2 id="similar-title" className="type-h4 mb-5">
            Похожие события
          </h2>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {similar.map((e) => (
              <li key={e.slug}>
                <EventCard event={e} className="h-full" />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
