import type { ReactNode } from "react";
import { Breadcrumbs } from "@/components/ui/Navigation";

export function LegalPage({ title, updated, children }: { title: string; updated: string; children: ReactNode }) {
  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: title }]} className="mb-6" />
      {/* break-words: «конфиденциальности» — 19 букв без пробелов, на 320px не помещается целиком в type-h2 */}
      <h1 className="type-h2 mb-2 break-words">{title}</h1>
      <p className="mb-8 text-sm text-muted">Действует с {updated}</p>
      <div className="max-w-3xl space-y-8">{children}</div>
    </div>
  );
}

export function LegalSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="type-h5 mb-3">{title}</h2>
      <div className="space-y-3 leading-relaxed text-choco [&_a]:font-semibold [&_a]:text-brick [&_a]:underline-offset-4 [&_a]:hover:underline [&_li]:ml-5 [&_li]:list-disc [&_strong]:font-semibold [&_strong]:text-ink">
        {children}
      </div>
    </section>
  );
}
