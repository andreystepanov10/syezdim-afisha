import { Star } from "lucide-react";
import { cn } from "@/lib/cn";

/** Пять звёзд с дробной заливкой (4.5 → четыре с половиной) */
export function Stars({ value, max = 5, size = 18, className }: { value: number; max?: number; size?: number; className?: string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const row = (
    <span className="flex gap-0.5">
      {Array.from({ length: max }, (_, i) => (
        <Star key={i} width={size} height={size} strokeWidth={1.5} className="shrink-0" fill="currentColor" />
      ))}
    </span>
  );
  return (
    <span role="img" aria-label={`Рейтинг ${value} из ${max}`} className={cn("relative inline-flex", className)}>
      <span className="text-line" aria-hidden>
        {row}
      </span>
      <span className="absolute inset-y-0 left-0 overflow-hidden text-mustard" style={{ width: `${pct}%` }} aria-hidden>
        {row}
      </span>
    </span>
  );
}

/** Компактный рейтинг для карточек: ★ 4.8 (30) */
export function RatingInline({ value, count, className }: { value: number; count?: number; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 text-sm font-semibold text-choco", className)}>
      <Star className="size-4 text-mustard" fill="currentColor" strokeWidth={1.5} aria-hidden />
      <span>
        <span className="sr-only">Рейтинг </span>
        {value.toLocaleString("ru-RU", { maximumFractionDigits: 1 })}
      </span>
      {count != null && <span className="font-normal text-muted">({count})</span>}
    </span>
  );
}

export function ProgressBar({ value, max = 100, label, className }: { value: number; max?: number; label: string; className?: string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={value}
      className={cn("h-2 w-full overflow-hidden rounded-full bg-line", className)}
    >
      <div className="h-full rounded-full bg-olive-strong transition-[width] duration-300" style={{ width: `${pct}%` }} />
    </div>
  );
}
