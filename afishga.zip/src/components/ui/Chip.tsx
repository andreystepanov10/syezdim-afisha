import Link from "next/link";
import { Check } from "lucide-react";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/cn";

// Фильтр-чип: cream в покое, mustard в активном состоянии.
// Визуально 36px, но зона нажатия расширена до 44px через псевдоэлемент.
const chip =
  "focus-ring relative inline-flex min-h-9 items-center gap-1.5 whitespace-nowrap rounded-full px-4 text-sm font-semibold transition duration-200 before:absolute before:inset-x-0 before:-inset-y-1 before:content-['']";

const tone = (active?: boolean) =>
  active ? "bg-mustard text-ink shadow-soft" : "bg-cream text-choco hover:bg-beige";

type Common = { active?: boolean; count?: number; className?: string; children: ReactNode };

export function Chip({
  active,
  count,
  className,
  children,
  href,
  ...rest
}: Common & { href?: string } & Omit<ComponentPropsWithoutRef<"button">, keyof Common | "href">) {
  const content = (
    <>
      {children}
      {count != null && <span className="text-xs font-bold opacity-70">{count}</span>}
    </>
  );
  if (href) {
    return (
      <Link href={href} aria-current={active ? "true" : undefined} aria-label={rest["aria-label"]} className={cn(chip, tone(active), className)}>
        {content}
      </Link>
    );
  }
  return (
    <button type="button" aria-pressed={active ?? false} className={cn(chip, tone(active), className)} {...rest}>
      {content}
    </button>
  );
}

/**
 * Чип-флажок для множественного выбора (категории в фильтрах). Под чипом — настоящий чекбокс:
 * работает с клавиатуры и в обычной форме без JavaScript. Выбор виден не только цветом, но и галочкой.
 */
export function ChipCheckbox({
  checked,
  onChange,
  className,
  children,
  ...rest
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  className?: string;
  children: ReactNode;
} & Omit<ComponentPropsWithoutRef<"input">, "type" | "checked" | "onChange" | "className" | "children">) {
  return (
    <label className={cn("relative inline-flex cursor-pointer", className)}>
      <input {...rest} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="peer sr-only" />
      <span
        className={cn(
          chip,
          tone(checked),
          "peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-choco peer-focus-visible:shadow-[0_0_0_2px_var(--color-mustard)]",
        )}
      >
        {checked && <Check className="-ml-1 size-4" strokeWidth={3} aria-hidden />}
        {children}
      </span>
    </label>
  );
}
