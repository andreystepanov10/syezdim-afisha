"use client";

import { cloneElement, useId } from "react";
import type { ReactElement } from "react";

/** Подсказка по наведению и фокусу. Связана с триггером через aria-describedby */
export function Tooltip({ label, children }: { label: string; children: ReactElement<{ "aria-describedby"?: string }> }) {
  const id = useId();
  return (
    <span className="group relative inline-flex">
      {cloneElement(children, { "aria-describedby": id })}
      <span
        id={id}
        role="tooltip"
        className="pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 -translate-x-1/2 translate-y-1 whitespace-nowrap rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-cream opacity-0 shadow-medium transition duration-200 group-focus-within:translate-y-0 group-focus-within:opacity-100 group-hover:translate-y-0 group-hover:opacity-100"
      >
        {label}
      </span>
    </span>
  );
}
