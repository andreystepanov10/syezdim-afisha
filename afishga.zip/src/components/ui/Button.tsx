import Link from "next/link";
import { LoaderCircle } from "lucide-react";
import type { ButtonHTMLAttributes, ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/cn";

export type ButtonVariant = "primary" | "secondary" | "olive" | "choco" | "ghost" | "link";
export type ButtonSize = "sm" | "md" | "lg";

// Состояния из дизайна: default / hover / active (scale .98) / focus (кольцо) / disabled (40%)
const base =
  "focus-ring relative inline-flex select-none items-center justify-center gap-2 whitespace-nowrap rounded-sm font-display font-semibold transition duration-200 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40 aria-disabled:pointer-events-none aria-disabled:opacity-40";

const variants: Record<ButtonVariant, string> = {
  primary: "bg-brick text-white hover:bg-brick-600 active:bg-brick-700",
  secondary: "border-[1.5px] border-choco/55 bg-transparent text-choco hover:bg-beige/70 active:bg-beige",
  olive: "bg-olive-strong text-white hover:bg-olive-700 active:bg-olive-700",
  choco: "bg-choco text-cream hover:bg-ink active:bg-ink",
  ghost: "bg-white text-choco shadow-soft hover:bg-cream active:bg-beige",
  link: "min-h-0 rounded-xs p-0 text-brick underline-offset-4 hover:underline active:scale-100",
};

const sizes: Record<ButtonSize, string> = {
  sm: "min-h-9 px-3.5 text-[13px]",
  md: "min-h-11 px-5 text-sm",
  lg: "min-h-[52px] px-7 text-base",
};

type Common = {
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
  iconLeft?: ReactNode;
  iconRight?: ReactNode;
  className?: string;
  children?: ReactNode;
};

type AsButton = Common & { loading?: boolean; href?: undefined; external?: undefined } & Omit<
    ComponentPropsWithoutRef<"button">,
    keyof Common
  >;

type AsLink = Common & { href: string; external?: boolean; disabled?: boolean } & Omit<
    ComponentPropsWithoutRef<"a">,
    keyof Common | "href"
  >;

export type ButtonProps = AsButton | AsLink;

function isLink(props: ButtonProps): props is AsLink {
  return props.href !== undefined;
}

export function buttonClasses({
  variant = "primary",
  size = "md",
  fullWidth,
  className,
}: Pick<Common, "variant" | "size" | "fullWidth" | "className">) {
  return cn(base, sizes[size], variants[variant], fullWidth && "w-full", className);
}

export function Button(props: ButtonProps) {
  if (isLink(props)) {
    const { variant, size, fullWidth, iconLeft, iconRight, className, children, external, disabled, href, ...rest } = props;
    const classes = buttonClasses({ variant, size, fullWidth, className });
    const content = (
      <>
        {iconLeft}
        {children}
        {iconRight}
      </>
    );
    if (disabled) {
      // Недоступная ссылка — не ссылка: без href и вне порядка табуляции
      return (
        <span role="link" aria-disabled="true" className={classes}>
          {content}
        </span>
      );
    }
    if (external) {
      // Ссылка на билеты у партнёра: новая вкладка, без передачи referrer/opener
      return (
        <a {...rest} href={href} target="_blank" rel="noopener noreferrer sponsored" className={classes}>
          {content}
        </a>
      );
    }
    return (
      <Link {...rest} href={href} className={classes}>
        {content}
      </Link>
    );
  }

  const { variant, size, fullWidth, iconLeft, iconRight, className, children, loading, disabled, type = "button", ...rest } = props;
  return (
    <button
      {...rest}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={buttonClasses({ variant, size, fullWidth, className })}
    >
      {loading ? <LoaderCircle className="size-4 animate-spin" aria-hidden /> : iconLeft}
      {children}
      {iconRight}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Иконочные кнопки: круглые, 44px (минимальная цель касания)
// ---------------------------------------------------------------------------

type IconVariant = "choco" | "ghost" | "secondary" | "primary";
type IconSize = "sm" | "md" | "lg";

const iconVariants: Record<IconVariant, string> = {
  choco: "bg-choco text-cream hover:bg-ink",
  ghost: "bg-white text-choco shadow-soft hover:bg-cream",
  secondary: "border-[1.5px] border-choco/55 text-choco hover:bg-beige/70",
  primary: "bg-brick text-white hover:bg-brick-600",
};
const iconSizes: Record<IconSize, string> = { sm: "size-9", md: "size-11", lg: "size-[52px]" };

const iconBase =
  "focus-ring inline-flex shrink-0 items-center justify-center rounded-full transition duration-200 active:scale-95 disabled:pointer-events-none disabled:opacity-40";

type IconCommon = { label: string; variant?: IconVariant; size?: IconSize; className?: string; children: ReactNode };

export function IconButton({
  label,
  variant = "choco",
  size = "md",
  className,
  children,
  type = "button",
  ...rest
}: IconCommon & Omit<ButtonHTMLAttributes<HTMLButtonElement>, keyof IconCommon>) {
  return (
    <button {...rest} type={type} aria-label={label} className={cn(iconBase, iconSizes[size], iconVariants[variant], className)}>
      {children}
    </button>
  );
}

export function IconLink({
  label,
  variant = "ghost",
  size = "md",
  className,
  children,
  href,
  ...rest
}: IconCommon & { href: string } & Omit<ComponentPropsWithoutRef<typeof Link>, keyof IconCommon | "href">) {
  return (
    <Link {...rest} href={href} aria-label={label} className={cn(iconBase, iconSizes[size], iconVariants[variant], className)}>
      {children}
    </Link>
  );
}
