"use client";

import { useId, useRef, useState } from "react";
import type { KeyboardEvent, ReactNode } from "react";
import { cn } from "@/lib/cn";

export type TabItem = { id: string; label: string; panel: ReactNode };

/** Вкладки с подчёркиванием. Клавиатура: ←/→, Home/End (паттерн WAI-ARIA Tabs) */
export function Tabs({
  tabs,
  defaultId,
  label,
  className,
  onChange,
}: {
  tabs: TabItem[];
  defaultId?: string;
  label: string;
  className?: string;
  /** Вызывается при переключении вкладки (клик или клавиатура) — например, чтобы отложенно смонтировать содержимое */
  onChange?: (id: string) => void;
}) {
  const [active, setActive] = useState(defaultId ?? tabs[0]?.id);
  const uid = useId();
  const buttons = useRef<Record<string, HTMLButtonElement | null>>({});

  const select = (id: string) => {
    setActive(id);
    onChange?.(id);
  };

  const move = (e: KeyboardEvent, index: number) => {
    const last = tabs.length - 1;
    const target =
      e.key === "ArrowRight" ? (index === last ? 0 : index + 1) : e.key === "ArrowLeft" ? (index === 0 ? last : index - 1) : e.key === "Home" ? 0 : e.key === "End" ? last : -1;
    if (target < 0) return;
    e.preventDefault();
    const next = tabs[target].id;
    select(next);
    buttons.current[next]?.focus();
  };

  return (
    <div className={className}>
      <div role="tablist" aria-label={label} className="flex gap-1 overflow-x-auto rounded-md border border-line bg-white p-1 shadow-soft">
        {tabs.map((tab, i) => {
          const selected = tab.id === active;
          return (
            <button
              key={tab.id}
              ref={(el) => {
                buttons.current[tab.id] = el;
              }}
              id={`${uid}-tab-${tab.id}`}
              role="tab"
              type="button"
              aria-selected={selected}
              aria-controls={`${uid}-panel-${tab.id}`}
              tabIndex={selected ? 0 : -1}
              onClick={() => select(tab.id)}
              onKeyDown={(e) => move(e, i)}
              className={cn(
                "focus-ring relative min-h-11 whitespace-nowrap rounded-sm px-4 text-[15px] font-semibold transition duration-200",
                selected ? "text-ink" : "text-muted hover:text-ink",
              )}
            >
              {tab.label}
              <span
                aria-hidden
                className={cn(
                  "absolute inset-x-4 bottom-1 h-0.5 rounded-full bg-brick transition-transform duration-200",
                  selected ? "scale-x-100" : "scale-x-0",
                )}
              />
            </button>
          );
        })}
      </div>
      {tabs.map((tab) => (
        <div
          key={tab.id}
          role="tabpanel"
          id={`${uid}-panel-${tab.id}`}
          aria-labelledby={`${uid}-tab-${tab.id}`}
          hidden={tab.id !== active}
          className="pt-4"
        >
          {tab.panel}
        </div>
      ))}
    </div>
  );
}
