import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { dayNumber, monthWeekdayShort } from "@/lib/format";

type BadgeVariant = "hot" | "free" | "age" | "neutral" | "mustard" | "pushkin";

const variants: Record<BadgeVariant, string> = {
  hot: "bg-brick text-white",
  free: "bg-olive-strong text-white",
  age: "border-[1.5px] border-brick bg-white/80 text-brick",
  neutral: "bg-beige text-choco",
  mustard: "bg-mustard text-ink",
  pushkin: "bg-sky text-ink",
};

export function Badge({ variant = "neutral", className, children }: { variant?: BadgeVariant; className?: string; children: ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center rounded-full px-2.5 font-display text-xs font-bold leading-none",
        variants[variant],
        className,
      )}
    >
      {children}
    </span>
  );
}

/** Плашка даты на обложке: крупное число + «ОКТ, СБ» */
export function DateBadge({ date, className }: { date: Date | string; className?: string }) {
  return (
    <div
      className={cn(
        "flex h-14 w-14 flex-col items-center justify-center rounded-md bg-white/95 text-center shadow-soft",
        className,
      )}
    >
      <span className="font-display text-xl font-extrabold leading-none text-ink">{dayNumber(date)}</span>
      <span className="mt-1 text-[10px] font-bold leading-none tracking-wide text-muted">{monthWeekdayShort(date)}</span>
    </div>
  );
}
