import { useId } from "react";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { CircleAlert } from "lucide-react";
import { cn } from "@/lib/cn";

// Чекбокс, радио и переключатель. Метка кликабельна, строка не ниже 44px (цель касания).

type ChoiceBase = { label: ReactNode; error?: string; className?: string };

const row =
  "inline-flex min-h-11 cursor-pointer items-center gap-3 text-[15px] has-[:disabled]:cursor-not-allowed has-[:disabled]:opacity-40";

function ErrorText({ id, children }: { id: string; children: ReactNode }) {
  return (
    <p id={id} className="flex items-start gap-1.5 text-sm font-medium text-brick">
      <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
      {children}
    </p>
  );
}

export function Checkbox({ label, error, className, id, ...props }: ChoiceBase & Omit<ComponentPropsWithoutRef<"input">, "type">) {
  const auto = useId();
  const inputId = id ?? auto;
  return (
    <div className={className}>
      <label className={row}>
        <input
          {...props}
          id={inputId}
          type="checkbox"
          className="ui-check"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${inputId}-error` : undefined}
        />
        <span>{label}</span>
      </label>
      {error && <ErrorText id={`${inputId}-error`}>{error}</ErrorText>}
    </div>
  );
}

export function Radio({ label, className, ...props }: Omit<ChoiceBase, "error"> & Omit<ComponentPropsWithoutRef<"input">, "type">) {
  return (
    <div className={className}>
      <label className={row}>
        <input {...props} type="radio" className="ui-radio" />
        <span>{label}</span>
      </label>
    </div>
  );
}

export function Switch({ label, error, className, id, ...props }: ChoiceBase & Omit<ComponentPropsWithoutRef<"input">, "type" | "role">) {
  const auto = useId();
  const inputId = id ?? auto;
  return (
    <div className={className}>
      <label className={row}>
        <input
          {...props}
          id={inputId}
          type="checkbox"
          role="switch"
          className="ui-switch"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${inputId}-error` : undefined}
        />
        <span className={cn(error && "text-brick")}>{label}</span>
      </label>
      {error && <ErrorText id={`${inputId}-error`}>{error}</ErrorText>}
    </div>
  );
}
