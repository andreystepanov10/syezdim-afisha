import { useId } from "react";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { CircleAlert, Search } from "lucide-react";
import { cn } from "@/lib/cn";

type FieldBase = {
  label?: string;
  hint?: string;
  /** Текст ошибки: подсвечивает поле и озвучивается скринридером */
  error?: string;
  className?: string;
};

function FieldMessage({ id, hint, error }: { id: string; hint?: string; error?: string }) {
  if (error) {
    return (
      <p id={id} className="flex items-start gap-1.5 text-sm font-medium text-brick">
        <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
        {error}
      </p>
    );
  }
  if (hint) {
    return (
      <p id={id} className="text-sm text-muted">
        {hint}
      </p>
    );
  }
  return null;
}

function Label({ htmlFor, children }: { htmlFor: string; children: ReactNode }) {
  return (
    <label htmlFor={htmlFor} className="text-sm font-semibold text-ink">
      {children}
    </label>
  );
}

export function Input({ label, hint, error, className, id, ...props }: FieldBase & ComponentPropsWithoutRef<"input">) {
  const auto = useId();
  const inputId = id ?? auto;
  const messageId = `${inputId}-message`;
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <Label htmlFor={inputId}>{label}</Label>}
      <input
        {...props}
        id={inputId}
        className="ui-field"
        aria-invalid={error ? true : undefined}
        aria-describedby={error || hint ? messageId : undefined}
      />
      <FieldMessage id={messageId} hint={hint} error={error} />
    </div>
  );
}

/** Поле поиска: «таблетка» с иконкой лупы, как в макете */
export function SearchInput({ label, hint, error, className, id, ...props }: FieldBase & ComponentPropsWithoutRef<"input">) {
  const auto = useId();
  const inputId = id ?? auto;
  const messageId = `${inputId}-message`;
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <Label htmlFor={inputId}>{label}</Label>}
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted" aria-hidden />
        <input
          {...props}
          id={inputId}
          type="search"
          className="ui-field rounded-full pl-11 pr-4"
          aria-invalid={error ? true : undefined}
          aria-describedby={error || hint ? messageId : undefined}
        />
      </div>
      <FieldMessage id={messageId} hint={hint} error={error} />
    </div>
  );
}

/** Нативный select с фирменным «скином» — на мобильных открывается системный выбор */
export function Select({
  label,
  hint,
  error,
  className,
  id,
  children,
  ...props
}: FieldBase & ComponentPropsWithoutRef<"select">) {
  const auto = useId();
  const selectId = id ?? auto;
  const messageId = `${selectId}-message`;
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <Label htmlFor={selectId}>{label}</Label>}
      <select
        {...props}
        id={selectId}
        className="ui-field"
        aria-invalid={error ? true : undefined}
        aria-describedby={error || hint ? messageId : undefined}
      >
        {children}
      </select>
      <FieldMessage id={messageId} hint={hint} error={error} />
    </div>
  );
}

export function Textarea({ label, hint, error, className, id, rows = 4, ...props }: FieldBase & ComponentPropsWithoutRef<"textarea">) {
  const auto = useId();
  const inputId = id ?? auto;
  const messageId = `${inputId}-message`;
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <Label htmlFor={inputId}>{label}</Label>}
      <textarea
        {...props}
        id={inputId}
        rows={rows}
        className="ui-field resize-y py-2.5"
        aria-invalid={error ? true : undefined}
        aria-describedby={error || hint ? messageId : undefined}
      />
      <FieldMessage id={messageId} hint={hint} error={error} />
    </div>
  );
}
