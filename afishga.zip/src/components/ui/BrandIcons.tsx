// Иконки соцсетей, которых нет в lucide. Только сети, доступные в РФ (VK, Telegram).
type IconProps = { className?: string };

export function VkIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden className={className}>
      <path d="M12.8 17.5C7.3 17.5 4.2 13.7 4.1 7.5h2.7c.1 4.6 2.1 6.5 3.7 6.9V7.5h2.6v4c1.6-.2 3.3-2 3.8-4h2.5c-.4 2.5-2.2 4.3-3.4 5 1.2.6 3.2 2.1 4 4.9h-2.8c-.6-1.9-2.1-3.3-4.1-3.5v3.6h-.3z" />
    </svg>
  );
}

export function TelegramIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden className={className}>
      <path d="M20.7 4.4 3.5 11c-1.2.5-1.2 1.2-.2 1.5l4.4 1.4 1.7 5.2c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.1-2 4.4 3.2c.8.5 1.4.2 1.6-.8l2.9-13.7c.3-1.2-.4-1.7-1.5-1.3zM9.1 13.6l8.7-5.5c.4-.3.8-.1.5.2l-7.2 6.5-.3 3-1.7-4.2z" />
    </svg>
  );
}
