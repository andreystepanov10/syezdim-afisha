"use client";

import { useEffect, useId, useRef } from "react";
import type { ReactNode } from "react";
import { X } from "lucide-react";
import { IconButton } from "./Button";
import { cn } from "@/lib/cn";

/**
 * Модальное окно на нативном <dialog>: фокус запирается внутри, Esc закрывает,
 * фон под окном неактивен — всё это делает браузер.
 * sheet — на телефоне окно выезжает снизу «шторкой» на всю ширину (фильтры), на планшете и десктопе остаётся по центру.
 * Содержимое прокручивается внутри окна, шапка и подвал остаются на месте.
 */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  sheet,
  className,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  sheet?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      aria-labelledby={titleId}
      onClose={onClose}
      // клик по подложке (а не по содержимому) закрывает окно
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className={cn(
        "m-auto w-[min(92vw,34rem)] flex-col rounded-xl bg-paper p-0 text-choco shadow-hover backdrop:bg-ink/60 backdrop:backdrop-blur-[2px] open:flex open:animate-modal-in",
        sheet && "max-md:mb-0 max-md:max-h-[92dvh] max-md:w-full max-md:max-w-none max-md:rounded-b-none max-md:open:animate-sheet-in",
        className,
      )}
    >
      <div className="flex shrink-0 items-start justify-between gap-4 border-b border-line px-6 py-4">
        <h2 id={titleId} className="type-h5 pt-2">
          {title}
        </h2>
        <IconButton label="Закрыть окно" variant="ghost" size="md" onClick={onClose}>
          <X className="size-5" aria-hidden />
        </IconButton>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">{children}</div>
      {footer && <div className="flex shrink-0 flex-wrap justify-end gap-3 border-t border-line bg-cream/60 px-6 py-4">{footer}</div>}
    </dialog>
  );
}
