import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Fragment } from "react";
import { cn } from "@/lib/cn";

// ---------------------------------------------------------------------------
// Хлебные крошки
// ---------------------------------------------------------------------------

export type Crumb = { label: string; href?: string };

export function Breadcrumbs({ items, className }: { items: Crumb[]; className?: string }) {
  return (
    <nav aria-label="Хлебные крошки" className={className}>
      <ol className="flex flex-wrap items-center gap-x-1 gap-y-0.5 text-sm text-muted">
        {items.map((item, i) => {
          const last = i === items.length - 1;
          return (
            <Fragment key={item.label}>
              <li className="inline-flex items-center">
                {last || !item.href ? (
                  <span aria-current={last ? "page" : undefined} className={cn(last && "font-semibold text-ink")}>
                    {item.label}
                  </span>
                ) : (
                  <Link href={item.href} className="focus-ring inline-flex min-h-8 items-center rounded-xs underline-offset-4 hover:text-brick hover:underline">
                    {item.label}
                  </Link>
                )}
              </li>
              {!last && (
                <li aria-hidden className="inline-flex">
                  <ChevronRight className="size-4" />
                </li>
              )}
            </Fragment>
          );
        })}
      </ol>
    </nav>
  );
}

// ---------------------------------------------------------------------------
// Пагинация: ‹ 1 … 4 5 6 … 20 ›
// ---------------------------------------------------------------------------

function pageItems(current: number, total: number): (number | "gap-l" | "gap-r")[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const items: (number | "gap-l" | "gap-r")[] = [1];
  const from = Math.max(2, current - 1);
  const to = Math.min(total - 1, current + 1);
  if (from > 2) items.push("gap-l");
  for (let p = from; p <= to; p++) items.push(p);
  if (to < total - 1) items.push("gap-r");
  items.push(total);
  return items;
}

const pageBox = "focus-ring inline-flex size-11 items-center justify-center rounded-sm font-display text-sm font-bold transition duration-200";

export function Pagination({
  page,
  pageCount,
  hrefFor,
  className,
}: {
  page: number;
  pageCount: number;
  hrefFor: (page: number) => string;
  className?: string;
}) {
  if (pageCount <= 1) return null;
  return (
    <nav aria-label="Страницы" className={cn("flex items-center gap-2", className)}>
      {page > 1 ? (
        <Link href={hrefFor(page - 1)} aria-label="Предыдущая страница" rel="prev" className={cn(pageBox, "bg-brick text-white hover:bg-brick-600")}>
          <ChevronLeft className="size-5" aria-hidden />
        </Link>
      ) : (
        <span aria-hidden className={cn(pageBox, "bg-brick text-white opacity-40")}>
          <ChevronLeft className="size-5" />
        </span>
      )}
      {/* На узких экранах номера не помещаются в 44px-цели — показываем «5 из 20» */}
      <p className="px-2 text-sm font-semibold text-choco sm:hidden">
        {page} из {pageCount}
      </p>
      <ul className="hidden items-center gap-1 sm:flex">
        {pageItems(page, pageCount).map((item) =>
          typeof item === "string" ? (
            <li key={item} aria-hidden className="inline-flex size-8 items-center justify-center text-muted">
              …
            </li>
          ) : (
            <li key={item}>
              <Link
                href={hrefFor(item)}
                aria-label={`Страница ${item}`}
                aria-current={item === page ? "page" : undefined}
                className={cn(pageBox, item === page ? "bg-mustard text-ink shadow-soft" : "text-choco hover:bg-cream")}
              >
                {item}
              </Link>
            </li>
          ),
        )}
      </ul>
      {page < pageCount ? (
        <Link href={hrefFor(page + 1)} aria-label="Следующая страница" rel="next" className={cn(pageBox, "bg-choco text-cream hover:bg-ink")}>
          <ChevronRight className="size-5" aria-hidden />
        </Link>
      ) : (
        <span aria-hidden className={cn(pageBox, "bg-choco text-cream opacity-40")}>
          <ChevronRight className="size-5" />
        </span>
      )}
    </nav>
  );
}
