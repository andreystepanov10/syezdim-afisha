import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

/** Иллюстрация «дорога с меткой» — фирменный пустой экран */
export function RoadIllustration({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 240 150" fill="none" aria-hidden className={cn("h-auto w-56", className)}>
      <circle cx="176" cy="38" r="20" fill="#E0A82E" />
      <g stroke="#E0A82E" strokeWidth="3" strokeLinecap="round">
        <path d="M176 6v8M176 62v8M144 38h8M200 38h8M153 15l6 6M199 61l-6-6M153 61l6-6M199 15l-6 6" />
      </g>
      <path d="M0 108c34-22 62-18 92-10s60 6 148-22v74H0z" fill="#E8D5AE" />
      <path d="M0 126c40-16 70-8 104 0s84 8 136-10v34H0z" fill="#7A7A3D" opacity=".55" />
      <path d="M96 150c8-28 18-44 44-52 22-6 34-14 30-24h14c4 16-8 26-32 34-20 7-30 22-34 42z" fill="#3B2417" />
      <path d="M118 150c6-18 14-32 36-42 18-8 26-16 24-26" stroke="#F5E6C8" strokeWidth="2.5" strokeDasharray="7 6" strokeLinecap="round" />
      <path d="M62 34c-11 0-19 8-19 18 0 14 19 30 19 30s19-16 19-30c0-10-8-18-19-18z" fill="#B54A2B" stroke="#3B2417" strokeWidth="2" />
      <circle cx="62" cy="52" r="6.5" fill="#FBF5E9" />
    </svg>
  );
}

export function EmptyState({
  title,
  description,
  action,
  className,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center gap-4 rounded-xl border border-dashed border-line-strong/40 bg-cream/50 px-6 py-12 text-center", className)}>
      <RoadIllustration />
      <div className="space-y-1.5">
        <h2 className="type-h4">{title}</h2>
        {description && <p className="mx-auto max-w-md text-muted">{description}</p>}
      </div>
      {action}
    </div>
  );
}
