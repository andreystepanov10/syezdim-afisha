"use client";

import { Children, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/cn";
import { IconButton } from "./Button";

/**
 * Горизонтальная лента с прилипанием карточек. На телефоне листается пальцем,
 * на десктопе — стрелками; стрелки видны только когда есть что прокручивать.
 */
export function Carousel({
  label,
  itemClassName,
  className,
  children,
}: {
  label: string;
  itemClassName?: string;
  className?: string;
  children: ReactNode;
}) {
  const list = useRef<HTMLUListElement>(null);
  const [edge, setEdge] = useState({ start: true, end: true });

  useEffect(() => {
    const el = list.current;
    if (!el) return;
    const update = () => setEdge({ start: el.scrollLeft <= 4, end: el.scrollLeft + el.clientWidth >= el.scrollWidth - 4 });
    el.addEventListener("scroll", update, { passive: true });
    const observer = new ResizeObserver(update); // срабатывает сразу при подключении — начальное состояние считается там
    observer.observe(el);
    return () => {
      el.removeEventListener("scroll", update);
      observer.disconnect();
    };
  }, []);

  const scrollPage = (direction: 1 | -1) => {
    const el = list.current;
    if (!el) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    el.scrollBy({ left: direction * el.clientWidth * 0.85, behavior: reduce ? "auto" : "smooth" });
  };

  const scrollable = !(edge.start && edge.end);

  return (
    <div role="region" aria-roledescription="карусель" aria-label={label} className={cn("relative", className)}>
      {scrollable && (
        <>
          <IconButton
            label="Назад"
            variant="ghost"
            disabled={edge.start}
            onClick={() => scrollPage(-1)}
            className="absolute -left-5 top-[38%] z-10 hidden -translate-y-1/2 shadow-medium md:inline-flex"
          >
            <ChevronLeft className="size-5" aria-hidden />
          </IconButton>
          <IconButton
            label="Вперёд"
            variant="ghost"
            disabled={edge.end}
            onClick={() => scrollPage(1)}
            className="absolute -right-5 top-[38%] z-10 hidden -translate-y-1/2 shadow-medium md:inline-flex"
          >
            <ChevronRight className="size-5" aria-hidden />
          </IconButton>
        </>
      )}
      <ul
        ref={list}
        className="-mx-4 flex snap-x snap-mandatory scroll-px-4 gap-3 overflow-x-auto px-4 pb-6 pt-1 [scrollbar-width:none] md:mx-0 md:gap-5 md:px-0 [&::-webkit-scrollbar]:hidden"
      >
        {Children.map(children, (child) => (
          <li className={cn("shrink-0 snap-start", itemClassName)}>{child}</li>
        ))}
      </ul>
    </div>
  );
}
