"use client";

import { createContext, useCallback, useContext, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { CircleAlert, CircleCheck, Info, X } from "lucide-react";
import { cn } from "@/lib/cn";

type ToastVariant = "success" | "error" | "info";
export type ToastInput = { title: string; description?: string; variant?: ToastVariant; duration?: number };
type ToastItem = ToastInput & { id: number };

const ToastContext = createContext<{ toast: (input: ToastInput) => void } | null>(null);

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast нужно вызывать внутри <ToastProvider>");
  return ctx;
}

const styles: Record<ToastVariant, { bar: string; icon: ReactNode }> = {
  success: { bar: "bg-olive-strong", icon: <CircleCheck className="size-5 text-olive-strong" aria-hidden /> },
  error: { bar: "bg-brick", icon: <CircleAlert className="size-5 text-brick" aria-hidden /> },
  info: { bar: "bg-mustard", icon: <Info className="size-5 text-mustard-600" aria-hidden /> },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const counter = useRef(0);

  const dismiss = useCallback((id: number) => setItems((list) => list.filter((t) => t.id !== id)), []);

  const toast = useCallback(
    (input: ToastInput) => {
      const id = ++counter.current;
      setItems((list) => [...list.slice(-3), { ...input, id }]);
      window.setTimeout(() => dismiss(id), input.duration ?? 5000);
    },
    [dismiss],
  );

  const value = useMemo(() => ({ toast }), [toast]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      {/* Область уведомлений: на мобильном поднята над нижним таб-баром */}
      <div
        role="region"
        aria-live="polite"
        aria-label="Уведомления"
        className="pointer-events-none fixed inset-x-4 bottom-20 z-[60] flex flex-col items-center gap-2 md:inset-x-auto md:bottom-6 md:right-6 md:items-end"
      >
        {items.map((t) => {
          const variant = t.variant ?? "info";
          return (
            <div
              key={t.id}
              role={variant === "error" ? "alert" : "status"}
              className="pointer-events-auto relative flex w-full max-w-sm animate-toast-in items-start gap-3 overflow-hidden rounded-md border border-line bg-cream py-3 pl-5 pr-3 shadow-medium"
            >
              <span aria-hidden className={cn("absolute inset-y-0 left-0 w-1.5", styles[variant].bar)} />
              <span className="mt-0.5">{styles[variant].icon}</span>
              <div className="min-w-0 flex-1">
                <p className="font-display text-sm font-bold text-ink">{t.title}</p>
                {t.description && <p className="mt-0.5 text-sm text-muted">{t.description}</p>}
              </div>
              <button
                type="button"
                onClick={() => dismiss(t.id)}
                aria-label="Закрыть уведомление"
                className="focus-ring -my-1 inline-flex size-9 shrink-0 items-center justify-center rounded-full text-muted transition hover:bg-beige hover:text-ink"
              >
                <X className="size-4" aria-hidden />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}
