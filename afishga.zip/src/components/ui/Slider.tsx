"use client";

import { useId, useState } from "react";
import { cn } from "@/lib/cn";

// Нативный <input type="range"> сдвигает центр бегунка на половину его ширины от краёв —
// поправка нужна, чтобы заливка трека сходилась с бегунком.
const THUMB = 24;
const pos = (pct: number) => `calc(${pct}% + ${((THUMB / 2) * (1 - pct / 50)).toFixed(2)}px)`;

type SingleProps = {
  label: string;
  min?: number;
  max?: number;
  step?: number;
  value?: number;
  defaultValue?: number;
  onChange?: (value: number) => void;
  tone?: "olive" | "brick";
  format?: (value: number) => string;
  className?: string;
};

export function Slider({
  label,
  min = 0,
  max = 100,
  step = 1,
  value,
  defaultValue = min,
  onChange,
  tone = "olive",
  format = String,
  className,
}: SingleProps) {
  const [inner, setInner] = useState(defaultValue);
  const current = value ?? inner;
  const pct = ((current - min) / (max - min)) * 100;
  const id = useId();
  return (
    <div className={cn("flex flex-col gap-1", className)}>
      <div className="flex items-baseline justify-between text-sm">
        <label htmlFor={id} className="font-semibold text-ink">
          {label}
        </label>
        <output htmlFor={id} className="font-display font-bold text-choco">
          {format(current)}
        </output>
      </div>
      <input
        id={id}
        type="range"
        className="ui-range"
        data-tone={tone}
        min={min}
        max={max}
        step={step}
        value={current}
        style={{ "--p": pos(pct) } as React.CSSProperties}
        onChange={(e) => {
          const next = Number(e.target.value);
          setInner(next);
          onChange?.(next);
        }}
      />
    </div>
  );
}

type RangeProps = {
  label: string;
  min: number;
  max: number;
  step?: number;
  defaultValue?: [number, number];
  onChange?: (value: [number, number]) => void;
  format?: (value: number) => string;
  className?: string;
};

/** Диапазон «от – до» (фильтр цены в каталоге) */
export function RangeSlider({ label, min, max, step = 100, defaultValue = [min, max], onChange, format = String, className }: RangeProps) {
  const [[lo, hi], setRange] = useState<[number, number]>(defaultValue);
  const loPct = ((lo - min) / (max - min)) * 100;
  const hiPct = ((hi - min) / (max - min)) * 100;
  const update = (next: [number, number]) => {
    setRange(next);
    onChange?.(next);
  };
  const span = hiPct - loPct;
  return (
    <div className={cn("flex flex-col gap-1", className)} role="group" aria-label={label}>
      <div className="flex items-baseline justify-between text-sm">
        <span className="font-semibold text-ink">{label}</span>
        <span className="font-display font-bold text-choco">
          {format(lo)} – {format(hi)}
        </span>
      </div>
      <div className="relative h-8">
        <div className="absolute inset-x-0 top-[13px] h-1.5 rounded-full bg-line" />
        <div
          className="absolute top-[13px] h-1.5 rounded-full bg-olive-strong"
          style={{ left: pos(loPct), width: `calc(${span}% - ${(span * (THUMB / 100)).toFixed(2)}px)` }}
        />
        <input
          type="range"
          className="ui-range-dual"
          aria-label={`${label}: от`}
          min={min}
          max={max}
          step={step}
          value={lo}
          style={{ zIndex: lo > max - (max - min) / 8 ? 5 : 3 }}
          onChange={(e) => update([Math.min(Number(e.target.value), hi - step), hi])}
        />
        <input
          type="range"
          className="ui-range-dual"
          aria-label={`${label}: до`}
          min={min}
          max={max}
          step={step}
          value={hi}
          style={{ zIndex: 4 }}
          onChange={(e) => update([lo, Math.max(Number(e.target.value), lo + step)])}
        />
      </div>
    </div>
  );
}
