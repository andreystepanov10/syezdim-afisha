import { cn } from "@/lib/cn";

/** Заглушка на время загрузки (мерцающая «бумага»). Скрыта от скринридера */
export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={cn(
        "animate-shimmer rounded-sm bg-[linear-gradient(100deg,var(--color-beige)_30%,var(--color-cream)_50%,var(--color-beige)_70%)] bg-[length:200%_100%]",
        className,
      )}
    />
  );
}

/** decorative — когда карточек много и «Загрузка…» озвучивает один общий контейнер, а не каждая карточка */
export function EventCardSkeleton({ decorative }: { decorative?: boolean }) {
  return (
    <div
      {...(decorative ? { "aria-hidden": true } : { role: "status", "aria-label": "Загрузка события" })}
      className="overflow-hidden rounded-lg bg-white shadow-soft"
    >
      <Skeleton className="aspect-[8/5] rounded-none" />
      <div className="space-y-3 p-4">
        <Skeleton className="h-3 w-2/5" />
        <Skeleton className="h-5 w-4/5" />
        <Skeleton className="h-4 w-3/5" />
        <Skeleton className="h-11 w-full" />
      </div>
    </div>
  );
}
