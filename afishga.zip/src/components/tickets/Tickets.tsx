import { Download, Send, Share2 } from "lucide-react";
import { EventCard } from "@/components/cards/EventCard";
import { Button, buttonClasses } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { Breadcrumbs } from "@/components/ui/Navigation";
import { timeShort } from "@/lib/format";
import { groupFavoritesByDay } from "@/lib/plan";
import type { EventSummary } from "@/lib/types";

/** Своей продажи билетов на сайте нет — «Купить билет» ведёт к партнёру, поэтому здесь избранное, сгруппированное в план по дням */
export function Tickets({
  events,
  hasBot = false,
  linkStatus,
}: {
  events: EventSummary[];
  /** Настроен Telegram-бот — показываем «Открыть в Telegram» (общая подборка с ботом) */
  hasBot?: boolean;
  /** Результат перехода из бота по ссылке «Открыть подборку на сайте» */
  linkStatus?: "ok" | "expired";
}) {
  const { upcoming, past } = groupFavoritesByDay(events, new Date());

  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Мои билеты" }]} className="mb-6" />
      <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="type-h2 mb-2">Мои билеты</h1>
          <p className="text-muted">
            Билеты продают партнёры — сайт ведёт к ним при покупке. Здесь собраны события, которые вы отметили сердечком, по датам —
            ваш план. Вход не нужен: список привязан к этому браузеру{hasBot ? " — а через Telegram-бота его можно открыть на телефоне и получать напоминания" : " и не синхронизируется между устройствами"}.
          </p>
        </div>
        {/* Ссылки на API-роуты (редиректы и файл), а не на страницы — поэтому <a>, а не Link */}
        <div className="flex flex-wrap gap-2">
          {hasBot && (
            // eslint-disable-next-line @next/next/no-html-link-for-pages -- редирект API-роута в Telegram
            <a href="/api/telegram/connect" className={buttonClasses({ variant: "secondary", size: "sm" })}>
              <Send className="size-4" aria-hidden />
              Открыть в Telegram
            </a>
          )}
          {upcoming.length > 0 && (
            <>
              {/* eslint-disable-next-line @next/next/no-html-link-for-pages -- API-роут создаёт ссылку и перенаправляет на неё */}
              <a href="/api/share" className={buttonClasses({ variant: "secondary", size: "sm" })}>
                <Share2 className="size-4" aria-hidden />
                Поделиться подборкой
              </a>
              {/* eslint-disable-next-line @next/next/no-html-link-for-pages -- ссылка на файл API-роута, а не на страницу */}
              <a href="/api/plan/ics" className={buttonClasses({ variant: "secondary", size: "sm" })}>
                <Download className="size-4" aria-hidden />
                Скачать план (.ics)
              </a>
            </>
          )}
        </div>
      </div>

      {linkStatus && (
        <p role="status" className="mb-8 rounded-lg bg-beige px-4 py-3 text-sm">
          {linkStatus === "ok"
            ? "Готово: подборка связана с Telegram-ботом — сохраняйте события здесь или в боте, список общий."
            : "Ссылка из бота устарела (она действует 15 минут) — нажмите в боте «Открыть на сайте» ещё раз."}
        </p>
      )}

      {upcoming.length > 0 ? (
        <div className="space-y-10">
          {upcoming.map((day) => (
            <section key={day.key} aria-labelledby={`plan-day-${day.key}`}>
              <h2 id={`plan-day-${day.key}`} className="type-h5 mb-4">
                {day.label}
              </h2>
              <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {day.events.map((event) => (
                  <li key={event.slug}>
                    <EventCard event={event} actions="buy-more" className="h-full" timeLabel={timeShort(event.startsAt)} />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : (
        <EmptyState
          title="Пока пусто"
          description="Отмечайте события сердечком в афише — они будут появляться здесь, сгруппированные по датам."
          action={
            <Button href="/events" variant="secondary">
              Смотреть события
            </Button>
          }
        />
      )}

      {past.length > 0 && (
        <section aria-labelledby="plan-past-title" className="mt-14 border-t border-line pt-8">
          <h2 id="plan-past-title" className="type-h5 mb-4 text-muted">
            Прошедшие
          </h2>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {past.map((event) => (
              <li key={event.slug}>
                <EventCard event={event} actions="buy-more" className="h-full" />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
