"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import { useCity } from "@/lib/city-store";
import { TAB_NAV, isActive, navHref } from "./nav";

/** Нижняя навигация для телефонов (в дизайне — Mobile Bottom Tab Bar). Цели касания — 56px */
export function MobileTabBar() {
  const pathname = usePathname();
  const city = useCity();
  if (pathname.startsWith("/admin")) return null; // админка — внутренний инструмент, нижняя навигация сайта тут ни к чему
  return (
    <nav
      aria-label="Нижняя панель навигации"
      className="fixed inset-x-0 bottom-0 z-50 border-t border-line bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
    >
      <ul className="mx-auto grid max-w-lg grid-cols-5">
        {TAB_NAV.map(({ href, label, icon: Icon }) => {
          const active = isActive(pathname, href);
          return (
            <li key={href}>
              <Link
                href={navHref(href, city)}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "focus-ring relative flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold transition-colors duration-200",
                  active ? "text-brick" : "text-muted hover:text-ink",
                )}
              >
                <span
                  aria-hidden
                  className={cn(
                    "absolute inset-x-5 top-0 h-0.5 rounded-b-full bg-brick transition-transform duration-200",
                    active ? "scale-x-100" : "scale-x-0",
                  )}
                />
                <Icon className="size-[22px]" strokeWidth={active ? 2.4 : 2} aria-hidden />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
