import { CalendarDays, Heart, House, MapPin, Ticket } from "lucide-react";
import { catalogPath } from "@/data/catalog-url";
import { isCitySlug, type CitySlug } from "@/lib/cities";

// Разделы сайта — единый источник для шапки, нижнего таб-бара и подвала
export const MAIN_NAV = [
  { href: "/events", label: "События" },
  { href: "/venues", label: "Места" },
  { href: "/collections", label: "Подборки" },
  { href: "/calendar", label: "Календарь" },
] as const;

export const TAB_NAV = [
  { href: "/", label: "Главная", icon: House },
  { href: "/events", label: "События", icon: Ticket },
  { href: "/venues", label: "Места", icon: MapPin },
  { href: "/calendar", label: "Календарь", icon: CalendarDays },
  { href: "/tickets", label: "Билеты", icon: Heart },
] as const;

/** Куда ведёт пункт меню: «События» — в каталог выбранного города (/voronezh/events), остальные — как есть */
export function navHref(href: string, city: CitySlug) {
  return href === "/events" ? catalogPath(city) : href;
}

export function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/";
  // Каталог города (/voronezh/events) — тоже раздел «События»
  const [, first = "", second] = pathname.split("/");
  const path = isCitySlug(first) && second === "events" ? pathname.slice(first.length + 1) : pathname;
  return path === href || path.startsWith(`${href}/`);
}
