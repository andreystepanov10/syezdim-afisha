import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/cn";

/** Словесный знак: «РАДИУС» (Oswald) + рукописное «Съездим» (Marck Script) — как в шапке макета */
export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("relative inline-flex flex-col leading-none", className)} aria-hidden>
      <span className="font-logo text-[1.75rem] font-bold uppercase leading-[0.95] tracking-tight text-ink md:text-[2.125rem]">
        Радиус
      </span>
      <span className="mt-1 ml-[30%] -rotate-3 whitespace-nowrap font-script text-[1.25rem] leading-none text-brick md:text-[1.5rem]">
        «Съездим»
      </span>
    </span>
  );
}

export function Logo({ className }: { className?: string }) {
  return (
    <Link
      href="/"
      aria-label="Радиус «Съездим» — афиша Черноземья, на главную"
      className={cn("focus-ring inline-flex items-center rounded-sm", className)}
    >
      <Wordmark />
    </Link>
  );
}

export function Emblem({ size = 56, className }: { size?: number; className?: string }) {
  return <Image src="/brand/emblem.png" alt="" width={size} height={size} className={cn("shrink-0", className)} />;
}
