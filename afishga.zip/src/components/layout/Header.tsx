import { Heart, Search } from "lucide-react";
import { IconLink } from "@/components/ui/Button";
import { CitySelect } from "./CitySelect";
import { Logo } from "./Logo";
import { NavLinks } from "./NavLinks";

/**
 * Шапка: 80px на десктопе (по дизайн-системе), 56px на телефоне.
 * На телефоне разделы — в нижнем таб-баре. Аккаунтов на сайте нет (избранное анонимно, по устройству) —
 * поэтому справа только поиск и «Мои билеты», без входа.
 */
export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-paper/90 backdrop-blur supports-[backdrop-filter]:bg-paper/80">
      <div className="container-page flex h-14 items-center gap-4 md:h-20">
        <Logo />
        <nav aria-label="Основная навигация" className="ml-2 hidden md:block xl:ml-10">
          <NavLinks />
        </nav>
        <div className="ml-auto flex items-center gap-1 md:gap-2 lg:gap-4">
          <CitySelect />
          <IconLink href="/search" label="Поиск по афише" className="bg-transparent shadow-none hover:bg-beige/70">
            <Search className="size-5" aria-hidden />
          </IconLink>
          <IconLink href="/tickets" label="Мои билеты" variant="primary">
            <Heart className="size-5" aria-hidden />
          </IconLink>
        </div>
      </div>
    </header>
  );
}
