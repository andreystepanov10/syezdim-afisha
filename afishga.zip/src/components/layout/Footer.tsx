import Link from "next/link";
import { Bot, Send } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { VkIcon } from "@/components/ui/BrandIcons";
import { catalogPath } from "@/data/catalog-url";
import { CITIES } from "@/lib/cities";
import { Emblem } from "./Logo";
import { MAIN_NAV } from "./nav";
import { socialLinks } from "@/lib/social";

const linkClass =
  "focus-ring inline-flex min-h-8 items-center rounded-xs text-[15px] text-cream/85 underline-offset-4 transition-colors hover:text-white hover:underline";


/**
 * Подвал. На досках дизайна два варианта, здесь гибрид:
 * бежевая полоса (design/3.jpg) + тёмный блок с эмблемой и колонками (design/1.jpg, 2.jpg).
 * Раньше полоса была формой подписки на email-рассылку — сознательно заменили на соцсети:
 * не хотим собирать email вообще, см. память проекта.
 */
export function Footer() {
  const links = socialLinks();
  const socials = [
    ...(links.vk ? [{ href: links.vk, label: "Радиус во ВКонтакте", icon: <VkIcon className="size-5" /> }] : []),
    ...(links.telegram ? [{ href: links.telegram.href, label: `Радиус: ${links.telegram.label}`, icon: <Send className="size-[18px]" aria-hidden /> }] : []),
    ...(links.bot ? [{ href: links.bot, label: "Радиус: Telegram-бот", icon: <Bot className="size-5" aria-hidden /> }] : []),
  ];
  return (
    <footer className="mt-16 pb-16 md:pb-0">
      <section aria-labelledby="newsletter-title" className="bg-beige">
        <div className="container-page flex flex-col gap-6 py-10 md:flex-row md:items-center md:justify-between md:py-12">
          <div>
            <h2 id="newsletter-title" className="type-h3">
              Следите за афишей
            </h2>
            <p className="mt-1 text-muted">Лучшие события Черноземья — в наших соцсетях, без регистрации и без спама.</p>
            {links.telegram?.note && <p className="mt-1 text-sm text-muted">{links.telegram.note}</p>}
          </div>
          <div className="flex flex-wrap gap-3">
            {links.vk && (
              <Button href={links.vk} external variant="secondary" iconLeft={<VkIcon className="size-5" />}>
                ВКонтакте
              </Button>
            )}
            {links.telegram && (
              <Button href={links.telegram.href} external iconLeft={<Send className="size-4" aria-hidden />}>
                {links.telegram.label}
              </Button>
            )}
            {links.bot && (
              <Button href={links.bot} external variant="secondary" iconLeft={<Bot className="size-4" aria-hidden />}>
                Telegram-бот
              </Button>
            )}
          </div>
        </div>
      </section>

      <div className="bg-choco text-cream">
        <div className="container-page grid gap-10 py-12 md:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div className="flex flex-col items-start gap-4">
            <Emblem size={72} />
            <p className="max-w-[16rem] text-[15px] text-cream/85">
              Радиус «Съездим» — афиша Черноземья. Находите события и выбирайтесь из дома.
            </p>
          </div>

          <nav aria-labelledby="footer-nav" className="space-y-2">
            <h2 id="footer-nav" className="type-caption text-mustard">
              Навигация
            </h2>
            <ul>
              {MAIN_NAV.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className={linkClass}>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-labelledby="footer-cities" className="space-y-2">
            <h2 id="footer-cities" className="type-caption text-mustard">
              Города
            </h2>
            <ul>
              {CITIES.map((c) => (
                <li key={c.slug}>
                  <Link href={catalogPath(c.slug)} className={linkClass}>
                    {c.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {socials.length > 0 && (
            <div className="space-y-4">
              <h2 className="type-caption text-mustard">Мы в соцсетях</h2>
              <ul className="flex gap-3">
                {socials.map((s) => (
                  <li key={s.label}>
                    <a
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={s.label}
                      className="focus-ring inline-flex size-11 items-center justify-center rounded-full bg-cream/12 text-cream transition duration-200 hover:bg-mustard hover:text-ink"
                    >
                      {s.icon}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="border-t border-cream/15">
          <div className="container-page flex flex-col gap-2 py-5 text-sm text-cream/75 md:flex-row md:items-center md:justify-between">
            <p>© {new Date().getFullYear()} Радиус «Съездим». Все права защищены.</p>
            <ul className="flex flex-wrap gap-x-5">
              <li>
                <Link href="/o-proekte" className={linkClass}>
                  О проекте
                </Link>
              </li>
              <li>
                <Link href="/organizatoram" className={linkClass}>
                  Организаторам
                </Link>
              </li>
              <li>
                <Link href="/privacy" className={linkClass}>
                  Политика конфиденциальности
                </Link>
              </li>
              <li>
                <Link href="/terms" className={linkClass}>
                  Пользовательское соглашение
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
