import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { Breadcrumbs } from "@/components/ui/Navigation";

/** Временная страница раздела, который соберём на одном из следующих этапов */
export function ComingSoon({ title, stage }: { title: string; stage: number }) {
  return (
    <div className="container-page py-8 md:py-12">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: title }]} className="mb-6" />
      <h1 className="type-h2 mb-8">{title}</h1>
      <EmptyState
        title="Раздел скоро появится"
        description={`Эта страница будет собрана на этапе ${stage}. Сейчас готов фундамент: дизайн-система и каркас сайта.`}
        action={
          <div className="flex flex-wrap justify-center gap-3">
            <Button href="/">На главную</Button>
            <Button href="/ui-kit" variant="secondary">
              Посмотреть UI-kit
            </Button>
          </div>
        }
      />
    </div>
  );
}
