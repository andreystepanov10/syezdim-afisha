"use client";

import { usePathname, useRouter } from "next/navigation";
import { ChevronDown } from "lucide-react";
import { catalogPath } from "@/data/catalog-url";
import { CITIES, isCitySlug } from "@/lib/cities";
import { setCity, useCity } from "@/lib/city-store";
import { cn } from "@/lib/cn";

/**
 * Выбор города в шапке. Нативный select — на телефоне открывается системный список.
 * Если открыт каталог города (/voronezh/events), он переключается на выбранный город вместе с остальными фильтрами.
 */
export function CitySelect({ className }: { className?: string }) {
  const city = useCity();
  const pathname = usePathname();
  const router = useRouter();

  const onChange = (slug: string) => {
    if (!isCitySlug(slug)) return;
    setCity(slug);
    const current = /^\/([a-z]+)\/events$/.exec(pathname)?.[1];
    if (current && isCitySlug(current) && current !== slug) {
      const params = new URLSearchParams(window.location.search);
      params.delete("page"); // в другом городе страниц может быть меньше
      router.push(params.size ? `${catalogPath(slug)}?${params}` : catalogPath(slug));
    }
  };

  return (
    <label className={cn("relative inline-flex min-h-11 items-center", className)}>
      <span className="sr-only">Город</span>
      <select
        value={city}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring cursor-pointer appearance-none rounded-xs bg-transparent py-2 pr-6 text-[15px] font-semibold text-ink"
      >
        {CITIES.map((c) => (
          <option key={c.slug} value={c.slug}>
            {c.name}
          </option>
        ))}
      </select>
      <ChevronDown className="pointer-events-none absolute right-0 size-4 text-ink" aria-hidden />
    </label>
  );
}
