"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import { useCity } from "@/lib/city-store";
import { MAIN_NAV, isActive, navHref } from "./nav";

export function NavLinks() {
  const pathname = usePathname();
  const city = useCity();
  return (
    <ul className="flex items-center gap-4 lg:gap-8">
      {MAIN_NAV.map((item) => {
        const active = isActive(pathname, item.href);
        return (
          <li key={item.href}>
            <Link
              href={navHref(item.href, city)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "focus-ring relative inline-flex min-h-11 items-center rounded-xs text-[15px] font-medium text-ink transition-colors duration-200 hover:text-brick",
                active && "text-brick",
              )}
            >
              {item.label}
              <span
                aria-hidden
                className={cn(
                  "absolute inset-x-0 bottom-1.5 h-0.5 rounded-full bg-brick transition-transform duration-200",
                  active ? "scale-x-100" : "scale-x-0",
                )}
              />
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
