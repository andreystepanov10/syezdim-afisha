import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // PGlite (Postgres в WebAssembly) подгружает свои .wasm/.data рядом с пакетом — бандлить его нельзя
  serverExternalPackages: ["@electric-sql/pglite"],
  // Открывает сайт с телефона в локальной сети в dev-режиме (иначе Next блокирует HMR с чужого origin)
  allowedDevOrigins: ["192.168.1.104"],
};

export default nextConfig;
